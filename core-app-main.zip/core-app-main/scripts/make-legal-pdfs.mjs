// Erzeugt die drei Rechtstexte als PDF (docs/legal/*.pdf) aus den HTML-Quellen.
// Aufruf: node scripts/make-legal-pdfs.mjs
import { chromium } from 'playwright';
import { pathToFileURL, fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const JOBS = [
  {
    src: 'datenschutz.html',
    out: 'docs/legal/datenschutzerklaerung-v2.1.pdf',
    // Screen-Media: dunkles CORE-Design wie im Web
    media: 'screen',
    pdf: { format: 'A4', printBackground: true, margin: { top: 0, bottom: 0, left: 0, right: 0 } },
  },
  {
    src: 'docs/legal/pilotvertrag-apex-ventures.html',
    out: 'docs/legal/pilotvertrag-apex-ventures.pdf',
    media: 'print',
    pdf: { format: 'A4', printBackground: true, margin: { top: '20mm', bottom: '20mm', left: '18mm', right: '18mm' } },
  },
  {
    src: 'docs/legal/avv-apex-ventures.html',
    out: 'docs/legal/avv-apex-ventures.pdf',
    media: 'print',
    pdf: { format: 'A4', printBackground: true, margin: { top: '20mm', bottom: '20mm', left: '18mm', right: '18mm' } },
  },
];

const browser = await chromium.launch();
const page = await browser.newPage();
for (const job of JOBS) {
  await page.emulateMedia({ media: job.media });
  await page.goto(pathToFileURL(path.join(root, job.src)).href, { waitUntil: 'networkidle' });
  await page.pdf({ path: path.join(root, job.out), ...job.pdf });
  console.log('OK:', job.out);
}
await browser.close();
