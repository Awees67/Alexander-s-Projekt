// Füllt das Submit-Formular 10x mit realistischen, unterschiedlichen Firmen aus.
// Läuft gegen die Live-URL: https://core-app-gamma.vercel.app/submit?fund=apex
// Aufruf: node scripts/fill-form.mjs

import { chromium } from '@playwright/test';

const URL = 'https://core-app-gamma.vercel.app/submit?fund=apex';

const companies = [
  {
    company_name: 'Routiq',
    contact_name: 'Jonas Weber',
    contact_email: 'jonas.weber@routiq.ai',
    pitch_deck_url: 'https://pitch.com/v/routiq-deck-2024',
    description: 'Routiq optimiert Lieferketten für Logistikdienstleister mit KI-basierter Tourenplanung. Die Plattform reduziert Fahrtkilometer um durchschnittlich 22 % und senkt CO₂-Emissionen messbar — in Echtzeit, ohne Systemwechsel.',
    problem_solution: 'Klassische Dispositionssoftware liefert statische Routenpläne. Routiq reagiert dynamisch auf Verkehr, Kapazitäten und Zeitfenster.',
    traction_note: '89 zahlende Kunden, 4 Tier-1-Logistiker. ARR-Wachstum 12 % MoM, NRR 121 %. Pilot bei DHL Freight in Q3.',
    origin_country: 'DE',
    stage: 'Series A',
    sector: 'AI',
    sub_sector: 'Applied AI / Vertical AI',
    team_size: 28,
      founded_year: 2022,
    market_served: ['Germany', 'DACH', 'EU'],
    mrr_eur: 210000,
    growth_pct: 12,
    burn_eur_per_month: 280000,
    runway_months: 18,
    paying_customers: 89,
    net_new_mrr_eur: 210000,
    nrr_pct: 121,
    gross_margin_pct: 76,
    cac_eur: 8200,
    logo_churn_pct: 0.8,
    revenue_churn_pct: 1.1,
    tam_eur: 8000000000,
    sam_eur: 600000000,
    ticket_eur: 5000000,
    valuation_eur: 28000000,
    total_raised_eur: 3500000,
    investor_count: 2,
    founder_pct: 58,
    investor_pct: 35,
    employees_pct: 7,
    team_note: 'Jonas und Lena kennen sich seit dem CS-Studium an der TU Berlin. Gemeinsam 3 Jahre bei HERE Technologies.',
    founders: [
      { name: 'Jonas Weber', role: 'CEO', linkedin: 'https://linkedin.com/in/jonasweber', prev_companies: 'HERE Technologies, McKinsey', prev_roles: 'Product Lead, Strategy Consultant', years: 10, education: 'TU Berlin, CS', strengths: ['Repeat Founder', 'GTM / Sales'] },
      { name: 'Lena Fischer', role: 'CTO', linkedin: 'https://linkedin.com/in/lenafischer', prev_companies: 'HERE Technologies, Palantir', prev_roles: 'Senior Engineer, ML Engineer', years: 9, education: 'TU Berlin, Informatik', strengths: ['Technical', 'Domain Expert'] },
    ],
  },
  {
    company_name: 'Klinikit GmbH',
    contact_name: 'Dr. Stefan Mayer',
    contact_email: 'stefan.mayer@klinikit.de',
    pitch_deck_url: 'https://docsend.com/view/klinikit-pitch-2024',
    description: 'Klinikit digitalisiert klinische Workflows in Krankenhäusern ab 200 Betten — von der Patientenaufnahme über OP-Planung bis zur Entlassdokumentation. Native KIS-Integration, DSGVO-konform, ISO 27001 zertifiziert.',
    problem_solution: 'Krankenhäuser verlieren 30–40 % der Pflegezeit durch papierbasierte Prozesse und isolierte Systeme. Klinikit schließt die Lücke.',
    traction_note: '18 Kliniken live, 6 in Onboarding. Durchschnittlicher Vertragswert 48.000 € p.a. NPS 74.',
    origin_country: 'AT',
    stage: 'Seed',
    sector: 'HealthTech',
    sub_sector: 'Clinical Workflow',
    team_size: 19,
      founded_year: 2023,
    market_served: ['Germany', 'Austria', 'DACH'],
    mrr_eur: 68000,
    growth_pct: 14,
    burn_eur_per_month: 95000,
    runway_months: 16,
    paying_customers: 18,
    net_new_mrr_eur: 68000,
    nrr_pct: 108,
    gross_margin_pct: 71,
    cac_eur: 6500,
    logo_churn_pct: 1.2,
    revenue_churn_pct: 2.2,
    tam_eur: 3200000000,
    sam_eur: 280000000,
    ticket_eur: 2500000,
    valuation_eur: 12000000,
    total_raised_eur: 1200000,
    investor_count: 1,
    founder_pct: 64,
    investor_pct: 31,
    employees_pct: 5,
    team_note: 'Stefan hat 8 Jahre als Chirurg gearbeitet bevor er in die Gründerszene gewechselt ist. Michael hat Systeme für 3 Krankenhausketten gebaut.',
    founders: [
      { name: 'Dr. Stefan Mayer', role: 'CEO', linkedin: 'https://linkedin.com/in/stefanmayer', prev_companies: 'AKH Wien, MedUni Wien', prev_roles: 'Facharzt, klinischer Leiter', years: 12, education: 'Medizinische Universität Wien', strengths: ['Domain Expert', 'GTM / Sales'] },
      { name: 'Michael Gruber', role: 'CTO', linkedin: 'https://linkedin.com/in/michaelgruber', prev_companies: 'SAP Health, Siemens Healthineers', prev_roles: 'Solution Architect, Engineering Lead', years: 11, education: 'JKU Linz, Wirtschaftsinformatik', strengths: ['Technical', 'Operator'] },
    ],
  },
  {
    company_name: 'Dataflux',
    contact_name: 'Nina Schreiber',
    contact_email: 'nina@dataflux.io',
    pitch_deck_url: 'https://pitch.com/v/dataflux-investor-deck',
    description: 'Dataflux ist eine Data-Observability-Plattform für Dateningenieure. Sie erkennt Data-Drift, Schema-Änderungen und Pipeline-Ausfälle automatisch — und gibt Teams kontextuelle Alerts bevor fehlerhafte Daten Produktionssysteme erreichen.',
    problem_solution: 'Fehlerhafte Daten kosten Unternehmen Stunden an manueller Debugzeit. Dataflux macht Datenqualität messbar und automatisiert das Monitoring.',
    traction_note: '34 zahlende Kunden, 8 davon Enterprise. MoM-Wachstum 28 %. Zwei Design-Partner: Commerzbank und Otto Group.',
    origin_country: 'DE',
    stage: 'Pre-Seed',
    sector: 'DevTools',
    sub_sector: 'Observability / Monitoring',
    team_size: 7,
      founded_year: 2024,
    market_served: ['Germany', 'EU', 'US'],
    mrr_eur: 18000,
    growth_pct: 28,
    burn_eur_per_month: 45000,
    runway_months: 20,
    paying_customers: 34,
    net_new_mrr_eur: 18000,
    nrr_pct: 125,
    gross_margin_pct: 83,
    cac_eur: 2800,
    logo_churn_pct: 1.5,
    revenue_churn_pct: 1.5,
    tam_eur: 2400000000,
    sam_eur: 180000000,
    ticket_eur: 800000,
    valuation_eur: 4000000,
    total_raised_eur: 0,
    investor_count: 0,
    founder_pct: 80,
    investor_pct: 20,
    employees_pct: 0,
    team_note: 'Nina und Tobias haben Monzo\'s Data Platform aufgebaut. Sie kennen das Problem aus eigener Erfahrung.',
    founders: [
      { name: 'Nina Schreiber', role: 'CEO', linkedin: 'https://linkedin.com/in/ninaschreiber', prev_companies: 'Monzo, Zalando', prev_roles: 'Staff Data Engineer, Engineering Manager', years: 9, education: 'HPI Potsdam, Software Engineering', strengths: ['Technical', 'Domain Expert', 'GTM / Sales'] },
      { name: 'Tobias Klein', role: 'CTO', linkedin: 'https://linkedin.com/in/tobiasklein', prev_companies: 'Monzo, Google', prev_roles: 'Senior SWE, Data Infrastructure', years: 8, education: 'KIT Karlsruhe, Informatik', strengths: ['Technical'] },
    ],
  },
  {
    company_name: 'Pensivo AG',
    contact_name: 'Claudia Huber',
    contact_email: 'claudia.huber@pensivo.ch',
    pitch_deck_url: 'https://docsend.com/view/pensivo-deck-sga',
    description: 'Pensivo ist eine B2B-Plattform für betriebliche Altersvorsorge (bAV). HR-Teams konfigurieren, verwalten und kommunizieren bAV-Pakete digital — BAFIN-konform, vollständig integriert in bestehende HR-Systeme wie Workday und SAP SuccessFactors.',
    problem_solution: 'bAV ist komplex, teuer in der Administration und für Mitarbeiter kaum verständlich. Pensivo macht bAV einfach und effizient.',
    traction_note: '41 Unternehmenskunden, davon 5 mit über 500 MA. Durchschnittlicher Vertrag 12.000 € p.a. Churn seit Launch: 0.',
    origin_country: 'CH',
    stage: 'Seed',
    sector: 'FinTech',
    sub_sector: 'WealthTech',
    team_size: 13,
      founded_year: 2024,
    market_served: ['Germany', 'Switzerland', 'DACH'],
    mrr_eur: 42000,
    growth_pct: 11,
    burn_eur_per_month: 78000,
    runway_months: 14,
    paying_customers: 41,
    net_new_mrr_eur: 42000,
    nrr_pct: 104,
    gross_margin_pct: 68,
    cac_eur: 5200,
    logo_churn_pct: 0,
    revenue_churn_pct: 2.8,
    tam_eur: 1800000000,
    sam_eur: 140000000,
    ticket_eur: 1800000,
    valuation_eur: 9000000,
    total_raised_eur: 800000,
    investor_count: 1,
    founder_pct: 68,
    investor_pct: 28,
    employees_pct: 4,
    team_note: 'Claudia war 6 Jahre Beraterin bei Mercer für bAV. Felix hat das Compliance-System für eine Schweizer Pensionskasse gebaut.',
    founders: [
      { name: 'Claudia Huber', role: 'CEO', linkedin: 'https://linkedin.com/in/claudiahuber', prev_companies: 'Mercer, Swiss Life', prev_roles: 'Senior Consultant, Product Manager', years: 10, education: 'Universität St. Gallen, BWL', strengths: ['Domain Expert', 'GTM / Sales'] },
      { name: 'Felix Braun', role: 'CTO', linkedin: 'https://linkedin.com/in/felixbraun', prev_companies: 'Swisscom, PK Rück', prev_roles: 'Software Architect, CTO', years: 12, education: 'ETH Zürich, Informatik', strengths: ['Technical', 'Repeat Founder'] },
    ],
  },
  {
    company_name: 'Reclaim Technologies',
    contact_name: 'Max Vogt',
    contact_email: 'max@reclaim.earth',
    pitch_deck_url: 'https://pitch.com/v/reclaim-earth-deck',
    description: 'Reclaim ist ein B2B-Marktplatz für gewerblichen E-Schrott. Unternehmen melden gebrauchte Elektronik an, Reclaim koordiniert zertifizierte Recycler, übernimmt die Logistik und stellt DSGVO-konforme Datenlöschzertifikate aus.',
    problem_solution: 'Unternehmen haben keinen effizienten Weg, gebrauchte IT-Hardware legal, nachhaltig und dokumentiert zu entsorgen. Reclaim schließt diese Lücke.',
    traction_note: '28 Unternehmenskunden, darunter Bosch und REWE. GMV Q4: €840.000. Wachstum 32 % MoM. Erste Zertifikate-Nachfrage von Wirtschaftsprüfern.',
    origin_country: 'DE',
    stage: 'Pre-Seed',
    sector: 'ClimateTech',
    sub_sector: 'Circular Economy',
    team_size: 5,
      founded_year: 2024,
    market_served: ['Germany', 'Austria'],
    mrr_eur: 8500,
    growth_pct: 32,
    burn_eur_per_month: 22000,
    runway_months: 24,
    paying_customers: 28,
    net_new_mrr_eur: 8500,
    nrr_pct: 118,
    gross_margin_pct: 55,
    cac_eur: 1200,
    logo_churn_pct: 0,
    revenue_churn_pct: 0,
    tam_eur: 900000000,
    sam_eur: 70000000,
    ticket_eur: 600000,
    valuation_eur: 3000000,
    total_raised_eur: 0,
    investor_count: 0,
    founder_pct: 85,
    investor_pct: 15,
    employees_pct: 0,
    team_note: 'Max hat 4 Jahre als Nachhaltigkeitsmanager bei einem DAX-Konzern gearbeitet. Sara hat Logistics-Plattformen bei Schenker skaliert.',
    founders: [
      { name: 'Max Vogt', role: 'CEO', linkedin: 'https://linkedin.com/in/maxvogt', prev_companies: 'Siemens, DB Schenker', prev_roles: 'Sustainability Manager, Logistics PM', years: 7, education: 'TU München, Umweltingenieurwesen', strengths: ['Domain Expert', 'GTM / Sales'] },
      { name: 'Sara Engel', role: 'COO', linkedin: 'https://linkedin.com/in/saraengel', prev_companies: 'DB Schenker, DHL', prev_roles: 'Operations Lead, Product Manager', years: 8, education: 'WHU Vallendar, BWL', strengths: ['Operator', 'Domain Expert'] },
    ],
  },
  {
    company_name: 'Solvora GmbH',
    contact_name: 'Philipp Hartmann',
    contact_email: 'philipp@solvora.de',
    pitch_deck_url: 'https://docsend.com/view/solvora-legaltech-deck',
    description: 'Solvora automatisiert die Erstellung, Prüfung und Verwaltung juristischer Dokumente für Kanzleien und Rechtsabteilungen. GPT-basierter Drafting-Assistent mit Versionierung, Freigabe-Workflow und Mandantenportal — DSGVO-konform, on-premise deploybar.',
    problem_solution: 'Anwälte verbringen bis zu 40 % ihrer Zeit mit Dokumentenroutine. Solvora eliminiert Standardarbeiten und gibt Kapazität für hochwertige Mandate frei.',
    traction_note: '22 Kanzleikunden, 8 Unternehmensrechtsabteilungen. Durchschnittlicher ACV: 28.000 €. NRR 112 %, kein Logo-Churn.',
    origin_country: 'DE',
    stage: 'Seed',
    sector: 'B2B SaaS',
    sub_sector: 'Vertical SaaS',
    team_size: 11,
      founded_year: 2024,
    market_served: ['Germany', 'Austria', 'Switzerland', 'DACH'],
    mrr_eur: 55000,
    growth_pct: 16,
    burn_eur_per_month: 85000,
    runway_months: 17,
    paying_customers: 30,
    net_new_mrr_eur: 55000,
    nrr_pct: 112,
    gross_margin_pct: 79,
    cac_eur: 4100,
    logo_churn_pct: 0,
    revenue_churn_pct: 1.8,
    tam_eur: 2100000000,
    sam_eur: 160000000,
    ticket_eur: 2000000,
    valuation_eur: 10000000,
    total_raised_eur: 500000,
    investor_count: 1,
    founder_pct: 70,
    investor_pct: 27,
    employees_pct: 3,
    team_note: 'Philipp hat als Wirtschaftsanwalt bei Linklaters gearbeitet. Anna hat LegalTech-Tools bei Wolters Kluwer entwickelt.',
    founders: [
      { name: 'Philipp Hartmann', role: 'CEO', linkedin: 'https://linkedin.com/in/philipphartmann', prev_companies: 'Linklaters, Freshfields', prev_roles: 'Associate, Senior Associate', years: 8, education: 'Humboldt-Universität Berlin, Jura', strengths: ['Domain Expert', 'GTM / Sales'] },
      { name: 'Anna Müller', role: 'CTO', linkedin: 'https://linkedin.com/in/annamueller', prev_companies: 'Wolters Kluwer, ThoughtWorks', prev_roles: 'Product Engineer, Tech Lead', years: 9, education: 'FU Berlin, Informatik', strengths: ['Technical', 'Domain Expert'] },
    ],
  },
  {
    company_name: 'Hiveport AG',
    contact_name: 'David Keller',
    contact_email: 'david.keller@hiveport.com',
    pitch_deck_url: 'https://pitch.com/v/hiveport-series-a-deck',
    description: 'Hiveport ist ein B2B-Beschaffungsmarktplatz für den Mittelstand. Einkäufer finden geprüfte Lieferanten, verhandeln digital und schließen Rahmenverträge ab — in einer Plattform, ohne RFP-Excel und manuelle Angebotsrunden.',
    problem_solution: 'Mittelständische Einkaufsabteilungen managen Hunderte Lieferanten über E-Mail und Tabellen. Hiveport bringt Transparenz, Effizienz und Vergleichbarkeit.',
    traction_note: '118 Einkäuferorganisationen, 640 verifizierte Lieferanten. GMV Q4: €3,2M. MoM-Wachstum 9 %. Net Promoter Score: 68.',
    origin_country: 'CH',
    stage: 'Pre-Series A',
    sector: 'Marketplace',
    sub_sector: 'B2B Marketplace',
    team_size: 24,
      founded_year: 2022,
    market_served: ['Germany', 'Switzerland', 'EU'],
    mrr_eur: 125000,
    growth_pct: 9,
    burn_eur_per_month: 210000,
    runway_months: 15,
    paying_customers: 118,
    net_new_mrr_eur: 125000,
    nrr_pct: 118,
    gross_margin_pct: 62,
    cac_eur: 11000,
    logo_churn_pct: 1.5,
    revenue_churn_pct: 1.4,
    tam_eur: 12000000000,
    sam_eur: 900000000,
    ticket_eur: 4000000,
    valuation_eur: 20000000,
    total_raised_eur: 2800000,
    investor_count: 2,
    founder_pct: 54,
    investor_pct: 36,
    employees_pct: 10,
    team_note: 'David und Marco haben gemeinsam Mercateo mitgebaut. Dritte Gründerin Yuki kommt aus dem Procurement-Consulting.',
    founders: [
      { name: 'David Keller', role: 'CEO', linkedin: 'https://linkedin.com/in/davidkeller', prev_companies: 'Mercateo, Oliver Wyman', prev_roles: 'VP Product, Strategy Consultant', years: 13, education: 'Universität Zürich, BWL', strengths: ['Repeat Founder', 'GTM / Sales', 'Operator'] },
      { name: 'Marco Roth', role: 'CTO', linkedin: 'https://linkedin.com/in/marcoroth', prev_companies: 'Mercateo, Zalando', prev_roles: 'Engineering Lead, Principal Engineer', years: 11, education: 'ETH Zürich, Informatik', strengths: ['Technical', 'Repeat Founder'] },
    ],
  },
  {
    company_name: 'Nukleos GmbH',
    contact_name: 'Prof. Dr. Thomas Richter',
    contact_email: 'thomas.richter@nukleos.de',
    pitch_deck_url: 'https://docsend.com/view/nukleos-cobot-deck-2024',
    description: 'Nukleos entwickelt kollaborative Industrieroboter (Cobots) für die Montage in der Kleinserienfertigung. Im Gegensatz zu klassischer Robotik ist kein Programmieraufwand nötig — Werker zeigen Bewegungsabläufe vor, der Cobot lernt via Imitation Learning.',
    problem_solution: 'Industrieroboter sind teuer, starr und erfordern spezialisierte Integratoren. Nukleos macht Robotik für Betriebe mit kleinen Losgrößen wirtschaftlich.',
    traction_note: '3 Piloten bei Tier-2-Automobilzulieferern. Letter of Intent über 4 Einheiten im Wert von €1,2M. Technologie TRL 7, CE-Zertifizierung Q2.',
    origin_country: 'DE',
    stage: 'Pre-Seed',
    sector: 'DeepTech',
    sub_sector: 'Robotics / Automation',
    team_size: 8,
      founded_year: 2024,
    market_served: ['Germany', 'EU'],
    mrr_eur: 12000,
    growth_pct: 0,
    burn_eur_per_month: 180000,
    runway_months: 22,
    paying_customers: 3,
    net_new_mrr_eur: 12000,
    nrr_pct: 100,
    gross_margin_pct: 42,
    cac_eur: 0,
    logo_churn_pct: 0,
    revenue_churn_pct: 0,
    tam_eur: 25000000000,
    sam_eur: 1200000000,
    ticket_eur: 1500000,
    valuation_eur: 8000000,
    total_raised_eur: 0,
    investor_count: 0,
    founder_pct: 78,
    investor_pct: 22,
    employees_pct: 0,
    team_note: 'Thomas ist Lehrstuhlinhaber für Robotik am KIT. Martin hat bei Kuka und ABB Roboterzellen entwickelt.',
    founders: [
      { name: 'Prof. Dr. Thomas Richter', role: 'CEO', linkedin: 'https://linkedin.com/in/thomasrichter', prev_companies: 'KIT, DLR', prev_roles: 'Professor, Research Lead', years: 20, education: 'TU München, Maschinenbau / Robotik', strengths: ['Domain Expert', 'Technical'] },
      { name: 'Martin Lange', role: 'CTO', linkedin: 'https://linkedin.com/in/martinlange', prev_companies: 'Kuka, ABB', prev_roles: 'Robotics Engineer, Product Lead', years: 14, education: 'RWTH Aachen, Mechatronik', strengths: ['Technical', 'Operator'] },
    ],
  },
  {
    company_name: 'GridCore',
    contact_name: 'Elena Weiß',
    contact_email: 'elena.weiss@gridcore.at',
    pitch_deck_url: 'https://pitch.com/v/gridcore-iot-energy-deck',
    description: 'GridCore ist eine IoT-Plattform für Energiemanagement in Gewerbeimmobilien. Sensornetzwerk + KI-Steuerung optimiert Heizung, Kühlung und Beleuchtung in Echtzeit — durchschnittlich 28 % Energieeinsparung ohne Bausanierung.',
    problem_solution: 'Gewerbliche Gebäude sind für 40 % des Energieverbrauchs verantwortlich. Gebäudebetreiber haben keine Sichtbarkeit über Ineffizienzen und verlieren tausende Euro monatlich.',
    traction_note: '31 Gewerbegebäude live, 6 Wohnbaugesellschaften als Pilotpartner. Durchschnittliche Energieeinsparung: 28 %. ROI für Kunden in <18 Monate.',
    origin_country: 'AT',
    stage: 'Seed',
    sector: 'PropTech',
    sub_sector: 'Smart Building / IoT',
    team_size: 16,
      founded_year: 2023,
    market_served: ['Germany', 'Austria', 'Switzerland'],
    mrr_eur: 47000,
    growth_pct: 13,
    burn_eur_per_month: 72000,
    runway_months: 13,
    paying_customers: 31,
    net_new_mrr_eur: 47000,
    nrr_pct: 109,
    gross_margin_pct: 58,
    cac_eur: 5800,
    logo_churn_pct: 2,
    revenue_churn_pct: 2.1,
    tam_eur: 4500000000,
    sam_eur: 350000000,
    ticket_eur: 2200000,
    valuation_eur: 11000000,
    total_raised_eur: 900000,
    investor_count: 1,
    founder_pct: 62,
    investor_pct: 32,
    employees_pct: 6,
    team_note: 'Elena war Energieberaterin bei Siemens Building Technologies. Kurt hat IoT-Hardware bei Legrand entwickelt.',
    founders: [
      { name: 'Elena Weiß', role: 'CEO', linkedin: 'https://linkedin.com/in/elenaweiss', prev_companies: 'Siemens Building Technologies, Verbund', prev_roles: 'Energy Consultant, Product Manager', years: 11, education: 'TU Wien, Energietechnik', strengths: ['Domain Expert', 'GTM / Sales'] },
      { name: 'Kurt Sommer', role: 'CTO', linkedin: 'https://linkedin.com/in/kurtsommer', prev_companies: 'Legrand, Bosch', prev_roles: 'Hardware Engineer, IoT Architect', years: 10, education: 'FH Technikum Wien, Elektronik', strengths: ['Technical', 'Operator'] },
    ],
  },
  {
    company_name: 'Cogniflow',
    contact_name: 'Sarah Zimmermann',
    contact_email: 'sarah@cogniflow.ai',
    pitch_deck_url: 'https://docsend.com/view/cogniflow-ai-deck-2024',
    description: 'Cogniflow automatisiert Tier-1-Kundenservice für E-Commerce und SaaS-Unternehmen mit KI-Agenten — Rückgaben, Tracking-Anfragen, Kontoänderungen, Stornierungen. 92 % Erstlösungsrate, Übergabe an menschliche Agenten bei Bedarf.',
    problem_solution: 'Support-Teams werden mit Volumen überhäuft. 60 % der Anfragen sind repetitiv lösbar. Cogniflow übernimmt diese Schicht vollständig und lernt kontinuierlich dazu.',
    traction_note: '67 zahlende Kunden, 12 Enterprise. Durchschnittlicher ACV: 18.500 €. NRR 124 %. Expansion-Revenue macht 38 % des MRR aus.',
    origin_country: 'DE',
    stage: 'Seed',
    sector: 'AI',
    sub_sector: 'Applied AI / Vertical AI',
    team_size: 18,
      founded_year: 2023,
    market_served: ['Germany', 'EU', 'US', 'Global'],
    mrr_eur: 92000,
    growth_pct: 22,
    burn_eur_per_month: 140000,
    runway_months: 19,
    paying_customers: 67,
    net_new_mrr_eur: 92000,
    nrr_pct: 124,
    gross_margin_pct: 82,
    cac_eur: 4800,
    logo_churn_pct: 0.9,
    revenue_churn_pct: 1.2,
    tam_eur: 15000000000,
    sam_eur: 1100000000,
    ticket_eur: 3000000,
    valuation_eur: 16000000,
    total_raised_eur: 1500000,
    investor_count: 1,
    founder_pct: 60,
    investor_pct: 35,
    employees_pct: 5,
    team_note: 'Sarah und Chris haben Intercom\'s AI-Routing aufgebaut. Dritter Founder Yusuf kommt aus dem Conversational AI Research bei Google.',
    founders: [
      { name: 'Sarah Zimmermann', role: 'CEO', linkedin: 'https://linkedin.com/in/sarahzimmermann', prev_companies: 'Intercom, Zendesk', prev_roles: 'Senior PM, Product Lead', years: 9, education: 'LMU München, Informatik', strengths: ['GTM / Sales', 'Domain Expert', 'Repeat Founder'] },
      { name: 'Chris Park', role: 'CTO', linkedin: 'https://linkedin.com/in/chrispark', prev_companies: 'Intercom, Google', prev_roles: 'Staff Engineer, Research SWE', years: 10, education: 'Universität Hamburg, Informatik', strengths: ['Technical', 'Domain Expert'] },
    ],
  },
  {
    company_name: 'Vaultix Security',
    contact_name: 'Markus Bauer',
    contact_email: 'markus.bauer@vaultix.io',
    pitch_deck_url: 'https://docsend.com/view/vaultix-security-deck',
    description: 'Vaultix ist eine Cloud-native Identity & Access Management Plattform für mittelständische Unternehmen. Wir ermöglichen Zero-Trust-Architekturen ohne die Komplexität und Kosten von Enterprise-Lösungen wie Okta — vollständig DSGVO-konform und in 48 Stunden deploybar.',
    problem_solution: 'KMUs sind häufigste Cyberangriffsziele, haben aber weder Budget noch Personal für Enterprise-IAM. Vaultix schließt diese Sicherheitslücke mit einer einfachen, bezahlbaren Plattform.',
    traction_note: '53 Unternehmenskunden, Ø ACV 9.600 €. SOC 2 Type II zertifiziert. Partner mit 12 Managed Service Providern. Churn Q4: 0.',
    origin_country: 'DE',
    stage: 'Seed',
    sector: 'Cybersecurity',
    sub_sector: 'Identity & Access',
    team_size: 14,
      founded_year: 2024,
    market_served: ['Germany', 'Austria', 'Switzerland', 'DACH'],
    mrr_eur: 42500,
    growth_pct: 18,
    burn_eur_per_month: 68000,
    runway_months: 21,
    paying_customers: 53,
    net_new_mrr_eur: 42500,
    nrr_pct: 116,
    gross_margin_pct: 81,
    cac_eur: 3200,
    logo_churn_pct: 0,
    revenue_churn_pct: 1.0,
    tam_eur: 5500000000,
    sam_eur: 420000000,
    ticket_eur: 2000000,
    valuation_eur: 11000000,
    total_raised_eur: 750000,
    investor_count: 1,
    founder_pct: 66,
    investor_pct: 30,
    employees_pct: 4,
    team_note: 'Markus war CISO bei einem SDAX-Unternehmen. Julia hat IAM-Infrastruktur für 80.000 Nutzer bei einer Bundesbehörde gebaut.',
    founders: [
      { name: 'Markus Bauer', role: 'CEO', linkedin: 'https://linkedin.com/in/markusbauer', prev_companies: 'thyssenkrupp, BSI', prev_roles: 'CISO, Security Architect', years: 14, education: 'TU Darmstadt, IT-Sicherheit', strengths: ['Domain Expert', 'GTM / Sales', 'Operator'] },
      { name: 'Julia Schneider', role: 'CTO', linkedin: 'https://linkedin.com/in/juliaschneider', prev_companies: 'Bundesdruckerei, Capgemini', prev_roles: 'IAM Lead, Security Engineer', years: 11, education: 'HU Berlin, Informatik', strengths: ['Technical', 'Domain Expert'] },
    ],
  },
  {
    company_name: 'Payloop GmbH',
    contact_name: 'Arjun Sharma',
    contact_email: 'arjun@payloop.io',
    pitch_deck_url: 'https://pitch.com/v/payloop-embedded-finance',
    description: 'Payloop ist eine Embedded-Finance-API für B2B-Plattformen und Marktplätze. In weniger als einem Entwicklertag lassen sich Zahlungen, Auszahlungen an Anbieter und Finanzprodukte direkt in bestehende Plattformen integrieren — BaFin-lizenziert, PCI DSS compliant.',
    problem_solution: 'B2B-Marktplätze verlieren Transaktionsvolumen an externe Zahlungsanbieter. Payloop ermöglicht es ihnen, Financial Services nativ anzubieten und Monetarisierung zu maximieren.',
    traction_note: '19 Plattformkunden, kombiniertes TPV €8,4M/Monat. Wachstum 41 % MoM. Letter of Intent von 3 weiteren Marktplätzen mit €50M+ GMV.',
    origin_country: 'DE',
    stage: 'Pre-Seed',
    sector: 'FinTech',
    sub_sector: 'Embedded Finance',
    team_size: 9,
      founded_year: 2024,
    market_served: ['Germany', 'EU'],
    mrr_eur: 28000,
    growth_pct: 41,
    burn_eur_per_month: 58000,
    runway_months: 16,
    paying_customers: 19,
    net_new_mrr_eur: 28000,
    nrr_pct: 131,
    gross_margin_pct: 72,
    cac_eur: 7500,
    logo_churn_pct: 0,
    revenue_churn_pct: 0,
    tam_eur: 7000000000,
    sam_eur: 520000000,
    ticket_eur: 1200000,
    valuation_eur: 6000000,
    total_raised_eur: 0,
    investor_count: 0,
    founder_pct: 82,
    investor_pct: 18,
    employees_pct: 0,
    team_note: 'Arjun hat das Payments-Backend bei Stripe Europe gebaut. Nora war Regulatory Lead bei der BaFin — einmalige Kombination für Embedded Finance.',
    founders: [
      { name: 'Arjun Sharma', role: 'CEO', linkedin: 'https://linkedin.com/in/arjunsharma', prev_companies: 'Stripe, N26', prev_roles: 'Senior SWE, Payments Lead', years: 8, education: 'IIT Bombay, CS / LMU München MBA', strengths: ['Technical', 'Repeat Founder'] },
      { name: 'Nora Wagner', role: 'COO', linkedin: 'https://linkedin.com/in/norawagner', prev_companies: 'BaFin, Deutsche Bank', prev_roles: 'Regulatory Affairs, FinTech Advisor', years: 9, education: 'Goethe-Universität Frankfurt, Wirtschaftsrecht', strengths: ['Domain Expert', 'Operator'] },
    ],
  },
  {
    company_name: 'Formify',
    contact_name: 'Lena Koch',
    contact_email: 'lena@formify.dev',
    pitch_deck_url: 'https://pitch.com/v/formify-plg-deck-2024',
    description: 'Formify ist ein No-Code-Formular- und Workflow-Builder für Produktteams. Teams erstellen komplexe mehrstufige Formulare, Onboarding-Flows und interne Tools in Minuten — mit nativer Integration in Notion, Airtable, Slack und 80 weiteren Tools.',
    problem_solution: 'Produktteams basteln Formulare und interne Workflows mit Dutzenden fragmentierten Tools zusammen. Formify konsolidiert dies in einer einzigen, entwicklerfreundlichen Plattform mit PLG-Modell.',
    traction_note: '4.200 aktive Teams, davon 310 zahlend. Viraler K-Faktor 1.4. Monatliches Signup-Wachstum 35 %. Product Hunt #1 of the Day.',
    origin_country: 'DE',
    stage: 'Pre-Seed',
    sector: 'B2B SaaS',
    sub_sector: 'PLG / Self-Serve',
    team_size: 6,
      founded_year: 2024,
    market_served: ['Germany', 'EU', 'US', 'Global'],
    mrr_eur: 14500,
    growth_pct: 35,
    burn_eur_per_month: 32000,
    runway_months: 28,
    paying_customers: 310,
    net_new_mrr_eur: 14500,
    nrr_pct: 119,
    gross_margin_pct: 88,
    cac_eur: 480,
    logo_churn_pct: 2.1,
    revenue_churn_pct: 2.3,
    tam_eur: 3800000000,
    sam_eur: 290000000,
    ticket_eur: 700000,
    valuation_eur: 4500000,
    total_raised_eur: 0,
    investor_count: 0,
    founder_pct: 84,
    investor_pct: 16,
    employees_pct: 0,
    team_note: 'Lena und Ben haben Typeform\'s Core-Produkt mitgebaut. Ben hat zuvor 2 SaaS-Tools auf ProductHunt gelaunchet.',
    founders: [
      { name: 'Lena Koch', role: 'CEO', linkedin: 'https://linkedin.com/in/lenakoch', prev_companies: 'Typeform, Personio', prev_roles: 'Product Manager, Growth Lead', years: 7, education: 'Uni Mannheim, BWL', strengths: ['GTM / Sales', 'Domain Expert'] },
      { name: 'Ben Hoffmann', role: 'CTO', linkedin: 'https://linkedin.com/in/benhoffmann', prev_companies: 'Typeform, Contentful', prev_roles: 'Frontend Engineer, Tech Lead', years: 8, education: 'FH Münster, Medieninformatik', strengths: ['Technical', 'Repeat Founder'] },
    ],
  },
  {
    company_name: 'Carboniq',
    contact_name: 'Dr. Petra Lindner',
    contact_email: 'petra.lindner@carboniq.eu',
    pitch_deck_url: 'https://docsend.com/view/carboniq-cdr-deck',
    description: 'Carboniq betreibt einen B2B-Marktplatz für zertifizierte Carbon Dioxide Removal Credits. Unternehmen kaufen hochwertige, verifizierte CDR-Credits aus europäischen Projekten (Biokohle, Direkt-Luft-Abscheidung, verbessertes Verwitterung) — mit vollständiger Monitoring-Chain und Reporting-Dashboard.',
    problem_solution: 'Der Markt für hochwertige CDR ist intransparent und fragmentiert. Unternehmenseinkäufer haben keinen Zugang zu verifizierten europäischen Projekten. Carboniq schafft Vertrauen, Liquidität und Compliance.',
    traction_note: '38 Corporate-Kunden, darunter 3 DAX-Konzerne. €2,1M CDR-Credits vermittelt seit Launch. Partnerschaft mit 11 zertifizierten Projektentwicklern. MoM-Wachstum 29 %.',
    origin_country: 'DE',
    stage: 'Seed',
    sector: 'ClimateTech',
    sub_sector: 'Carbon Capture / Removal',
    team_size: 12,
      founded_year: 2024,
    market_served: ['Germany', 'EU'],
    mrr_eur: 38000,
    growth_pct: 29,
    burn_eur_per_month: 62000,
    runway_months: 20,
    paying_customers: 38,
    net_new_mrr_eur: 38000,
    nrr_pct: 122,
    gross_margin_pct: 48,
    cac_eur: 6800,
    logo_churn_pct: 1.0,
    revenue_churn_pct: 1.5,
    tam_eur: 20000000000,
    sam_eur: 1500000000,
    ticket_eur: 2500000,
    valuation_eur: 13000000,
    total_raised_eur: 1000000,
    investor_count: 1,
    founder_pct: 63,
    investor_pct: 33,
    employees_pct: 4,
    team_note: 'Petra war Klimaforscherin am PIK Potsdam. Sören hat CO₂-Märkte bei RWE strukturiert. Einmaliges Team für die CDR-Infrastruktur.',
    founders: [
      { name: 'Dr. Petra Lindner', role: 'CEO', linkedin: 'https://linkedin.com/in/petralindner', prev_companies: 'PIK Potsdam, IPCC', prev_roles: 'Climate Researcher, Policy Advisor', years: 15, education: 'FU Berlin, Klimawissenschaften', strengths: ['Domain Expert', 'Repeat Founder'] },
      { name: 'Sören Brandt', role: 'COO', linkedin: 'https://linkedin.com/in/sorenbrandt', prev_companies: 'RWE, EEX', prev_roles: 'Carbon Markets Trader, Structured Products', years: 12, education: 'Uni Köln, VWL', strengths: ['Operator', 'Domain Expert'] },
    ],
  },
  {
    company_name: 'Quanify Labs',
    contact_name: 'Dr. Isabel Roth',
    contact_email: 'isabel.roth@quanify.de',
    pitch_deck_url: 'https://docsend.com/view/quanify-quantum-deck',
    description: 'Quanify entwickelt Quantum-Computing-Middleware, die bestehende Unternehmensanwendungen ohne Umprogrammierung auf Quantenprozessoren ausführbar macht. Unsere Abstraktionsschicht übersetzt klassische Optimierungsprobleme automatisch in quantenkompatible Schaltkreise — für Logistik, Pharma und Finanzbranche.',
    problem_solution: 'Unternehmen können Quantencomputer nicht nutzen, weil keine ihrer Softwareentwickler Quantenprogrammierung beherrscht. Quanify beseitigt diese Einstiegshürde vollständig.',
    traction_note: '4 Pilotpartner (Lufthansa Cargo, Bayer, DZ Bank, Bosch). EU-Horizons-Grant €1,8M. Patent auf Kompilierungsalgorithmus eingereicht. TRL 5, kommerzieller Launch Q3.',
    origin_country: 'DE',
    stage: 'Pre-Seed',
    sector: 'DeepTech',
    sub_sector: 'Quantum Computing',
    team_size: 10,
      founded_year: 2024,
    market_served: ['Germany', 'EU', 'US'],
    mrr_eur: 5000,
    growth_pct: 0,
    burn_eur_per_month: 150000,
    runway_months: 26,
    paying_customers: 4,
    net_new_mrr_eur: 5000,
    nrr_pct: 100,
    gross_margin_pct: 90,
    cac_eur: 0,
    logo_churn_pct: 0,
    revenue_churn_pct: 0,
    tam_eur: 30000000000,
    sam_eur: 800000000,
    ticket_eur: 2000000,
    valuation_eur: 12000000,
    total_raised_eur: 1800000,
    investor_count: 1,
    founder_pct: 72,
    investor_pct: 28,
    employees_pct: 0,
    team_note: 'Isabel hat ihre Promotion in Quanteninformatik am Max-Planck-Institut gemacht. Viktor war Principal Engineer bei IonQ in den USA — absoluter Weltklasse-Hintergrund.',
    founders: [
      { name: 'Dr. Isabel Roth', role: 'CEO', linkedin: 'https://linkedin.com/in/isabelroth', prev_companies: 'Max-Planck-Institut, Fraunhofer FOKUS', prev_roles: 'Research Lead, Quantum Algorithms', years: 12, education: 'TU München, Quanteninformatik', strengths: ['Domain Expert', 'Technical'] },
      { name: 'Viktor Novak', role: 'CTO', linkedin: 'https://linkedin.com/in/viktornovak', prev_companies: 'IonQ, IBM Research', prev_roles: 'Principal Engineer, Quantum Software', years: 10, education: 'Charles University Prag / MIT, Physics', strengths: ['Technical', 'Repeat Founder'] },
    ],
  },
];

async function fillFounder(page, cardIdx, f) {
  const card = page.locator('.founder-card').nth(cardIdx);
  await card.locator('.f-name').fill(f.name);
  await card.locator('.f-role').selectOption(f.role);
  if (f.linkedin) await card.locator('.f-linkedin').fill(f.linkedin);
  await card.locator('.f-prev-companies').fill(f.prev_companies);
  if (f.prev_roles) await card.locator('.f-prev-roles').fill(f.prev_roles);
  if (f.years) await card.locator('.f-years').fill(String(f.years));
  if (f.education) await card.locator('.f-education').fill(f.education);
  for (const strength of (f.strengths || [])) {
    await card.locator(`.f-strength[value="${strength}"]`).check();
  }
}

async function submitCompany(page, c) {
  await page.goto(URL, { waitUntil: 'networkidle' });
  // Warten bis Fund geladen (nicht mehr "Laden...")
  await page.waitForFunction(
    () => document.getElementById('fundName').textContent !== 'Laden...',
    { timeout: 15000 }
  );

  // Sektion 1 – Basis
  await page.fill('#description', c.description);
  await page.fill('#problem_solution', c.problem_solution);
  await page.fill('#traction_note', c.traction_note);
  await page.fill('#company_name', c.company_name);
  await page.fill('#contact_name', c.contact_name);
  await page.fill('#contact_email', c.contact_email);
  if (c.pitch_deck_url) await page.fill('#pitch_deck_url', c.pitch_deck_url);
  await page.selectOption('#origin_country', c.origin_country);
  await page.selectOption('#stage', c.stage);
  await page.selectOption('#sector', c.sector);
  await page.waitForTimeout(300);
  await page.selectOption('#sub_sector', c.sub_sector);
  await page.fill('#team_size', String(c.team_size));
  if (c.founded_year != null) await page.fill('#founded_year', String(c.founded_year));

  for (const m of c.market_served) {
    await page.locator(`#market_served_group input[value="${m}"]`).check();
  }

  // Sektion 2b – Founders
  for (let i = 1; i < c.founders.length; i++) {
    await page.click('#addFounderBtn');
    await page.waitForTimeout(200);
  }
  for (let i = 0; i < c.founders.length; i++) {
    await fillFounder(page, i, c.founders[i]);
  }
  if (c.team_note) await page.fill('#team_note', c.team_note);

  // Sektion 3 – Revenue
  await page.fill('#mrr_eur', String(c.mrr_eur));
  if (c.growth_pct != null) await page.fill('#growth_pct', String(c.growth_pct));
  await page.fill('#burn_eur_per_month', String(c.burn_eur_per_month));
  await page.fill('#runway_months', String(c.runway_months));
  if (c.paying_customers != null) await page.fill('#paying_customers', String(c.paying_customers));
  if (c.net_new_mrr_eur != null) await page.fill('#net_new_mrr_eur', String(c.net_new_mrr_eur));

  // Sektion 4 – Unit Economics
  if (c.nrr_pct != null) await page.fill('#nrr_pct', String(c.nrr_pct));
  if (c.gross_margin_pct != null) await page.fill('#gross_margin_pct', String(c.gross_margin_pct));
  if (c.cac_eur != null) await page.fill('#cac_eur', String(c.cac_eur));
  if (c.logo_churn_pct != null) await page.fill('#logo_churn_pct', String(c.logo_churn_pct));
  if (c.revenue_churn_pct != null) await page.fill('#revenue_churn_pct', String(c.revenue_churn_pct));

  // Sektion 5 – Markt
  if (c.tam_eur != null) await page.fill('#tam_eur', String(c.tam_eur));
  if (c.sam_eur != null) await page.fill('#sam_eur', String(c.sam_eur));

  // Sektion 6 – Runde
  await page.fill('#ticket_eur', String(c.ticket_eur));
  if (c.valuation_eur != null) await page.fill('#valuation_eur', String(c.valuation_eur));
  if (c.total_raised_eur != null) await page.fill('#total_raised_eur', String(c.total_raised_eur));
  if (c.investor_count != null) await page.fill('#investor_count', String(c.investor_count));
  if (c.founder_pct != null) await page.fill('#founder_pct', String(c.founder_pct));
  if (c.investor_pct != null) await page.fill('#investor_pct', String(c.investor_pct));
  if (c.employees_pct != null) await page.fill('#employees_pct', String(c.employees_pct));

  // Absenden
  await page.click('#submitBtn');

  // Warten auf Erfolg ODER Fehler
  const result = await Promise.race([
    page.waitForSelector('#successScreen:not([style*="none"])', { timeout: 15000 }).then(() => 'success'),
    page.waitForFunction(
      () => {
        const el = document.getElementById('errorMsg');
        return el && el.style.display !== 'none' && el.textContent.trim().length > 0;
      },
      { timeout: 15000 }
    ).then(() => 'error'),
  ]);

  if (result === 'error') {
    const errText = await page.locator('#errorMsg').textContent();
    throw new Error('Formularfehler: ' + errText.trim());
  }
}

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  let passed = 0;
  for (const c of companies) {
    process.stdout.write(`  ${c.company_name} ... `);
    try {
      await submitCompany(page, c);
      console.log('✓');
      passed++;
    } catch (e) {
      console.log(`✗ ${e.message.split('\n')[0]}`);
    }
  }

  await browser.close();
  console.log(`\n${passed}/${companies.length} Submissions erfolgreich.`);
})();
