// API-Bombing Script: schickt die Test-Fixtures an /api/submit auf der Live-Vercel-URL.
// Usage: node scripts/seed-submissions.mjs
//
// Optional ENV-Variablen (sonst Defaults):
//   APP_URL       Vercel-App-URL (default: https://core-app-gamma.vercel.app)
//   FUND_SLUG     Fund-Slug (default: apex)
//
// Aufräumen in Supabase:
//   DELETE FROM submissions WHERE company_name LIKE 'TEST-%';

import { fixtures } from './fixtures.mjs';

const APP_URL = process.env.APP_URL || 'https://core-app-gamma.vercel.app';
const FUND_SLUG = process.env.FUND_SLUG || 'apex';

function genAnonId() {
  const letter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(Math.random() * 26)];
  return `${letter}-${Math.floor(1000 + Math.random() * 9000)}`;
}

async function loadFund() {
  const res = await fetch(`${APP_URL}/api/fund?slug=${encodeURIComponent(FUND_SLUG)}`);
  if (!res.ok) {
    throw new Error(`Fund '${FUND_SLUG}' konnte nicht geladen werden (HTTP ${res.status})`);
  }
  const data = await res.json();
  if (data.error) throw new Error(`Fund-API Fehler: ${data.error}`);
  return data;
}

async function submitOne(fund, fixture) {
  const payload = {
    fund_id: fund.id,
    anon_id: genAnonId(),
    ...fixture.data,
    status: 'pending',
  };

  const res = await fetch(`${APP_URL}/api/submit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.text();
    return { ok: false, status: res.status, error: err };
  }
  return { ok: true, anon_id: payload.anon_id };
}

async function main() {
  console.log(`→ Lade Fund '${FUND_SLUG}' von ${APP_URL} ...`);
  const fund = await loadFund();
  console.log(`✓ Fund geladen: ${fund.name} (id: ${fund.id})\n`);

  const results = [];
  for (const fx of fixtures) {
    process.stdout.write(`  ${fx.label} ... `);
    const t0 = Date.now();
    const r = await submitOne(fund, fx);
    const ms = Date.now() - t0;
    if (r.ok) {
      console.log(`✓ ${ms}ms (anon_id: ${r.anon_id}, erwartet: ${fx.expectedStatus})`);
    } else {
      console.log(`✗ HTTP ${r.status} — ${r.error}`);
    }
    results.push({ label: fx.label, ...r });
  }

  const ok = results.filter(r => r.ok).length;
  console.log(`\n${ok}/${results.length} Submissions erfolgreich.`);
  console.log(`\nZum Prüfen: Supabase SQL Editor →`);
  console.log(`  SELECT company_name, plausibility_status, plausibility_summary`);
  console.log(`  FROM submissions WHERE company_name LIKE 'TEST-%' ORDER BY created_at DESC;`);
}

main().catch(err => {
  console.error('\nFehler:', err.message);
  process.exit(1);
});
