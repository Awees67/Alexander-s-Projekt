# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

CORE is a dealflow infrastructure and screening platform for VC funds in the DACH region. All 7 views are implemented; scoring/pipeline/compare logic is complete. Backend is Supabase (auth, submissions, pipeline, notes, activity log); only UI state (filters, compare, saved) still lives in localStorage. No build tools. Die App ist dark-only: `data-theme="dark"` steht statisch auf `<html>` und wird von `forceDarkTheme()` (utils.js) erzwungen — es gibt keinen Light-Mode-Toggle mehr (entfernt Juni 2026); das Light-CSS in `main.css` ist toter Code bis zur Token-Konsolidierung.

**Design System v2** (Juni 2026, `docs/` bzw. Design-Doku des Users): Dark-First, Teal-Akzent `#00dfc1`, Tokens `--bg #0b0f1a / --surface #111827 / --s2 #1a2235 / --tp / --ts / --tm`. Bereits umgestellt: **Submit-Formular**, **App-Header**, **Detailansicht**, **Submissions-View**, **Pipeline-View**, **Compare-View** (pixelgenau nach Mockup). Umgestellte In-App-Views werden in `V2_DARK_VIEWS` (`renderers.js:setActiveNav`) registriert → `body.v2-dark` + scoped Token-Remap auf dem View-Root (z.B. `#viewSubmissions`). Restliche Views (Dashboard, Übersicht, Activity, Anfragen) folgen mit weiteren Mockups.

## Running the App

No build step. Serve statically (API-Routen `/api/*` brauchen Vercel oder einen Wrapper):

```bash
npx serve .
# or
python -m http.server 8080
```

## Script Load Order

`index.html` loads scripts in a fixed dependency order — **do not reorder**:

1. `@supabase/supabase-js` (CDN) → `env.js` → `supabase-client.js`
2. `config.js` — constants, localStorage keys, pipeline stages, sector taxonomy
3. `utils.js` — DOM helpers, formatting, theme, toast, clipboard
4. `state.js` — app state, localStorage wrapper, pipeline/notes/compare logic
5. `api.js` — Supabase queries (submissions, pipeline, notes, funds)
6. `signal-index.js` → `filters.js` → `custom-index.js` → `activity.js`
7. `renderers-helpers.js` → `renderers-dashboard.js` → `renderers-cards.js` → `renderers-submissions.js` → `renderers-pipeline.js` → `renderers-compare.js` → `renderers-activity.js` → `renderers-inbox.js` → `renderers-modals.js` → `renderers-weekly-top5.js` → `renderers.js`
8. `main.js` — **must be last**: auth guard, app init, event listeners, view routing

## Architecture

### Data Flow

```
main.js (init + routing)
  ├─ supabaseClient.auth.getSession() → Auth Guard
  ├─ getCurrentFund() → window.fundName + Header-Fund-Badge (#fundBadge)
  ├─ apiLoadSubmissions() → injectSubmissionsIntoStartups() → window.startups
  ├─ renderCurrent() → dispatches to view renderer based on currentView
  └─ User event → update state.js → saveUIState() → re-render
```

window.startups wird ausschliesslich via injectSubmissionsIntoStartups() mit echten Supabase-Submissions befuellt (kein Mock-Daten-Generator mehr im Repo).

UI state lives in localStorage under keys defined in `config.js:LS_KEYS` (`safeGetJSON`/`safeSetJSON` in `state.js`). Pipeline/Notes/Submissions/Activity kommen aus Supabase.

### View Rendering

Each view has a dedicated renderer in `js/renderers-*.js`. Renderers generate HTML strings via template literals, then inject via `innerHTML`. Always use `escapeHTML()` for any user-supplied or data-derived content.

### Header & Detailansicht (Design v2)

- **Header**: eine 52px-Bar (`header.app-header` in `index.html`), fix dark, enthaelt Brand, die 7 Nav-Tabs (IDs `topTab*`, Klasse `.viewnav-tab`) und Utils inkl. Fund-Badge. Nav-Klick bei offenem Detail-Modal schliesst es (`navTo()` in `main.js`).
- **Detailansicht**: Fullscreen-Modal unter dem Header (`#modalBackdrop`, `inset: 52px 0 0 0`). Dark-only via **scoped Token-Remap auf `#modalBackdrop`** (Theme-Tokens werden dort auf v2-Werte gemappt). Farb-Logik laut Mockup: positive Werte/Score teal `#00dfc1`, negative rot, LinkedIn/Kontext-Stage blau `#0a84ff`, Push to CRM lila `#a78bfa`, Plausibility gruen `#10b981`. Waehrungen mit Euro-Praefix (`€82.400`). Notiz-Eintraege rendert `dvNoteEntryHTML()`/`dvRelTime()` (eine Quelle fuer Initial-Render und Re-Render nach dem Speichern).

### Pipeline-View (Design v2)

- Stages: **In Review → Contacted → Hot Deal → Watching / Declined / Synced** — „Contacted" ist seit Juni 2026 vollwertige Stage (DB-Constraint + `PIPELINE_TRANSITIONS` in `config.js`).
- Spalte **Zugewiesen** = **letzter Bearbeiter**: `fund_members.user_id` mappt Logins auf Mitarbeiter-Profile (`getCurrentMember()` in state.js). Jede Aktion (Add, Stage, Notiz, CRM-Push) setzt `assigned_member_id` + `last_activity_*` auf den Handelnden. Fallback ohne Profil: Round-Robin beim Add, bestehende Zuweisung bei Updates.
- Spalte **Zuletzt aktiv**: `last_activity_at/by/action` auf der `pipeline`-Zeile; wird bei Stage-Wechsel, CRM-Push, Notiz (state.js `addNote`) und Hinzufügen gesetzt. Format `pipe3RelTime()`: „Heute, 10:42" / „Gestern, 16:15" / Datum.
- Push-to-CRM-Button in **jeder aktiven Zeile** (User-Entscheid, weicht vom Mockup ab); Synced-Zeilen sind gesperrt (keine Checkbox, „✓ Im CRM"). „Synced" ist in `PIPELINE_TRANSITIONS` aus jeder Stage erreichbar, wird aber aus dem Stage-Dropdown gefiltert (CRM nur über den Button).
- Test: `tests/pipeline-view.spec.js` (self-contained Login; `PW_OFFLINE=1` nutzt `tests/fixtures/workspace-fixtures.json` als Supabase-Stub via Playwright-Route-Interception). Dazu `tests/offline-smoke.spec.js`: alle 7 Views ohne JS-Fehler, Activity-View (Supabase), Accept→activity_log-Insert. In Sandboxen ohne Zugriff auf cdn.playwright.dev: `playwright.offline.config.js` nutzt das npm-Paket `@sparticuz/chromium` als Browser (`PW_OFFLINE=1 APP_URL=http://127.0.0.1:8765 npx playwright test -c playwright.offline.config.js`; dessen Single-Process-Modus macht Browser-Relaunches flaky → `--retries=2`).

### Compare-View (Design v2)

- Layout nach Mockup (Juni 2026): **Deals als Zeilen, 7 Metriken als Spalten** (MRR, Wachstum MoM, NRR, CAC Payback, LTV/CAC, Runway, Burn Multiple). Implementierung: `renderCompare()` in `main.js` (`CMP_METRICS`), Styles `#viewCompare .cmp3-*` in `main.css`.
- Farblogik Doku §9: Mini-Balken (2px) und Wert tragen **exakt dieselbe Hex-Farbe** — Best `#22c55e` (Spaltenbester, mit BEST-Label, ab 2 vergleichbaren Werten), Good `#86efac`, Weak `#6b7280`, Bad `#ef4444`. Schwellen pro Metrik in `CMP_METRICS.rate()` (MRR relativ zum Spaltenmax, Rest absolut). Balkenbreite = Qualitätsanteil: higher-better `v/max`, lower-better `best/v` (Spaltenbester = volle Breite). Fehlende Werte: „—" + leerer Track.
- Stage-Dot in der Namensspalte nach Doku §8 (Pre-Seed gelb, Seed/Pre-Series A lila, Series* teal). „Liste leeren" (`#compareClearBtn`) leert nur den localStorage-Compare-State (`core_compare_v1`). `#compareBody`/`#compareExportBtn` sind Test-Verträge — IDs nicht umbenennen.

### Scoring System

`custom-index.js` contains a full rules engine — users configure weighted metric rules with AND/OR logic. `signal-index.js` renders the score popover and delegates configuration to `custom-index.js`.

### Cap-Table- & Metrik-Standard (Design-Doku §12/§13)

- `founder_pct + investor_pct + employees_pct = 100` — **kein ESOP-Feld** mehr (Spalte `esop_pct` existiert nur noch als Altdaten, wird nicht mehr geschrieben).
- **Net New MRR** (`net_new_mrr_eur`, monatlich) statt Net New ARR; `burn_multiple = burn / net_new_mrr`. Spalte `net_new_arr_eur` ist Altdaten; Fallbacks (`/12`) in `api/submit.js` + `main.js` fangen alte Clients ab.
- `founded_year` (optional) fuer die „Gegruendet"-Zeile der Detailansicht.

## Known Tech Debt

**Critical for new work:**

- **Monkey-patching pattern**: `main.js` and `custom-index.js` wrap `renderCompare`, `renderPipeline` and `openModalWithStartup` at runtime (look for `._v41`, `._ciV6` suffixes). When modifying these renderers, check all wrapping layers in both files. Funktionsnamen/Signaturen nicht aendern.

- **Dual CSS token systems**: `main.css` has two parallel variable sets — old (`--bg`, `--text`, `--muted`, `--card`, `--border`, `--brand`) and new (`--surface-*`, `--text-*`, `--accent`) — plus die v2-Hex-Werte (Header hart, Detailansicht via scoped Remap auf `#modalBackdrop`). Der `!important`-Override-Block (sucht nach `HOTFIX`/Override-Kommentaren) ist eine Patch-Schicht. Konsolidierung auf EIN Token-Set (v2, dark-only) erst wenn alle Views umgestellt sind.

- **Score ring (consolidated)**: There is now exactly ONE score-ring builder, `_buildScoreRing()` (viewBox 56px) in `renderers-cards.js` — do NOT reintroduce a second ring function. Ring stroke colors are driven by CSS variables (`--score-ring-high/medium/low/bg`). Achtung: Innerhalb der Detailansicht ist `--score-ring-high` per Scope auf teal `#00dfc1` gemappt (Mockup), ausserhalb bleibt es gruen.

**Erledigt / nicht mehr gueltig (Stand Juni 2026):**
- ~~`zoom: 0.9`-Hack auf `#app-wrapper`/Modals~~ — komplett entfernt, alles rendert nativ.
- ~~DEAL VIEW v1 CSS, alte Header-/viewnav-Styles, `renderModalNotes()`, `note-item`-CSS~~ — toter Code entfernt.
- ~~`window.prompt()`-Filterset, `execCommand("copy")`, Toast 2.2s, `startupLabelById` ohne Namen~~ — bereits frueher gefixt.

## Backend Integration Status

Supabase ist live. Abgeschlossen:
- Auth: Passwort-Login + Magic Link via supabaseClient.auth (login.html + main.js Auth Guard). Self-Signup ist deaktiviert — neue Accounts werden im Supabase-Dashboard angelegt/eingeladen und brauchen DANACH zwei Verknüpfungen: `fund_users`-Zeile (steuert ALLE RLS-Policies) + `fund_members.user_id` (steuert Zugewiesen/Aktivitäts-Namen)
- Fund-Load: getCurrentFund() → window.fundName + Header-Badge
- Submissions: apiLoadSubmissions() → injectSubmissionsIntoStartups() → window.startups
- Submit-Formular: /submit/index.html → /api/submit.js → Supabase submissions Tabelle (Design v2)
- Plausibility Check: server-seitig in api/submit.js (inkl. ownership_total mit investor_pct, founded_year_range)
- Backend Hardening (Woche 1): Credentials aus git, Service Role Key serverseitig, Rate Limiting, fund_id + anon_id serverseitig, 6 Indexes
- RLS: alle Tabellen vollständig abgesichert — fund_id Isolation auf SELECT/INSERT/UPDATE/DELETE
- Pipeline-State + Notes: Supabase-backed via state.js + api.js (kein localStorage mehr)
- Activity Log: Supabase-backed (`activity_log`, append-only — RLS nur SELECT/INSERT, kein Clear-Button). Einmalige localStorage-Migration (`core_activity_v1`) in `_migrateLocalActivity()`; `activityLogAppend()` bleibt sync (optimistischer Cache + Fire-and-forget-Insert)
- DB-Trigger `trg_pipeline_set_activity` (Juni 2026): `last_activity_by/at` + `last_updated` werden serverseitig aus `auth.uid()` → `fund_members.name` gesetzt — Client-Werte für diese Felder werden überschrieben, nur `last_activity_action` kommt vom Client
- `pipeline.owner` (Text) entfernt — Zuweisung läuft ausschliesslich über `assigned_member_id`, Anzeigename via Join (`assigned_name`)
- Migrationen Juni 2026: `investor_pct` (+ Backfill, ESOP in founder_pct gefaltet), `founded_year`, `net_new_mrr_eur` (+ Backfill ARR/12)
- Pipeline-Erweiterung Juni 2026: Tabelle `fund_members` (RLS wie übrige Tabellen), `pipeline.assigned_member_id/last_activity_at/last_activity_by/last_activity_action`, Status-Constraint um `Contacted` erweitert

Naechste Schritte (offen):
- Restliche Views auf Design System v2 (Mockups folgen) — danach Token-Konsolidierung + Light-Mode-CSS entfernen
- Attio CRM Integration (attio_pushes Tabelle bereits angelegt)
- Altdaten-Spalten `esop_pct` / `net_new_arr_eur` droppen, sobald keine alten Clients mehr submitten (vorher Export)
