// TEMP (Pixelvergleich Compare-View): Config für tests/compare-shot.spec.js.
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  timeout: 60_000,
  workers: 1,
  reporter: [['list']],
  use: {
    baseURL: process.env.APP_URL || 'http://127.0.0.1:8765',
    ...devices['Desktop Chrome'],
    // Standard: Playwright-Chromium (manuell installiert, siehe Memory windows-test-umgebung);
    // Fallback auf System-Edge via PW_CHANNEL=msedge.
    channel: process.env.PW_CHANNEL || undefined,
    viewport: { width: 1440, height: 900 },
  },
  projects: [
    { name: 'shot', testMatch: '**/compare-shot.spec.js' },
    { name: 'views', testMatch: '**/views-shot.spec.js' },
  ],
});
