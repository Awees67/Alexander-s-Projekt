# Befund 02 — Joint Controller (Art. 26) vs. Auftragsverarbeiter (Art. 28)

**Audit-Datum:** 6. Juni 2026
**Schweregrad:** KRITISCH
**Kategorie:** B — Fehlinterpretation / Rechtsfehler
**Betrifft:** Datenschutzerklärung v5.6.2026, AVV mit APEX Ventures, api/submit.js, state.js, main.js

---

## Was ist das Problem?

Die Datenschutzerklärung behandelt den Plattformbetreiber durchgehend als reinen **Auftragsverarbeiter** des Fonds nach Art. 28 DSGVO. Das bedeutet laut Dokument: Der Plattformbetreiber führt nur aus, was der Fonds anweist. Der Fonds ist der alleinige Verantwortliche.

Das stimmt nicht mit der technischen Realität überein.

---

## Warum ist das ein Problem?

### Art. 28 vs. Art. 26 -- der Unterschied

**Auftragsverarbeiter (Art. 28):**
Handelt ausschliesslich nach Weisung des Verantwortlichen. Er entscheidet nicht, welche Daten gesammelt werden, warum sie gesammelt werden oder wie sie verarbeitet werden. Er führt nur aus.

**Gemeinsame Verantwortliche (Art. 26):**
Wenn zwei oder mehr Stellen gemeinsam festlegen, zu welchem Zweck und auf welche Weise Daten verarbeitet werden. Beide haften dann gemeinsam -- gesamtschuldnerisch.

### Was der Plattformbetreiber eigenständig entschieden hat

Der Plattformbetreiber hat folgende Entscheidungen getroffen, ohne Weisung des Fonds:

**1. Die 4 booleschen Merkmale (api/submit.js, Zeilen 251-254)**
Der Plattformbetreiber hat festgelegt, dass für jeden Gründer dauerhaft gespeichert wird:
- `has_repeat_founder`
- `has_prior_exit`
- `has_technical_founder`
- `has_domain_expert`

Der Fonds hat das nicht angeordnet. Der Plattformbetreiber hat entschieden, dass das relevante Datenkategorien über Personen sind.

**2. Die 11 Plausibilitätsregeln (api/submit.js, Zeilen 1-80)**
Welche 11 Regeln angewendet werden, welche Schwellenwerte gelten, welche Kennzahlen gegeneinander geprüft werden -- das hat der Plattformbetreiber allein definiert.

**3. Die 5 berechneten Kennzahlen (api/submit.js, Zeilen 226-240)**
ARR, ARPA, LTV, CAC Payback, Burn Multiple werden serverseitig berechnet und dauerhaft als Teil der Einreichung gespeichert. Der Fonds hat nicht angeordnet, dass diese Derivate existieren.

**4. Die Scoring-Architektur**
7 Regelgruppen, Normierung auf 0-100, gewichtete Summe -- das ist die Architektur des Signal-Scores. Der Fonds konfiguriert nur die Gewichtungen innerhalb dieser Struktur. Er entscheidet nicht, dass Wachstum überhaupt eine Kategorie ist.

### Die rechtliche Konsequenz

Die EDSA-Leitlinien 07/2020 unterscheiden zwischen:
- **Wesentliche Mittel** (essential means): Welche Daten, welche Betroffenen, wie lange, an wen -- nur der Verantwortliche bestimmt das.
- **Nicht-wesentliche Mittel** (non-essential means): Technische Architektur, Sicherheitsmassnahmen -- darf der Auftragsverarbeiter eigenständig bestimmen.

Die booleschen Merkmale und berechneten Kennzahlen sind keine technischen Implementierungsdetails -- das sind **Datenkategorien über Personen**, die der Plattformbetreiber eigenständig erfunden hat. Das ist Bestimmung wesentlicher Mittel -- und damit potenziell Art. 26.

### Was Art. 26 für dich bedeuten würde

- Der bestehende AVV ist das falsche Instrument -- Art. 26 braucht eine andere Vereinbarung.
- Du haftest **gesamtschuldnerisch** für Verstösse des Fonds. Datenpanne bei APEX Ventures -- du kannst direkt in Anspruch genommen werden.
- Gründer könnten Rechte (Auskunft, Löschung, Widerspruch) direkt bei dir geltend machen.
- Die Datenschutzerklärung wäre in der Rollenbeschreibung falsch.

---

## Die Lösung: Art. 28 wasserdicht machen

Das Ziel ist klar: Reiner Auftragsverarbeiter bleiben. Das ist erreichbar -- mit zwei parallelen Massnahmen: Vertrag und Code.

### Massnahme 1 -- AVV: Expliziter Weisungskatalog (anwaltlich aufsetzen lassen)

Der bestehende AVV wird um einen **Weisungskatalog** als Anlage erweitert. Darin beauftragt der Fonds schriftlich jede einzelne Verarbeitung.

### Massnahme 2 -- Technische Kontrollmöglichkeit für den Fonds (Code-Änderung)

Der Fonds muss Features deaktivieren können. Nicht weil er das tun wird -- sondern weil die blosse Möglichkeit beweist, dass er der Entscheider ist, nicht du.

#### Schritt 1: Supabase -- `features`-Spalte in `funds`-Tabelle

```sql
ALTER TABLE funds
  ADD COLUMN IF NOT EXISTS features JSONB DEFAULT NULL;
```

#### Schritt 2: api/submit.js -- Fund-Query erweitern

```javascript
const features         = fundData[0].features || {};
const computeBooleans  = features.boolean_flags    !== false;
const runPlausibility  = features.plausibility     !== false;
const computeMetrics   = features.computed_metrics !== false;
const computeScore     = features.signal_score     !== false;
```

#### Schritt 3: state.js Zeile 191 -- lokale Score-Berechnung absichern

```javascript
signal_index: (
  window.fundFeatures?.signal_score !== false &&
  typeof computeSignalIndex === 'function' &&
  resolved_anon_id
)
  ? computeSignalIndex(resolved_anon_id)
  : null,
```

### Massnahme 3 -- Datenschutzerklärung: Abschnitt 1.2 anpassen

> "Der Plattformbetreiber hat die technische Infrastruktur der Plattform entwickelt und stellt sie dem Fonds als konfigurierbares Werkzeug zur Verfügung. Alle inhaltlichen Entscheidungen über den Umfang der Datenverarbeitung -- insbesondere welche Scoring-Merkmale berechnet werden, ob eine Plausibilitätsprüfung durchgeführt wird und wie der Signal-Score gewichtet ist -- trifft ausschliesslich der Fonds als Verantwortlicher."

---

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*
*Erstellt: 6. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
