# Befund 13 — Datenschutzerklärung: Vollständigkeit und aktuelle Lücken

**Datum:** 07. Juni 2026
**Schweregrad:** KRITISCH
**Betroffene Normen:** Art. 13 DSGVO, Art. 14 DSGVO, Art. 12 DSGVO, Art. 83 Abs. 5 lit. b DSGVO, nDSG (Schweiz, seit 01.09.2023)
**Status:** Handlungsbedarf identifiziert

---

## 1. Kritische strukturelle Lücken

### Lücke A: CORE-eigene Zwecke nicht transparent

Die DSE deckt (bestenfalls) die Verarbeitung im Auftrag des VC-Fonds ab. Die eigenständige Verarbeitung durch CORE (Benchmarking, Cross-Fonds-Analyse — Befund 09) ist nicht beschrieben. Fehlend:
- Wer ist Verantwortlicher für diese Zwecke (CORE, nicht der Fonds)
- Rechtsgrundlage
- Speicherdauer
- Betroffenenrechte gegenüber CORE

### Lücke B: Dynamische Fondsanzeige fehlt

Empfänger sind nach Art. 13 Abs. 1 lit. e zu nennen. Der konkrete Fonds muss dynamisch ausgewiesen werden. EDSA-Stellungnahme 07.10.2024: Auftragsverarbeiter muss dem Verantwortlichen die nötigen Informationen liefern — fehlt die Infrastruktur, kann der Fonds Art. 13 nicht erfüllen.

### Lücke C: Schweizer Fonds und nDSG

Bei Schweizer Fonds oder Schweizer Gründern greift nDSG (seit 01.09.2023). Besonderheit: Bußgelder bis CHF 250.000 **persönlich gegen natürliche Personen** (Geschäftsführer).

## 2. Art.-13-Checkliste — Lücken im Überblick

| Anforderung | Status |
|---|---|
| Verarbeitungszwecke für CORE-eigene Zwecke | FEHLT |
| Rechtsgrundlage für Ableitungen (lit. f) | FEHLT |
| Berechtigte Interessen (Art. 13 Abs. 1 lit. d) | FEHLT |
| Empfänger: konkreter Fonds (dynamisch) | FEHLT |
| Drittlandtransfers (Supabase, Vercel) | UNKLAR |
| Speicherdauer oder Kriterien | FEHLT (Befund 11) |
| Art. 21 Widerspruchsrecht für lit.-f-Verarbeitungen | FEHLT |
| Signal-Score als Profiling (Art. 13 Abs. 2 lit. f) | FEHLT |
| Beschwerderecht: konkrete Behörde benannt | UNKLAR |

## 3. Handlungsbedarf

**Sofortmassnahmen:**
1. DSE-Audit gegen Art.-13-Checkliste
2. Separate Sektion "CORE als eigenständiger Verantwortlicher" in DSE
3. Dynamische Fondsnamenanzeige im Submit-Formular
4. Beschwerderecht: konkrete Behörde benennen (DSB Wien oder zuständiges Landesamt)

**Mittelfristig:**
5. Signal-Score transparent machen (Abschnitt in DSE)
6. Fondsindividuelle DSE-Strecke aufbauen (Fondsdaten beim Onboarding hinterlegen)
7. Drittlandtransfer vollständig dokumentieren (Supabase, Vercel, SCC-Grundlage)
8. nDSG-Kompatibilitätsprüfung falls Schweizer Fonds/Gründer betroffen

**Langfristig:**
9. Jährliche DSE-Überprüfung
10. Two-Controller-Informationsmodell (Auftragsverarbeiter + eigenständiger Verantwortlicher klar trennen)

## 4. Fazit

Mehrere kritische Art.-13-Lücken: CORE-eigene Zwecke nicht beschrieben, kein dynamischer Fondsname, Speicherfristen fehlen, Signal-Score-Profiling nicht erläutert. Art.-13-Verstösse sind die am häufigsten sanktionierte Kategorie im DSGVO-Bußgeldregime.

**Schweregrad: KRITISCH** — Art. 83 Abs. 5 lit. b: bis 20 Mio. EUR / 4 % Jahresumsatz. Lücken sind mit verhältnismässig geringem Aufwand schliessbar.

---

*Quellen: Art. 13 DSGVO, Art. 12 Abs. 1, Art. 83 Abs. 5 lit. b, EDSA-Stellungnahme 07.10.2024, nDSG Art. 19/20, Art. 3 Abs. 2 nDSG*
