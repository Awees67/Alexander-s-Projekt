# Befund 03 — `core_leads_v1` und `core_outreach_v2`: Verarbeitung ohne Rechtsgrundlage und ohne Erwähnung in der Datenschutzerklärung

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** HOCH  
**Kategorie:** C — Lücke / fehlende Pflichtangabe  
**Betrifft:** Datenschutzerklärung v5.6.2026, js/state.js (LS_KEYS), js/config.js, js/renderers-inbox.js

---

## Was ist das Problem?

Es gibt zwei localStorage-Schlüssel, die **personenbezogene Daten von Dritten** speichern — Daten, die weder in der Datenschutzerklärung erwähnt werden noch eine dokumentierte Rechtsgrundlage haben.

**`core_leads_v1`** — speichert pro Eintrag (state.js Zeilen 90–101):
- `name` — vollständiger Name einer Person
- `email` — E-Mail-Adresse
- `firm` — Arbeitgeber
- `msg` — Nachrichtentext
- `anon_id`, `display_label`, `ts`

**`core_outreach_v2`** — speichert pro Eintrag (state.js Zeilen 491–504):
- `contact_name`, `contact_email` — direkte Personendaten des kontaktierten Gründers
- `sent_at` — wann die E-Mail gesendet wurde
- `status` — aktueller Outreach-Status
- `followup_sent` — ob ein Follow-up versendet wurde

---

## Warum ist das ein Problem?

1. Nicht in der Datenschutzerklärung erwähnt — verletzt Art. 13 DSGVO
2. Keine Rechtsgrundlage dokumentiert — Art. 6 Abs. 1 DSGVO
3. Speicherort localStorage — keine Zugriffskontrolle, keine Verschlüsselung
4. Löschfristen fehlen — verletzt Art. 5 Abs. 1 lit. e DSGVO
5. TKG 2021 bei `core_outreach_v2` (Österreich) — mögliche separate TKG-Verletzung

---

## Die Lösung

### Massnahme 1 — Datenschutzerklärung erweitern

**Zu `core_leads_v1`:** Rechtsgrundlage Art. 6 Abs. 1 lit. f, Speicherdauer max. 12 Monate.

**Zu `core_outreach_v2`:** Rechtsgrundlage Art. 6 Abs. 1 lit. f, automatische Löschung nach 6 Monaten.

### Massnahme 2 — Technisch: Automatische Löschfrist implementieren

In `main.js` beim App-Start: `core_leads_v1` (älter als 12 Monate) und `core_outreach_v2` (älter als 6 Monate) bereinigen.

### Massnahme 3 — TKG-Einschätzung für Outreach-E-Mails (anwaltlich)

Vor Produktivbetrieb: § 174 TKG 2021 klären.

### Massnahme 4 — Mittelfristig: Migration zu Supabase

localStorage ist kein geeigneter Ort für personenbezogene Daten in einem produktiven B2B-SaaS.

---

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
