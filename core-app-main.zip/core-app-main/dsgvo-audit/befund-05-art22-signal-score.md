# Befund 05 (Revision 2) — Art. 22 DSGVO und Profiling: Der Signal-Score als Thesis-Match-Indikator

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** MITTEL  
**Kategorie:** B — Fehlende Transparenz und Dokumentation; Profiling ohne vollständige Art.-13-Information  
**Betrifft:** Datenschutzerklärung v5.6.2026, js/custom-index.js, js/state.js, js/config.js, submit/index.html  
**Referenz:** Art. 4 Nr. 4, Art. 13, Art. 22 DSGVO; EDSA-Leitlinien WP251 rev.01; BVwG W256 2235360-1 (1. September 2025, AMS-Algorithmus)

---

## Korrektur gegenüber erster Berichtversion

Die erste Version hat Art. 22 als anwendbar eingestuft. Das war zu streng. Der Pipeline-Status wird **ausschliesslich manuell** gesetzt. Der Signal-Score ist ein visueller Thesis-Match-Indikator — er löst keine Entscheidung aus.

## Frage 1: Greift Art. 22 DSGVO?

**Einschätzung: Nein.** Art. 22 Abs. 1 gilt nur bei Entscheidungen, die *ausschliesslich* auf automatisierter Verarbeitung beruhen (EDSA WP251 rev.01). Der österreichische Referenzfall BVwG W256 2235360-1 (1. September 2025, AMS-Algorithmus) bestätigt: Auch ein automatisierter Score, der menschliche Entscheidungen informiert, fällt nicht unter Art. 22 — solange echte menschliche Einflussnahme besteht.

**Rubber-Stamping-Risiko:** Wenn rote Scores faktisch immer zu "Declined" führen ohne echte Prüfung, könnte eine Behörde trotzdem Art. 22 arguieren.

## Frage 2: Pflichten aus Profiling (Art. 4 Nr. 4)

1. **Rechtsgrundlage** — Art. 6 Abs. 1 lit. f (nicht lit. b)
2. **Transparenz** — Art. 13: Gründer müssen wissen, dass ein Score berechnet wird
3. **Dokumentation** — Beweislast Art. 5 Abs. 2: menschliche Entscheidungspraxis nachweisbar halten
4. **Fairness** — kein systematischer Bias

## Die Lösung

**Massnahme 1** — Kein Default-Regelwerk; Score erst nach aktiver Fondskonfiguration.

**Massnahme 2** — Score als "Thesis-Match-Indikator" labeln; Tooltip erklären.

**Massnahme 3** — Datenschutzerklärung: Profiling und Score transparent machen.

**Massnahme 4** — Pipeline-Audit-Trail als Dokumentation der menschlichen Entscheidung erhalten.

**Massnahme 5** — Jährlicher Fairness-Check der Score-Verteilung.

---

*Quellen: Art. 4 Nr. 4, Art. 5, Art. 6, Art. 13, Art. 22 DSGVO; EDSA WP251 rev.01; BVwG W256 2235360-1 (1. September 2025); EuGH C-634/21.*

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026, überarbeitet auf Basis präzisierter Systemarchitektur.*
