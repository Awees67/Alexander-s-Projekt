# Befund 04 — Art. 6 Abs. 1 lit. b: Rechtsgrundlage für abgeleitete Kennzahlen überdehnt

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** MITTEL  
**Kategorie:** B — Fehlinterpretation / Rechtsfehler  
**Betrifft:** Datenschutzerklärung v5.6.2026, api/submit.js (Zeilen 226–254)

---

## Was ist das Problem?

Die Datenschutzerklärung nennt als primäre Rechtsgrundlage **Art. 6 Abs. 1 lit. b DSGVO**. Das trägt für Rohdaten der Einreichung — nicht aber für serverseitig berechnete Ableitungen:

- `arr_eur`, `arpa_eur`, `ltv_eur`, `cac_payback_months`, `burn_multiple`
- `has_repeat_founder`, `has_prior_exit`, `has_technical_founder`, `has_domain_expert`

Diese hat der Gründer **nicht eingegeben**. Sie sind neue Datenpunkte — Ableitungen aus den Rohdaten.

## Warum ist das ein Problem?

Lit. b darf nur für objektiv Notwendiges zur Vertragserfüllung herangezogen werden (EuGH C-252/21). Die Ableitungen sind keine objektive Notwendigkeit. Boolesche Merkmale wie `has_repeat_founder` sind Profiling nach Art. 4 Nr. 4 DSGVO.

Die korrekte Rechtsgrundlage wäre **lit. f** — aber mit Dreistufenprüfungspflicht und Widerspruchsrecht nach Art. 21 DSGVO.

## Die Lösung

| Verarbeitung | Rechtsgrundlage |
|---|---|
| Rohdaten der Einreichung | Art. 6 Abs. 1 lit. b |
| Berechnete Kennzahlen | Art. 6 Abs. 1 lit. f |
| Boolesche Gründermerkmale | Art. 6 Abs. 1 lit. f |
| Signal-Score | Art. 6 Abs. 1 lit. f |

**Massnahme 1** — Rechtsgrundlagen-Tabelle in Datenschutzerklärung einfügen.

**Massnahme 2** — Art.-21-Widerspruchsrecht für Ableitungen ergänzen.

**Massnahme 3** — Selektive Löschung berechneter Felder technisch ermöglichen.

**Massnahme 4** — Interessenabwägung im Art.-30-Verarbeitungsverzeichnis dokumentieren.

---

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
