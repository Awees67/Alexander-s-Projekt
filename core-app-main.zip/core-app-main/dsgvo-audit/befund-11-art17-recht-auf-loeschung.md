# Befund 11 — Art. 17 DSGVO: Recht auf Löschung (technische Umsetzbarkeit)

**Datum:** 07. Juni 2026
**Schweregrad:** HOCH
**Betroffene Normen:** Art. 17 DSGVO, Art. 28 Abs. 3 lit. g DSGVO, Art. 5 Abs. 1 lit. e DSGVO
**Status:** Handlungsbedarf identifiziert

---

## 1. Ist-Zustand

Ein Gründer, der seine Daten löschen lassen möchte, findet heute keinen definierten Prozess. Fehlende Infrastruktur:

- Kein Löschantrags-Formular oder Kontaktweg
- Kein dokumentiertes Löschverfahren
- Unklar ob CASCADE DELETE zwischen Tabellen vorhanden
- localStorage-Daten (leads, outreach, activity) werden bei DB-Löschung nicht automatisch gelöscht
- Keine Löschbestätigung / kein Nachweis

**EDSA Koordinierte Aktion 2025:** 32 nationale Aufsichtsbehörden prüfen aktiv Art. 17.

## 2. Doppelrolle schafft Komplexität

CORE als Auftragsverarbeiter → Löschung nur auf Weisung des Fonds (Art. 28). CORE als eigenständiger Verantwortlicher → eigenständige Löschpflicht gegenüber Gründern (Art. 17). Ohne klare Prozesse: Gründer erhält keine Antwort.

## 3. Technische Lücken

- **Fehlende CASCADE-Constraints:** Löschungen müssen manuell in jeder Tabelle erfolgen → Phantom-Daten wahrscheinlich
- **localStorage als blinder Fleck:** Serverseitige Löschung erreicht localStorage nicht
- **Backup-Daten:** Gelöschte Daten bleiben in Backups für Retention-Periode

## 4. Handlungsbedarf

**Sofortmassnahmen:**
1. Kontaktweg einrichten (z.B. datenschutz@core-platform.io) — in Datenschutzerklärung nennen
2. Internes Löschverfahren (SOP) dokumentieren: Wer, was, welche Tabellen, max. 30 Tage
3. CASCADE DELETEs einrichten:
```sql
ALTER TABLE pipeline_items
  ADD CONSTRAINT fk_submission
  FOREIGN KEY (submission_id)
  REFERENCES submissions(id)
  ON DELETE CASCADE;

ALTER TABLE notes
  ADD CONSTRAINT fk_submission
  FOREIGN KEY (submission_id)
  REFERENCES submissions(id)
  ON DELETE CASCADE;
```

**Mittelfristig:**
4. Löschbestätigung per E-Mail mit Zeitstempel (OLG Dresden 2024)
5. Fonds-Koordination im AVV regeln (Art. 17 Abs. 2)
6. Löschfristen definieren (z.B. Submissions ohne Pipeline-Aktion nach 24 Monaten)
7. localStorage-Hinweis an Fonds beim Onboarding

**Langfristig:**
8. Self-Service-Löschfunktion prüfen
9. Backup-Policy für Löschfälle dokumentieren

---

*Quellen: Art. 17 DSGVO, Art. 28 Abs. 3 lit. g, Art. 5 Abs. 1 lit. e, OLG Dresden 2024, EDSA Koordinierte Aktion 2025 zu Art. 17 DSGVO*
