# Befund 12 — Art. 33/34 DSGVO: Datenpannenmeldung und Incident-Response-Prozess

**Datum:** 07. Juni 2026
**Schweregrad:** HOCH
**Betroffene Normen:** Art. 33 DSGVO, Art. 34 DSGVO, Art. 28 Abs. 3 lit. f DSGVO
**Status:** Handlungsbedarf identifiziert

---

## 1. Ist-Zustand — Was heute fehlt

| Aspekt | Ist-Stand |
|---|---|
| Dokumentierter Incident-Response-Plan | Nicht vorhanden |
| Interne Meldeschwelle | Nicht definiert |
| Meldeprozess an Aufsichtsbehörde | Nicht dokumentiert |
| Kettenmeldung an Fonds (Art. 33 Abs. 2) | Nicht im AVV geregelt |
| Meldeprozess an Gründer (Art. 34) | Nicht vorhanden |
| Datenpannen-Register (Art. 33 Abs. 5) | Nicht geführt |

## 2. Technische Risikofaktoren

- RLS-Fehlkonfiguration → horizontale Datenexpansion zwischen Fonds
- Kompromittierter Service Role Key → voller DB-Zugriff ohne RLS
- Vercel api/submit.js öffentlich erreichbar
- Multi-Fonds-Architektur: Eine Panne betrifft potenziell mehrere Verantwortliche

## 3. Rechtliche Kernpunkte

**Art. 33 Abs. 1:** 72-Stunden-Frist ab Kenntnis an zuständige Aufsichtsbehörde.

**Art. 33 Abs. 2 (Kettenmeldung):** CORE als Auftragsverarbeiter muss Fonds **unverzüglich** (AVV: innerhalb 24h) informieren. Der Fonds meldet dann an Behörde.

**Art. 33 Abs. 5:** Auch nicht meldepflichtige Pannen müssen intern dokumentiert werden.

**Art. 34:** Bei hohem Risiko für Betroffene → Gründer unverzüglich benachrichtigen. Bei CORE-Datenpanne ist hohes Risiko regelmässig anzunehmen.

**Zuständige Behörde:** DSB Wien (dsb@dsb.gv.at) wenn Hauptsitz Österreich; Landesdatenschutzbehörde wenn Deutschland.

**Sanktionen:** Art. 83 Abs. 4 lit. a: bis 10 Mio. EUR / 2 % Jahresumsatz bei verspäteter/fehlender Meldung.

## 4. Handlungsbedarf

**Sofortmassnahmen:**
1. Incident-Response-Plan (IRP) erstellen: Eskalationsablauf, Schwellendefinition, Behördenmeldeprozess
2. AVV-Ergänzung: Kettenmeldepflicht (CORE → Fonds innerhalb 24h, Art. 28 Abs. 3 lit. f)
3. Kontaktliste aller Fonds für Datenschutz-Notfälle
4. Datenpannen-Register einrichten (Art. 33 Abs. 5)

**Mittelfristig:**
5. Meldeformulare vorbereiten (Art. 33 Abs. 3 + Art. 34 Abs. 2)
6. Risikobewertungsmatrix (Datenkategorie × Betroffenenanzahl × Verletzungsart)
7. Supabase Audit Logging + Alerting bei anomalen Zugriffsmustern

**Langfristig:**
8. Jährliche IRP-Übung (Tabletop: "Was wenn Service Role Key kompromittiert wird?")

---

*Quellen: Art. 33 DSGVO, Art. 34 DSGVO, Art. 28 Abs. 3 lit. f, Art. 83 Abs. 4 lit. a, Art. 56 DSGVO (One-Stop-Shop)*
