# Befund 07 — Art. 6 Abs. 1 lit. f: Dreistufentest für den Signal-Score nicht dokumentiert

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** HOCH  
**Kategorie:** B — Fehlende Dokumentation / Rechtsfehler  
**Betrifft:** Datenschutzerklärung v5.6.2026, custom-index.js, Art.-30-Verarbeitungsverzeichnis (nicht vorhanden)

---

## Was ist das Problem?

Art. 6 Abs. 1 lit. f gilt nur wenn der **Dreistufentest** (Legitimate Interest Assessment, LIA) bestanden und **dokumentiert** ist. Für den Signal-Score existiert keine solche Dokumentation.

## Die drei Prüfstufen

**Stufe 1 — Berechtigtes Interesse:** Begründbar (VC-Screening-Interesse), aber nicht konkret formuliert und dokumentiert.

**Stufe 2 — Erforderlichkeit:** Schwerste Prüfstufe. Alternativen (manuelles Screening, Keyword-Filterung) müssen geprüft und als unzureichend belegt sein. Diese Dokumentation fehlt.

**Stufe 3 — Interessenabwägung:** Fällt zugunsten des Fonds aus **nur wenn** mindestens folgende Schutzmassnahmen implementiert sind:
1. Gründer über Score informiert (Art. 13)
2. Score-Erläuterung auf Anfrage möglich
3. Fondsmitarbeiter kann Score überschreiben
4. Dokumentierte Human-Override-Rate als Nachweis echter menschlicher Prüfung

## Rubber-Stamping-Risiko

Wenn rote Scores faktisch immer zu Ablehnung führen ohne echte Prüfung: Stufe 3 fällt nachträglich weg, Art. 22 Abs. 1 wird auslösbar (EuGH C-634/21).

## Die Lösung

**Massnahme 1** — Legitimate Interest Assessment (LIA) erstellen: internes Governance-Dokument (PDF), datiert, unterschrieben, mit allen drei Prüfstufen.

**Massnahme 2** — Recht auf Score-Erläuterung implementieren (EuGH C-634/21, C-203/22).

**Massnahme 3** — Art. 21 Widerspruchsrecht in Datenschutzerklärung nennen.

**Massnahme 4** — Human-Override-Log führen (quartalsweise prüfen ob Override-Rate > 0).

**Massnahme 5** — Scoring-Absatz in Datenschutzerklärung ergänzen.

---

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
