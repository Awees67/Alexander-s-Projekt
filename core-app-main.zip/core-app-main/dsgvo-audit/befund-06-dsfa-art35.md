# Befund 06 — Art. 35 DSGVO: Datenschutz-Folgenabschätzung (DSFA) fehlt — zwingend erforderlich

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** KRITISCH  
**Kategorie:** A — Fehlende Pflichtdokumentation, Verarbeitung ohne vorherige DSFA  
**Referenz:** Art. 35 DSGVO, Art. 36 DSGVO, Art. 83 Abs. 4 DSGVO; EDSA-Leitlinien WP248 rev.01; österreichische DSFA-V (BGBl II Nr. 278/2018)

---

## Was ist das Problem?

Für CORE existiert keine DSFA. Das Scoring-System ist in Betrieb. Die DSFA war Voraussetzung, nicht Nachschritt. Fehlende DSFA ist eigenständiger Verstoss nach Art. 83 Abs. 4 DSGVO (bis 10 Mio. EUR).

## Vier unabhängige Auslöser für DSFA-Pflicht

**Auslöser 1** — Art. 35 Abs. 1: Hohes Risiko durch automatisierte Bewertung mit Einfluss auf Investitionsentscheidungen.

**Auslöser 2** — Art. 35 Abs. 3 lit. a: Regelbeispiel erfüllt — systematische Bewertung persönlicher Aspekte durch automatisiertes Profiling als Grundlage für erhebliche Entscheidungen. Alle 6 Tatbestandsmerkmale erfüllt.

**Auslöser 3** — Österreichische DSFA-V (BGBl II Nr. 278/2018): Nationale Muss-Liste erfasst Evaluierung/Klassifizierung von Personen mit finanziellen Wirkungen.

**Auslöser 4** — EDSA WP248 rev.01: Mindestens 3 von 9 Kriterien eindeutig erfüllt (Scoring/Profiling, erhebliche Wirkung, Ausschluss von Diensten).

## Wichtig: Art. 35 gilt auch bei manuellen Entscheidungen

Art. 22 greift nicht (Befund 05v2 — manuelle Pipeline-Status). Art. 35 hat niedrigeren Auslöseschwellenwert: er greift bereits wenn Profiling *als Grundlage* für erhebliche menschliche Entscheidungen dient.

## Was eine wasserdichte DSFA enthalten muss (Art. 35 Abs. 7)

**(a)** Systematische Beschreibung der Verarbeitungsvorgänge und Zwecke

**(b)** Bewertung der Notwendigkeit und Verhältnismässigkeit

**(c)** Bewertung der Risiken: Falschklassifizierung, Diskriminierung, Intransparenz, Dauerspeicherung negativer Bewertungen, Datenpanne, Sekundärnutzung

**(d)** Abhilfemassnahmen zur Risikoreduzierung

## Prozess

- Verantwortlicher ist der Fonds (nicht Plattformbetreiber)
- Plattformbetreiber liefert technische Beschreibung (Teil a+b)
- Fonds trägt Risikoabwägung (Teil c+d)
- Gemeinsame Unterzeichnung
- Falls Restrisiko hoch: DSB-Konsultation nach Art. 36 (8–14 Wochen)

**DSB Österreich:** Barichgasse 40–42, 1030 Wien | dsb@dsb.gv.at

---

*Quellen: Art. 35, 36, 83 DSGVO; EDSA WP248 rev.01; österreichische DSFA-V BGBl II Nr. 278/2018.*

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
