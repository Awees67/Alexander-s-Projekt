# Befund 09 — Plattformbetreiber als eigenständiger Verantwortlicher

**Datum:** 07. Juni 2026
**Projekt:** CORE — Dealflow Screening Platform
**Schweregrad:** KRITISCH
**Artikel:** Art. 5 Abs. 1 lit. b DSGVO (Zweckbindung), Art. 5 Abs. 1 lit. e DSGVO (Speicherbegrenzung), Art. 26 DSGVO, Art. 13/14 DSGVO
**Status:** Offen

---

## 1. Zusammenfassung

CORE verarbeitet personenbezogene Daten im Auftrag der VC-Fonds (Art. 28 — Auftragsverarbeiter). Darüber hinaus nutzt CORE dieselben Daten für **eigene Zwecke** — Benchmarking, historische Vergleiche, Marktanalysen — ohne Weisung des Fonds. Für diese Verarbeitung ist CORE **eigenständiger Verantwortlicher**.

## 2. Sachverhalt

### Sekundärverarbeitung (eigenständige Verantwortlichkeit)

| Zweck | Beschreibung |
|---|---|
| Benchmarking | Vergleich von Startup-Qualitätsmerkmalen über Fonds hinweg |
| Historische Vergleiche | Longitudinale Analyse von Gründer-Karriereverläufen |
| Marktanalyse | Mustererkennung ("Gründer von Uni X erzielen Outcome Z") |
| Produktverbesserung | Kalibrierung des Signal-Score-Algorithmus |

Diese Zwecke sind nicht vom Fonds angewiesen. Daten verbleiben **unbegrenzt** in der CORE-Datenbank — auch nach Ende der Fondsbeziehung.

### "Anonym aber spezifisch"

Geplante Aussagen wie "Gründer von Uni X mit Hintergrund Y haben Erfolgsquote Z" sind in kleinen Populationen (DACH-VC) **pseudonymisiert, nicht anonym** (EDSA Anonymisierungstests: Singling-out, Linkability, Inference). DSGVO gilt vollumfänglich.

## 3. Rechtliche Analyse

### Art. 5 Abs. 1 lit. b — Zweckbindung

Gründer haben Daten für Bewerbung beim Fonds eingereicht. Nutzung für CORE-Benchmarking ist **Zweckänderung**. Kompatibilitätsprüfung nach Art. 6 Abs. 4 fällt negativ aus. Art. 89 DSGVO (Forschungsausnahme) gilt nicht für kommerzielle Marktanalysen.

### Art. 5 Abs. 1 lit. e — Speicherbegrenzung

Keine differenzierten Löschfristen pro Verarbeitungszweck. Unbegrenzte Speicherung ohne Rechtsgrundlage verletzt Art. 5 Abs. 1 lit. e.

### Art. 26 — Gemeinsame Verantwortlichkeit (latent)

Sobald CORE Benchmarking-Ergebnisse an Fonds zurückspielt, entsteht gemeinsame Verarbeitung → Art. 26-Vereinbarung erforderlich.

**Bußgeldrisiko:** Art. 5-Verstösse → Art. 83 Abs. 5: bis 20 Mio. EUR / 4 % Jahresumsatz.

## 4. Handlungsbedarf

**Schritt 1** — Rechtsgrundlage für eigenständige Verarbeitung definieren:
- **Option A (empfohlen):** Einwilligung (Art. 6 Abs. 1 lit. a) — separate Checkbox im Submit-Formular
- **Option B:** Berechtigtes Interesse (Art. 6 Abs. 1 lit. f) — Dreistufentest offen und nicht trivial

**Schritt 2** — Löschkonzept: differenzierte Fristen pro Verarbeitungszweck.

**Schritt 3** — Datenschutzerklärung: eigenständige CORE-Verarbeitung explizit abdecken.

**Schritt 4** — Submit-Formular: separate Einwilligungsbox (kein Pre-ticked-Checkbox).

**Mittelfristig** — Technisches Pseudonymisierungskonzept: Identifikatortabelle mit kurzer Frist + Analysedatentabelle mit längerer Frist.

---

*Erstellt im Rahmen des systematischen DSGVO-Audits von CORE, 07. Juni 2026.*
*Dieser Befund stellt keine anwaltliche Beratung dar.*
