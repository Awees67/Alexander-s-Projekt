# Befund 08 — Art. 28 + Art. 44 ff. DSGVO: AVV fehlt, Drittlandtransfer ungesichert

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** HOCH  
**Kategorie:** C — Fehlende Pflichtverträge / ungesicherter Drittlandtransfer  
**Betrifft:** Supabase Inc., Vercel Inc., zukünftige E-Mail-Anbieter  
**Referenz:** Art. 28, 44–49, 83 Abs. 4 DSGVO; EU-SCC Beschluss 2021/914 + 2021/915; EU-US Data Privacy Framework (Juli 2023); CJEU C-555/25 (anhängig)

---

## Vier separate Probleme

| # | Problem | Norm | Schwere |
|---|---|---|---|
| 1 | Kein AVV mit Supabase | Art. 28 DSGVO | Kritisch |
| 2 | Vercel-Functions laufen in USA (kein vercel.json) | Art. 44 ff. DSGVO | Hoch |
| 3 | Vercel-CDN/DDoS läuft durch US-Infrastruktur | Art. 44 ff. DSGVO | Mittel |
| 4 | Kein Plan für zukünftigen E-Mail-Anbieter | Art. 28 + Art. 44 ff. | Mittel |

## Problem 1 — Kein AVV mit Supabase

Ohne AVV nach Art. 28 DSGVO ist die Verarbeitung rechtswidrig. De-facto-AVV durch AGB sind nicht wirksam (Art. 28 Abs. 9: Schriftform erforderlich).

**Lösung:** Supabase DPA unterzeichnen — Supabase Dashboard → Organisation → **Legal Documents** (PandaDoc-Flow). Aufwand: 30 Minuten.

Supabase DPA = SCC Modul 2, erfüllt gleichzeitig Art. 28 und Art. 46.

## Problem 2 — Vercel: Serverless Functions laufen in USA

Ohne `vercel.json` läuft jede Function in **iad1 (Washington D.C., USA)**. Aktiver Drittlandtransfer.

**Lösung:** `vercel.json` erstellen:
```json
{
  "regions": ["fra1"]
}
```

Vercel ist DPF-zertifiziert + stellt fertige DPA bereit (vercel.com/legal/dpa).

## DPF-Stabilitätsrisiko

CJEU C-555/25 (Latombe-Berufung) anhängig. PCLOB faktisch handlungsunfähig. Schrems-III-Szenario realistisch. Vercel-DPA enthält SCC als Fallback.

## Problem 3 — Fra1 eliminiert Drittlandtransfer nicht vollständig

Auch mit fra1: DDoS-System, CDN-PoPs und Control Plane laufen durch US-Infrastruktur. Durch DPF + SCC abgedeckt, aber nicht eliminiert.

## E-Mail-Anbieter-Empfehlung

**Brevo** (Sendinblue SAS, Paris) — EU-ansässig, OVH FR/DE, SCC + DPF, AVV automatisch. Free-Plan: 300 E-Mails/Tag.

## Massnahmen (Priorität)

1. Supabase DPA unterzeichnen — **Sofort, 30 Min**
2. Supabase TIA archivieren — **Sofort, 5 Min**
3. `vercel.json` mit fra1 — **Diese Woche, 10 Min**
4. Vercel DPA archivieren — **Diese Woche, 5 Min**
5. Art.-30-Verarbeitungsverzeichnis anlegen — **Diese Woche, 30–60 Min**

**Gesamtaufwand für sofortige Compliance: ca. 2 Stunden — ohne Anwalt.**

---

*Quellen: DSGVO Art. 28, 44–49, 83; EU-SCC 2021/914 Modul 2; Supabase DPA März 2025; Vercel DPA; EU-US DPF Juli 2023; General Court T-553/23; CJEU C-555/25; BfDI Vodafone EUR 15M März 2025.*

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
