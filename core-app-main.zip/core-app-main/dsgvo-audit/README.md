# DSGVO-Audit — CORE Dealflow Platform

**Datum:** 07.–08. Juni 2026  
**Erstellt von:** Andreas Awees (Plattformbetreiber)  
**Rechtsrahmen:** DSGVO (EU) 2016/679 + DSG 2018 (Österreich)

---

## Übersicht aller Befunde

| Nr | Datei | Thema | Schweregrad |
|---|---|---|---|
| 01 | [befund-01](./befund-01-art14-mitgruender.md) | Art. 14 DSGVO — Mitgründer ohne Datenschutzinformation | **KRITISCH** |
| 02 | [befund-02](./befund-02-joint-controller.md) | Joint Controller (Art. 26) vs. Auftragsverarbeiter (Art. 28) | **KRITISCH** |
| 03 | [befund-03](./befund-03-leads-outreach-localstorage.md) | Leads & Outreach ohne Rechtsgrundlage (localStorage) | **HOCH** |
| 04 | [befund-04](./befund-04-rechtsgrundlage-ableitungen.md) | Rechtsgrundlage für abgeleitete Datenkategorien | **HOCH** |
| 05 | [befund-05](./befund-05-art22-signal-score.md) | Art. 22 DSGVO — Signal-Score & automatisierte Entscheidungen | **MITTEL** |
| 06 | [befund-06](./befund-06-dsfa-art35.md) | DSFA (Art. 35) — Datenschutz-Folgenabschätzung erforderlich | **KRITISCH** |
| 07 | [befund-07](./befund-07-dreistufentest-signal-score.md) | Dreistufentest — berechtigtes Interesse Signal-Score | **HOCH** |
| 08 | [befund-08](./befund-08-avv-scc-drittlandtransfer.md) | AVV + SCC + Drittlandtransfer (Supabase/Vercel) | **HOCH** |
| 09 | [befund-09](./befund-09-plattformbetreiber-eigenstaendiger-verantwortlicher.md) | Plattformbetreiber als eigenständiger Verantwortlicher | **KRITISCH** |
| 10 | [befund-10](./befund-10-art32-toms.md) | Art. 32 — Technische und organisatorische Maßnahmen | **HOCH** |
| 11 | [befund-11](./befund-11-art17-recht-auf-loeschung.md) | Art. 17 — Recht auf Löschung (technische Umsetzbarkeit) | **HOCH** |
| 12 | [befund-12](./befund-12-art33-34-datenpannenmeldung.md) | Art. 33/34 — Datenpannenmeldung & Incident Response | **HOCH** |
| 13 | [befund-13](./befund-13-datenschutzerklaerung-vollstaendigkeit.md) | Datenschutzerklärung — Vollständigkeit & Lücken | **KRITISCH** |

---

## Zusammenfassung

- **4× KRITISCH** — Befunde 01, 02, 06, 09, 13
- **9× HOCH** — Befunde 03, 04, 07, 08, 10, 11, 12

Die neue Datenschutzerklärung v2.0 (basierend auf allen 13 Befunden) befindet sich unter `/datenschutz/index.html`.

---

*Dieser Audit ersetzt keine anwaltliche Beratung. Für rechtlich verbindliche Einschätzungen ist qualifizierter Rechtsrat einzuholen.*
