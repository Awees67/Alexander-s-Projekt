# Befund 10 — Art. 32 DSGVO: Technische und organisatorische Maßnahmen (TOMs)

**Datum:** 07. Juni 2026  
**Schweregrad:** HOCH  
**Status:** Handlungsbedarf identifiziert  
**Betroffene Norm:** Art. 32 DSGVO, ErwGr. 83, NIS-2-Umsetzungsgesetz (DE, ab 06.12.2025)

---

## 1. Ist-Zustand

**Implementierte TOMs:**
- Supabase RLS (fund_id-Isolation)
- Service Role Key serverseitig
- Rate Limiting auf /api/submit.js
- Magic Link Auth
- Supabase Frankfurt (EU-Hosting)

**Fehlende / nicht dokumentierte TOMs:**
- Verschlüsselung at-rest/in-transit nicht schriftlich dokumentiert
- Zugriffsprotokollierung (Audit Log) fehlt
- Backup-Konzept ohne dokumentiertes RTO/RPO
- Kein Penetrationstest durchgeführt
- Kein Sicherheitskonzept / Informationssicherheitsrichtlinie
- Keine dokumentierten Mitarbeiterschulungen
- Kein Notfall- und Wiederherstellungsplan

## 2. Kernproblem

Das Rechenschaftsprinzip (Art. 5 Abs. 2) verlangt Nachweisfähigkeit. Ohne schriftliche TOM-Dokumentation — auch wenn Massnahmen technisch implementiert sind — besteht formale Verletzung. Im AVV (Art. 28 Abs. 3 lit. c) müssen TOMs als Anhang vorliegen.

## 3. Handlungsbedarf

**Sofortmassnahmen (0–4 Wochen):**
1. TOM-Dokument als AVV-Anhang erstellen
2. Supabase-Einstellungen dokumentieren (AES-256 at-rest, TLS 1.2/1.3)
3. Backup-Policy: Supabase PITR, RTO/RPO definieren (z.B. RTO: 4h, RPO: 24h)

**Mittelfristig (1–3 Monate):**
4. Zugriffsprotokollierung: Supabase Audit Logging aktivieren (mind. 6 Monate Retention)
5. Vertraulichkeitsverpflichtung für alle Mitarbeiter/Auftragnehmer
6. Einmaliger Penetrationstest (Fokus: RLS-Bypass, API-Injection, Auth-Bypass)
7. Jährliche Datenschutz-Grundschulung dokumentieren

**Langfristig (3–12 Monate):**
8. Jährliche TOM-Überprüfung
9. NIS-2-Gap-Analyse

## 4. Fazit

Solider technischer Unterbau vorhanden. Die schriftliche TOM-Dokumentation fehlt vollständig — das ist die gravierendste Lücke. **Schweregrad: HOCH** — kein unmittelbares Bußgeldrisiko, aber erhebliche Compliance-Lücke.

---

*Quellen: Art. 32 DSGVO, ErwGr. 83, Art. 28 Abs. 3 lit. c, NIS-2-Umsetzungsgesetz DE (06.12.2025), Art. 5 Abs. 2 DSGVO*
