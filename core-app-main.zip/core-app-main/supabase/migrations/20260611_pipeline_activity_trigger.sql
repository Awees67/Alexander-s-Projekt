-- Serverseitige Pflege der Aktivitaetsfelder auf public.pipeline.
-- last_activity_by wird aus auth.uid() abgeleitet (fund_members.name) und kann
-- damit nicht mehr vom Client gefaelscht oder durch vergessene Code-Pfade
-- inkonsistent werden. Schreibt ein Kontext ohne auth.uid() (z.B. Service Role),
-- bleibt der vom Client gelieferte Wert erhalten.
--
-- Angewendet auf Projekt ggfjgzjevyemwbclvfpp am 2026-06-11 via MCP apply_migration
-- (Migrationsname: pipeline_activity_trigger).

create or replace function public.set_pipeline_activity()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  member_name text;
begin
  if auth.uid() is not null then
    select m.name into member_name
    from public.fund_members m
    where m.user_id = auth.uid()
      and m.fund_id = new.fund_id;

    if member_name is not null then
      new.last_activity_by := member_name;
    end if;
  end if;

  new.last_activity_at := now();
  new.last_updated := now();
  return new;
end;
$$;

drop trigger if exists trg_pipeline_set_activity on public.pipeline;
create trigger trg_pipeline_set_activity
  before insert or update on public.pipeline
  for each row
  execute function public.set_pipeline_activity();

-- Trigger-Funktionen brauchen kein EXECUTE fuer API-Rollen; der Trigger selbst
-- laeuft unabhaengig davon (Advisor-Lints 0028/0029).
revoke execute on function public.set_pipeline_activity() from public, anon, authenticated;
