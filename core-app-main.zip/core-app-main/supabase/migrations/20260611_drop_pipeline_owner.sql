-- Entfernt die redundante owner-Textspalte aus pipeline.
-- Die Zuweisung laeuft vollstaendig ueber assigned_member_id (FK auf
-- fund_members); der Anzeigename kommt aus dem Join (assigned_name).
--
-- pipeline_view (Convenience-View, nicht vom Frontend genutzt) hing an der
-- Spalte und wird ohne owner, dafuer mit Zuweisungs-/Aktivitaetsfeldern und
-- security_invoker neu aufgebaut (vorher lief sie mit Owner-Rechten an RLS vorbei).
--
-- Angewendet auf Projekt ggfjgzjevyemwbclvfpp am 2026-06-11 via MCP apply_migration
-- (Migrationsname: drop_pipeline_owner), NACH Merge des Frontend-Stands ohne
-- owner-Schreibzugriffe.

drop view if exists public.pipeline_view;

alter table public.pipeline drop column if exists owner;

create view public.pipeline_view
with (security_invoker = true) as
select p.id,
       p.fund_id,
       p.submission_id,
       s.company_name,
       s.anon_id,
       p.status,
       m.name as assigned_name,
       p.decline_reason,
       p.decline_note,
       p.last_activity_at,
       p.last_activity_by,
       p.last_activity_action,
       p.last_updated,
       p.created_at
  from public.pipeline p
  left join public.submissions s on s.id = p.submission_id
  left join public.fund_members m on m.id = p.assigned_member_id;
