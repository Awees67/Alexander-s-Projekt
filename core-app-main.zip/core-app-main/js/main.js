/* =========================
   SUBMISSIONS → STARTUPS BRIDGE
   Maps raw Supabase submission rows into the startup object shape that all
   renderers, the score engine, and the detail modal expect.
========================= */
function buildStartupFromSubmission(sub) {
  const mrr = Number(sub.mrr_eur || 0);
  const arr = Number(sub.arr_eur || mrr * 12);
  const burn = Number(sub.burn_eur_per_month || 0);
  const runway = sub.runway_months != null ? Number(sub.runway_months) : null;
  const cac = Number(sub.cac_eur || 0);
  const ltv = Number(sub.ltv_eur || 0);
  const ltv_cac = sub.ltv_cac_ratio != null
    ? Number(sub.ltv_cac_ratio)
    : (cac > 0 ? Number((ltv / cac).toFixed(1)) : null);
  // Net New MRR (monatlich, Doku §13) — Fallback für Altzeilen ohne Backfill: ARR/12
  const net_new_mrr = Number(sub.net_new_mrr_eur || (sub.net_new_arr_eur ? sub.net_new_arr_eur / 12 : 0));
  const burn_multiple = sub.burn_multiple != null
    ? Number(sub.burn_multiple)
    : (net_new_mrr > 0 ? Number((burn / net_new_mrr).toFixed(2)) : null);

  return {
    anon_id:              String(sub.anon_id || sub.id || ''),
    _supabase_id:         String(sub.id || ''),
    company_name:         String(sub.company_name || sub.anon_id || ''),
    contact_name:         String(sub.contact_name || ''),
    contact_email:        String(sub.contact_email || ''),
    origin_country:       String(sub.origin_country || ''),
    market_served:        Array.isArray(sub.market_served) ? sub.market_served : ['DACH'],
    stage:                String(sub.stage || ''),
    sector:               String(sub.sector || ''),
    sub_sector:           sub.sub_sector ? String(sub.sub_sector) : null,
    team_size:            Number(sub.team_size || 0),
    founded_year:         sub.founded_year != null ? Number(sub.founded_year) : null,
    description:          String(sub.description || ''),
    notes:                String(sub.notes || ''),

    mrr_eur:              mrr,
    arr_eur:              arr,
    burn_eur_per_month:   burn,
    runway_months:        runway,
    net_new_mrr_eur:      net_new_mrr,

    growth: {
      type:      'MoM',
      value_pct: Number(sub.growth_pct || 0)
    },

    nrr_pct:              sub.nrr_pct != null ? Number(sub.nrr_pct) : null,
    gross_margin_pct:     sub.gross_margin_pct != null ? Number(sub.gross_margin_pct) : null,
    logo_churn_pct:       sub.logo_churn_pct != null ? Number(sub.logo_churn_pct) : null,
    revenue_churn_pct:    sub.revenue_churn_pct != null ? Number(sub.revenue_churn_pct) : null,

    cac_eur:              cac,
    ltv_eur:              ltv,
    ltv_cac_ratio:        ltv_cac,
    cac_payback_months:   sub.cac_payback_months != null ? Number(sub.cac_payback_months) : null,
    burn_multiple:        burn_multiple,

    paying_customers:     sub.paying_customers != null ? Number(sub.paying_customers) : null,
    arpa_eur:             sub.arpa_eur != null ? Number(sub.arpa_eur) : null,
    acv_eur:              sub.acv_eur != null ? Number(sub.acv_eur) : null,

    // Server-seitige Plausibility reist mit ins Startup-Objekt — die Submission
    // verschwindet nach dem Accept aus dem (pending-)Cache, Badge/Breakdown/Score
    // brauchen die Werte aber weiterhin.
    plausibility_status:  sub.plausibility_status || null,
    plausibility_checks:  Array.isArray(sub.plausibility_checks) ? sub.plausibility_checks : null,
    plausibility_summary: sub.plausibility_summary || null,

    tam_eur:              sub.tam_eur != null ? Number(sub.tam_eur) : null,
    sam_eur:              sub.sam_eur != null ? Number(sub.sam_eur) : null,

    ticket_eur:           Number(sub.ticket_eur || 0),
    valuation_eur:        sub.valuation_eur != null ? Number(sub.valuation_eur) : null,
    total_raised_eur:     sub.total_raised_eur != null ? Number(sub.total_raised_eur) : null,
    investor_count:       sub.investor_count != null ? Number(sub.investor_count) : null,
    valuation_arr_multiple: (sub.valuation_eur != null && arr > 0)
      ? Number((sub.valuation_eur / arr).toFixed(1))
      : null,
    capital_efficiency:   (sub.total_raised_eur != null && arr > 0)
      ? Number((sub.total_raised_eur / arr).toFixed(1))
      : null,
    founder_pct:          Number(sub.founder_pct || 0),
    investor_pct:         Number(sub.investor_pct || 0),
    employees_pct:        Number(sub.employees_pct || 0),

    founders:               Array.isArray(sub.founders) ? sub.founders : [],
    founder_count:          Number(sub.founder_count || (Array.isArray(sub.founders) ? sub.founders.length : 0)),
    has_repeat_founder:     !!sub.has_repeat_founder,
    has_prior_exit:         !!sub.has_prior_exit,
    has_technical_founder:  !!sub.has_technical_founder,
    has_domain_expert:      !!sub.has_domain_expert,
    max_founder_experience: Array.isArray(sub.founders) && sub.founders.some(f => Number(f.years_experience) > 0)
      ? Math.max(...sub.founders.map(f => Number(f.years_experience || 0)))
      : null,
    founders_with_exit_count: Array.isArray(sub.founders)
      ? sub.founders.filter(f => !!f.had_exit).length
      : null,
    team_note:              sub.team_note ? String(sub.team_note) : '',
    pitch_deck_url:         sub.pitch_deck_url ? String(sub.pitch_deck_url) : null,

    ebitda_margin_pct:    { from: 0, to: 0 },

    submitted_at:         sub.submitted_at || sub.created_at || null,
    _from_submission:     true
  };
}

function injectSubmissionsIntoStartups(rawSupabaseSubs) {
  if (!Array.isArray(rawSupabaseSubs) || !rawSupabaseSubs.length) return;
  const existingIds = new Set((window.startups || []).map(s => String(s.anon_id)));
  const toInject = rawSupabaseSubs
    .filter(sub => {
      const id = String(sub.anon_id || sub.id || '');
      return id && !existingIds.has(id);
    })
    .map(buildStartupFromSubmission);
  if (!toInject.length) return;
  window.startups = [...toInject, ...(window.startups || [])];
  startups = window.startups;
  try { _cache = {}; } catch(_) {}
}

document.addEventListener("DOMContentLoaded", async ()=>{

  // Retention-Fristen für lokale Daten durchsetzen (Datenschutzerklärung §4/§8/§12)
  // — bewusst vor dem Auth-Guard, damit die Bereinigung auch ohne Session läuft.
  try{ pruneExpiredLocalData(); }catch(e){ console.warn('[CORE] Retention-Prune fehlgeschlagen:', e); }

  // ── Auth guard ──────────────────────────────────────────────────────────
  // getSession() automatically exchanges a magic-link token in the URL if present.
  try {
    const { data: { session } } = await supabaseClient.auth.getSession();
    if (!session) {
      window.location.href = 'login.html';
      return;
    }
    window._authSession = session;
    window.fundName = null;
  } catch (e) {
    console.error('[CORE] Auth check failed:', e.message);
    window.location.href = 'login.html';
    return;
  }
  // ────────────────────────────────────────────────────────────────────────

  // Fund laden — kein fund_users Eintrag = nicht autorisierter User → ausloggen
  try {
    const fund = await getCurrentFund();
    if (!fund) {
      await supabaseClient.auth.signOut();
      window.location.href = 'login.html?error=unauthorized';
      return;
    }
    window.fundName = fund.name;
    const fundBadge = document.getElementById('fundBadge');
    if (fundBadge && fund.name) {
      document.getElementById('fundBadgeName').textContent = fund.name;
      fundBadge.title = fund.name; // sichtbar, wenn schmale Breakpoints den Namen ausblenden
      fundBadge.hidden = false;
    }
  } catch (e) {
    console.warn('[CORE] Fund load failed:', e.message);
    await supabaseClient.auth.signOut();
    window.location.href = 'login.html?error=unauthorized';
    return;
  }

  // Startups werden ausschliesslich via injectSubmissionsIntoStartups() befuellt
  startups = [];
  window.startups = startups;
  try{ _cache = {}; }catch(_){}

  // Preload Supabase caches (submissions + pipeline + activity) before first render
  if (window._authSession) {
    try {
      await ensureSubmissionsLoaded();
      const fund_id = await getCurrentFundId();
      const accepted = await apiLoadAcceptedSubmissions(fund_id);
      injectSubmissionsIntoStartups(accepted);
      await ensurePipelineLoaded();
      await ensureActivityLoaded();
    } catch (e) {
      console.warn('[CORE] Supabase cache preload failed:', e.message);
    }
  }

  // Eingeloggten User im Header anzeigen: Member-Profil (Name · Rolle),
  // Fallback E-Mail wenn der Login kein fund_members-Profil hat.
  try {
    await ensureFundMembersLoaded();
    const me = await getCurrentMember();
    const email = window._authSession?.user?.email || '';
    const label = me?.name || email;
    if (label) {
      const initials = label.split(/[\s.@_-]+/).filter(Boolean)
        .slice(0, 2).map(s => s[0].toUpperCase()).join('') || '?';
      const badge = document.getElementById('userBadge');
      document.getElementById('userBadgeName').textContent = label;
      document.getElementById('userBadgeIni').textContent = initials;
      badge.title = me
        ? `Angemeldet als ${me.name}${me.role ? ' (' + me.role + ')' : ''} — ${email}`
        : `Angemeldet als ${email}`;
      badge.hidden = false;
    }
  } catch (e) {
    console.warn('[CORE] User-Badge konnte nicht gesetzt werden:', e.message);
  }

  on("logoutBtn", "click", async () => {
    try { await supabaseClient.auth.signOut(); } catch (_) {}
    window.location.href = 'login.html';
  });

  ensurePipelineIdsExist();

  forceDarkTheme();

  on("openFilterBtn","click", openFilterModal);
  on("filterCloseBtn","click", closeFilterModal);
  on("filterBackdrop","click", (e)=>{
    if(e.target.id==="filterBackdrop") closeFilterModal();
  });

  on("advToggle","change", (e)=>{
    document.getElementById("advFields").style.display = e.target.checked ? "" : "none";
  });

  on("applyFiltersBtn","click", applyFilterModal);
  on("resetFiltersBtn","click", ()=>{
    resetFiltersAll();
    syncFilterModalFromState();
  });

  attachWorkspaceHandlers();
  updateCompareTray();

  loadUIState();
  renderCurrent();
  updateCounts();

  on("searchInput","input", ()=>{
    saveUIState();
    if(currentView==="home") renderCards();
  });

  on("sortSelect","change", ()=>{
    saveUIState();
    if(currentView==="home") renderCards();
  });

  // Header bleibt bei offenem Detail-Modal sichtbar — Nav-Klick schließt es
  function navTo(view){
    try{
      if(document.getElementById("modalBackdrop")?.style.display === "flex") closeModal();
    }catch(_){}
    currentView = view;
    renderCurrent();
  }

  on("navDashboard","click", ()=>navTo("dashboard"));
  on("navHome","click", ()=>navTo("home"));
  on("navSubmissions","click", ()=>navTo("submissions"));
  on("navPipeline","click", ()=>navTo("pipeline"));
  on("navCompare","click", ()=>navTo("compare"));
  on("navActivity","click", ()=>navTo("activity"));
  on("navInbox","click", ()=>navTo("inbox"));

  on("topTabDashboard",  "click", ()=>navTo("dashboard"));
  on("topTabHome",       "click", ()=>navTo("home"));
  on("topTabSubmissions","click", ()=>navTo("submissions"));
  on("topTabPipeline",   "click", ()=>navTo("pipeline"));
  on("topTabCompare",    "click", ()=>navTo("compare"));
  on("topTabActivity",   "click", ()=>navTo("activity"));
  on("topTabInbox",      "click", ()=>navTo("inbox"));

  on("navScore","click", ()=>{ if(typeof openCustomIndex === "function") openCustomIndex(); });
  document.getElementById('navWeeklyTop5')?.addEventListener('click', openWeeklyTop5Modal);


  on("clearAllFiltersBtn","click", ()=>{
    resetFiltersAll();
    toast("OK","Filter gelöscht");
  });

  on("modalClose","click", closeModal);
  on("modalBackdrop","click", (e)=>{
    if(e.target.id==="modalBackdrop") closeModal();
  });

  // global click -> close dropdowns
  document.addEventListener("click",(e)=>{
    const dd = e.target.closest(".dd");
    if(!dd) closeAllDropdowns();
  });

  document.addEventListener("keydown",(e)=>{
    if(e.key==="Escape"){
      closeModal();
      closeFilterModal();
      closeSignalPopover();
      if(typeof closeDeclineDialog === "function") closeDeclineDialog();
      const _otBd = document.getElementById('otSendBackdrop'); if(_otBd && _otBd.style.display==='flex'){ _otBd.style.display='none'; _otBd.setAttribute('aria-hidden','true'); document.body.classList.remove('no-scroll'); }
    }
    if((e.ctrlKey || e.metaKey) && e.key.toLowerCase()==="k"){
      e.preventDefault();
      document.getElementById("searchInput").focus();
      toast("Suche", "Fokus gesetzt");
    }
    if(document.getElementById("modalBackdrop").style.display === "flex"){
      if(e.key === "ArrowRight") document.getElementById("dvNextBtn")?.click();
      if(e.key === "ArrowLeft") document.getElementById("dvPrevBtn")?.click();
    }
  });
});


/* =========================
   RUNTIME OVERRIDES & ENHANCEMENTS
========================= */
(function(){
  if(window.__CORE_APP_V1__) return;
  window.__CORE_APP_V1__ = true;

  /* ---------- Popover scroll lock (overlay scrolls, background doesn't) ---------- */
  try{
    const _open = window.openSignalPopover;
    const _close = window.closeSignalPopover;
    window.openSignalPopover = function(anchorEl, html, anon_id=null){
      try{
        const b = document.body;
        if(b && b.style.overflow !== "hidden"){
          b.dataset._prevOverflow = b.style.overflow || "";
          b.style.overflow = "hidden";
        }
      }catch(_){}
      return _open(anchorEl, html, anon_id);
    };
    window.closeSignalPopover = function(){
      const res = _close();
      try{
        const b = document.body;
        if(b){
          b.style.overflow = (b.dataset._prevOverflow || "");
          delete b.dataset._prevOverflow;
        }
      }catch(_){}
      return res;
    };
    // Close on ESC should also restore (already calls closeSignalPopover)
  }catch(_){}

  /* ---------- Status dropdown colors: blue except Invested (green) / Passed (red) ---------- */
  function applyStatusColorToSelect(sel){
    if(!sel) return;
    const v = String(sel.value || "Screening");
    sel.classList.add("statusSel");
    sel.classList.remove("status-blue","status-green","status-red");
    if(v === "Invested") sel.classList.add("status-green");
    else if(v === "Passed") sel.classList.add("status-red");
    else sel.classList.add("status-blue");
  }
  function applyPipelineStatusColors(root){
    (root || document).querySelectorAll('select[data-status]').forEach(sel=>{
      applyStatusColorToSelect(sel);
      if(!sel._v5Colored){
        sel.addEventListener("change", ()=>applyStatusColorToSelect(sel));
        sel._v5Colored = true;
      }
    });
  }

  /* ---------- Compare v2 (Mockup Juni 2026): Deals als Zeilen, Metriken als Spalten ----------
     Farblogik Doku §9: Balken und Wert tragen exakt dieselbe Hex-Farbe.
     Stufen: best = Spaltenbester (#22c55e, mit BEST-Label), good #86efac,
     weak #6b7280, bad #ef4444. Balkenbreite = Qualitätsanteil:
     higher-better → v/max, lower-better → best/v (Spaltenbester = volle Breite). */
  const CMP_Q = { best:"#22c55e", good:"#86efac", weak:"#6b7280", bad:"#ef4444" };
  const cmpStageDot = (stage)=>{
    const st = String(stage || "");
    if(st === "Pre-Seed") return "#fbbf24";
    if(st === "Seed" || st === "Pre-Series A") return "#a78bfa";
    if(st.startsWith("Series")) return "#00dfc1";
    return "#8892a4";
  };
  const cmpNum = (s, key)=>{
    const n = Number(s?.[key]);
    return (s?.[key] == null || !Number.isFinite(n)) ? null : n;
  };
  const cmpEUR = (v)=> "€" + Math.round(v).toLocaleString("de-DE");
  const cmpDec = (v)=> (Math.round(v*10)/10).toFixed(1);
  const CMP_METRICS = [
    { label:"MRR", sub:"Monthly Recurring",
      get:(s)=> Number(s?.mrr_eur ?? (s?.mrr && (s.mrr.value_eur ?? s.mrr.value ?? s.mrr.eur)) ?? 0),
      fmt:cmpEUR,
      rate:(v,ctx)=> ctx.max > 0 ? (v/ctx.max >= 0.5 ? "good" : v/ctx.max >= 0.15 ? "weak" : "bad") : "weak" },
    { label:"Wachstum", sub:"MoM %",
      get:(s)=> Number(s?.growth?.value_pct ?? s?.growth_pct ?? (s?.growth && (s.growth.pct ?? s.growth.value)) ?? 0),
      fmt:(v)=> (v > 0 ? "+" : "") + Math.round(v) + " %",
      rate:(v)=> v >= 25 ? "good" : v >= 5 ? "weak" : "bad" },
    { label:"NRR", sub:"Net Rev. Retention",
      get:(s)=> cmpNum(s, "nrr_pct"),
      fmt:(v)=> Math.round(v) + " %",
      rate:(v)=> v >= 95 ? "good" : v >= 70 ? "weak" : "bad" },
    { label:"CAC Payback", sub:"Mo. · ↓ besser", lowerBetter:true,
      get:(s)=> cmpNum(s, "cac_payback_months"),
      fmt:(v)=> Math.round(v) + " Mo.",
      rate:(v)=> v <= 24 ? "good" : v <= 36 ? "weak" : "bad" },
    { label:"LTV / CAC", sub:"GM-adjustiert",
      get:(s)=>{
        let lv = (s?.ltv_cac_ratio ?? s?.ltv_cac ?? s?.ltvcac ?? s?.ltvCac ?? s?.unit?.ltv_cac_ratio ?? s?.unit?.ltv_cac ?? s?.unit?.ltvCac);
        if(typeof lv === "string") lv = lv.replace(",", ".");
        const n = Number(lv);
        return (lv == null || !Number.isFinite(n)) ? null : n;
      },
      fmt:(v)=> cmpDec(v) + " ×",
      rate:(v)=> v >= 2 ? "good" : v >= 1 ? "weak" : "bad" },
    { label:"Runway", sub:"Monate",
      get:(s)=> cmpNum(s, "runway_months"),
      fmt:(v)=> Math.round(v) + " Mo.",
      rate:(v)=> v >= 18 ? "good" : v >= 14 ? "weak" : "bad" },
    { label:"Burn Multiple", sub:"↓ besser", lowerBetter:true,
      get:(s)=> cmpNum(s, "burn_multiple"),
      fmt:(v)=> cmpDec(v) + " ×",
      rate:(v)=> v <= 1.8 ? "good" : v < 3 ? "weak" : "bad" },
  ];

  window.renderCompare = function(){
  hideAllViews();
  const v = document.getElementById("viewCompare");
  v.style.display = "";

  const ids = getCompare();
  const deals = ids.map(id=>startups.find(s=>s.anon_id===id)).filter(Boolean);

  v.innerHTML = `
    <div class="cmp3-head">
      <div class="panelhead">
        <h2>Compare</h2>
        <div class="note">${deals.length} ${deals.length === 1 ? "Deal" : "Deals"} · bester Wert je Spalte hervorgehoben</div>
      </div>
      <div class="cmp3-actions">
        <button class="cmp3-btn" id="compareExportBtn">Export</button>
        <button class="cmp3-btn cmp3-btn-danger" id="compareClearBtn">Liste leeren</button>
      </div>
    </div>
    <div class="cmp3-wrap">
      <table class="cmp3-table" aria-label="Compare Metrik-Matrix">
        <thead>
          <tr>
            <th class="cmp3-th-name"></th>
            ${CMP_METRICS.map(m=>`
              <th>
                <div class="cmp3-th-l">${escapeHTML(m.label)}</div>
                <div class="cmp3-th-s">${escapeHTML(m.sub)}</div>
              </th>`).join("")}
          </tr>
        </thead>
        <tbody id="compareBody"></tbody>
      </table>
    </div>
  `;

  document.getElementById("compareExportBtn").onclick = ()=>{
    downloadJSON("core_compare_export.json", deals.map(s=>({
      anon_id: s.anon_id,
      company_name: s.company_name || s.anon_id,
      stage: s.stage,
      sector: s.sector,
      mrr_eur: s.mrr_eur,
      growth_pct: s.growth?.value_pct,
      nrr_pct: s.nrr_pct,
      cac_payback_months: s.cac_payback_months,
      ltv_cac_ratio: s.ltv_cac_ratio,
      runway_months: s.runway_months,
      burn_multiple: s.burn_multiple
    })));
  };
  document.getElementById("compareClearBtn").onclick = ()=>{
    if(!getCompare().length) return;
    clearCompare();
    toast("Compare", "Liste geleert");
    window.renderCompare();
  };

  const body = v.querySelector("#compareBody");
  if(!deals.length){
    body.innerHTML = `<tr><td class="cmp3-empty" colspan="${CMP_METRICS.length + 1}">
      Keine Deals im Compare. Füge Deals über „Add to Compare" hinzu.
    </td></tr>`;
    return;
  }

  // Pro Spalte: Werte aller Deals + Spaltenbester (markiert ab 2 vergleichbaren Werten)
  const cols = CMP_METRICS.map(m=>{
    const vals = deals.map(s=>{
      const n = m.get(s);
      return (n == null || !Number.isFinite(n)) ? null : n;
    });
    const present = vals.filter(n=>n != null);
    const max = present.length ? Math.max(...present) : null;
    const min = present.length ? Math.min(...present) : null;
    return { m, vals, max, min, best: m.lowerBetter ? min : max, markBest: present.length >= 2 };
  });

  body.innerHTML = deals.map((s, i)=>{
    const name = escapeHTML(s.company_name || s.anon_id);
    const meta = [s.stage, s.sector].filter(Boolean).join(" · ");
    const cells = cols.map(({ m, vals, max, min, best, markBest })=>{
      const val = vals[i];
      if(val == null){
        return `<td><div class="cmp3-cell">
          <div class="cmp3-bar"></div>
          <div class="cmp3-vrow"><span class="cmp3-val cmp3-val-na">—</span></div>
        </div></td>`;
      }
      const isBest = markBest && val === best;
      let pct;
      if(m.lowerBetter){
        if(val === best) pct = 100;
        else if(best === 0 || val <= 0) pct = 0;
        else pct = Math.round((best / val) * 100);
      } else {
        pct = (max && max > 0) ? Math.round((Math.max(0, val) / max) * 100) : 0;
      }
      pct = Math.max(0, Math.min(100, pct));
      const color = isBest ? CMP_Q.best : (CMP_Q[m.rate(val, { max, min })] || CMP_Q.weak);
      return `<td><div class="cmp3-cell">
        <div class="cmp3-bar"><div class="cmp3-fill" style="width:${pct}%; background:${color};"></div></div>
        <div class="cmp3-vrow">
          <span class="cmp3-val" style="color:${color};">${escapeHTML(m.fmt(val))}</span>
          ${isBest ? `<span class="cmp3-best" style="color:${color};">Best</span>` : ""}
        </div>
      </div></td>`;
    }).join("");
    return `
      <tr>
        <td class="cmp3-name-td">
          <button class="cmp3-name" data-open="${escapeHTML(s.anon_id)}">${name}</button>
          ${meta ? `<div class="cmp3-meta"><span class="cmp3-dot" style="background:${cmpStageDot(s.stage)};"></span>${escapeHTML(meta)}</div>` : ""}
        </td>
        ${cells}
      </tr>
    `;
  }).join("");

  body.querySelectorAll("[data-open]").forEach(b=>{
    b.onclick = ()=> openModalByAnonId(b.getAttribute("data-open"), startups);
  });
};
window.renderCompare._v5 = true;

  /* ---------- Final: ensure colors apply on first pipeline open ---------- */
  // run once after initial paint
  setTimeout(()=>{ 
    try{ applyPipelineStatusColors(document); }catch(_){}
  }, 0);

})();