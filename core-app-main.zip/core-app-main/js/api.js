/* =========================
   SUPABASE API LAYER
   All functions are async and prefixed with `api` to avoid collisions
   with existing state.js globals (e.g. addNote, getPipeline).
========================= */

// Supabase/PostgREST liefert maximal 1000 Zeilen pro Request und kappt
// STILL — ohne Paging fehlen ab Zeile 1001 Datensätze ohne Fehlermeldung.
// buildQuery muss eine FRISCHE Query mit deterministischer Sortierung
// liefern (Tie-Breaker!), sonst können Zeilen zwischen Seiten verrutschen.
const API_PAGE_SIZE = 1000;

async function _apiFetchAllPages(buildQuery) {
  const all = [];
  for (let from = 0; ; from += API_PAGE_SIZE) {
    const { data, error } = await buildQuery().range(from, from + API_PAGE_SIZE - 1);
    if (error) throw error;
    const rows = data || [];
    all.push(...rows);
    if (rows.length < API_PAGE_SIZE) return all;
  }
}

async function apiLoadFund(slug) {
  const { data, error } = await supabaseClient
    .from('funds')
    .select('id, name, slug')
    .eq('slug', slug)
    .single();
  if (error) throw error;
  return data;
}

async function apiLoadFundForUser(user_id) {
  const { data, error } = await supabaseClient
    .from('fund_users')
    .select('funds(id, name, slug)')
    .eq('user_id', user_id)
    .single();
  if (error) throw error;
  return data?.funds || null;
}

async function apiLoadSubmissions(fund_id) {
  if (!fund_id) throw new Error('[apiLoadSubmissions] fund_id fehlt — kein Query ohne Fund-Filter');
  return _apiFetchAllPages(() => supabaseClient
    .from('submissions')
    .select('*')
    .eq('status', 'pending')
    .eq('fund_id', fund_id)
    .order('submitted_at', { ascending: false })
    .order('id', { ascending: true }));
}

async function apiLoadAcceptedSubmissions(fund_id) {
  if (!fund_id) throw new Error('[apiLoadAcceptedSubmissions] fund_id fehlt — kein Query ohne Fund-Filter');
  return _apiFetchAllPages(() => supabaseClient
    .from('submissions')
    .select('*')
    .eq('status', 'accepted')
    .eq('fund_id', fund_id)
    .order('submitted_at', { ascending: false })
    .order('id', { ascending: true }));
}

const PIPELINE_SELECT = '*, submissions!inner(anon_id, company_name), fund_members(name, role)';

function _mapPipelineRow(row) {
  return {
    ...row,
    _pipeline_id: row.id,
    anon_id: row.submissions?.anon_id || row.submission_id,
    assigned_name: row.fund_members?.name || '',
    assigned_role: row.fund_members?.role || '',
  };
}

async function apiLoadPipeline(fund_id) {
  const data = await _apiFetchAllPages(() => {
    let query = supabaseClient
      .from('pipeline')
      .select(PIPELINE_SELECT)
      .order('created_at', { ascending: false })
      .order('id', { ascending: true });
    if (fund_id) query = query.eq('fund_id', fund_id);
    return query;
  });
  return (data || []).map(_mapPipelineRow);
}

// Einzelzeilen-Refetch nach Mutationen (Audit P1.2): der DB-Trigger setzt
// last_activity_*/last_updated serverseitig — deshalb die Zeile frisch laden
// statt lokal zu patchen. Ersetzt den Komplett-Reload der ganzen Pipeline.
async function apiLoadPipelineRow(pipeline_id) {
  const { data, error } = await supabaseClient
    .from('pipeline')
    .select(PIPELINE_SELECT)
    .eq('id', pipeline_id)
    .single();
  if (error || !data) { console.error('apiLoadPipelineRow:', error); return null; }
  return _mapPipelineRow(data);
}

async function apiLoadPipelineRowBySubmission(submission_id) {
  const { data, error } = await supabaseClient
    .from('pipeline')
    .select(PIPELINE_SELECT)
    .eq('submission_id', submission_id)
    .single();
  if (error || !data) { console.error('apiLoadPipelineRowBySubmission:', error); return null; }
  return _mapPipelineRow(data);
}

async function apiLoadFundMembers(fund_id) {
  let query = supabaseClient.from('fund_members').select('*').order('created_at');
  if (fund_id) query = query.eq('fund_id', fund_id);
  const { data, error } = await query;
  if (error) { console.error('apiLoadFundMembers:', error); return []; }
  return data || [];
}

async function apiAddNote(fund_id, submission_id, text, author = 'Analyst') {
  const { data: userData } = await supabaseClient.auth.getUser();
  const payload = {
    text: String(text || '').trim(),
    author,
    created_at: new Date().toISOString(),
  };
  if (fund_id) payload.fund_id = fund_id;
  if (submission_id) payload.submission_id = String(submission_id);
  if (userData?.user?.id) payload.user_id = userData.user.id;
  const { data, error } = await supabaseClient
    .from('notes')
    .insert(payload)
    .select()
    .single();
  if (error) throw error;
  return data;
}

async function apiUpdatePipelineStatus(pipeline_id, status, decline_reason = null, decline_note = '', activity = null) {
  const now = new Date().toISOString();
  const patch = {
    status,
    last_updated: now,
    decline_reason: status === 'Declined' ? decline_reason : null,
    decline_note:   status === 'Declined' ? (decline_note || '') : '',
    last_activity_at: now,
    last_activity_by: activity?.by || null,
    last_activity_action: activity?.action
      || (status === 'Declined' ? 'Declined' : status === 'Synced' ? 'Push to CRM' : 'Stage geändert'),
  };
  // Zugewiesen folgt dem letzten Bearbeiter
  if (activity?.member_id) { patch.assigned_member_id = activity.member_id; }
  const { error } = await supabaseClient
    .from('pipeline')
    .update(patch)
    .eq('id', pipeline_id);
  if (error) throw error;
}

async function apiAcceptSubmission(submission_id) {
  const { error } = await supabaseClient
    .from('submissions')
    .update({ status: 'accepted' })
    .eq('id', submission_id);
  if (error) console.error('apiAcceptSubmission:', error);
  return !error;
}

async function apiDeclineSubmission(submission_id) {
  const { error } = await supabaseClient
    .from('submissions')
    .update({ status: 'declined' })
    .eq('id', submission_id);
  if (error) console.error('apiDeclineSubmission:', error);
  return !error;
}

// Bulk: EIN Update für N Zeilen statt N einzelner Requests (Audit P1.2)
async function apiUpdateSubmissionsStatus(submission_ids, status) {
  if (!submission_ids || !submission_ids.length) return true;
  const { error } = await supabaseClient
    .from('submissions')
    .update({ status })
    .in('id', submission_ids);
  if (error) { console.error('apiUpdateSubmissionsStatus:', error); return false; }
  return true;
}

async function apiRemoveFromPipelineBulk(pipeline_ids) {
  if (!pipeline_ids || !pipeline_ids.length) return true;
  const { error } = await supabaseClient
    .from('pipeline')
    .delete()
    .in('id', pipeline_ids);
  if (error) { console.error('apiRemoveFromPipelineBulk:', error); return false; }
  return true;
}

async function apiAddToPipeline(fund_id, submission_id, status = 'In Review', assigned = null) {
  const now = new Date().toISOString();
  const { error } = await supabaseClient
    .from('pipeline')
    .insert({
      fund_id,
      submission_id,
      status,
      created_at: now,
      last_updated: now,
      assigned_member_id: assigned?.id || null,
      last_activity_at: now,
      last_activity_by: assigned?.name || null,
      last_activity_action: status === 'Synced' ? 'Push to CRM' : 'Zur Pipeline hinzugefügt',
    });
  if (error) console.error('apiAddToPipeline:', error);
  return !error;
}

async function apiRemoveFromPipeline(pipeline_id) {
  const { error } = await supabaseClient
    .from('pipeline')
    .delete()
    .eq('id', pipeline_id);
  if (error) console.error('apiRemoveFromPipeline:', error);
  return !error;
}

async function apiLoadNotes(submission_id) {
  const { data, error } = await supabaseClient
    .from('notes')
    .select('id, submission_id, text, author, created_at')
    .eq('submission_id', submission_id)
    .order('created_at', { ascending: false });
  if (error) { console.error('apiLoadNotes:', error); return []; }
  return data || [];
}

async function apiDeleteNote(note_id) {
  const { error } = await supabaseClient
    .from('notes')
    .delete()
    .eq('id', note_id);
  if (error) console.error('apiDeleteNote:', error);
  return !error;
}

async function apiLoadActivity(fund_id, limit = 500) {
  if (!fund_id) return [];
  const { data, error } = await supabaseClient
    .from('activity_log')
    .select('id, event, anon_id, submission_id, meta, created_at')
    .eq('fund_id', fund_id)
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) { console.error('apiLoadActivity:', error); return []; }
  return data || [];
}

async function apiLogActivity(fund_id, event, anon_id = null, submission_id = null, meta = null) {
  const payload = {
    fund_id,
    event: String(event || ''),
    anon_id: anon_id ? String(anon_id) : null,
    meta: meta || {},
  };
  if (submission_id) payload.submission_id = submission_id;
  const user_id = window._authSession?.user?.id;
  if (user_id) payload.user_id = user_id;
  const { data, error } = await supabaseClient
    .from('activity_log')
    .insert(payload)
    .select('id, created_at')
    .single();
  if (error) { console.error('apiLogActivity:', error); return null; }
  return data;
}
