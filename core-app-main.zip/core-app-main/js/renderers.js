/* =========================
   RENDERERS — ROUTING & APP ACTIONS
   View-specific renderers have been split into:
     renderers-helpers.js    — hideAllViews, updateCounts, renderMiniKPI
     renderers-dashboard.js  — renderDashboard
     renderers-cards.js      — renderCards, _buildScoreRing, renderActiveChips
     renderers-submissions.js— renderSubmissions
     renderers-pipeline.js   — renderPipeline, stageBadgeClass
     renderers-compare.js    — renderCompare, addToCompare, updateCompareTray
     renderers-activity.js   — renderActivity
     renderers-inbox.js      — renderInbox
     renderers-modals.js     — openModal*, closeModal, openDeclineDialog, syncModalPipelineButtons
========================= */

/* =========================
   ROUTING
========================= */
function setActiveNav(){
  // Horizontale Tab-Bar
  const tabMap = {
    dashboard:  "topTabDashboard",
    home:       "topTabHome",
    submissions:"topTabSubmissions",
    pipeline:   "topTabPipeline",
    compare:    "topTabCompare",
    activity:   "topTabActivity",
    inbox:      "topTabInbox"
  };
  document.querySelectorAll(".viewnav-tab").forEach(t => t.classList.remove("active"));
  const activeTabId = tabMap[currentView] || "topTabDashboard";
  const activeTab = document.getElementById(activeTabId);
  if(activeTab) activeTab.classList.add("active");

  // Views, die bereits auf Design System v2 (dark-only) umgestellt sind
  const V2_DARK_VIEWS = ["submissions", "pipeline", "compare"];
  document.body.classList.toggle("v2-dark", V2_DARK_VIEWS.includes(currentView));
}

function renderCurrent(){
  setActiveNav();
  bulkSelection.clear(); // Clear bulk selection on every view change to prevent leaking across tabs

  if(currentView==="dashboard") renderDashboard();
  if(currentView==="home") renderCards();
  if(currentView==="submissions") renderSubmissions();
  if(currentView==="pipeline") renderPipeline();
  if(currentView==="compare") renderCompare();
  if(currentView==="activity") renderActivity();
  if(currentView==="inbox") renderInbox();

  saveUIState();
}

/* =========================
   UI STATE SAVE/LOAD
========================= */
function saveUIState(){
  const state = {
    view: currentView,
    search: document.getElementById("searchInput").value,
    sort: document.getElementById("sortSelect").value,
    filters: serializeFilters()
  };
  safeSetJSON(LS_KEYS.ui, state);
}

function loadUIState(){
  const state = safeGetJSON(LS_KEYS.ui, null);
  if(!state) return;

  if(state.view) currentView = (["dashboard","home","submissions","pipeline","compare","activity","inbox"].includes(state.view) ? state.view : "dashboard");
  if(typeof state.search==="string") document.getElementById("searchInput").value = state.search;
  if(typeof state.sort==="string") document.getElementById("sortSelect").value = state.sort;

  applyFilterObject(state.filters || {});
}

/* =========================
   RESET + RANDOMIZE
========================= */

function ensurePipelineIdsExist(){
  // If Pipeline contains anon_ids that are not in the current dataset (e.g. after Dataset neu mischen),
  // replace them with existing ids so Custom/Signal calculations work and Preview can show them.
  try{
    const p = (typeof getPipeline === "function") ? getPipeline() : [];
    if(!Array.isArray(p) || !p.length) return;
    if(!Array.isArray(startups) || !startups.length) return;

    const existing = new Set(startups.map(s=>String(s.anon_id)));
    const used = new Set();
    const available = startups.map(s=>String(s.anon_id));

    let changed = false;
    const next = p.map(item=>{
      const cur = String(item.anon_id||"");
      if(existing.has(cur)){
        used.add(cur);
        return item;
      }
      // pick first not used, else first available
      const repl = available.find(id=>!used.has(id)) || available[0];
      if(repl){
        changed = true;
        used.add(repl);
        return { ...item, anon_id: repl, last_updated: Date.now() };
      }
      return item;
    });

    if(changed && typeof setPipeline === "function") setPipeline(next);
  }catch(_){}
}


/* =========================
   FILTER ACTIONS
========================= */
function captureCurrentFilterState(){ return serializeFilters(); }

async function saveCurrentFilters(){
  const name = await showInputModal('Filterset-Name eingeben');
  if (!name) return;
  const list = getSavedFilters();
  const entry = { id: uid(), name, filters: captureCurrentFilterState(), created_at: Date.now(), last_used_at: null };
  list.unshift(entry);
  setSavedFilters(list);
  activityLogAppend("FILTER_SAVED", null, { name });
  toast("Saved Filters","Gespeichert");
}

function applySavedFilter(id){
  const list = getSavedFilters();
  const item = list.find(x=>x.id===id);
  if(!item) return;

  applyFilterObject(item.filters || {});

  syncFilterModalFromState();
  item.last_used_at = Date.now();
  setSavedFilters(list);

  activityLogAppend("FILTER_APPLIED", null, { id, name: item.name });
  toast("Saved Filters","Angewendet");
  currentView = "home";
  renderCurrent();
}

function deleteSavedFilter(id){
  const list = getSavedFilters();
  const item = list.find(x=>x.id===id);
  setSavedFilters(list.filter(x=>x.id!==id));
  activityLogAppend("FILTER_DELETED", null, { id, name: item?item.name:null });
  toast("Saved Filters","Gelöscht");
}

/* =========================
   PIPELINE ACTIONS
========================= */
async function handleAddToPipeline(anon_id){
  const p = getPipeline();
  const existing = p.find(x=>x.anon_id===anon_id);
  if(existing){
    toast("Pipeline", "Deal ist bereits in der Pipeline");
    return;
  }
  const res = await pipelineAdd(anon_id, "In Review");
  if (!res) { toast("Fehler","Pipeline-Hinzufuegen fehlgeschlagen"); return; }
  activityLogAppend("PIPELINE_ADDED", anon_id, { status: "In Review" });
  toast("Pipeline", "Deal zur Pipeline hinzugefügt");
  if(currentView === "home") {
    const btn = document.querySelector(`[data-action="addpipeline"][data-id="${CSS.escape(anon_id)}"]`);
    if(btn) {
      btn.textContent = "✓ In Pipeline";
      btn.disabled = true;
    }
  }
  if(currentView === "pipeline") renderPipeline();
}

/* =========================
   WORKSPACE EVENT HANDLERS
========================= */
function attachWorkspaceHandlers(){
  // card buttons (delegation)
  document.addEventListener("click", (e)=>{
    const t = e.target;
    if(!(t instanceof HTMLElement)) return;

    const cid = t.getAttribute("data-compare");
    if(cid){
      addToCompare(cid);
      return;
    }
  });

}
