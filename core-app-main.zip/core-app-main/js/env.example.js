// Kopiere diese Datei zu js/env.js und trage echte Werte ein.
// js/env.js ist in .gitignore — wird niemals committed.
// Neue Keys erhältst du in: Supabase Dashboard → Project Settings → API
const SUPABASE_URL      = 'https://DEIN-PROJEKT-ID.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_XXXXXXXXXXXXXXXXXXXXXXXXXX';
