const supabaseClient = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_ANON_KEY
);

async function getCurrentUser() {
  const { data: { user }, error } = await supabaseClient.auth.getUser();
  if (error) throw error;
  return user;
}

async function getCurrentFundId() {
  const user = await getCurrentUser();
  if (!user) return null;
  const { data, error } = await supabaseClient
    .from('fund_users')
    .select('fund_id')
    .eq('user_id', user.id)
    .single();
  if (error) throw error;
  return data?.fund_id || null;
}

async function getCurrentFund() {
  const fund_id = await getCurrentFundId();
  if (!fund_id) return null;
  const { data, error } = await supabaseClient
    .from('funds')
    .select('id, name, slug')
    .eq('id', fund_id)
    .single();
  if (error) throw error;
  if (data?.name) window.fundName = data.name;
  return data;
}
