/* Safe DOM binding helper (prevents demo freeze if optional elements are missing) */
function on(id, evt, fn){ const el=document.getElementById(id); if(el) el.addEventListener(evt, fn); }

/* =========================
   UTIL: Seeded RNG (deterministic)
========================= */
function mulberry32(a){
  return function(){
    let t = a += 0x6D2B79F5;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function randInt(rng, min, max){
  return Math.floor(rng() * (max - min + 1)) + min;
}
function randChoice(rng, arr){
  return arr[Math.floor(rng() * arr.length)];
}
function clamp(n, a, b){ return Math.max(a, Math.min(b, n)); }

function uid(){
  return "id_" + Date.now().toString(36) + "_" + Math.floor(Math.random()*1e6).toString(36);
}

function escapeHTML(str){
  return String(str||"")
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#39;");
}

function downloadTextFile(filename, text){
  try{
    const blob = new Blob([text], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename || "export.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(()=>URL.revokeObjectURL(url), 1200);
    return true;
  }catch(e){
    return false;
  }
}

function downloadJSON(filename, data){
  try{
    const blob = new Blob([JSON.stringify(data, null, 2)], { type:"application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 0);
  }catch(e){}
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch(e) {
    console.warn('Clipboard write failed:', e);
  }
  toast('Kopiert');
}

function fmtEUR(n){ return (n || 0).toLocaleString("de-DE") + " €"; }
function fmtPct(n){
  if(n === null || n === undefined) return "—";
  const sign = n > 0 ? "+" : "";
  return sign + n + " %";
}
function fmtTicket(n){
  const v = n || 0;
  if(v >= 1000000) return (v/1000000).toFixed(2).replace(".",",") + "M€";
  if(v >= 1000) return (v/1000).toFixed(0) + "k€";
  return v + "€";
}
function startupLabel(s){
  return s?.company_name || `Startup ${s?.anon_id || "—"}`;
}
function computeBadge(s){
  const ue = classifyUE(s), rq = classifyRQ(s), ce = classifyCE(s);
  const g = s.growth?.value_pct ?? 0;
  if((ue === "Strong" || ue === "No Risk") && rq !== "Risk" && ce !== "Inefficient" && s.mrr_eur >= 60000 && g >= 20) return { cls:"good", text:"High signal" };
  if(g < 0 || rq === "Risk") return { cls:"watch", text:"Watch" };
  if(s.mrr_eur >= 120000) return { cls:"hot", text:"Hot" };
  return { cls:"", text:"Standard" };
}

function toast(title, sub){
  const t = document.getElementById("toast");
  t.innerHTML = `
    <div><strong>${escapeHTML(title || "OK")}</strong>${sub ? `<small>${escapeHTML(sub)}</small>` : ""}</div>
    <button class="toast-close" onclick="this.closest('.toast').style.display='none'" aria-label="Schließen">×</button>
  `;
  t.style.display = "flex";
  clearTimeout(toast._t);
  toast._t = setTimeout(()=>{ t.style.display = "none"; }, 4000);
}

/* =========================
   THEME (dark-only)
========================= */
function forceDarkTheme(){
  document.documentElement.setAttribute("data-theme","dark");
  // Alten Theme-Key aus der Light/Dark-Toggle-Ära entfernen
  try { localStorage.removeItem("core_theme_v1"); } catch (_) {}
}


/* =========================
   DASHBOARD HELPERS
========================= */
function timeAgo(ts){
  const diff = Date.now() - ts;
  if(diff < 60000) return "gerade eben";
  if(diff < 3600000) return "vor " + Math.floor(diff/60000) + " Min";
  if(diff < 86400000) return "vor " + Math.floor(diff/3600000) + " Std";
  return new Date(ts).toLocaleDateString("de-DE");
}

function groupBy(arr, keyFn){
  const map = {};
  arr.forEach(x=>{ const k = keyFn(x) || "—"; map[k] = (map[k]||0) + 1; });
  return Object.entries(map).sort((a,b)=>b[1]-a[1]);
}

function pctOf(part, total){
  return total > 0 ? Math.round((part/total)*100) : 0;
}

const DASHBOARD_EVENT_LABELS = {
  "SUBMISSION_ACCEPTED": "📥 Angenommen",
  "SUBMISSION_DECLINED": "📥 Abgelehnt",
  "PIPELINE_ADDED": "📋 Pipeline",
  "CRM_PUSHED": "🔗 CRM",
  "STATUS_CHANGED": "🔄 Status",
  "PIPELINE_REMOVED": "🗑 Entfernt",
  "COMPARE_ADDED": "⚖ Compare",
  "COMPARE_REMOVED": "⚖ Compare",
  "COMPARE_CLEARED": "⚖ Compare",
  "COMPARE_OPENED": "⚖ Compare",
  "SAVED": "⭐ Gemerkt",
  "UNSAVED": "⭐ Entfernt",
  "LEAD_SAVED": "📧 Anfrage",
  "INTERESTED": "📋 Pipeline",
  "INTERESTED_AGAIN": "📋 Pipeline",
  "PASSED": "✗ Passed",
  "NOTE_ADDED": "📝 Notiz",
  "NOTE_DELETED": "📝 Notiz gelöscht"
};

function showInputModal(title, defaultValue = '') {
  return new Promise((resolve) => {
    const overlay = document.getElementById('input-modal-overlay');
    const field = document.getElementById('input-modal-field');
    const titleEl = document.getElementById('input-modal-title');
    titleEl.textContent = title;
    field.value = defaultValue;
    overlay.setAttribute('aria-hidden', 'false');
    field.focus();
    document.getElementById('input-modal-confirm').onclick = () => {
      overlay.setAttribute('aria-hidden', 'true');
      resolve(field.value.trim() || null);
    };
    document.getElementById('input-modal-cancel').onclick = () => {
      overlay.setAttribute('aria-hidden', 'true');
      resolve(null);
    };
  });
}

/* =========================
   PLAUSIBILITY RULES + COMPUTE
========================= */
const PLAUSIBILITY_RULES = [
  {
    id: "mrr_arr_consistency",
    label: "MRR/ARR Konsistenz",
    kategorie: "Konsistenz",
    schwere: "hard",
    check: (s) => Math.abs((s.arr_eur || 0) - ((s.mrr_eur || 0) * 12)) < 1000,
    fail_text: "ARR weicht von MRR × 12 ab",
    pass_text: "ARR konsistent mit MRR"
  },
  {
    id: "burn_vs_mrr",
    label: "Burn/MRR Verhältnis",
    kategorie: "Konsistenz",
    schwere: "soft",
    check: (s) => s.burn_eur_per_month > 0 && s.burn_eur_per_month < (s.mrr_eur * 10),
    fail_text: "Burn unrealistisch hoch im Verhältnis zum MRR (>10x)",
    pass_text: "Burn/MRR Verhältnis plausibel"
  },
  {
    id: "runway_consistency",
    label: "Runway Plausibilität",
    kategorie: "Konsistenz",
    schwere: "hard",
    check: (s) => s.runway_months >= 2 && s.runway_months <= 48,
    fail_text: "Runway außerhalb plausibler Spanne (2–48 Monate)",
    pass_text: "Runway im plausiblen Bereich"
  },
  {
    id: "growth_plausibility",
    label: "Wachstum realistisch",
    kategorie: "Konsistenz",
    schwere: "soft",
    check: (s) => s.growth && s.growth.value_pct >= -50 && s.growth.value_pct <= 200,
    fail_text: "Wachstumsrate außerhalb plausibler Spanne (-50% bis 200%)",
    pass_text: "Wachstumsrate im plausiblen Bereich"
  },
  {
    id: "mrr_positive",
    label: "MRR vorhanden",
    kategorie: "Vollständigkeit",
    schwere: "hard",
    check: (s) => s.mrr_eur > 0,
    fail_text: "Kein MRR angegeben oder 0€",
    pass_text: "MRR vorhanden"
  },
  {
    id: "ownership_total",
    label: "Ownership-Summe",
    kategorie: "Konsistenz",
    schwere: "hard",
    check: (s) => ((s.founder_pct || 0) + (s.investor_pct || 0) + (s.employees_pct || 0)) <= 100.5,
    fail_text: "Ownership-Anteile summieren sich auf über 100%",
    pass_text: "Ownership-Summe plausibel"
  },
  {
    id: "ltv_cac_positive",
    label: "LTV/CAC vorhanden",
    kategorie: "Vollständigkeit",
    schwere: "soft",
    check: (s) => s.ltv_cac_ratio > 0 && s.cac_eur > 0,
    fail_text: "LTV oder CAC fehlt",
    pass_text: "Unit Economics angegeben"
  },
  {
    id: "gross_margin_range",
    label: "Gross Margin Spanne",
    kategorie: "Konsistenz",
    schwere: "soft",
    check: (s) => s.gross_margin_pct >= 0 && s.gross_margin_pct <= 99,
    fail_text: "Gross Margin außerhalb plausibler Spanne (0–99%)",
    pass_text: "Gross Margin plausibel"
  },
  {
    id: "ticket_range",
    label: "Rundengröße plausibel",
    kategorie: "Konsistenz",
    schwere: "soft",
    check: (s) => {
      const ranges = {
        "Pre-Seed": [50000, 2000000],
        "Seed": [200000, 5000000],
        "Pre-Series A": [500000, 8000000],
        "Series A": [1000000, 15000000],
        "Series B": [3000000, 50000000]
      };
      const r = ranges[s.stage];
      if(!r) return true;
      return s.ticket_eur >= r[0] && s.ticket_eur <= r[1];
    },
    fail_text: "Rundengröße ungewöhnlich für die angegebene Stage",
    pass_text: "Rundengröße passt zur Stage"
  },
  {
    id: "team_size_range",
    label: "Teamgröße plausibel",
    kategorie: "Vollständigkeit",
    schwere: "soft",
    check: (s) => s.team_size >= 1 && s.team_size <= 500,
    fail_text: "Teamgröße außerhalb plausibler Spanne",
    pass_text: "Teamgröße plausibel"
  }
];

function computePlausibility(s){
  const checks = PLAUSIBILITY_RULES.map(rule => {
    let passed;
    try { passed = !!rule.check(s); } catch(e) { passed = false; }
    return {
      id: rule.id,
      label: rule.label,
      kategorie: rule.kategorie,
      schwere: rule.schwere,
      result: passed ? "pass" : "fail",
      message: passed ? rule.pass_text : rule.fail_text
    };
  });
  const failed_hard = checks.filter(c => c.result === "fail" && c.schwere === "hard").length;
  const failed_soft = checks.filter(c => c.result === "fail" && c.schwere === "soft").length;
  const passed_count = checks.filter(c => c.result === "pass").length;
  let status;
  if(failed_hard > 0) status = "failed";
  else if(failed_soft > 0) status = "flagged";
  else status = "passed";
  return {
    status,
    checks,
    summary: { total: checks.length, passed: passed_count, failed_hard, failed_soft }
  };
}

/* =========================
   KPI CLASSIFICATION
========================= */
function classifyUE(s){
  const ok1 = s.ltv_cac_ratio >= 3;
  const ok2 = s.cac_payback_months <= 12;
  const ok3 = s.gross_margin_pct >= 70;
  const passed = [ok1,ok2,ok3].filter(Boolean).length;
  if(passed === 3) return "Strong";
  if(passed >= 2) return "No Risk";
  return "Risk";
}
function classifyRQ(s){
  const high = (s.nrr_pct >= 110 && s.logo_churn_pct <= 3);
  if(high) return "High";
  if(s.nrr_pct >= 100 && s.nrr_pct <= 109) return "Stable";
  if(s.nrr_pct < 100 || s.logo_churn_pct > 5) return "Risk";
  return "Stable";
}
function classifyCE(s){
  if(s.burn_multiple <= 1.5 && s.runway_months >= 12) return "Efficient";
  if(s.burn_multiple > 1.5 && s.burn_multiple <= 2.5) return "Neutral";
  return "Inefficient";
}
function kpiChipClass(kind, value){
  const green = new Set(["Strong","High","Efficient"]);
  const orange = new Set(["Stable","Neutral","No Risk"]);
  const red = new Set(["Risk","Inefficient"]);
  if(green.has(value)) return "kpi-good";
  if(orange.has(value)) return "kpi-warn";
  if(red.has(value)) return "kpi-bad";
  return "";
}

function scoreColorClass(score, stage) {
  const thresholds = {
    'Pre-Seed':     { high: 45, mid: 25 },
    'Seed':         { high: 55, mid: 30 },
    'Pre-Series A': { high: 60, mid: 35 },
    'Series A':     { high: 65, mid: 40 },
    'Series B':     { high: 70, mid: 45 },
  };
  const t = thresholds[stage] || { high: 60, mid: 35 };
  return score >= t.high ? 'high' : score >= t.mid ? 'mid' : 'low';
}
