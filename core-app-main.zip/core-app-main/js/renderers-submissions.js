/* =========================
   RENDERER — NEW SUBMISSIONS TAB
========================= */
function renderSubmissions(){
  hideAllViews();
  const viewSub = document.getElementById("viewSubmissions");
  if(!viewSub) return;
  viewSub.style.display = "";

  const allSubs = getSubmissions()
    .filter(x => !x.status || x.status === 'pending')
    .slice()
    .sort((a,b)=>{
      const ta = a.submitted_at ? new Date(a.submitted_at).getTime() : 0;
      const tb = b.submitted_at ? new Date(b.submitted_at).getTime() : 0;
      return tb - ta;
    });
  const statusFilter = renderSubmissions._filter || "Alle";
  const list = statusFilter === "Alle" ? allSubs : allSubs.filter(x=>x.plausibility_status===statusFilter);

  const resultCount = document.getElementById("resultCount");
  const activeFilterCount = document.getElementById("activeFilterCount");
  if(resultCount) resultCount.textContent = allSubs.length + " Bewerbungen";
  if(activeFilterCount) activeFilterCount.textContent = "0 Filter aktiv";

  // Einzeilig wie Mockup: "✓ Passed" / "⚠ 2 Warnings" / "✗ Failed" + ⓘ
  const plausiBadge = (sub)=>{
    const status = sub.plausibility_status || "passed";
    const summary = sub.plausibility_summary || {};
    const warnings = (summary.failed_soft || 0) + (summary.failed_hard || 0) || 1;
    const label = status === "passed" ? "✓ Passed"
      : status === "flagged" ? `⚠ ${warnings} Warning${warnings !== 1 ? "s" : ""}`
      : "✗ Failed";
    return `<div class="subs2-plaus">
      <div class="subs2-plaus-label ${escapeHTML(status)}">
        <span>${escapeHTML(label)}</span>
        <button class="subs2-infoicon" data-plaus="${escapeHTML(sub.anon_id)}"
          type="button" aria-label="Plausibility Breakdown">ⓘ</button>
      </div>
    </div>`;
  };
  const stageCls = (stage)=> stage === "Pre-Seed" ? "subs2-stage-pre"
    : stage === "Seed" ? "subs2-stage-seed"
    : "subs2-stage-series";

  const selectedNote = bulkCount() > 0 ? ` · ${bulkCount()} ausgewählt` : "";
  viewSub.innerHTML = `
    <div class="subs2-head">
      <div class="panelhead">
        <h2>New Submissions</h2>
        <div class="note">${allSubs.length} neue Bewerbungen${escapeHTML(selectedNote)}</div>
      </div>
      <div class="subs2-head-actions">
        <select class="select" id="submissionsFilter">
          <option value="Alle" ${statusFilter==="Alle"?"selected":""}>Alle</option>
          <option value="passed" ${statusFilter==="passed"?"selected":""}>Passed</option>
          <option value="flagged" ${statusFilter==="flagged"?"selected":""}>Flagged</option>
          <option value="failed" ${statusFilter==="failed"?"selected":""}>Failed</option>
        </select>
        <button class="btn secondary small" id="submissionsExportBtn">⤓ Export JSON</button>
      </div>
    </div>
    <div id="submissionsMount"></div>
  `;

  document.getElementById("submissionsFilter").onchange = e=>{
    renderSubmissions._filter = e.target.value;
    renderSubmissions();
  };
  document.getElementById("submissionsExportBtn").onclick = ()=>{
    downloadJSON("core_submissions_export.json", getSubmissions());
  };

  const mount = document.getElementById("submissionsMount");
  if(list.length === 0){
    mount.innerHTML = `<div class="empty">Keine neuen Bewerbungen.<div class="hint">Wenn Startups sich über deinen CoreLink bewerben, erscheinen sie hier.</div></div>`;
    return;
  }

  const visibleIds = list.map(s => s.anon_id);
  const selectedCount = visibleIds.filter(id => bulkIsSelected(id)).length;
  const allChecked = selectedCount === visibleIds.length && visibleIds.length > 0;
  const someChecked = selectedCount > 0 && selectedCount < visibleIds.length;

  const bulkToolbarHtml = bulkCount() > 0 ? `
    <div class="bulk-toolbar" id="submBulkToolbar">
      <span class="bulk-count">${bulkCount()} ausgewählt</span>
      <div class="bulk-actions">
        <button class="btn small" id="submBulkAccept">Annehmen</button>
        <button class="btn secondary small" id="submBulkDecline">Ablehnen</button>
        <button class="btn secondary small" id="submBulkDeselect">Auswahl aufheben</button>
      </div>
    </div>
  ` : "";

  mount.innerHTML = `
    ${bulkToolbarHtml}
    <div class="subs2-wrap">
      <table>
        <thead>
          <tr>
            <th style="width:40px;"><input type="checkbox" id="submBulkAll" title="Alle auswählen" ${allChecked ? "checked" : ""}></th>
            <th>STARTUP</th>
            <th>SEKTOR</th>
            <th style="text-align:center;">STAGE</th>
            <th style="text-align:center;">SCORE</th>
            <th>PLAUSIBILITY</th>
            <th style="white-space:nowrap; min-width:120px;">EINGEREICHT</th>
            <th style="text-align:right; min-width:180px;">AKTIONEN</th>
          </tr>
        </thead>
        <tbody>
          ${list.map(sub=>{
            const dt = sub.submitted_at ? new Date(sub.submitted_at).toLocaleDateString("de-DE", {day:"2-digit",month:"2-digit",year:"numeric"}) : "—";
            const ss = startups.find(x=>x.anon_id===sub.anon_id);
            // Fuer pending Submissions ein Startup-Objekt on-the-fly bauen,
            // damit computeCustomIndexV6 tatsaechlich Werte ziehen kann
            const scoreTarget = ss || (typeof buildStartupFromSubmission === "function"
              ? buildStartupFromSubmission(sub)
              : sub.anon_id);
            const isSelected = bulkIsSelected(sub.anon_id);
            let score = Number.isFinite(sub.signal_index) ? Math.round(sub.signal_index) : null;
            try {
              const _liveRes = computeCustomIndexV6(scoreTarget);
              // null = Scoring deaktiviert — dann auch keinen Cache-Wert zeigen
              score = (_liveRes && _liveRes.score !== null && _liveRes.score !== undefined)
                ? Math.round(_liveRes.score) : null;
            } catch (_) {}
            const scoreClass = score === null ? "" : score >= 70 ? "high" : score >= 40 ? "mid" : "low";
            return `<tr class="${isSelected ? "bulk-selected" : ""}">
              <td><input type="checkbox" class="bulk-check" data-bulk="${escapeHTML(sub.anon_id)}" ${isSelected ? "checked" : ""}></td>
              <td>
                <button class="subs2-name" data-open="${escapeHTML(sub.anon_id)}">${escapeHTML(sub.company_name || ss?.company_name || sub.anon_id)}</button>
                <div class="subs2-id">ID: ${escapeHTML(sub.anon_id)}</div>
              </td>
              <td class="subs2-sector">
                <div class="subs2-sector-main">${escapeHTML(sub.sector||"—")}</div>
                ${sub.sub_sector?`<div class="subs2-sector-sub">${escapeHTML(sub.sub_sector)}</div>`:""}
              </td>
              <td class="subs2-stage ${stageCls(sub.stage)}">${escapeHTML(sub.stage||"—")}</td>
              <td class="subs2-score">
                <div class="subs2-score-inner">
                  <span class="subs2-score-val ${scoreClass}">${score === null ? "—" : score}</span>
                  <button class="subs2-infoicon" data-action="scoreinfo" data-id="${escapeHTML(sub.anon_id)}" type="button" aria-label="Score Breakdown">ⓘ</button>
                </div>
              </td>
              <td>${plausiBadge(sub)}</td>
              <td class="subs2-date">${dt}</td>
              <td class="subs2-actions">
                <div class="subs2-actions-inner">
                  <button class="subs2-btn-accept" data-accept="${escapeHTML(sub.anon_id)}">Annehmen</button>
                  <button class="subs2-btn-decline" data-decline="${escapeHTML(sub.anon_id)}">Ablehnen</button>
                </div>
              </td>
            </tr>`;
          }).join("")}
        </tbody>
      </table>
    </div>
  `;

  // Set indeterminate state on header checkbox
  const submBulkAll = document.getElementById("submBulkAll");
  if(submBulkAll) submBulkAll.indeterminate = someChecked;

  // Select-All handler
  if(submBulkAll){
    submBulkAll.onchange = ()=>{
      if(submBulkAll.checked) bulkSelectAll(visibleIds);
      else bulkDeselectAll();
      renderSubmissions();
    };
  }

  // Individual checkbox handlers
  mount.querySelectorAll(".bulk-check").forEach(cb=>{
    cb.onchange = ()=>{
      bulkToggle(cb.getAttribute("data-bulk"));
      renderSubmissions();
    };
  });

  // Bulk toolbar handlers
  const submBulkAccept = document.getElementById("submBulkAccept");
  const submBulkDecline = document.getElementById("submBulkDecline");
  const submBulkDeselect = document.getElementById("submBulkDeselect");

  if(submBulkAccept){
    submBulkAccept.onclick = async ()=>{
      const ids = Array.from(bulkSelection);
      // EIN Batch-Update statt N Einzel-Updates mit je einem Listen-Reload
      const done = await acceptSubmissionsBulk(ids);
      done.forEach(id => activityLogAppend("SUBMISSION_ACCEPTED", id));
      bulkDeselectAll();
      toast("OK", `${done.length} Deal${done.length !== 1 ? "s" : ""} angenommen`);
      renderSubmissions();
    };
  }
  if(submBulkDecline){
    submBulkDecline.onclick = async ()=>{
      const ids = Array.from(bulkSelection);
      const done = await declineSubmissionsBulk(ids);
      done.forEach(id => activityLogAppend("SUBMISSION_DECLINED", id));
      bulkDeselectAll();
      toast("Abgelehnt", `${done.length} Bewerbung${done.length !== 1 ? "en" : ""} abgelehnt`);
      renderSubmissions();
    };
  }
  if(submBulkDeselect){
    submBulkDeselect.onclick = ()=>{ bulkDeselectAll(); renderSubmissions(); };
  }

  mount.querySelectorAll("[data-open]").forEach(b=>{
    b.onclick = ()=>{
      const anon_id = b.getAttribute("data-open");
      // Pending-Submissions sind nicht in `startups` (dort nur accepted) — on-the-fly konvertieren
      const existing = startups.find(x => x.anon_id === anon_id);
      if (existing) { openModalByAnonId(anon_id, startups); return; }
      const sub = getSubmissions().find(x => x.anon_id === anon_id);
      if (sub && typeof buildStartupFromSubmission === "function") {
        const built = buildStartupFromSubmission(sub);
        openModalWithStartup(built, [built]);
      }
    };
  });
  mount.querySelectorAll("[data-action='scoreinfo']").forEach(b=>{
    b.onclick = (e)=>{ openScoreBreakdown(b.getAttribute("data-id"), b); e.stopPropagation(); };
  });
  mount.querySelectorAll("[data-plaus]").forEach(b=>{
    b.onclick = (e)=>{ openPlausibilityBreakdown(b.getAttribute("data-plaus"), b); e.stopPropagation(); };
  });
  mount.querySelectorAll("[data-accept]").forEach(b=>{
    b.onclick = async ()=>{
      const id = b.getAttribute("data-accept");
      const ok = await acceptSubmission(id);
      if (!ok) return;
      activityLogAppend("SUBMISSION_ACCEPTED", id);
      bulkSelection.delete(id);
      toast("Angenommen", "Deal erscheint jetzt in der Übersicht");
      renderSubmissions();
    };
  });
  mount.querySelectorAll("[data-decline]").forEach(b=>{
    b.onclick = async ()=>{
      const id = b.getAttribute("data-decline");
      const ok = await declineSubmission(id);
      if (!ok) return;
      activityLogAppend("SUBMISSION_DECLINED", id);
      bulkSelection.delete(id);
      toast("Abgelehnt", "Bewerbung entfernt");
      renderSubmissions();
    };
  });
}
