/* =========================
   computeSignalIndex → Proxy für computeCustomIndexV6
   Signal Index ist ersetzt durch Custom Index (Score).
   Diese Funktion bleibt als Proxy um bestehende Referenzen nicht zu brechen.
========================= */
function computeSignalIndex(anon_id){
  try{
    const res = computeCustomIndexV6(anon_id);
    // null = Scoring deaktiviert/kein Wert — KEIN Pseudo-Score erfinden,
    // sonst zeigen Listen trotz deaktiviertem Regelwerk eine Zahl.
    return (res && res.score !== null && res.score !== undefined) ? res.score : null;
  }catch(e){ console.warn('computeSignalIndex failed for', anon_id, e); return null; }
}

/* =========================
   Popover-Infrastruktur (wird für Score Breakdown wiederverwendet)
========================= */
let _signalPopoverState = { open:false, anon_id:null };

function closeSignalPopover(){
  const pop = document.getElementById("signalIndexPopover");
  if(!pop) return;
  pop.style.display = "none";
  pop.innerHTML = "";
  _signalPopoverState = { open:false, anon_id:null };
}

// body{zoom:var(--app-zoom)} (main.css): getBoundingClientRect/clientX liefern
// Viewport-Pixel, style.left/top im gezoomten Body werden aber nochmal mit dem
// Faktor multipliziert — beim Schreiben deshalb durch _appZoom() teilen.
function _appZoom(){
  const z = parseFloat(getComputedStyle(document.body).zoom);
  return (isFinite(z) && z > 0) ? z : 1;
}

function openSignalPopover(anchorEl, html, anon_id=null){
  const pop = document.getElementById("signalIndexPopover");
  if(!pop || !anchorEl || typeof html !== 'string') return;

  pop.innerHTML = html;
  pop.style.display = "block";
  _signalPopoverState = { open:true, anon_id: anon_id };

  // Popover uses position:fixed — coordinates are viewport-relative, no scroll offset needed
  const r = anchorEl.getBoundingClientRect();
  const pad = 10;

  pop.style.left = "0px";
  pop.style.top = "0px";
  const pr = pop.getBoundingClientRect();

  let left = r.left;
  let top = r.bottom + 8;

  // clamp horizontally within viewport
  left = Math.min(left, window.innerWidth - pr.width - pad);
  left = Math.max(left, pad);

  // if too low, place above anchor
  if(top + pr.height > window.innerHeight - pad){
    top = r.top - pr.height - 8;
  }
  top = Math.max(top, pad);

  const z = _appZoom();
  pop.style.left = (left / z) + "px";
  pop.style.top = (top / z) + "px";

  _initPopoverDrag(pop);
}

/* =========================
   Score Breakdown Hilfsfunktionen (neu)
========================= */

function getScoreColorClass(score){
  const n = Number(score ?? 0);
  if(n <= 18) return "score-red";
  if(n <= 35) return "score-orange";
  if(n <= 56) return "score-yellow";
  return "score-green";
}

function formatOperatorLabel(operator, value, unit){
  const op = String(operator || "").toLowerCase();
  const fmt = (v) => {
    if(v === null || v === undefined) return "—";
    if(unit === "EUR") return fmtEUR(v);
    if(unit === "percent") return v + "%";
    if(unit === "months") return v + " Monate";
    if(unit === "x") return v + "x";
    if(unit === "Personen") return v + " Mitarbeiter";
    return String(v);
  };

  if(op === "between_inclusive" || op === "between_exclusive"){
    const min = value?.min, max = value?.max;
    return "zwischen " + fmt(min) + " und " + fmt(max);
  }

  const labels = {
    lt: "unter",
    lte: "maximal",
    gt: "über",
    gte: "mindestens",
    eq: "genau",
    neq: "nicht"
  };
  return (labels[op] || op) + " " + fmt(value);
}

function _stageBadgeHTML(stage){
  if(!stage) return "";
  const colors = {
    "Pre-Seed":     { bg:"#e8edf2", text:"#4a5568" },
    "Seed":         { bg:"#dbeafe", text:"#1d4ed8" },
    "Pre-Series A": { bg:"#d1fae5", text:"#065f46" },
    "Series A":     { bg:"#dcfce7", text:"#166534" },
    "Series B":     { bg:"#ede9fe", text:"#5b21b6" }
  };
  const c = colors[stage] || { bg:"#f3f4f6", text:"#6b7280" };
  return `<span style="display:inline-block; font-size:0.72rem; font-weight:800; padding:2px 8px; border-radius:99px; background:${c.bg}; color:${c.text}; letter-spacing:0.02em;">${escapeHTML(stage)}</span>`;
}

function buildCustomBreakdownHTML(anon_id, res){
  const rules = (typeof getCustomRulesV6 === "function") ? getCustomRulesV6() : {};
  const rulesetName = rules.name || "Ruleset";
  const score = (res && res.score !== null && res.score !== undefined) ? res.score : "—";
  const breakdown = (res && Array.isArray(res.breakdown)) ? res.breakdown : [];
  const startScore = rules.scoring?.start_score ?? 50;
  const maxScore = rules.scoring?.max_score ?? 100;

  const allStartups = (typeof startups !== "undefined" && Array.isArray(startups)) ? startups : [];
  const startup = allStartups.find(x => String(x.anon_id) === String(anon_id)) || null;
  let stage = startup?.stage || null;
  if(!stage && typeof getSubmissions === "function"){
    const sub = getSubmissions().find(x => String(x.anon_id) === String(anon_id));
    stage = sub?.stage || null;
  }

  const triggered = breakdown.filter(b => !b.skipped);
  const plausSummary = triggered.find(b => b.rule_id === "plaus_summary");
  const scoreRows = triggered.filter(b => b.rule_id !== "plaus_summary");

  const rows = scoreRows.map(b => {
    const kpiDef = rules.kpi_map?.[b.kpi] || {};
    const kpiLabel = kpiDef.label || b.kpi;
    const unit = kpiDef.unit || "";
    const pts = Number(b.points || 0);
    const sign = pts > 0 ? "+" : "";
    const opLabel = formatOperatorLabel(b.operator, b.threshold, unit);
    const icon = pts > 0 ? "✓" : (pts < 0 ? "⚠" : "—");
    const cls = pts > 0 ? "breakdown-positive" : (pts < 0 ? "breakdown-negative" : "breakdown-zero");

    return `
      <div class="breakdown-item">
        <div class="breakdown-rule">${escapeHTML(icon)} ${escapeHTML(kpiLabel)} ${escapeHTML(opLabel)}</div>
        <div class="breakdown-points ${cls}">${sign}${pts} Pkt.</div>
      </div>
    `;
  }).join("");

  let plausSummaryHTML = "";
  if(plausSummary && plausSummary._plaus_summary){
    const ps = plausSummary._plaus_summary;
    const allPass = ps.failed_hard === 0 && ps.failed_soft === 0;
    const icon = allPass ? "✓" : (ps.failed_hard > 0 ? "✗" : "⚠");
    const cls = allPass ? "breakdown-positive" : (ps.failed_hard > 0 ? "breakdown-negative" : "breakdown-zero");
    let label;
    if(allPass){
      label = `Plausibility: ${ps.passed}/${ps.total} Checks bestanden`;
    } else {
      const parts = [];
      if(ps.failed_hard > 0) parts.push(`${ps.failed_hard} kritisch`);
      if(ps.failed_soft > 0) parts.push(`${ps.failed_soft} Hinweis${ps.failed_soft > 1 ? "e" : ""}`);
      label = `Plausibility: ${parts.join(", ")} · ${ps.passed}/${ps.total} bestanden`;
    }
    plausSummaryHTML = `
      <div class="breakdown-item" style="margin-top:6px; padding-top:6px; border-top:1px dashed var(--border);">
        <div class="breakdown-rule">${icon} ${escapeHTML(label)}</div>
        <div class="breakdown-points ${cls}">0 Pkt.</div>
      </div>
    `;
  }

  const ts = res?.computed_at ? new Date(res.computed_at).toLocaleString("de-DE") : "—";

  return `
    <div style="min-width:300px; max-width:400px; padding:4px;">
      <div class="popover-drag-handle" style="display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; cursor:grab; user-select:none;">
        <div style="font-weight:950; font-size:1.02rem;">Score Breakdown</div>
        <div style="font-size:0.8rem; color:var(--muted); font-weight:800;">${escapeHTML(rulesetName)}</div>
      </div>
      <div style="display:flex; align-items:baseline; gap:10px; margin-bottom:14px; flex-wrap:wrap;">
        <span style="font-weight:950; font-size:2rem; line-height:1;">${escapeHTML(String(score))}</span>
        <span style="font-size:1rem; color:var(--muted); font-weight:700;">/ ${maxScore}</span>
        ${stage ? _stageBadgeHTML(stage) : ""}
      </div>
      <div style="border-top:1px solid var(--border); padding-top:10px;">
        ${rows || `<div style="color:var(--muted); font-size:0.9rem; padding:8px 0;">Keine Regeln getriggert.</div>`}
        ${plausSummaryHTML}
      </div>
      <div style="margin-top:12px; padding-top:10px; border-top:1px solid var(--border); font-size:0.8rem; color:var(--muted);">
        Zuletzt berechnet: ${escapeHTML(ts)}
      </div>
    </div>
  `;
}

function _initPopoverDrag(pop){
  if(pop._dragBound) return;
  pop._dragBound = true;

  pop.addEventListener("mousedown", (e)=>{
    if(!e.target.closest(".popover-drag-handle")) return;
    e.preventDefault();

    let startX = e.clientX;
    let startY = e.clientY;
    let startLeft = parseInt(pop.style.left) || 0;
    let startTop  = parseInt(pop.style.top)  || 0;

    const z = _appZoom();
    const onMove = (e)=>{
      let newLeft = startLeft + (e.clientX - startX) / z;
      let newTop  = startTop  + (e.clientY - startY) / z;
      newLeft = Math.max(0, Math.min(newLeft, window.innerWidth  / z - pop.offsetWidth));
      newTop  = Math.max(0, Math.min(newTop,  window.innerHeight / z - pop.offsetHeight));
      pop.style.left = newLeft + "px";
      pop.style.top  = newTop  + "px";
    };
    const onUp = ()=>{
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseup", onUp);
    };
    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseup", onUp);
  });
}

function openScoreBreakdown(anon_id, anchorEl){
  // Fuer pending Submissions ein Startup-Objekt on-the-fly bauen,
  // sonst findet computeCustomIndexV6 keine Werte zum Scoren
  let target = anon_id;
  const inStartups = (typeof startups !== "undefined") && startups.find(x => x.anon_id === anon_id);
  if (!inStartups && typeof getSubmissions === "function" && typeof buildStartupFromSubmission === "function") {
    const sub = getSubmissions().find(x => x.anon_id === anon_id);
    if (sub) target = buildStartupFromSubmission(sub);
  }
  const res = computeCustomIndexV6(target);
  const html = buildCustomBreakdownHTML(anon_id, res);
  openSignalPopover(anchorEl, html, anon_id);
}

/* =========================
   PLAUSIBILITY BREAKDOWN POPOVER
========================= */
function buildPlausibilityBreakdownHTML(anon_id){
  const subs = (typeof getSubmissions === "function") ? getSubmissions() : [];
  const sub = subs.find(x => x.anon_id === anon_id);
  const startup = (typeof startups !== "undefined") ? startups.find(x => x.anon_id === anon_id) : null;
  const name = startup ? (startup.company_name || anon_id) : anon_id;

  let plausData = null;
  if(sub && sub.plausibility_checks && sub.plausibility_checks.length){
    plausData = { status: sub.plausibility_status || "passed", checks: sub.plausibility_checks, summary: sub.plausibility_summary || {} };
  } else if(startup && Array.isArray(startup.plausibility_checks) && startup.plausibility_checks.length){
    // Accepted: Submission ist nicht mehr im pending-Cache, Server-Checks stecken im Startup
    plausData = { status: startup.plausibility_status || "passed", checks: startup.plausibility_checks, summary: startup.plausibility_summary || {} };
  } else if(startup && typeof computePlausibility === "function"){
    plausData = computePlausibility(startup);
  }

  if(!plausData){
    return `<div style="min-width:280px; padding:4px;">
      <div style="font-weight:950; font-size:1rem; margin-bottom:8px;">Plausibility Check – ${escapeHTML(name)}</div>
      <div style="color:var(--muted); font-size:0.9rem;">Plausibility Check konnte nicht berechnet werden.</div>
    </div>`;
  }

  const status = plausData.status;
  const summary = plausData.summary;
  const checks = plausData.checks.slice();

  // Sort: hard fails first, soft fails second, passes last
  checks.sort((a, b) => {
    const rank = (c) => c.result === "fail" && c.schwere === "hard" ? 0 : c.result === "fail" ? 1 : 2;
    return rank(a) - rank(b);
  });

  const statusMap = {
    passed: { cls: "plaus-passed", icon: "✓", label: "Passed" },
    flagged: { cls: "plaus-flagged", icon: "⚠", label: "Flagged" },
    failed:  { cls: "plaus-failed",  icon: "✗", label: "Failed" }
  };
  const sm = statusMap[status] || statusMap.failed;

  const summaryText = (() => {
    const t = summary.total || checks.length;
    const p = summary.passed || checks.filter(c=>c.result==="pass").length;
    const fh = summary.failed_hard || 0;
    const fs = summary.failed_soft || 0;
    const parts = [`${p} von ${t} Checks bestanden`];
    if(fh > 0) parts.push(`${fh} kritisch`);
    if(fs > 0) parts.push(`${fs} Hinweis${fs > 1 ? "e" : ""}`);
    return parts.join(" • ");
  })();

  const checkRows = checks.map(c => {
    let icon, cls;
    if(c.result === "fail" && c.schwere === "hard"){ icon = "✗"; cls = "plaus-icon-fail-hard"; }
    else if(c.result === "fail"){ icon = "⚠"; cls = "plaus-icon-fail-soft"; }
    else { icon = "✓"; cls = "plaus-icon-pass"; }
    return `
      <div class="plaus-check">
        <div class="plaus-icon ${cls}">${icon}</div>
        <div class="plaus-check-body">
          <span class="plaus-check-label">${escapeHTML(c.label)}</span>
          <span class="plaus-check-kategorie">${escapeHTML(c.kategorie)}</span>
          <div class="plaus-check-message">${escapeHTML(c.message)}</div>
        </div>
      </div>`;
  }).join("");

  return `
    <div style="min-width:320px; max-width:420px; padding:4px;">
      <div class="popover-drag-handle" style="display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; cursor:grab; user-select:none;">
        <div style="font-weight:950; font-size:1rem;">Plausibility Check</div>
        <div style="font-size:0.8rem; color:var(--muted); font-weight:800;">${escapeHTML(name)}</div>
      </div>
      <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
        <span class="badge ${sm.cls}" style="font-size:1rem; padding:4px 12px;">${sm.icon} ${sm.label}</span>
        <span style="font-size:0.82rem; color:var(--muted); font-weight:700;">${escapeHTML(summaryText)}</span>
      </div>
      <div style="border-top:1px solid var(--border); padding-top:8px;">
        ${checkRows}
      </div>
      <div style="margin-top:10px; padding-top:8px; border-top:1px solid var(--border); font-size:0.78rem; color:var(--muted); font-style:italic;">
        Plausibilitätsprüfung ersetzt keine Due Diligence. Sie macht Inkonsistenzen sichtbar.
      </div>
    </div>
  `;
}

function openPlausibilityBreakdown(anon_id, anchorEl){
  const html = buildPlausibilityBreakdownHTML(anon_id);
  openSignalPopover(anchorEl, html, anon_id);
}

// Close popover on outside click
document.addEventListener("click",(e)=>{
  const pop = document.getElementById("signalIndexPopover");
  if(!pop || pop.style.display==="none") return;
  const onIcon = e.target.closest(".infoicon");
  const inside = pop.contains(e.target);
  if(!onIcon && !inside){
    closeSignalPopover();
  }
});
window.addEventListener("resize", ()=>{
  if(_signalPopoverState.open) closeSignalPopover();
});

/* =========================
   V4.1 JS patches
========================= */

// V4.1 patch: no-scroll body lock removed — caused scroll-reset & freeze for cards below the fold

function sigClassFromScore(score){
  const n = Number(score||0);
  if(n >= 70) return "HIGH";
  if(n >= 35) return "MID";
  return "LOW";
}

function sigToneFromClass(cls){
  if(cls==="HIGH") return "high";
  if(cls==="MID") return "mid";
  return "low";
}

// Toggle legend inside popover (event delegation)
document.addEventListener("click", (e)=>{
  const btn = e.target.closest("[data-toggle-legend]");
  if(!btn) return;
  const id = btn.getAttribute("data-toggle-legend");
  const el = document.getElementById(id);
  if(!el) return;
  el.style.display = (el.style.display === "none" || !el.style.display) ? "block" : "none";
});

// Pipeline: stronger status color semantics (without redesign)
function statusTone(status){
  const s = String(status||"").toLowerCase();
  if(s==="passed") return "bad";
  if(s==="invested" || s==="term sheet") return "good";
  if(s==="ic" || s==="diligence" || s==="contacted") return "warn";
  return "";
}
