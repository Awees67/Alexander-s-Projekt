/* =========================
   RENDERER — PIPELINE TAB (Design v2, 1:1 nach Mockup)
   Spalten: Startup, Sektor, Stage (Funding), Score, Pipeline (Status),
   Zugewiesen (Fund-Mitarbeiter + Position), Zuletzt aktiv, Aktionen.
   Funktionsname renderPipeline NICHT ändern (Monkey-Patching ._v41/._ciV6).
========================= */
const PIPE3_STATUS_META = {
  "In Review": { cls: "pipe3-st-review",    label: "In Review" },
  "Contacted": { cls: "pipe3-st-contacted", label: "Contacted" },
  "Hot Deal":  { cls: "pipe3-st-hot",       label: "Hot Deal" },
  "Watching":  { cls: "pipe3-st-watching",  label: "Watching" },
  "Declined":  { cls: "pipe3-st-declined",  label: "Declined" },
  "Synced":    { cls: "pipe3-st-synced",    label: "Synced" }
};

function pipe3RelTime(ts){
  if(!ts) return "—";
  const d = new Date(ts);
  const now = new Date();
  const day = (x)=> new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diffDays = Math.round((day(now) - day(d)) / 86400000);
  const hm = d.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
  if(diffDays === 0) return `Heute, ${hm}`;
  if(diffDays === 1) return `Gestern, ${hm}`;
  return d.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function renderPipeline(){
  hideAllViews();
  const viewPipeline = document.getElementById("viewPipeline");
  if(!viewPipeline) return;
  viewPipeline.style.display = "";
  const pipeline = getPipeline();
  const stages = ["In Review","Contacted","Hot Deal","Watching","Declined","Synced"];
  const stageCounts = {};
  stages.forEach(st=>{ stageCounts[st] = 0; });
  pipeline.forEach(x=>{ if(stageCounts[x.status]!==undefined) stageCounts[x.status]++; });
  const statusFilter = renderPipeline._statusFilter || "Alle";
  let list = pipeline.slice().sort((a,b)=>(b.last_activity_at||b.last_updated||0)-(a.last_activity_at||a.last_updated||0));
  if(statusFilter !== "Alle") list = list.filter(x=>x.status===statusFilter);

  const resultCount = document.getElementById("resultCount");
  const activeFilterCount = document.getElementById("activeFilterCount");
  if(resultCount) resultCount.textContent = pipeline.length + " Deals";
  if(activeFilterCount) activeFilterCount.textContent = "0 Filter aktiv";

  const checkableIds = list.filter(item => item.status !== "Synced").map(item => item.anon_id);
  const selectedCount = checkableIds.filter(id => bulkIsSelected(id)).length;
  const allChecked = selectedCount === checkableIds.length && checkableIds.length > 0;
  const someChecked = selectedCount > 0 && selectedCount < checkableIds.length;
  const selectedNote = bulkCount() > 0 ? ` · ${bulkCount()} ausgewählt` : "";

  // ── Kopf + Stage-Tabs + Auswahl-Bar ──────────────────────────────────────
  viewPipeline.innerHTML = `
    <div class="pipe3-head">
      <div class="panelhead">
        <h2>Pipeline</h2>
        <div class="note">${pipeline.length} Startup${pipeline.length!==1?"s":""}${escapeHTML(selectedNote)}</div>
      </div>
      <div class="pipe3-head-actions">
        <button class="btn secondary small" id="openCustomRulesBtn">⚙ Score</button>
        <select class="select" id="pipelineStatusFilter">
          ${["Alle",...stages].map(st=>`<option value="${st}"${statusFilter===st?" selected":""}>${st==="Alle"?"Filter":st}</option>`).join("")}
        </select>
        <button class="btn secondary small" id="pipelineExportBtn">⤓ Export</button>
      </div>
    </div>
    <div class="pipe3-tabs">
      <button class="pipe3-tab${statusFilter==="Alle"?" active":""}" data-stage-filter="Alle">Alle <span class="pipe3-tab-count">${pipeline.length}</span></button>
      ${stages.map(st=>`<button class="pipe3-tab${statusFilter===st?" active":""}" data-stage-filter="${escapeHTML(st)}">${escapeHTML(st)} <span class="pipe3-tab-n">${stageCounts[st]||0}</span></button>`).join("")}
    </div>
    ${bulkCount() > 0 ? `
    <div class="pipe3-bulkbar" id="pipeBulkToolbar">
      <span class="pipe3-bulk-count">${bulkCount()} ausgewählt</span>
      <div class="pipe3-bulk-actions">
        <select id="pipeBulkStatusSel" class="pipe3-bulk-stage">
          <option value="">Stage ändern ▾</option>
          ${["In Review","Contacted","Hot Deal","Watching","Declined"].map(st=>`<option value="${st}">${st}</option>`).join("")}
        </select>
        <button id="pipeBulkRemove">Entfernen</button>
        <button id="pipeBulkDeselect">Auswahl aufheben</button>
      </div>
    </div>` : ""}
    <div id="pipelineTableMount"></div>
  `;

  viewPipeline.querySelectorAll("[data-stage-filter]").forEach(badge=>{
    badge.onclick=()=>{ renderPipeline._statusFilter = badge.getAttribute("data-stage-filter"); renderPipeline(); };
  });
  document.getElementById("pipelineStatusFilter").onchange = e=>{
    renderPipeline._statusFilter = e.target.value; renderPipeline();
  };
  document.getElementById("pipelineExportBtn").onclick = ()=>{
    downloadJSON("core_pipeline_export.json", getPipeline());
  };
  const scoreBtn = document.getElementById("openCustomRulesBtn");
  if(scoreBtn) scoreBtn.onclick = (e)=>{
    e.preventDefault();
    if(typeof openCustomIndex === "function") openCustomIndex();
  };

  const mount = document.getElementById("pipelineTableMount");
  if(list.length === 0){
    mount.innerHTML = `<div class="empty">Noch keine Deals${statusFilter!=="Alle"?` in „${escapeHTML(statusFilter)}"`:" in der Pipeline"}.<div class="hint">Füge Deals aus der Übersicht oder den Submissions hinzu.</div></div>`;
    bindPipe3BulkHandlers();
    return;
  }

  // ── Tabelle ───────────────────────────────────────────────────────────────
  mount.innerHTML = `
    <div class="pipe3-wrap">
      <table>
        <thead>
          <tr>
            <th style="width:40px;"><input type="checkbox" id="pipeBulkAll" title="Alle auswählen" ${allChecked ? "checked" : ""}></th>
            <th>STARTUP</th>
            <th>SEKTOR</th>
            <th style="text-align:center;">STAGE</th>
            <th style="text-align:center;">SCORE</th>
            <th>PIPELINE</th>
            <th>ZUGEWIESEN</th>
            <th style="min-width:170px;">ZULETZT AKTIV</th>
            <th style="text-align:right; min-width:210px;">AKTIONEN</th>
          </tr>
        </thead>
        <tbody>
          ${list.map(item=>{
            const ps = Array.isArray(startups) ? startups.find(x=>x.anon_id===item.anon_id) : null;
            const isSynced = item.status === "Synced";
            const isSelected = bulkIsSelected(item.anon_id);
            let score = Number.isFinite(item.signal_index) ? Math.round(item.signal_index) : null;
            try {
              const _liveRes = computeCustomIndexV6(ps || item.anon_id);
              // null = Scoring deaktiviert — dann auch keinen Cache-Wert zeigen
              score = (_liveRes && _liveRes.score !== null && _liveRes.score !== undefined)
                ? Math.round(_liveRes.score) : null;
            } catch (_) {}
            const scoreClass = score === null ? "" : score >= 70 ? "high" : score >= 40 ? "mid" : "low";
            const stage = ps?.stage || "—";
            const stageCls = stage === "Pre-Seed" ? "pipe3-stage-pre" : stage === "Seed" ? "pipe3-stage-seed" : "pipe3-stage-series";
            const stMeta = PIPE3_STATUS_META[item.status] || PIPE3_STATUS_META["In Review"];
            const declineReasonLabel = item.status === "Declined" && item.decline_reason
              ? (DECLINE_REASONS.find(r => r.key === item.decline_reason)?.label || item.decline_reason)
              : null;
            const actName = item.last_activity_by || item.assigned_name || "";
            const actAction = item.last_activity_action || "";
            // Festes 2-Slot-Raster (Stage | CRM), damit die Buttons über alle
            // Zeilen fluchten — leere Slots als Platzhalter. Detailansicht
            // öffnet über den Firmennamen (data-open).
            const stageSlot = isSynced ? `<span class="pipe3-slot"></span>` : `
              <select class="pipe3-stagesel" data-pipe-id="${escapeHTML(item.anon_id)}">
                <option value="" selected hidden>Stage ▾</option>
                ${(PIPELINE_TRANSITIONS[item.status]||[]).filter(t=>t!=="Synced").map(t=>`<option value="${escapeHTML(t)}">${escapeHTML(t)}</option>`).join("")}
              </select>`;
            const crmSlot = isSynced
              ? `<span class="pipe3-incrm">✓ Im CRM</span>`
              : `<button class="pipe3-crm" data-crm="${escapeHTML(item.anon_id)}">Push to CRM</button>`;
            return `<tr class="${isSelected ? "bulk-selected" : ""}">
              <td>${isSynced ? "" : `<input type="checkbox" class="bulk-check" data-bulk="${escapeHTML(item.anon_id)}" ${isSelected ? "checked" : ""}>`}</td>
              <td>
                <button class="pipe3-name" data-open="${escapeHTML(item.anon_id)}">${escapeHTML(ps?.company_name || item.anon_id)}</button>
                <div class="pipe3-id">${escapeHTML(item.anon_id)}</div>
              </td>
              <td>
                <div class="pipe3-sector-main">${escapeHTML(ps?.sector||"—")}</div>
                ${ps?.sub_sector?`<div class="pipe3-sector-sub">${escapeHTML(ps.sub_sector)}</div>`:""}
              </td>
              <td class="pipe3-stage ${stageCls}">${escapeHTML(stage)}</td>
              <td class="pipe3-score">
                <div class="pipe3-score-inner">
                  <span class="pipe3-score-val ${scoreClass}">${score === null ? "—" : score}</span>
                  <button class="pipe3-infoicon" data-action="scoreinfo" data-id="${escapeHTML(item.anon_id)}" type="button" aria-label="Score Breakdown">ⓘ</button>
                </div>
              </td>
              <td>
                <span class="pipe3-status ${stMeta.cls}"><span class="pipe3-dot"></span>${escapeHTML(stMeta.label)}</span>
                ${declineReasonLabel ? `<div class="pipe3-dreason"${item.decline_note ? ` title="${escapeHTML(item.decline_note)}"` : ""}>${escapeHTML(declineReasonLabel)}</div>` : ""}
              </td>
              <td>
                <div class="pipe3-assignee">${escapeHTML(item.assigned_name || "—")}</div>
                ${item.assigned_role?`<div class="pipe3-assignee-role">${escapeHTML(item.assigned_role)}</div>`:""}
              </td>
              <td>
                <div class="pipe3-act-time">${escapeHTML(pipe3RelTime(item.last_activity_at || item.last_updated))}</div>
                ${actName||actAction?`<div class="pipe3-act-detail">${escapeHTML(actName)}${actName&&actAction?" · ":""}${escapeHTML(actAction)}</div>`:""}
              </td>
              <td>
                <div class="pipe3-actions-inner">
                  ${stageSlot}
                  ${crmSlot}
                </div>
              </td>
            </tr>`;
          }).join("")}
        </tbody>
      </table>
    </div>
  `;

  // ── Events ────────────────────────────────────────────────────────────────
  const pipeBulkAll = document.getElementById("pipeBulkAll");
  if(pipeBulkAll){
    pipeBulkAll.indeterminate = someChecked;
    pipeBulkAll.onchange = ()=>{
      if(pipeBulkAll.checked) bulkSelectAll(checkableIds);
      else bulkDeselectAll();
      renderPipeline();
    };
  }
  mount.querySelectorAll(".bulk-check").forEach(cb=>{
    cb.onchange = ()=>{ bulkToggle(cb.getAttribute("data-bulk")); renderPipeline(); };
  });
  bindPipe3BulkHandlers();
  mount.querySelectorAll("[data-open]").forEach(b=>{
    b.onclick=()=>openModalByAnonId(b.getAttribute("data-open"), startups);
  });
  mount.querySelectorAll("[data-pipe-id]").forEach(sel=>{
    sel.onchange=async ()=>{
      const id = sel.getAttribute("data-pipe-id");
      const newStatus = sel.value;
      if(!newStatus) return;
      if(newStatus === "Declined"){
        // "" = bei Abbruch zurück auf den "Stage ▾"-Platzhalter
        openDeclineDialog(id, "", sel);
        return;
      }
      const ok = await pipelineSetStatus(id, newStatus);
      if(ok === false){ sel.value = ""; return; }
      renderPipeline();
    };
  });
  mount.querySelectorAll("[data-crm]").forEach(b=>{
    b.onclick=async ()=>{ await pipelinePushToCRM(b.getAttribute("data-crm")); renderPipeline(); };
  });
  mount.querySelectorAll("[data-action='scoreinfo']").forEach(b=>{
    b.onclick=(e)=>{ e.stopPropagation(); openScoreBreakdown(b.getAttribute("data-id"), b); };
  });
}

/* Bulk-Bar-Handler (Stage ändern / Entfernen / Auswahl aufheben) */
function bindPipe3BulkHandlers(){
  const pipeBulkStatusSel = document.getElementById("pipeBulkStatusSel");
  const pipeBulkRemove = document.getElementById("pipeBulkRemove");
  const pipeBulkDeselect = document.getElementById("pipeBulkDeselect");
  if(pipeBulkStatusSel){
    pipeBulkStatusSel.onchange = async ()=>{
      const toStatus = pipeBulkStatusSel.value;
      if(!toStatus) return;
      pipeBulkStatusSel.value = "";
      if(toStatus === "Declined"){
        const ids = Array.from(bulkSelection);
        openDeclineDialog(null, null, null, ids);
        return;
      }
      const ids = Array.from(bulkSelection);
      let changed = 0;
      let skipped = 0;
      for (const id of ids) {
        if(isPipelineTransitionAllowed(id, toStatus)){
          const ok = await pipelineSetStatus(id, toStatus);
          if (ok) changed++; else skipped++;
        } else {
          skipped++;
        }
      }
      bulkDeselectAll();
      if(skipped > 0){
        toast("Stage gesetzt", `${changed} Deal${changed!==1?"s":""} geändert, ${skipped} übersprungen (Übergang nicht erlaubt)`);
      } else {
        toast("Stage gesetzt", `${changed} Deal${changed!==1?"s":""} geändert`);
      }
      renderPipeline();
    };
  }
  if(pipeBulkRemove){
    pipeBulkRemove.onclick = async ()=>{
      const ids = Array.from(bulkSelection);
      const count = ids.length;
      if(!confirm(`${count} Deal${count!==1?"s":""} aus der Pipeline entfernen?`)) return;
      // EIN Batch-Delete statt N Einzel-Deletes mit je einem Pipeline-Reload
      const removed = await pipelineRemoveBulk(ids);
      bulkDeselectAll();
      toast("Entfernt", `${removed} Deal${removed!==1?"s":""} entfernt`);
      renderPipeline();
    };
  }
  if(pipeBulkDeselect){
    pipeBulkDeselect.onclick = ()=>{ bulkDeselectAll(); renderPipeline(); };
  }
}
