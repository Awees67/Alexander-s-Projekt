/* =========================
   RENDERER — MODALS
   Includes: Details modal, Decline dialog, Score/Plausibility popovers
========================= */


// Relative Zeit wie Mockup: "3 TAGE HER", "1 WOCHE HER"
function dvRelTime(ts){
  const d = Math.floor((Date.now() - new Date(ts).getTime()) / 86400000);
  if (d < 1) return "HEUTE";
  if (d === 1) return "1 TAG HER";
  if (d < 7) return d + " TAGE HER";
  const w = Math.floor(d / 7);
  if (w === 1) return "1 WOCHE HER";
  if (w <= 8) return w + " WOCHEN HER";
  return new Date(ts).toLocaleDateString("de-DE");
}

function dvNoteEntryHTML(n){
  return `
      <div class="dv-note-entry">
        <div class="dv-note-meta">
          <span class="dv-note-ts">${escapeHTML(dvRelTime(n.created_at))}</span>
          <span class="dv-note-author">${escapeHTML(n.author||"Analyst")}</span>
        </div>
        <div class="dv-note-body">
          <button class="dv-note-del" data-del="${escapeHTML(n.id)}">\u2715</button>
          ${escapeHTML(n.text)}
        </div>
      </div>
    `;
}

let _modalStartup = null;

function openModalByIndex(idx, list){
  if(!list || !list.length) return;
  modalIndex = Math.max(0, Math.min(idx, list.length-1));
  const s = list[modalIndex];
  openModalWithStartup(s, list);
}

function openModalById(id){
  const list = buildFilteredList();
  const idx = list.findIndex(x=>x.anon_id===id);
  if(idx>=0) openModalByIndex(idx, list);
  else{
    const s = Array.isArray(startups) ? startups.find(x=>x.anon_id===id) : null;
    if(s) openModalWithStartup(s, [s]);
  }
}

function openModalByAnonId(anon_id, list){
  const arr = (list && list.length) ? list : startups;
  const idx = arr.findIndex(x=>x.anon_id===anon_id);
  if(idx>=0) openModalByIndex(idx, arr);
}

async function openModalWithStartup(s, list){
  _modalStartup = s;
  const backdrop = document.getElementById("modalBackdrop");
  backdrop.style.display = "flex";
  backdrop.setAttribute("aria-hidden","false");
  const modal = backdrop.querySelector(".modal");
  if(!modal) return;

  // ── Helpers ──────────────────────────────────
  function fmt(n){
    if(n===null||n===undefined) return "—";
    if(n>=1000000) return "€"+(n/1000000).toFixed(2).replace(/\.?0+$/,"")+"M";
    if(n>=1000) return "€"+(n/1000).toFixed(0)+"k";
    return "€"+Math.round(n);
  }
  // €-Präfix-Format wie Mockup: "€82.400" / "−€38.000"
  function fmtFull(n){
    const v = Number(n||0);
    return (v<0?"−":"") + "€" + Math.abs(v).toLocaleString("de-DE", { maximumFractionDigits: 0 });
  }

  // ── Custom Score ──────────────────────────────
  let scoreVal="—", rulesetName="Standard Screening";
  try{
    const res = computeCustomIndexV6(s.anon_id);
    const rules = getCustomRulesV6();
    rulesetName = rules.name||"Standard Screening";
    if(res&&res.score!==null) scoreVal = String(res.score);
  }catch(_){}
  const scoreNum = parseFloat(scoreVal);
  const scoreClr = scoreColorClass(scoreNum, s.stage);

  // ── Plausibility ──────────────────────────────
  // Quelle: pending-Submission aus dem Cache, sonst die ins Startup gemappten Werte
  const subs=(typeof getSubmissions==="function")?getSubmissions():[];
  const sub=subs.find(x=>x.anon_id===s.anon_id) || (s.plausibility_status ? s : null);
  let plausHTML="";
  if(sub){
    const pm={
      passed:{cls:"dv-pill-pass",txt:"✓ Plausibility Passed"},
      flagged:{cls:"dv-pill-warn",txt:"⚠ Flagged"},
      failed:{cls:"dv-pill-fail",txt:"✗ Failed"}
    }[sub.plausibility_status]||{cls:"dv-pill-fail",txt:"✗ Failed"};
    plausHTML=`<span class="dv-pill ${pm.cls}" id="dvPlausBadge" data-plaus="${escapeHTML(s.anon_id)}">${pm.txt}</span>`;
  }

  // ── Pipeline / CRM state ─────────────────────
  const pipeline=getPipeline();
  const pipeItem=pipeline.find(x=>x.anon_id===s.anon_id);
  const isSynced=pipeItem?.status==="Synced";
  const inPipeline=!!pipeItem;
  const alreadySent=(typeof getOutreach==="function")&&getOutreach().some(x=>x.anon_id===s.anon_id);

  // ── Sector / market display ───────────────────
  const marketStr=(s.market_served||[]).join(", ").replace("DACH","DACH (DE · AT · CH)");

  // ── Growth ───────────────────────────────────
  const g=s.growth?.value_pct??null;
  const gVal=g===null?"—":(g>0?"+":"")+g+" %";
  const gCls=g===null?"":g>20?"g":g>0?"a":"r";

  // ── Semantic color helpers ────────────────────
  function nrrCls(v){ return v>=110?"g":v>=100?"a":"r"; }
  function gmCls(v){ return v>=70?"g":v>=50?"a":"r"; }
  function pbCls(v){ return v<=18?"g":v<=30?"a":"r"; }
  function churnCls(v){ return v<=0?"g":v>=2?"r":"a"; }
  function ltvcCls(v){ return v>=3?"g":v>=1?"a":"r"; }
  function bmCls(v){ return v<=1.5?"g":v<=3?"a":"r"; }
  function rwCls(v){ return v>=18?"g":v>=12?"a":"r"; }

  // ── Notes HTML ───────────────────────────────
  const notes=(typeof getNotesForDeal==="function") ? (await getNotesForDeal(s.anon_id)) : [];
  const notesHTML=notes.length===0
    ?`<div class="dv-note-empty">Noch keine Notizen.</div>`
    :notes.map(dvNoteEntryHTML).join("");

  // ── Burn Multiple ─────────────────────────────
  const bm=s.burn_multiple!==null&&s.burn_multiple!==undefined?s.burn_multiple.toFixed(2)+" ×":"—";
  const bmCl=s.burn_multiple!==null?bmCls(s.burn_multiple):"";

  // ── Ownership ─────────────────────────────────
  const owInvestoren=((s.investor_pct||0)).toFixed(1);
  const owMitarbeiter=((s.employees_pct||0)).toFixed(1);

  // ── Founder-Team ──────────────────────────────
  const founders = Array.isArray(s.founders) ? s.founders : [];
  const buildBackground = (prevCos, prevRoles, years) => {
    if (!prevCos.length) return '—';
    const parts = prevCos.map((co, i) => {
      const role = prevRoles[i] || '';
      return role ? `${co} — ${role}` : co;
    });
    const base = parts.join(' · ');
    return years ? `${base}  (${years} Jahre)` : base;
  };
  const foundersHTML = founders.length === 0
    ? `<div class="dv-founder-empty">Keine Founder-Informationen angegeben.</div>`
    : founders.map((f, i) => {
        const prevCos = Array.isArray(f.prev_companies) ? f.prev_companies.filter(Boolean) : [];
        const prevRoles = Array.isArray(f.prev_roles) ? f.prev_roles.filter(Boolean) : [];
        const strengths = Array.isArray(f.strengths) ? f.strengths : [];
        const name = f.name || '—';
        const role = escapeHTML(f.role || '');
        const background = buildBackground(prevCos, prevRoles, f.years_experience);
        const education = f.education || '';
        const strengthsStr = strengths.length ? strengths.map(escapeHTML).join(', ') : '';
        const exitStr = f.had_exit ? (f.exit_detail || 'Ja') : '';
        const linkedin = f.linkedin_url
          ? `<a class="dv-founder-link" href="${escapeHTML(f.linkedin_url)}" target="_blank" rel="noopener">LinkedIn ↗</a>`
          : '';
        // Alle Zeilen immer anzeigen — leere Werte als "—" (wie Mockup)
        const row = (label, value) =>
          `<div class="dv-frow"><span class="dv-fpl">${escapeHTML(label)}</span><span class="dv-fpv">${value || '—'}</span></div>`;
        return `
          <div class="dv-founder-card">
            <div class="dv-founder-head">
              <span class="dv-founder-name">${escapeHTML(name)}</span>
              <span class="dv-founder-role">${role}</span>
              ${linkedin}
            </div>
            <div class="dv-founder-rows">
              ${row('Background', escapeHTML(background))}
              ${row('Ausbildung', escapeHTML(education))}
              ${row('Stärken', strengthsStr)}
              ${row('Prior Exit', escapeHTML(exitStr))}
            </div>
          </div>
        `;
      }).join('');
  const teamNoteHTML = s.team_note
    ? `<div class="dv-team-note"><span class="dv-team-note-label">Team-Notiz</span>${escapeHTML(s.team_note)}</div>`
    : '';

  // ── Render ────────────────────────────────────
  modal.innerHTML=`
    <div class="dv-topbar">
      <span class="dv-topbar-id">${escapeHTML(startupLabel(s))}</span>
      <span class="dv-topbar-sep">/</span>
      <span class="dv-topbar-meta">${escapeHTML(s.anon_id)} · ${escapeHTML(s.sector)} · ${escapeHTML(s.stage)} · ${escapeHTML(s.origin_country)}</span>
      <button class="dv-btn" id="dvPrevBtn">← Zurück</button>
      <button class="dv-btn" id="dvNextBtn">Weiter →</button>
      <button class="dv-btn" id="dvCompareBtn">Compare</button>
      <button class="dv-btn" id="dvPipeBtn" ${inPipeline?"disabled":""}>${inPipeline?"✓ In Pipeline":"Pipeline"}</button>
      <button class="dv-btn dv-btn-crm" id="dvCrmBtn" ${isSynced?"disabled":""}>${isSynced?"✓ Synced":"Push to CRM"}</button>
      <button class="dv-btn dv-btn-prim" id="dvAnfrageBtn" ${alreadySent?"disabled":""}>${alreadySent?"✓ Angefragt":"Anfrage senden"}</button>
      ${s.pitch_deck_url?`<a class="dv-btn" href="${escapeHTML(s.pitch_deck_url)}" target="_blank" rel="noopener">Pitch Deck ↗</a>`:''}
      <button class="dv-btn dv-btn-close" id="modalClose" title="Schließen">✕</button>
    </div>

    <div class="dv-main">
      <div class="dv-left">

        <div class="dv-hero">
          <div class="dv-hero-info">
            <div class="dv-hero-name">
              ${escapeHTML(startupLabel(s))}
              <span class="dv-pill dv-pill-stage">${escapeHTML(s.stage)}</span>
              <span class="dv-pill">${escapeHTML(s.sector)}</span>
              ${plausHTML}
            </div>
            <div class="dv-hero-desc">${escapeHTML(s.description||s.notes||"")}</div>
          </div>
          <div class="dv-score-block">
            <span class="dv-score-label">Custom Score</span>
            <span class="dv-score-number ${scoreClr}">${escapeHTML(scoreVal)}</span>
            <span class="dv-score-ruleset">${escapeHTML(rulesetName)}</span>
            <button class="dv-score-info" id="dvScoreInfo" data-si="${escapeHTML(s.anon_id)}">(i) Breakdown</button>
          </div>
        </div>

        <div class="dv-section">
          <div class="dv-sec-head"><span class="dv-sec-title">Kontext</span><div class="dv-sec-line"></div></div>
          <div class="dv-pgrid">
            <div class="dv-prow"><span class="dv-pl">HQ</span><span class="dv-pv ui">${escapeHTML(s.origin_country)}</span></div>
            <div class="dv-prow"><span class="dv-pl">Markt</span><span class="dv-pv ui">${escapeHTML(marketStr)}</span></div>
            <div class="dv-prow"><span class="dv-pl">Stage</span><span class="dv-pv ui dv-kx-stage">${escapeHTML(s.stage)}</span></div>
            <div class="dv-prow"><span class="dv-pl">Gegründet</span><span class="dv-pv">${s.founded_year!=null?escapeHTML(String(s.founded_year)):"—"}</span></div>
            ${s.contact_name?`<div class="dv-prow full"><span class="dv-pl">Kontakt</span><span class="dv-pv ui">${escapeHTML(s.contact_name)}${s.contact_email?" — "+escapeHTML(s.contact_email):""}</span></div>`:""}
            ${s.pitch_deck_url?`<div class="dv-prow full"><span class="dv-pl">Pitch Deck</span><span class="dv-pv"><a href="${escapeHTML(s.pitch_deck_url)}" target="_blank" rel="noopener" style="color:var(--accent);">Deck öffnen ↗</a></span></div>`:""}
          </div>
        </div>

        <div class="dv-section">
          <div class="dv-sec-head"><span class="dv-sec-title">Founder & Team</span><div class="dv-sec-line"></div></div>
          <div class="dv-founders">
            ${foundersHTML}
            ${teamNoteHTML}
          </div>
        </div>

        <div class="dv-section">
          <div class="dv-sec-head"><span class="dv-sec-title">Revenue & Wachstum</span><div class="dv-sec-line"></div></div>
          <div class="dv-pgrid">
            <div class="dv-prow"><span class="dv-pl">MRR</span><span class="dv-pv">${escapeHTML(fmtFull(s.mrr_eur))}</span></div>
            <div class="dv-prow"><span class="dv-pl">ARR</span><span class="dv-pv">${escapeHTML(fmtFull(s.arr_eur))}</span></div>
            <div class="dv-prow"><span class="dv-pl">Wachstum ${escapeHTML(s.growth?.type||"MoM")}</span><span class="dv-pv ${gCls}">${escapeHTML(gVal)}</span></div>
            <div class="dv-prow"><span class="dv-pl">Net New MRR</span><span class="dv-pv">${escapeHTML(fmtFull(s.net_new_mrr_eur))}</span></div>
            ${s.paying_customers!=null?`<div class="dv-prow full"><span class="dv-pl">Paying Customers</span><span class="dv-pv">${escapeHTML(String(s.paying_customers))}</span></div>`:''}

          </div>
        </div>

        <div class="dv-section">
          <div class="dv-sec-head"><span class="dv-sec-title">Retention</span><div class="dv-sec-line"></div></div>
          <div class="dv-pgrid">
            <div class="dv-prow"><span class="dv-pl">NRR</span><span class="dv-pv ${nrrCls(s.nrr_pct)}">${escapeHTML(String(s.nrr_pct))} %</span></div>
            <div class="dv-prow"><span class="dv-pl">Logo Churn</span><span class="dv-pv ${churnCls(s.logo_churn_pct)}">${escapeHTML(String(s.logo_churn_pct))} %</span></div>
            <div class="dv-prow full"><span class="dv-pl">Revenue Churn</span><span class="dv-pv ${churnCls(s.revenue_churn_pct)}">${escapeHTML(String(s.revenue_churn_pct))} %</span></div>
          </div>
        </div>

        <div class="dv-section">
          <div class="dv-sec-head"><span class="dv-sec-title">Unit Economics</span><div class="dv-sec-line"></div></div>
          <div class="dv-pgrid">
            <div class="dv-prow"><span class="dv-pl">Gross Margin</span><span class="dv-pv ${s.gross_margin_pct!=null?gmCls(s.gross_margin_pct):""}">${s.gross_margin_pct!=null?escapeHTML(String(s.gross_margin_pct))+" %":"—"}</span></div>
            <div class="dv-prow"><span class="dv-pl">LTV</span><span class="dv-pv">${s.ltv_eur!=null?escapeHTML(fmtFull(s.ltv_eur)):"—"}</span></div>
            <div class="dv-prow"><span class="dv-pl">CAC</span><span class="dv-pv">${s.cac_eur!=null?escapeHTML(fmtFull(s.cac_eur)):"—"}</span></div>
            <div class="dv-prow"><span class="dv-pl">CAC Payback</span><span class="dv-pv ${s.cac_payback_months!=null?pbCls(s.cac_payback_months):""}">${s.cac_payback_months!=null?escapeHTML(String(s.cac_payback_months))+" Monate":"—"}</span></div>
            <div class="dv-prow full"><span class="dv-pl">LTV / CAC</span><span class="dv-pv ${s.ltv_cac_ratio!=null?ltvcCls(s.ltv_cac_ratio):""}">${s.ltv_cac_ratio!=null?escapeHTML(s.ltv_cac_ratio.toFixed(1))+" ×":"—"}</span></div>
            ${s.arpa_eur!=null?`<div class="dv-prow"><span class="dv-pl">ARPA</span><span class="dv-pv">${escapeHTML(fmtFull(s.arpa_eur))} / Mo</span></div>`:''}
            ${s.acv_eur!=null?`<div class="dv-prow"><span class="dv-pl">ACV</span><span class="dv-pv">${escapeHTML(fmtFull(s.acv_eur))}</span></div>`:''}

          </div>
        </div>

        <div class="dv-section">
          <div class="dv-sec-head"><span class="dv-sec-title">Capital Efficiency</span><div class="dv-sec-line"></div></div>
          <div class="dv-pgrid">
            <div class="dv-prow"><span class="dv-pl">Burn / Monat</span><span class="dv-pv r">${s.burn_eur_per_month>0?"−":""}${escapeHTML(fmtFull(s.burn_eur_per_month))}</span></div>
            <div class="dv-prow"><span class="dv-pl">Runway</span><span class="dv-pv ${rwCls(s.runway_months)}">${escapeHTML(String(s.runway_months))} Monate</span></div>
            <div class="dv-prow full"><span class="dv-pl">Burn Multiple</span><span class="dv-pv ${bmCl}">${escapeHTML(bm)}</span></div>
          </div>
        </div>

        ${(s.tam_eur||s.sam_eur)?`
        <div class="dv-section">
          <div class="dv-sec-head"><span class="dv-sec-title">Markt</span><div class="dv-sec-line"></div></div>
          <div class="dv-pgrid">
            ${s.tam_eur!=null?`<div class="dv-prow"><span class="dv-pl">TAM</span><span class="dv-pv">${escapeHTML(fmtFull(s.tam_eur))}</span></div>`:''}
            ${s.sam_eur!=null?`<div class="dv-prow"><span class="dv-pl">SAM</span><span class="dv-pv">${escapeHTML(fmtFull(s.sam_eur))}</span></div>`:''}
          </div>
        </div>`:''}

        <div class="dv-section">
          <div class="dv-sec-head"><span class="dv-sec-title">Cap Table & Runde</span><div class="dv-sec-line"></div></div>
          <div class="dv-pgrid">
            <div class="dv-prow"><span class="dv-pl">Round Size</span><span class="dv-pv">${escapeHTML(fmtFull(s.ticket_eur))}</span></div>
            ${s.valuation_eur!=null?`<div class="dv-prow"><span class="dv-pl">Pre-Money</span><span class="dv-pv">${escapeHTML(fmtFull(s.valuation_eur))}</span></div>`:''}
            ${s.total_raised_eur!=null?`<div class="dv-prow"><span class="dv-pl">Raised to Date</span><span class="dv-pv">${escapeHTML(fmtFull(s.total_raised_eur))}</span></div>`:''}
            ${s.investor_count!=null?`<div class="dv-prow"><span class="dv-pl">Bisherige Investoren</span><span class="dv-pv">${escapeHTML(String(s.investor_count))}</span></div>`:''}
            <div class="dv-prow"><span class="dv-pl">Founder Ownership</span><span class="dv-pv">${escapeHTML((s.founder_pct||0).toFixed(1))} %</span></div>
            <div class="dv-prow"><span class="dv-pl">Vergeben (Investoren)</span><span class="dv-pv">${escapeHTML(owInvestoren)} %</span></div>
            <div class="dv-prow"><span class="dv-pl">Vergeben (Mitarbeiter)</span><span class="dv-pv">${escapeHTML(owMitarbeiter)} %</span></div>
          </div>
        </div>

      </div>

      <div class="dv-right">
        <div class="dv-notes">
          <div class="dv-notes-head">
            <span class="dv-notes-title">Notes</span>
          </div>
          <div class="dv-notes-list" id="dvNotesList">${notesHTML}</div>
          <div class="dv-note-add">
            <textarea class="dv-note-inp" id="dvNoteInput" placeholder="Neue Notiz…" rows="3" maxlength="500"></textarea>
            <button class="dv-note-save" id="dvNoteSave">Speichern</button>
            <div class="dv-note-hint">Ctrl+Enter zum Speichern</div>
          </div>
        </div>
      </div>
    </div>
  `;

  // ── Event Bindings ─────────────────────────────
  const arr=(list&&list.length)?list:[s];
  const idx=arr.findIndex(z=>z.anon_id===s.anon_id);

  // Navigation
  document.getElementById("dvPrevBtn").onclick=()=>openModalByIndex((idx-1+arr.length)%arr.length,arr);
  document.getElementById("dvNextBtn").onclick=()=>openModalByIndex((idx+1)%arr.length,arr);

  // Close button
  const closeBtn=document.getElementById("modalClose");
  if(closeBtn) closeBtn.onclick=closeModal;

  // Keyboard
  if(modal._keyHandler) document.removeEventListener("keydown",modal._keyHandler);
  modal._keyHandler=(e)=>{
    if(backdrop.style.display!=="flex") return;
    if(e.key==="ArrowRight") document.getElementById("dvNextBtn")?.click();
    if(e.key==="ArrowLeft")  document.getElementById("dvPrevBtn")?.click();
    if(e.key==="Escape") closeModal();
  };
  document.addEventListener("keydown",modal._keyHandler);

  // Pipeline
  const pipeBtn=document.getElementById("dvPipeBtn");
  if(pipeBtn&&!inPipeline){
    pipeBtn.onclick=async ()=>{
      const res = await pipelineAdd(s.anon_id,"In Review");
      if (!res) { toast("Fehler","Pipeline-Hinzufuegen fehlgeschlagen"); return; }
      activityLogAppend("PIPELINE_ADDED", s.anon_id, { status: "In Review" });
      toast("Pipeline","Deal zur Pipeline hinzugefügt");
      pipeBtn.textContent="✓ In Pipeline";
      pipeBtn.disabled=true;
      if(currentView==="pipeline") renderPipeline();
    };
  }

  // CRM
  const crmBtn=document.getElementById("dvCrmBtn");
  if(crmBtn&&!isSynced){
    crmBtn.onclick=async ()=>{
      const pi=getPipeline().find(x=>x.anon_id===s.anon_id);
      if(pi&&pi.status==="Declined"){
        if(!confirm("Dieser Deal wurde declined. Trotzdem ins CRM pushen?")) return;
      }
      const ok = await pipelinePushToCRM(s.anon_id);
      if (!ok) return;
      crmBtn.textContent="✓ Synced";
      crmBtn.disabled=true;
      if(currentView==="pipeline") renderPipeline();
    };
  }

  // Compare
  document.getElementById("dvCompareBtn").onclick=()=>addToCompare(s.anon_id);

  // Anfrage
  const anfBtn=document.getElementById("dvAnfrageBtn");
  if(anfBtn&&!alreadySent){
    anfBtn.onclick=()=>{ closeModal(); if(typeof _otOpenSendModal==="function") _otOpenSendModal(s); };
  }

  // Plausibility
  const plausEl=document.getElementById("dvPlausBadge");
  if(plausEl) plausEl.onclick=(e)=>{ if(typeof openPlausibilityBreakdown==="function") openPlausibilityBreakdown(s.anon_id,plausEl); e.stopPropagation(); };

  // Score breakdown
  const scoreInfoBtn=document.getElementById("dvScoreInfo");
  if(scoreInfoBtn) scoreInfoBtn.onclick=(e)=>{ if(typeof openScoreBreakdown==="function") openScoreBreakdown(s.anon_id,scoreInfoBtn); e.stopPropagation(); };

  // Notes: save
  const noteSave=document.getElementById("dvNoteSave");
  const noteInput=document.getElementById("dvNoteInput");
  if(noteSave&&noteInput){
    const doSave=async ()=>{
      const text=noteInput.value.trim();
      if(!text) return;
      const actor=(typeof getCurrentMember==="function") ? await getCurrentMember() : null;
      const author=actor?.name || "Analyst";
      const saved = await addNote(s.anon_id,text,author);
      if (!saved) return;
      activityLogAppend("NOTE_ADDED", s.anon_id, { text: saved.text.slice(0, 80), author: saved.author });
      noteInput.value="";
      toast("Gespeichert","Notiz hinzugefügt");
      const updatedNotes=(typeof getNotesForDeal==="function") ? (await getNotesForDeal(s.anon_id)) : [];
      const listEl=document.getElementById("dvNotesList");
      if(listEl){
        if(updatedNotes.length===0){
          listEl.innerHTML='<div class="dv-note-empty">Noch keine Notizen.</div>';
        }else{
          listEl.innerHTML=updatedNotes.map(dvNoteEntryHTML).join("");
          listEl.querySelectorAll("[data-del]").forEach(btn=>{
            btn.onclick=async (e)=>{
              e.stopPropagation();
              const nid = btn.getAttribute("data-del");
              const ok = await deleteNote(nid);
              if (!ok) return;
              activityLogAppend("NOTE_DELETED", s.anon_id, { note_id: nid });
              btn.closest(".dv-note-entry").remove();
              toast("Gelöscht","Notiz gelöscht");
            };
          });
        }
      }
    };
    noteSave.onclick=doSave;
    noteInput.addEventListener("keydown",(e)=>{ if((e.ctrlKey||e.metaKey)&&e.key==="Enter"){ e.preventDefault(); doSave(); } });
  }

  // Notes: delete
  modal.querySelectorAll("[data-del]").forEach(btn=>{
    btn.onclick=async (e)=>{
      e.stopPropagation();
      const nid = btn.getAttribute("data-del");
      const ok = await deleteNote(nid);
      if (!ok) return;
      activityLogAppend("NOTE_DELETED", s.anon_id, { note_id: nid });
      btn.closest(".dv-note-entry").remove();
      toast("Gelöscht","Notiz gelöscht");
    };
  });
}

function closeModal(){
  const backdrop=document.getElementById("modalBackdrop");
  backdrop.style.display="none";
  backdrop.setAttribute("aria-hidden","true");
  const modal=backdrop.querySelector(".modal");
  if(modal&&modal._keyHandler){
    document.removeEventListener("keydown",modal._keyHandler);
    modal._keyHandler=null;
  }
}

/* =========================
   DECLINE DIALOG
========================= */
let _declineAnonId = null;
let _declinePrevStatus = null;
let _declineSelectEl = null;
let _declineBulkIds = null; // non-null = bulk mode

function openDeclineDialog(anon_id, prevStatus, selectEl, bulkIds){
  _declineAnonId = anon_id;
  _declinePrevStatus = prevStatus;
  _declineSelectEl = selectEl;
  _declineBulkIds = bulkIds || null;

  const dlg = document.getElementById("declineDialog");
  const dealNameEl = document.getElementById("declineDealName");
  const reasonSel = document.getElementById("declineReasonSelect");
  const noteInput = document.getElementById("declineNoteInput");
  if(!dlg || !dealNameEl || !reasonSel || !noteInput) return;

  // Set deal name (bulk vs. single)
  if(_declineBulkIds){
    dealNameEl.textContent = `${_declineBulkIds.length} ausgewählte Deals (Grund gilt für alle)`;
  } else {
    const startup = Array.isArray(startups) ? startups.find(x => x.anon_id === anon_id) : null;
    dealNameEl.textContent = startup ? startupLabel(startup) : anon_id;
  }

  // Fill reason dropdown
  reasonSel.innerHTML = `<option value="">— Bitte auswählen —</option>` +
    DECLINE_REASONS.map(r => `<option value="${escapeHTML(r.key)}">${escapeHTML(r.label)}</option>`).join("");
  reasonSel.classList.remove("shake");

  // Clear note
  noteInput.value = "";

  dlg.style.display = "flex";

  const confirmBtn = document.getElementById("declineConfirmBtn");
  const cancelBtn  = document.getElementById("declineCancelBtn");

  // Clone buttons to remove old listeners
  const newConfirm = confirmBtn.cloneNode(true);
  const newCancel  = cancelBtn.cloneNode(true);
  confirmBtn.parentNode.replaceChild(newConfirm, confirmBtn);
  cancelBtn.parentNode.replaceChild(newCancel, cancelBtn);

  newConfirm.addEventListener("click", async ()=>{
    const reason = document.getElementById("declineReasonSelect").value;
    if(!reason){
      const sel = document.getElementById("declineReasonSelect");
      sel.classList.remove("shake");
      void sel.offsetWidth; // reflow to restart animation
      sel.classList.add("shake");
      toast("Pflichtfeld", "Bitte einen Grund auswählen");
      return;
    }
    const note = document.getElementById("declineNoteInput").value.trim();

    if(_declineBulkIds){
      // Bulk decline mode: apply reason to all selected IDs
      const ids = _declineBulkIds;
      let changed = 0;
      let skipped = 0;
      for (const id of ids) {
        if(isPipelineTransitionAllowed(id, "Declined")){
          const ok = await pipelineSetStatus(id, "Declined", reason, note);
          if (ok) changed++; else skipped++;
        } else {
          skipped++;
        }
      }
      bulkDeselectAll();
      closeDeclineDialog();
      if(skipped > 0){
        toast("Declined", `${changed} Deal${changed!==1?"s":""} abgelehnt, ${skipped} übersprungen`);
      } else {
        toast("Declined", `${changed} Deal${changed!==1?"s":""} abgelehnt`);
      }
      renderPipeline();
    } else {
      const ok = await pipelineSetStatus(_declineAnonId, "Declined", reason, note);
      closeDeclineDialog();
      if(ok){ renderPipeline(); }
    }
  });

  newCancel.addEventListener("click", ()=>{
    // Revert dropdown to previous status (single mode only)
    if(_declineSelectEl && !_declineBulkIds){
      _declineSelectEl.value = _declinePrevStatus || "";
    }
    closeDeclineDialog();
  });
}

function closeDeclineDialog(){
  const dlg = document.getElementById("declineDialog");
  if(dlg) dlg.style.display = "none";
  _declineAnonId = null;
  _declinePrevStatus = null;
  _declineSelectEl = null;
}

/* =========================
   MODAL PIPELINE BUTTONS
========================= */
function syncModalPipelineButtons(s){
  if(!s) return;
  const p = getPipeline();
  const item = p.find(x=>x.anon_id===s.anon_id);

  const addBtn = document.getElementById("addToPipelineBtn");
  const crmBtn = document.getElementById("pushToCrmBtn");
  if(!addBtn || !crmBtn) return;

  if(!item){
    addBtn.textContent = "Add to Pipeline";
    addBtn.disabled = false;
    addBtn.title = "";
    crmBtn.textContent = "Push to CRM";
    crmBtn.disabled = false;
    crmBtn.style.opacity = "";
  } else if(item.status === "Synced"){
    addBtn.textContent = "In Pipeline ✓";
    addBtn.disabled = true;
    addBtn.title = "Status: Synced";
    crmBtn.textContent = "✓ Synced to CRM";
    crmBtn.disabled = true;
    crmBtn.style.opacity = "0.5";
  } else {
    addBtn.textContent = "In Pipeline ✓";
    addBtn.disabled = true;
    addBtn.title = `Status: ${item.status}`;
    crmBtn.textContent = "Push to CRM";
    crmBtn.disabled = false;
    crmBtn.style.opacity = "";
  }
}
