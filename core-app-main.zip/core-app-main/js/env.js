const SUPABASE_URL      = 'https://ggfjgzjevyemwbclvfpp.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_27NELp2B1onC07knBjxKVQ_n5A_k9ox';
