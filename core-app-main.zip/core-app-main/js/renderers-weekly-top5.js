/* =========================
   RENDERER — WEEKLY TOP 5
========================= */

function _t5StagePillClass(stage) {
  const map = {
    'Pre-Seed':     'dv-pill-preseed',
    'Seed':         'dv-pill-seed',
    'Pre-Series A': 'dv-pill-prea',
    'Series A':     'dv-pill-a',
    'Series B':     'dv-pill-a',
  };
  return map[stage] || '';
}

function _t5ScoreClass(score, stage) {
  return scoreColorClass(score, stage);
}

function computePeerRank(startup) {
  const targetStage = startup.stage || '';
  const peerGroup = (window.startups || [])
    .filter(s => (s.stage || '') === targetStage)
    .map(s => ({ anon_id: s.anon_id, score: computeSignalIndex(s.anon_id) }))
    .sort((a, b) => b.score - a.score);

  const rank = peerGroup.findIndex(s => s.anon_id === startup.anon_id) + 1;
  const total = peerGroup.length;
  const topPercent = total > 1 ? Math.ceil((rank / total) * 100) : null;

  return { rank, total, topPercent };
}

function getWeeklyTop5Candidates(days) {
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  const pipelineIds = new Set((getPipeline() || []).map(p => p.anon_id));

  return (window.startups || []).filter(s =>
    !pipelineIds.has(s.anon_id) &&
    s.submitted_at !== null &&
    s.submitted_at !== undefined &&
    new Date(s.submitted_at).getTime() >= cutoff
  );
}

function buildWhyText(anon_id) {
  let res;
  try { res = computeCustomIndexV6(anon_id); } catch(_) { return null; }
  const top3 = (res.breakdown || [])
    .filter(r => r.points > 0 && !r.skipped)
    .sort((a, b) => b.points - a.points)
    .slice(0, 3);
  if (!top3.length) return null;
  return top3.map(r => `${escapeHTML(r.note || r.kpi)} (+${r.points} Pkt)`).join(', ');
}

function _t5Fmt(n) {
  if (n === null || n === undefined || n === 0) return null;
  if (n >= 1000000) return '€' + (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000)    return '€' + (n / 1000).toFixed(0) + 'k';
  return '€' + Math.round(n);
}

function buildWeeklyTop5RowHTML(startup, rank, peerData) {
  const score = computeSignalIndex(startup.anon_id);
  const scoreClass = _t5ScoreClass(score, startup.stage);
  const isTop = rank === 1;
  const stageLabel = escapeHTML(startup.stage || 'Unbekannt');
  const stagePillClass = _t5StagePillClass(startup.stage || '');

  const whyText = buildWhyText(startup.anon_id);
  const whyContent = whyText ?? 'Relativ bester Deal im Zeitraum.';

  const kpis = [];
  const mrr = _t5Fmt(startup.mrr_eur);
  if (mrr) kpis.push(`MRR <strong>${mrr}</strong>`);
  const g = startup.growth?.value_pct;
  if (g !== null && g !== undefined) kpis.push(`Growth <strong>${g > 0 ? '+' : ''}${g}%</strong>`);
  if (startup.nrr_pct) kpis.push(`NRR <strong>${startup.nrr_pct}%</strong>`);
  if (startup.runway_months) kpis.push(`Runway <strong>${startup.runway_months} Mo.</strong>`);

  let peerHTML = '';
  if (peerData.topPercent !== null) {
    peerHTML = `<div class="t5-peer ${scoreClass}">Top ${peerData.topPercent}%</div>`;
  }

  let peerCountHTML = '';
  if (peerData.topPercent === null) {
    peerCountHTML = `<div class="t5-peercount--singleton">#1 von 1 ${stageLabel}</div>`;
  } else {
    peerCountHTML = `<div class="t5-peercount">#${peerData.rank} von ${peerData.total} ${stageLabel}s</div>`;
  }

  return `
    <div class="t5-row${isTop ? ' t5-row--top' : ''}">
      <div class="t5-rank${isTop ? ' t5-rank--gold' : ''}">#${rank}</div>
      <div class="t5-body">
        <div class="t5-head">
          <span class="t5-id t5-id--link" data-anon-id="${escapeHTML(startup.anon_id)}">${escapeHTML(startup.company_name || startup.anon_id)}</span>
          <span class="dv-pill ${stagePillClass}">${stageLabel}</span>
        </div>
        <div class="t5-kpis">
          ${kpis.map(k => `<span class="t5-kpi">${k}</span>`).join('')}
        </div>
        <div class="t5-why">
          <strong>Warum Top 5:</strong> ${escapeHTML(whyContent)}
        </div>
      </div>
      <div class="t5-score">
        <div class="t5-score-num ${scoreClass}">${score}</div>
        <div class="t5-score-max">/ ${getCustomRulesV6()?.scoring?.max_score ?? 100}</div>
        ${peerHTML}
        ${peerCountHTML}
      </div>
    </div>
  `;
}

function renderWeeklyTop5Modal(days) {
  // Top 5 rankt nach Signal-Score — ohne aktives Regelwerk nicht möglich.
  if (typeof isCustomIndexEnabled === "function" && !isCustomIndexEnabled()) {
    const modalOff = document.querySelector('#weeklyTop5Backdrop .top5-modal');
    if (modalOff) {
      modalOff.innerHTML = `
        <div class="t5-topbar">
          <span class="t5-title">★ Top 5 Deals — <span class="t5-accent">unbearbeitet</span></span>
          <button class="dv-btn dv-btn-close" id="t5CloseBtn">✕</button>
        </div>
        <div class="t5-empty">Der Signal-Score ist deaktiviert. Aktiviere das Regelwerk über den
          „Score"-Button (Häkchen „Aktiv"), um das Top-5-Ranking zu nutzen.</div>
      `;
      modalOff.querySelector('#t5CloseBtn')?.addEventListener('click', closeWeeklyTop5Modal);
    }
    return;
  }
  const candidates = getWeeklyTop5Candidates(days);
  const total = candidates.length;

  const ranked = candidates
    .map(s => ({ startup: s, peerData: computePeerRank(s), score: computeSignalIndex(s.anon_id) }))
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      const pa = a.peerData.topPercent ?? 999;
      const pb = b.peerData.topPercent ?? 999;
      return pa - pb;
    })
    .slice(0, 5);

  const timeOptions = [7, 14, 30, 90];
  const timeBtns = timeOptions.map(d =>
    `<button class="dv-btn${d === days ? ' active' : ''}" data-t5days="${d}">${d} Tage</button>`
  ).join('');

  const dealsHTML = ranked.length === 0
    ? `<div class="t5-empty">Keine unbearbeiteten Deals in diesem Zeitraum.</div>`
    : ranked.map((item, i) => buildWeeklyTop5RowHTML(item.startup, i + 1, item.peerData)).join('');

  const footerHTML = ranked.length > 0
    ? `<div class="t5-footer">Nur ohne Pipeline-Stage · Peer-Rang innerhalb der Stage-Gruppe · Sortiert nach Peer-Percentile</div>`
    : '';

  const modal = document.querySelector('#weeklyTop5Backdrop .top5-modal');
  if (!modal) return;

  modal.innerHTML = `
    <div class="t5-topbar">
      <span class="t5-title">★ Top 5 Deals — <span class="t5-accent">unbearbeitet</span></span>
      <button class="dv-btn dv-btn-close" id="t5CloseBtn">✕</button>
    </div>
    <div class="t5-timebar">
      <span class="t5-timelabel">Zeitraum</span>
      ${timeBtns}
      <span class="t5-meta">${total} ohne Stage · ${ranked.length} gerankt</span>
    </div>
    <div class="t5-list">${dealsHTML}</div>
    ${footerHTML}
  `;

  modal.querySelectorAll('[data-t5days]').forEach(btn => {
    btn.addEventListener('click', () => renderWeeklyTop5Modal(Number(btn.dataset.t5days)));
  });

  modal.querySelector('#t5CloseBtn')?.addEventListener('click', closeWeeklyTop5Modal);

  modal.querySelectorAll('.t5-id--link').forEach(el => {
    el.addEventListener('click', () => {
      closeWeeklyTop5Modal();
      openModalByAnonId(el.dataset.anonId, window.startups);
    });
  });
}

function openWeeklyTop5Modal() {
  const backdrop = document.getElementById('weeklyTop5Backdrop');
  if (!backdrop) return;
  backdrop.style.display = 'flex';
  backdrop.setAttribute('aria-hidden', 'false');
  renderWeeklyTop5Modal(7);
}

function closeWeeklyTop5Modal() {
  const backdrop = document.getElementById('weeklyTop5Backdrop');
  if (!backdrop) return;
  backdrop.style.display = 'none';
  backdrop.setAttribute('aria-hidden', 'true');
}

document.getElementById('weeklyTop5Backdrop')?.addEventListener('click', function(e) {
  if (e.target.id === 'weeklyTop5Backdrop') closeWeeklyTop5Modal();
});
