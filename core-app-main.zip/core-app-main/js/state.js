/* =========================
   APP STATE (localStorage)
========================= */
let startups = [];
let currentView = "dashboard"; // dashboard | home | submissions | pipeline | compare | activity | inbox
let modalIndex = -1;
let lastListContext = [];

/* =========================
   BULK SELECTION STATE
========================= */
let bulkSelection = new Set(); // Temporary, RAM-only. Cleared on every view change.

function bulkToggle(id){ bulkSelection.has(id) ? bulkSelection.delete(id) : bulkSelection.add(id); }
function bulkSelectAll(ids){ ids.forEach(id => bulkSelection.add(id)); }
function bulkDeselectAll(){ bulkSelection.clear(); }
function bulkIsSelected(id){ return bulkSelection.has(id); }
function bulkCount(){ return bulkSelection.size; }

/** Returns true if the pipeline transition from current status → toStatus is allowed (without side effects). */
function isPipelineTransitionAllowed(anon_id, toStatus){
  const item = getPipeline().find(x => x.anon_id === anon_id);
  if(!item) return false;
  const from = item.status;
  if(from === "Synced") return false;
  const allowed = PIPELINE_TRANSITIONS[from] || [];
  return allowed.includes(toStatus) || toStatus === from;
}

const FILTER_DEFAULTS = {
  ue: "All", rq: "All", ce: "All",
  advEnabled: false,
  nrrMin: null, ltvCacMin: null,
  mrrMin: null, mrrMax: null,
  growthMin: null, runwayMin: null, burnMax: null, ebitdaMin: null,
  ticketMin: null, ticketMax: null
};
function makeFilters(){
  return { origin: new Set(), market: new Set(), stage: new Set(), sector: new Set(), sub_sector: new Set(), ...FILTER_DEFAULTS };
}
function serializeFilters(){
  return {
    origin: Array.from(filters.origin), market: Array.from(filters.market),
    stage: Array.from(filters.stage), sector: Array.from(filters.sector),
    sub_sector: Array.from(filters.sub_sector),
    ...FILTER_DEFAULTS,
    ue: filters.ue, rq: filters.rq, ce: filters.ce,
    advEnabled: filters.advEnabled,
    nrrMin: filters.nrrMin, ltvCacMin: filters.ltvCacMin,
    mrrMin: filters.mrrMin, mrrMax: filters.mrrMax,
    growthMin: filters.growthMin, runwayMin: filters.runwayMin,
    burnMax: filters.burnMax, ebitdaMin: filters.ebitdaMin,
    ticketMin: filters.ticketMin, ticketMax: filters.ticketMax
  };
}
function applyFilterObject(f){
  const nn = (v) => (v === null || v === undefined) ? null : Number(v);
  filters.origin = new Set(f.origin || []);
  filters.market = new Set(f.market || []);
  filters.stage = new Set(f.stage || []);
  filters.sector = new Set(f.sector || []);
  filters.sub_sector = new Set(f.sub_sector || []);
  filters.ue = f.ue || "All";
  filters.rq = f.rq || "All";
  filters.ce = f.ce || "All";
  filters.advEnabled = !!f.advEnabled;
  filters.nrrMin = nn(f.nrrMin); filters.ltvCacMin = nn(f.ltvCacMin);
  filters.mrrMin = nn(f.mrrMin); filters.mrrMax = nn(f.mrrMax);
  filters.growthMin = nn(f.growthMin); filters.runwayMin = nn(f.runwayMin);
  filters.burnMax = nn(f.burnMax); filters.ebitdaMin = nn(f.ebitdaMin);
  filters.ticketMin = nn(f.ticketMin); filters.ticketMax = nn(f.ticketMax);
}

let filters = makeFilters();

function safeGetJSON(key, fallback){
  try{
    const raw = localStorage.getItem(key);
    if(!raw) return fallback;
    return JSON.parse(raw);
  }catch(e){
    return fallback;
  }
}
function safeSetJSON(key, value){
  try{ localStorage.setItem(key, JSON.stringify(value)); }catch(e){}
}

function getLeads(){
  const arr = safeGetJSON(LS_KEYS.leads, []);
  return Array.isArray(arr) ? arr.map(x=>({
    anon_id: String(x?.anon_id || ""),
    display_label: String(x?.display_label || ""),
    name: String(x?.name || ""),
    email: String(x?.email || ""),
    firm: String(x?.firm || ""),
    msg: String(x?.msg || ""),
    ts: Number(x?.ts || 0)
  })).filter(x=>x.anon_id && Number.isFinite(x.ts) && x.ts > 0) : [];
}
function setLeads(arr){
  safeSetJSON(LS_KEYS.leads, Array.isArray(arr) ? arr : []);
  updateCounts();
}

function getSavedSet(){
  const arr = safeGetJSON(LS_KEYS.saved, []);
  return new Set(Array.isArray(arr) ? arr.map(x=>String(x || "")).filter(Boolean) : []);
}
function setSavedIds(ids){
  const next = Array.isArray(ids) ? ids.map(x=>String(x || "")).filter(Boolean) : [];
  safeSetJSON(LS_KEYS.saved, Array.from(new Set(next)));
  updateCounts();
}
function setSavedSet(setObj){
  setSavedIds(Array.from(setObj || []));
}
function toggleSaved(id, btnEl){
  const safeId = String(id || "");
  if(!safeId) return false;

  const saved = getSavedSet();
  let isSaved = false;

  if(saved.has(safeId)){
    saved.delete(safeId);
    toast("Entfernt", "Aus Merkliste gelöscht");
    isSaved = false;
  }else{
    saved.add(safeId);
    toast("Gemerkt", "Zur Merkliste hinzugefügt");
    isSaved = true;
  }

  setSavedSet(saved);

  if(btnEl){
    btnEl.textContent = isSaved ? "Aus Merkliste" : "Merken";
  }

  if(currentView === "home") renderCards();

  return isSaved;
}

/* =========================
   VC WORKSPACE STORAGE
========================= */
function getPipeline(){
  return _pipelineCache || [];
}

/* =========================
   SUBMISSIONS / PIPELINE CACHE (Supabase)
   _submissionsCache und _pipelineCache werden beim Start einmalig
   aus Supabase befuellt. ensure*Loaded() ist idempotent und kann
   gefahrlos mehrfach aufgerufen werden.
========================= */
let _submissionsCache = null;
let _pipelineCache = null;
const _notesCacheBySubmissionId = new Map();

async function ensureSubmissionsLoaded(){
  if (_submissionsCache !== null) return;
  try {
    const fund_id = await getCurrentFundId();
    _submissionsCache = await apiLoadSubmissions(fund_id);
  } catch(e) {
    console.warn('[state] Submissions konnten nicht geladen werden:', e);
    _submissionsCache = [];
  }
}

// Mappt eine apiLoadPipeline*-Zeile in das Cache-Format — eine Quelle für
// Komplett-Load UND Einzelzeilen-Refresh nach Mutationen (Audit P1.2).
function _pipelineCacheItemFromRow(row) {
  // row.anon_id is resolved via DB JOIN in apiLoadPipeline (submissions are accepted, not in _submissionsCache)
  const resolved_anon_id = row.anon_id || String(row.submission_id || '');
  return {
    _pipeline_id: row.id,
    _submission_id: row.submission_id,
    anon_id: resolved_anon_id,
    status: row.status || 'In Review',
    signal_index: (typeof computeSignalIndex === 'function' && resolved_anon_id) ? computeSignalIndex(resolved_anon_id) : null,
    last_updated: row.last_updated ? new Date(row.last_updated).getTime() : Date.now(),
    created_at: row.created_at ? new Date(row.created_at).getTime() : Date.now(),
    decline_reason: row.decline_reason || null,
    decline_note: row.decline_note || '',
    assigned_name: row.assigned_name || '',
    assigned_role: row.assigned_role || '',
    last_activity_at: row.last_activity_at ? new Date(row.last_activity_at).getTime() : null,
    last_activity_by: row.last_activity_by || '',
    last_activity_action: row.last_activity_action || ''
  };
}

// Ersetzt (oder ergänzt) genau eine Zeile im Pipeline-Cache durch frische
// DB-Daten. Fallback bei Fehlschlag: Komplett-Reload.
async function _refreshPipelineCacheRow(pipeline_id) {
  const fresh = await apiLoadPipelineRow(pipeline_id);
  if (fresh && Array.isArray(_pipelineCache)) {
    const item = _pipelineCacheItemFromRow(fresh);
    const idx = _pipelineCache.findIndex(x => (x._pipeline_id || x.id) === pipeline_id);
    if (idx >= 0) _pipelineCache[idx] = item; else _pipelineCache.push(item);
    return item;
  }
  invalidatePipelineCache();
  await ensurePipelineLoaded();
  return (_pipelineCache || []).find(x => (x._pipeline_id || x.id) === pipeline_id) || null;
}

async function ensurePipelineLoaded(){
  if (_pipelineCache !== null) return;
  try {
    const fund_id = await getCurrentFundId();
    const rows = await apiLoadPipeline(fund_id);
    // Ensure submissions are loaded so we can join anon_id
    await ensureSubmissionsLoaded();
    _pipelineCache = (rows || []).map(_pipelineCacheItemFromRow);
  } catch(e) {
    console.warn('[state] Pipeline konnte nicht geladen werden:', e);
    _pipelineCache = [];
  }
}

function invalidateSubmissionsCache(){ _submissionsCache = null; }
function invalidatePipelineCache(){ _pipelineCache = null; }

/* =========================
   SUBMISSIONS STORAGE (Supabase-backed)
========================= */
function getSubmissions() {
  return _submissionsCache || [];
}

async function acceptSubmission(anon_id) {
  const sub = (_submissionsCache || []).find(s => s.anon_id === anon_id);
  if (!sub) return false;
  const ok = await apiAcceptSubmission(sub.id);
  if (!ok) { toast('Fehler', 'Annehmen fehlgeschlagen'); return false; }
  // Akzeptierte Submission sofort ins startups-Array injizieren, sonst verschwindet
  // sie bis zum naechsten Page-Reload komplett aus der UI
  if (typeof buildStartupFromSubmission === "function" && Array.isArray(window.startups)) {
    const alreadyIn = window.startups.some(x => x.anon_id === anon_id);
    if (!alreadyIn) {
      const built = buildStartupFromSubmission({ ...sub, status: 'accepted' });
      window.startups = [built, ...window.startups];
      startups = window.startups;
      try { _cache = {}; } catch(_) {}
    }
  }
  // Gezielte Cache-Pflege statt Komplett-Reload (Audit P1.2): Das Ergebnis
  // der Mutation ist bekannt — die eine Zeile fliegt aus der pending-Liste.
  _submissionsCache = (_submissionsCache || []).filter(s => s.anon_id !== anon_id);
  return true;
}

async function declineSubmission(anon_id) {
  const sub = (_submissionsCache || []).find(s => s.anon_id === anon_id);
  if (!sub) return false;
  const ok = await apiDeclineSubmission(sub.id);
  if (!ok) { toast('Fehler', 'Ablehnen fehlgeschlagen'); return false; }
  _submissionsCache = (_submissionsCache || []).filter(s => s.anon_id !== anon_id);
  if (Array.isArray(window.startups)) {
    window.startups = window.startups.filter(x => x.anon_id !== anon_id);
    startups = window.startups;
  }
  return true;
}

/* Bulk-Varianten (Audit P1.2): EIN Batch-Update für N Deals statt
   N Einzel-Updates mit je einem Komplett-Reload der Liste.
   Rückgabe: Array der tatsächlich verarbeiteten anon_ids. */
async function acceptSubmissionsBulk(anonIds) {
  const wanted = new Set(anonIds || []);
  const subs = (_submissionsCache || []).filter(s => wanted.has(s.anon_id));
  if (!subs.length) return [];
  const ok = await apiUpdateSubmissionsStatus(subs.map(s => s.id), 'accepted');
  if (!ok) { toast('Fehler', 'Annehmen fehlgeschlagen'); return []; }
  if (typeof buildStartupFromSubmission === 'function' && Array.isArray(window.startups)) {
    const fresh = subs
      .filter(sub => !window.startups.some(x => x.anon_id === sub.anon_id))
      .map(sub => buildStartupFromSubmission({ ...sub, status: 'accepted' }));
    if (fresh.length) {
      window.startups = [...fresh, ...window.startups];
      startups = window.startups;
      try { _cache = {}; } catch(_) {}
    }
  }
  const done = new Set(subs.map(s => s.anon_id));
  _submissionsCache = (_submissionsCache || []).filter(s => !done.has(s.anon_id));
  return subs.map(s => s.anon_id);
}

async function declineSubmissionsBulk(anonIds) {
  const wanted = new Set(anonIds || []);
  const subs = (_submissionsCache || []).filter(s => wanted.has(s.anon_id));
  if (!subs.length) return [];
  const ok = await apiUpdateSubmissionsStatus(subs.map(s => s.id), 'declined');
  if (!ok) { toast('Fehler', 'Ablehnen fehlgeschlagen'); return []; }
  const done = new Set(subs.map(s => s.anon_id));
  _submissionsCache = (_submissionsCache || []).filter(s => !done.has(s.anon_id));
  if (Array.isArray(window.startups)) {
    window.startups = window.startups.filter(x => !done.has(x.anon_id));
    startups = window.startups;
  }
  return subs.map(s => s.anon_id);
}

function getCompare(){
  const arr = safeGetJSON(LS_KEYS.compare, []);
  return Array.isArray(arr) ? arr.map(String).filter(Boolean) : [];
}
function setCompare(arr){ safeSetJSON(LS_KEYS.compare, Array.isArray(arr)?arr:[]); }

function getSavedFilters(){
  const arr = safeGetJSON(LS_KEYS.savedFilters, []);
  return Array.isArray(arr) ? arr : [];
}
function setSavedFilters(arr){ safeSetJSON(LS_KEYS.savedFilters, Array.isArray(arr)?arr:[]); }

/* =========================
   ACTIVITY LOG (Supabase-backed)
   _activityCache wird beim Start via ensureActivityLoaded() befuellt.
   activityLogAppend() schreibt optimistisch in den Cache und persistiert
   asynchron nach Supabase (activity_log).
========================= */
let _activityCache = null;

function getActivity(){
  return _activityCache || [];
}

async function ensureActivityLoaded(){
  if (_activityCache !== null) return;
  try {
    const fund_id = await getCurrentFundId();
    await _migrateLocalActivity(fund_id);
    const rows = await apiLoadActivity(fund_id);
    _activityCache = rows.map(r => ({
      id: r.id,
      ts: r.created_at ? new Date(r.created_at).getTime() : Date.now(),
      event: r.event || '',
      anon_id: r.anon_id || null,
      meta: (r.meta && Object.keys(r.meta).length) ? r.meta : null,
    }));
  } catch(e) {
    console.warn('[state] Activity konnte nicht geladen werden:', e);
    _activityCache = [];
  }
}

/* Einmalige Uebernahme alter localStorage-Events (core_activity_v1) nach
   Supabase. Der localStorage-Key wird nur nach erfolgreichem Insert geleert. */
async function _migrateLocalActivity(fund_id){
  const old = safeGetJSON(LS_KEYS.activity, []);
  if (!Array.isArray(old) || !old.length || !fund_id) return;
  const user_id = window._authSession?.user?.id || null;
  const rows = old.slice(0, 500).map(ev => ({
    fund_id,
    user_id,
    event: String(ev?.event || ''),
    anon_id: ev?.anon_id ? String(ev.anon_id) : null,
    meta: ev?.meta || {},
    created_at: new Date(Number(ev?.ts) || Date.now()).toISOString(),
  })).filter(r => r.event);
  if (!rows.length) { try{ localStorage.removeItem(LS_KEYS.activity); }catch(_){} return; }
  const { error } = await supabaseClient.from('activity_log').insert(rows);
  if (error) { console.warn('[state] Activity-Migration fehlgeschlagen:', error); return; }
  try{ localStorage.removeItem(LS_KEYS.activity); }catch(_){}
}

/* =========================
   NOTES STORAGE (Supabase-backed, lazy per submission)
========================= */

// Finds submission UUID from pending cache OR accepted startups (window.startups)
function _findSubId(anon_id) {
  const sub = (_submissionsCache || []).find(s => s.anon_id === anon_id);
  if (sub) return String(sub.id);
  return (window.startups || []).find(s => s.anon_id === anon_id)?._supabase_id || null;
}

async function getNotesForDeal(anon_id) {
  const subId = _findSubId(anon_id);
  if (!subId) return [];
  if (_notesCacheBySubmissionId.has(subId)) return _notesCacheBySubmissionId.get(subId);
  const rows = await apiLoadNotes(subId);
  const notes = rows.map(n => ({
    id: n.id,
    anon_id,
    _submission_id: subId,
    text: n.text,
    author: n.author || 'Analyst',
    created_at: new Date(n.created_at).getTime(),
    pinned: false,
  }));
  _notesCacheBySubmissionId.set(subId, notes);
  return notes;
}

async function getNotesCount(anon_id) {
  return (await getNotesForDeal(anon_id)).length;
}

async function addNote(anon_id, text, author = 'Analyst') {
  const subId = _findSubId(anon_id);
  if (!subId) return null;
  let fund_id = null;
  try { fund_id = await getCurrentFundId(); } catch(_) {}
  let row;
  try {
    row = await apiAddNote(fund_id, subId, text, author);
  } catch(e) {
    console.error('addNote:', e);
    toast('Fehler', 'Notiz konnte nicht gespeichert werden');
    return null;
  }
  if (!row) return null;
  const note = {
    id: row.id,
    anon_id,
    _submission_id: subId,
    text: row.text,
    author: row.author || author,
    created_at: new Date(row.created_at).getTime(),
    pinned: false,
  };
  if (!_notesCacheBySubmissionId.has(subId)) _notesCacheBySubmissionId.set(subId, []);
  _notesCacheBySubmissionId.get(subId).unshift(note);
  // "Zugewiesen" + "Zuletzt aktiv" folgen dem letzten Bearbeiter
  const pipeItem = (_pipelineCache || []).find(x => x.anon_id === anon_id);
  if (pipeItem) {
    try {
      const actor = await getCurrentMember();
      const by = actor?.name || pipeItem.assigned_name || null;
      const patch = {
        last_activity_at: new Date().toISOString(),
        last_activity_by: by,
        last_activity_action: 'Note hinzugefügt',
      };
      if (actor) { patch.assigned_member_id = actor.id; }
      await supabaseClient.from('pipeline').update(patch).eq('id', pipeItem._pipeline_id || pipeItem.id);
      pipeItem.last_activity_at = Date.now();
      pipeItem.last_activity_by = by || '';
      pipeItem.last_activity_action = 'Note hinzugefügt';
      if (actor) { pipeItem.assigned_member_id = actor.id; pipeItem.assigned_name = actor.name; pipeItem.assigned_role = actor.role || pipeItem.assigned_role; }
    } catch(_) {}
  }
  return note;
}

async function deleteNote(noteId) {
  let sub_id = null;
  for (const [sid, notes] of _notesCacheBySubmissionId.entries()) {
    const n = notes.find(x => x.id === noteId);
    if (n) { sub_id = sid; break; }
  }
  if (!sub_id) return false;
  const ok = await apiDeleteNote(noteId);
  if (!ok) return false;
  _notesCacheBySubmissionId.set(sub_id, _notesCacheBySubmissionId.get(sub_id).filter(n => n.id !== noteId));
  return true;
}

function activityLogAppend(event, anon_id=null, meta=null){
  if (_activityCache === null) _activityCache = [];
  const entry = { id: uid(), ts: Date.now(), event: String(event||""), anon_id: anon_id?String(anon_id):null, meta: meta||null };
  _activityCache.unshift(entry);
  if(_activityCache.length > 500) _activityCache.length = 500;
  (async () => {
    try {
      const fund_id = await getCurrentFundId();
      if (!fund_id) return;
      const submission_id = entry.anon_id ? _findSubId(entry.anon_id) : null;
      const row = await apiLogActivity(fund_id, entry.event, entry.anon_id, submission_id, entry.meta);
      if (row?.id) { entry.id = row.id; entry.ts = new Date(row.created_at).getTime(); }
    } catch(e) { console.warn('activityLogAppend:', e); }
  })();
  if(currentView==="activity") renderActivity();
}

/* Fund-Mitarbeiter (für Zuweisung in der Pipeline) */
let _fundMembersCache = null;

async function ensureFundMembersLoaded(){
  if (_fundMembersCache !== null) return;
  try {
    const fund_id = await getCurrentFundId();
    _fundMembersCache = await apiLoadFundMembers(fund_id);
  } catch(e) {
    console.warn('[state] Fund-Members konnten nicht geladen werden:', e);
    _fundMembersCache = [];
  }
}

function getFundMembers(){
  return _fundMembersCache || [];
}

/* Mitarbeiter-Profil des eingeloggten Users (fund_members.user_id-Mapping).
   null, wenn der Login kein Profil hat — dann greifen Fallbacks. */
async function getCurrentMember(){
  await ensureFundMembersLoaded();
  const uid = window._authSession?.user?.id;
  if (!uid) return null;
  return getFundMembers().find(m => m.user_id === uid) || null;
}

async function pipelineAdd(anon_id, initialStatus = 'In Review') {
  const existing = (_pipelineCache || []).find(x => x.anon_id === anon_id);
  if (existing) return { created: false, item: existing };
  const sub = (_submissionsCache || []).find(s => s.anon_id === anon_id);
  const subId = sub?.id || (window.startups || []).find(s => s.anon_id === anon_id)?._supabase_id;
  if (!subId) return null;
  const fund_id = await getCurrentFundId();
  if (!fund_id) return null;
  // Zugewiesen = letzter Bearbeiter: Wer den Deal hinzufügt, steht dran.
  // Fallback (Login ohne Mitarbeiter-Profil): Round-Robin nach geringster Last.
  let assigned = await getCurrentMember();
  if (!assigned) {
    const members = getFundMembers();
    if (members.length) {
      const load = new Map(members.map(m => [m.id, 0]));
      (_pipelineCache || []).forEach(x => { if (x.assigned_member_id && load.has(x.assigned_member_id)) load.set(x.assigned_member_id, load.get(x.assigned_member_id) + 1); });
      assigned = members.slice().sort((a,b) => load.get(a.id) - load.get(b.id))[0];
    }
  }
  const ok = await apiAddToPipeline(fund_id, subId, initialStatus, assigned);
  if (!ok) return null;
  // Nur die neue Zeile nachladen (submission_id ist UNIQUE) statt der
  // ganzen Pipeline; Fallback: Komplett-Reload (Audit P1.2).
  const freshRow = await apiLoadPipelineRowBySubmission(subId);
  if (freshRow && Array.isArray(_pipelineCache)) {
    const item = _pipelineCacheItemFromRow(freshRow);
    _pipelineCache.push(item);
    return { created: true, item };
  }
  invalidatePipelineCache();
  await ensurePipelineLoaded();
  return { created: true, item: (_pipelineCache || []).find(x => x.anon_id === anon_id) };
}

async function pipelineSetStatus(anon_id, toStatus, declineReason = null, declineNote = '') {
  const item = (_pipelineCache || []).find(x => x.anon_id === anon_id);
  if (!item) return false;
  const from = item.status || 'In Review';
  if (from === 'Synced') { toast('Gesperrt', 'Synced Deals können nicht geändert werden'); return false; }
  const allowed = PIPELINE_TRANSITIONS[from] || [];
  if (!allowed.includes(toStatus) && toStatus !== from) { toast('Ungültig', `${from} → ${toStatus} nicht erlaubt`); return false; }
  if (toStatus === 'Declined' && !declineReason) return false;
  try {
    const actor = await getCurrentMember();
    await apiUpdatePipelineStatus(item._pipeline_id || item.id, toStatus, declineReason, declineNote,
      { by: actor?.name || item.assigned_name || null, member_id: actor?.id || null });
  } catch(e) { console.error('pipelineSetStatus:', e); toast('Fehler', 'Status konnte nicht gesetzt werden'); return false; }
  await _refreshPipelineCacheRow(item._pipeline_id || item.id);
  // Zentrales Activity-Logging für alle Stage-Wechsel (Einzel, Bulk, Decline, CRM)
  if (toStatus !== from) {
    const meta = { from, to: toStatus };
    if (toStatus === 'Declined' && declineReason) meta.reason = declineReason;
    activityLogAppend(toStatus === 'Synced' ? 'CRM_PUSHED' : 'STATUS_CHANGED', anon_id, meta);
  }
  return true;
}

async function pipelinePushToCRM(anon_id) {
  const p = getPipeline();
  const idx = p.findIndex(x => x.anon_id === anon_id);
  if (idx < 0) {
    const result = await pipelineAdd(anon_id, 'Synced');
    if (!result) return false;
    activityLogAppend('CRM_PUSHED', anon_id, { from: null, to: 'Synced' });
  } else {
    const ok = await pipelineSetStatus(anon_id, 'Synced');
    if (!ok) return false;
  }
  toast('CRM', 'Deal an CRM übergeben');
  return true;
}

async function pipelineRemove(anon_id) {
  const item = (_pipelineCache || []).find(x => x.anon_id === anon_id);
  if (!item) return false;
  const ok = await apiRemoveFromPipeline(item._pipeline_id || item.id);
  if (!ok) { toast('Fehler', 'Entfernen fehlgeschlagen'); return false; }
  const removedId = item._pipeline_id || item.id;
  _pipelineCache = (_pipelineCache || []).filter(x => (x._pipeline_id || x.id) !== removedId);
  return true;
}

/* Bulk-Entfernen (Audit P1.2): EIN Delete für N Zeilen. Rückgabe: Anzahl. */
async function pipelineRemoveBulk(anonIds) {
  const wanted = new Set(anonIds || []);
  const items = (_pipelineCache || []).filter(x => wanted.has(x.anon_id));
  if (!items.length) return 0;
  const ids = items.map(x => x._pipeline_id || x.id);
  const ok = await apiRemoveFromPipelineBulk(ids);
  if (!ok) { toast('Fehler', 'Entfernen fehlgeschlagen'); return 0; }
  const removed = new Set(ids);
  _pipelineCache = (_pipelineCache || []).filter(x => !removed.has(x._pipeline_id || x.id));
  return items.length;
}

// pipelineMarkPassed removed – use pipelineSetStatus(anon_id, 'Declined') instead

function addToCompare(anon_id){
  const ids = getCompare();
  if(ids.includes(anon_id)){
    toast("Compare", "Bereits ausgewählt");
    return;
  }
  if(ids.length >= 10){
    toast("Compare", "Max. 10 Deals");
    return;
  }
  ids.push(anon_id);
  setCompare(ids);
  updateCompareTray();
  toast("Compare", "Hinzugefügt");
}

function removeFromCompare(anon_id){
  const ids = getCompare().filter(x=>x!==anon_id);
  setCompare(ids);
  updateCompareTray();
}

function clearCompare(){
  setCompare([]);
  updateCompareTray();
}

function captureCurrentFilterState(){ return serializeFilters(); }

async function saveCurrentFilters(){
  const name = await showInputModal('Filterset-Name eingeben');
  if (!name) return;
  const list = getSavedFilters();
  const entry = { id: uid(), name, filters: captureCurrentFilterState(), created_at: Date.now(), last_used_at: null };
  list.unshift(entry);
  setSavedFilters(list);
  activityLogAppend("FILTER_SAVED", null, { name });
  toast("Saved Filters","Gespeichert");
}

function applySavedFilter(id){
  const list = getSavedFilters();
  const item = list.find(x=>x.id===id);
  if(!item) return;

  applyFilterObject(item.filters || {});

  syncFilterModalFromState();
  item.last_used_at = Date.now();
  setSavedFilters(list);

  activityLogAppend("FILTER_APPLIED", null, { id, name: item.name });
  toast("Saved Filters","Angewendet");
  currentView = "home";
  renderCurrent();
}

function deleteSavedFilter(id){
  const list = getSavedFilters();
  const item = list.find(x=>x.id===id);
  setSavedFilters(list.filter(x=>x.id!==id));
  activityLogAppend("FILTER_DELETED", null, { id, name: item?item.name:null });
  toast("Saved Filters","Gelöscht");
}

function openModalByAnonId(anon_id, list){
  const arr = (list && list.length) ? list : startups;
  const idx = arr.findIndex(x=>x.anon_id===anon_id);
  if(idx>=0) openModalByIndex(idx, arr);
}

/* =========================
   OUTREACH TRACKER STATE
========================= */
function getOutreach(){
  const arr = safeGetJSON(LS_KEYS.outreach, []);
  return Array.isArray(arr) ? arr : [];
}
function setOutreach(arr){
  safeSetJSON(LS_KEYS.outreach, Array.isArray(arr) ? arr : []);
}
function updateOutreachItem(id, patch){
  const arr = getOutreach();
  const idx = arr.findIndex(x=>x.id===id);
  if(idx<0) return;
  arr[idx] = { ...arr[idx], ...patch, last_activity_at: Date.now() };
  setOutreach(arr);
}
function computeFollowupRecommended(item){
  if(item.followup_sent) return false;
  if(item.status !== 'keine_antwort' && item.status !== 'anfrage_gesendet') return false;
  const days = (Date.now() - item.sent_at) / (1000 * 60 * 60 * 24);
  return days >= 3;
}

/* =========================
   RETENTION — LOKALE DATEN
   Datenschutzerklärung §4/§8/§12: Leads max. 12 Monate,
   Outreach max. 6 Monate. Einträge ohne Zeitstempel werden
   entfernt, weil die Frist für sie nicht nachweisbar ist.
========================= */
function pruneExpiredLocalData(){
  const now = Date.now();
  const LEADS_MAX_AGE_MS    = 365 * 24 * 60 * 60 * 1000;
  const OUTREACH_MAX_AGE_MS = 180 * 24 * 60 * 60 * 1000;

  const leads = safeGetJSON(LS_KEYS.leads, []);
  if(Array.isArray(leads) && leads.length){
    const kept = leads.filter(x=>{
      const ts = Number(x?.ts || 0);
      return Number.isFinite(ts) && ts > 0 && (now - ts) < LEADS_MAX_AGE_MS;
    });
    if(kept.length !== leads.length) safeSetJSON(LS_KEYS.leads, kept);
  }

  const outreach = safeGetJSON(LS_KEYS.outreach, []);
  if(Array.isArray(outreach) && outreach.length){
    const kept = outreach.filter(x=>{
      const ref = Number(x?.sent_at || x?.last_activity_at || 0);
      return Number.isFinite(ref) && ref > 0 && (now - ref) < OUTREACH_MAX_AGE_MS;
    });
    if(kept.length !== outreach.length) safeSetJSON(LS_KEYS.outreach, kept);
  }
}
