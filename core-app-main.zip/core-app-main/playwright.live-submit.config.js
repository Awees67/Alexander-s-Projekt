// TEMP (Live-Durchlauf-Test): schickt echte Submissions über das Live-Formular
// auf Vercel. WICHTIG: retries MUSS 0 sein — ein Retry würde die Submission
// doppelt einreichen. Aufruf:
//   npx playwright test -c playwright.live-submit.config.js
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  testMatch: '**/submit-live.spec.js',
  timeout: 90_000,
  workers: 1,
  retries: 0,
  reporter: [['list']],
  use: {
    baseURL: process.env.APP_URL || 'https://core-app-gamma.vercel.app',
    ...devices['Desktop Chrome'],
    // Playwright-Chromium (manuell installiert, siehe Memory
    // windows-test-umgebung); Fallback auf System-Edge via PW_CHANNEL=msedge.
    channel: process.env.PW_CHANNEL || undefined,
  },
});
