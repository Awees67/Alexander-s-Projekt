import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  timeout: 30_000,
  fullyParallel: false, // seriell, weil wir eine echte DB schreiben
  workers: 1,
  reporter: [['list']],
  use: {
    baseURL: process.env.APP_URL || 'https://core-app-gamma.vercel.app',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
  projects: [
    // Login-Setup läuft zuerst, speichert Session
    { name: 'setup', testMatch: '**/auth.setup.js' },

    // Submit-Tests brauchen kein Login
    {
      name: 'submit',
      testMatch: ['**/submit-form.spec.js', '**/rate-limit.spec.js'],
      use: { ...devices['Desktop Chrome'] },
    },

    // Workspace-Tests nutzen gespeicherte Session
    {
      name: 'workspace',
      testMatch: '**/workspace.spec.js',
      use: { ...devices['Desktop Chrome'], storageState: 'playwright/.auth/user.json' },
      dependencies: ['setup'],
    },

    // Tiefe Tests: Daten + Interaktionen
    {
      name: 'workspace-deep',
      testMatch: '**/workspace-deep.spec.js',
      use: { ...devices['Desktop Chrome'], storageState: 'playwright/.auth/user.json' },
      dependencies: ['setup'],
    },

    // Anfragen-Flow: Submissions → Detail-Modal → Send-Modal → Anfragen-View
    {
      name: 'outreach',
      testMatch: '**/outreach.spec.js',
      use: { ...devices['Desktop Chrome'], storageState: 'playwright/.auth/user.json' },
      dependencies: ['setup'],
    },

    // Kompletter User-Journey: alle Views, Modal, Anfrage, Pipeline, Compare
    {
      name: 'full-flow',
      testMatch: '**/full-flow.spec.js',
      use: { ...devices['Desktop Chrome'], storageState: 'playwright/.auth/user.json' },
      dependencies: ['setup'],
    },

    // Vollständiger App-Test: alle 7 Views, Vollbild-Modal-Prüfung, alle Buttons
    {
      name: 'app-complete',
      testMatch: '**/app-complete.spec.js',
      use: {
        ...devices['Desktop Chrome'],
        storageState: 'playwright/.auth/user.json',
        viewport: { width: 1280, height: 720 },
      },
      dependencies: ['setup'],
    },

    // Pipeline-View v2 (Design-Mockup): Tabs, Zugewiesen, Zuletzt aktiv, Bulk-Bar.
    // Self-contained Login; mit PW_OFFLINE=1 laufen alle Supabase-Calls gegen
    // tests/fixtures/workspace-fixtures.json (für Umgebungen ohne Netzzugriff).
    {
      name: 'pipeline-view',
      testMatch: '**/pipeline-view.spec.js',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
