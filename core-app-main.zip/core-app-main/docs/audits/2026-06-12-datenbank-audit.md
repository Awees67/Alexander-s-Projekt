# CORE — Datenbank- & Security-Audit

**Datum:** 12. Juni 2026
**Geprüft:** Live-Supabase-Projekt „Core" (Schema, RLS-Policies, Trigger, Constraints, Indexes, Migrationshistorie, Advisor-Läufe, echte Zeilenzahlen) sowie der komplette API- und Frontend-Datenpfad im Repo.
**Methode:** Alle Aussagen direkt am Live-System bzw. Code verifiziert — keine Übernahme aus Dokumentation.

---

## 1. Steckbrief

| | |
|---|---|
| Plattform | Supabase (Projekt „Core", `ggfjgzjevyemwbclvfpp`), Status: aktiv & gesund |
| Region | **eu-central-1 (Frankfurt)** — Daten in der EU (DSGVO) |
| Datenbank | PostgreSQL 17.6 |
| Größe | 11 MB (Pre-Launch) |
| Migrationen | 27 versionierte Migrationen seit April 2026 |
| Security-Advisor | **0 Befunde** (Lauf vom 12.06.2026, nach allen Änderungen) |

**Datenbestand am Audit-Tag:** 1 Fund (APEX Ventures), 2 Login-Konten (beide korrekt in `fund_users` + `fund_members` verknüpft). Submissions, Pipeline, Notes, Activity: leer.

---

## 2. Datenmodell

8 Tabellen um den Mandanten-Anker `funds`:

```
                    funds (Mandanten / Kunden)
                      │
   ┌──────────┬───────┼────────┬─────────────┬──────────┐
fund_users  fund_members  submissions   activity_log  attio_pushes
(Login↔Fund) (Mitarbeiter)     │
                      ┌────────┼────────┐
                  pipeline   notes   (activity_log & attio_pushes
                  (1:1!)   (pro Deal)  referenzieren submissions ebenfalls)
```

| Tabelle | Zweck | Bemerkenswert |
|---|---|---|
| `funds` | Kunden (VC-Fonds) | Eindeutiger Slug pro Fund (Submit-Links) |
| `fund_users` | Login ↔ Fund | **Sicherheits-Anker**: alle RLS-Policies hängen hieran |
| `fund_members` | Mitarbeiter-Profile | Optionales Login-Mapping; speist „Zugewiesen"/„Zuletzt aktiv" |
| `submissions` | Herzstück, ~65 Spalten | Kontakt, Stammdaten, Metrik-Suite (MRR/ARR/Burn/Churn/NRR/LTV/CAC/TAM/SAM/Cap Table), Founder als JSONB, Plausibility als JSONB, Lifecycle `pending→accepted/declined`, `ip_hash` (pseudonymisiert), `privacy_accepted_at` (DSGVO-Einwilligung) |
| `pipeline` | Deal-Tracking | 6 Stages per CHECK erzwungen; UNIQUE `submission_id` (Deal max. 1× in Pipeline) |
| `notes` | Notizen pro Deal | Autor + `user_id` |
| `activity_log` | Audit-Trail | **Append-only** (RLS: nur SELECT/INSERT — Löschen technisch unmöglich) |
| `attio_pushes` | CRM-Integration | Vorbereitet, noch ungenutzt |

Views `pipeline_view` / `fund_users_view`: reine Admin-Sichten, `security_invoker=true` (verifiziert) — können RLS nicht umgehen; von der App ungenutzt.

Abgeleitete Kennzahlen (ARPA, ACV, LTV, CAC-Payback, Burn Multiple, ARR) werden serverseitig berechnet — Bewerber können keine geschönten Werte einschleusen.

---

## 3. Sicherheitsarchitektur (drei Schichten)

### Schicht 1 — API vor der DB (Vercel, `/api/*`)
- CORS-Allowlist (`ALLOWED_ORIGINS`): nur eigene Domain; fremde Origins → 403 (live verifiziert)
- Rate-Limits: 3 Submissions/E-Mail/24h + 10/IP/24h; IP nur als HMAC-SHA256-Hash (`IP_HASH_SALT`) — DB-basiert, daher serverless-fest
- Input-Validierung (`validateBody`): 60-KB-Gesamtlimit, Längen-/Typ-/Bereichs-Checks je Feld, max. 10 Founder / 20 Zielmärkte, `http(s)://`-Pflicht für `pitch_deck_url` (blockt `javascript:`-XSS) — live verifiziert
- Feld-Whitelist + serverseitige Hoheit: `fund_id`, `anon_id`, `status`, `ip_hash`, `privacy_accepted_at` setzt ausschließlich der Server
- DSGVO-Consent serverseitig erzwungen (`privacy_accepted !== true` → 400)
- Fehlermeldungen generisch; DB-Details nur ins Vercel-Log

### Schicht 2 — Row Level Security
- Auf allen 8 Tabellen, je Operation einzeln (18 Policies); Muster: `fund_id IN (eigene fund_users)` in initplan-optimierter Form `(select auth.uid())`
- Asymmetrien (gewollt): `submissions` clientseitig ohne INSERT/DELETE (Insert nur via Server); `activity_log` append-only; `funds` seit 12.06. nur für Mitglieder lesbar (vorher öffentlich enumerierbar)
- Verifiziert per Rollen-Simulation: anon = 0 Zeilen; Mitglied = nur eigener Fund

### Schicht 3 — Härtung in der DB
- **Event-Trigger `ensure_rls`**: neue Tabellen erhalten RLS automatisch — „RLS vergessen" ist unmöglich
- **Trigger `trg_pipeline_set_activity`** (BEFORE INSERT/UPDATE): `last_activity_by/at`, `last_updated` serverseitig aus `auth.uid()` → `fund_members.name`; EXECUTE auf der Funktion entzogen
- Auth: Passwort + Magic Link, Self-Signup deaktiviert; Konten nur via Dashboard (+ Pflicht-Verknüpfung `fund_users` & `fund_members`)
- Nur 5 Extensions installiert (pgcrypto, uuid-ossp, pg_stat_statements, plpgsql, supabase_vault) — minimale Angriffsfläche

---

## 4. Datenintegrität

- CHECK-Constraints: `submissions.status` ∈ pending/accepted/declined; `pipeline.status` ∈ In Review/Contacted/Hot Deal/Watching/Declined/Synced
- UNIQUE: `(fund_id, anon_id)`, `pipeline.submission_id`, `fund_users(fund_id, user_id)`, `fund_members.user_id`, `funds.slug`
- Vollständige FKs mit gehärteten Löschregeln (Migration Juni 2026); UUIDs als PKs überall

## 5. Performance & Skalierung

- 29 Indexes, passend zu den echten App-Queries: u.a. `(fund_id, status, submitted_at DESC)`, partieller `(ip_hash, submitted_at DESC)`, `contact_email`, `activity_log(fund_id, created_at DESC)`
- „Unused Index"-Advisor-Hinweise = Rauschen (DB leer)
- Frontend-Paging gegen Supabases stilles 1.000-Zeilen-Limit implementiert (12.06., siehe Maßnahmen)
- `pg_stat_statements` aktiv → spätere Query-Analyse möglich

---

## 6. Maßnahmen-Protokoll vom 12.06.2026 (P0 abgeschlossen)

| # | Befund (Schwere) | Maßnahme | Verifikation |
|---|---|---|---|
| P0.1 | `ALLOWED_ORIGINS`/`IP_HASH_SALT` fehlten in Vercel; CORS-/IP-Limit-Code war zudem **nie committed/deployed** | Env-Vars gesetzt; Schutz-Code live geschaltet (Commit `c379c36`) | Fremde Domain → 403; eigene Domain + Preflight ok (live) |
| P0.2 | Rohe PostgREST-Fehler an Clients (Information Disclosure) | Generische Meldung + Server-Log (Commit `a29f815`) | Live: kaputter Request → generische 500 |
| P0.3 | Keine Längen-/Typ-/Array-Validierung hinter der Whitelist; `javascript:`-URLs möglich | `validateBody()` (Commit `0580bf0`) | 14 Unit-Tests + 3 Live-Tests bestanden |
| P0.4 | `funds`-SELECT-Policy `qual=true` → Kundenliste mit Anon-Key enumerierbar | Migration `restrict_funds_select_to_members` | anon=0, Mitglied=eigener Fund, `/api/fund` unberührt |
| P1.1 | Stilles 1.000-Zeilen-Limit: ab Zeile 1.001 fehlten Datensätze kommentarlos | Paging-Helfer `_apiFetchAllPages` in `js/api.js` + deterministische Sortierung | 6 Unit-Tests (Grenzfälle 1000/1001) + 10 Playwright-Tests grün — live mit `2b5adab` |

**Nachtrag (Abend):** Auch P1.2 (Bulk-Batch + gezielte Cache-Pflege, `9783f4e`) und P1.4 (anon_id-Insert-Retry, `4708f72`) wurden behoben und live verifiziert — Details im [Fix-Protokoll](2026-06-12-fix-protokoll.md).

## 7. Offene Punkte

**P1 (vor echtem Traffic):**
- ~~Bulk-Accept/Decline: pro Element ein Update + Komplett-Reload~~ → ✅ behoben (`9783f4e`)
- ~~Pipeline-Vollreload nach jeder Mutation~~ → ✅ behoben (`9783f4e`)
- Rate-Limit nicht burst-fest (Check und Insert nicht atomar); kein Bot-Schutz → Cloudflare Turnstile vors öffentliche Formular — **einziger offener P1-Punkt**
- ~~`anon_id`-Vergabe: check-then-insert-Race~~ → ✅ behoben (`4708f72`)
- `select('*')` → Spaltenlisten: bewusst zurückgestellt (Scoring/Detailansicht nutzen die meisten Spalten; Regressions-Risiko > Nutzen)

**P2 (bei Datenwachstum):**
- Serverseitige Filterung/Suche statt Client-Filter über `window.startups` (relevant ab ~10.000 Zeilen)
- Realtime-Entscheidung (aktuell kein Multi-User-Sync — Änderungen anderer erst nach Reload sichtbar)

**Betrieb:**
- **Backups im Supabase-Dashboard prüfen** (planabhängig; Free-Plan hat keine automatischen Backups) — vor Launch klären
- Altdaten-Spalten `esop_pct`/`net_new_arr_eur` droppen, sobald keine alten Clients mehr einreichen (vorher Export)
- Advisor-INFO: Auth-Server fix auf 10 DB-Verbindungen — erst bei Instanz-Upgrade relevant

---

## Fazit

Das Fundament ist solide und deutlich über dem Standard typischer AI-generierter Projekte: lückenlose Mandanten-Isolation auf DB-Ebene, automatische RLS-Pflicht für künftige Tabellen, serverseitige Datenhoheit über sicherheitskritische Felder, erzwungene Status-Maschinen, versionierte Migrationen, null Advisor-Befunde. Die Architektur trägt zehntausende Submissions. Verbleibende Risiken liegen in der Frontend-Effizienz unter Last (P1) und im Betrieb (Backups, Bot-Schutz).
