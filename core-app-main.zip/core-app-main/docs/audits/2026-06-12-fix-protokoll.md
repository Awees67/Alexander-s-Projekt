# CORE — Fix-Protokoll vom 12. Juni 2026

**Anlass:** Skalierbarkeits- und Security-Audit (siehe [2026-06-12-datenbank-audit.md](2026-06-12-datenbank-audit.md)) mit anschließender sequentieller Abarbeitung aller kritischen Befunde.
**Methode:** Jeder Fix wurde vor dem Deployment lokal getestet (Unit-/E2E-Tests) und nach dem Deployment **gegen die Live-Produktionsumgebung verifiziert**. Kein Fix gilt als erledigt ohne Live-Nachweis.
**Ergebnis:** Alle kritischen Befunde (P0) und drei von vier P1-Befunden sind behoben und live. Offen: nur noch Bot-Schutz (P1.3, braucht Cloudflare-Konto) und P2-Themen.

---

## 1. Ausgangslage (Befund des Morgen-Audits)

Die Datenbank selbst war solide (RLS lückenlos, Indexes korrekt, 0 Security-Advisor-Befunde). Die Lücken lagen davor und dahinter:

- Der gesamte API-Schutz (CORS + IP-Rate-Limit) war **gebaut, aber nie committed/deployed** — auf dem Server lief die ungeschützte Version
- Die beiden Sicherheits-Umgebungsvariablen fehlten in Vercel komplett
- Rohe Datenbankfehler gingen 1:1 an Fremde (Information Disclosure)
- Keine serverseitige Validierung von Feldlängen/-typen/-größen
- Die Kundenliste (`funds`) war mit dem öffentlichen Anon-Key enumerierbar
- Supabases stilles 1.000-Zeilen-Limit hätte ab Datensatz 1.001 kommentarlos Daten „verschwinden" lassen
- Bulk-Aktionen: pro Element ein Update + ein Komplett-Download der Liste
- `anon_id`-Vergabe mit Race Condition bei parallelen Einreichungen

## 2. Durchgeführte Fixes (Security-Strang)

| # | Befund | Schwere | Fix | Commit | Live-Verifikation |
|---|---|---|---|---|---|
| P0.1a | `ALLOWED_ORIGINS` + `IP_HASH_SALT` nicht in Vercel gesetzt | kritisch | Beide gesetzt (Salt kryptografisch generiert); in `.env.example` als Launch-Blocker dokumentiert | — (Vercel-Konfig) | E2E-Test: `ip_hash` wird live gespeichert |
| P0.1b | CORS-/IP-Limit-Code nie deployed | kritisch | Commit + Push des lokalen Schutz-Codes | `c379c36` 16:46 | Fremde Domain → 403; eigene Domain + OPTIONS-Preflight ok; POST von fremder Domain → 403 |
| P0.2 | Rohe PostgREST-Fehler an Clients | hoch | Generische Meldung an Client, Details via `console.error` ins Vercel-Log (`api/submit.js`, `api/fund.js`) | `a29f815` 16:51 | Live: absichtlich kaputter Request → generische 500 statt DB-Interna |
| P0.3 | Keine Input-Validierung (Längen/Typen/Arrays); `javascript:`-URLs möglich | hoch | `validateBody()`: 60-KB-Limit, Limits je Feld, max. 10 Founder / 20 Zielmärkte, `http(s)://`-Pflicht für `pitch_deck_url`; Verstoß → 400 mit Feldname, ohne DB-Query | `0580bf0` 17:07 | 14 Unit-Tests; live: Text-statt-Zahl → 400, `javascript:`-URL → 400, 50 Founder → 400 |
| P0.4 | `funds`-Policy `qual=true`: Kundenliste öffentlich enumerierbar | hoch | DB-Migration `restrict_funds_select_to_members` (Mitglieder-Policy) | Migration 12.06. | Rollen-Simulation: anon = 0 Zeilen, Mitglied = eigener Fund; `/api/fund` (Service Role) unberührt |
| P1.1 | Stilles 1.000-Zeilen-Limit (PostgREST kappt ohne Fehler) | hoch (Wartbarkeit) | `_apiFetchAllPages()`: 1.000er-Paging bis Vollständigkeit, deterministische Sortierung (id-Tie-Breaker) für Submissions/Accepted/Pipeline | in `2b5adab` 20:55 | 6 Unit-Tests (Grenzfälle 0/999/1000/1001/2500 Zeilen, Fehler-Durchreichung); 10 Playwright-Tests |
| P1.2 | Bulk = N Updates + N Komplett-Reloads; Mutationen luden ganze Listen neu | hoch (Performance) | Batch-Update/-Delete via `.in()`; Accept/Decline pflegen Cache lokal; Stage-Wechsel/Add refetchen nur die eine Pipeline-Zeile (DB-Trigger stempelt serverseitig); Fallback bei Fehlern: Komplett-Reload | `9783f4e` 21:34 | 10 Playwright-Tests (inkl. Accept- und Stage-Wechsel-Flows) |
| P1.4 | `anon_id`: Check-then-Insert-Race bei parallelen Requests | mittel | Vorab-SELECT entfernt; Insert-Retry bei 409 auf `submissions_fund_anon_unique` (max. 5 Versuche, frische ID je Wurf); andere Fehler brechen sofort ab | `4708f72` 21:54 | Handler-E2E mit fetch-Mock: 5 Szenarien (kein Konflikt / 2 Kollisionen→Erfolg / Dauerkollision→sauberer Abbruch / fremde Fehler) |

## 3. Parallel-Strang (zweite Session, gleicher Tag)

Zur Vollständigkeit — nicht Teil dieses Audits, aber Teil des Tages:

- `2b5adab` 20:55 — **DSGVO-Pilotpaket**: `datenschutz.html` live (Consent-Link des Formulars funktioniert damit), Pilotvertrag + AVV unter `docs/legal/`, `privacy_accepted` als Server-Pflicht + `privacy_accepted_at` serverseitig (Art. 5 Abs. 2 Nachweis), Retention für lokale Daten, Vercel-Functions auf Region `fra1` gepinnt, `.vercelignore` (Tests/Verträge/Audits nicht im Deploy)
- `c1e0044` 21:04 — Datenschutzerklärung CSS-Fix
- `49f507c` 21:08 — Rechtstexte als PDF + Generator-Skript
- `10f1ee4` 22:12 — Signal-Score standardmäßig aktiv (vertraglich abgesichert)

## 4. Abschließender End-to-End-Beweis (21:58)

Echte Test-Bewerbung („TEST-BITTE-LOESCHEN") über die Live-API, danach DB-Inspektion und restlose Löschung:

| Mechanismus | Ergebnis |
|---|---|
| Einreichung über `/api/submit` | ✅ 200 `{"success":true}` |
| `anon_id` serverseitig (`K-6138`), Status `pending` hartkodiert | ✅ |
| `fund_id` aus Slug abgeleitet | ✅ |
| DSGVO-Zeitstempel `privacy_accepted_at` | ✅ gesetzt |
| `ip_hash` gespeichert (Beweis: `IP_HASH_SALT` greift in Produktion) | ✅ |
| Abgeleitete Kennzahlen (ARR 300k=25k×12, ARPA 625, ACV 7.500, Burn Multiple 13,33, CAC-Payback 3,2) | ✅ alle korrekt |
| Plausibility serverseitig (`passed`), Founder-Ableitungen | ✅ |
| Cleanup | ✅ 0 Testdatensätze verbleibend |

## 5. Test-Bilanz des Tages

- 25 Unit-/Handler-Tests (Validierung 14, Paging 6, anon_id-Retry 5) — alle grün
- 2 × kompletter Playwright-Offline-Lauf (je 10 Tests, System-Edge) — alle grün
- 9 Live-Tests gegen die Produktions-API (CORS ×4, Fehler-Leak, Validierung ×3, E2E-Submission) — alle bestanden
- 3 × DB-Rollen-Simulation (anon / authenticated / Service-Role-Pfad) — korrekt isoliert
- 2 × Supabase-Security-Advisor (morgens + nach Migration) — 0 Befunde

## 6. Offen nach diesem Tag

| Priorität | Punkt | Abhängigkeit |
|---|---|---|
| P1.3 | Cloudflare Turnstile vors öffentliche Formular (Rate-Limit ist nicht burst-fest; Bots) | Cloudflare-Konto des Betreibers |
| P2 | Serverseitige Filterung/Suche (ab ~10.000 Zeilen relevant) | — |
| P2 | Realtime-Sync-Entscheidung (Multi-User sieht Änderungen erst nach Reload) | Produktentscheidung |
| P2 | Altdaten-Spalten `esop_pct`/`net_new_arr_eur` droppen | keine Alt-Clients mehr; vorher Export |
| Betrieb | Backups: Pro-Plan mit täglichen Backups bestätigt ✅ (PITR optional bei echten Kundendaten) | — |
