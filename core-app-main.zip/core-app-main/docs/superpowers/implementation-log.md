# Implementation Log — Backend Hardening

Dieses Dokument protokolliert jeden Implementierungsschritt chronologisch.  
Für jeden Schritt: **Was** wurde gemacht, **Wie** es gemacht wurde, **Warum** es notwendig war.

---

## Kontext

**Ziel:** Backend vor erstem Pilot-User absichern.  
**Spec:** `docs/superpowers/specs/2026-04-28-backend-hardening-pre-pilot-design.md` (V3)  
**Plan:** `docs/superpowers/plans/2026-04-28-backend-hardening-week1-plan.md`

---

## Phase A — Git & Env

### Schritt 1 — `.gitignore` erweitern (2026-04-28)

**Was:**  
Am Ende von `.gitignore` wurde hinzugefügt:
```
.env
.env.local
.env.*.local
js/env.js
```

**Wie:**  
Datei mit dem Edit-Tool geöffnet und am Ende erweitert.  
Danach mit `git check-ignore` und `git status` verifiziert, dass `js/env.js` tatsächlich ignoriert wird.

**Warum:**  
Supabase-Credentials (URL + Anon Key) dürfen nie in git committet werden. Wenn sie im Repository landen, kann jeder mit Repo-Zugriff direkt auf die Datenbank zugreifen — ohne Login.

`.env`-Varianten werden ignoriert, weil manche Tools (z.B. Vercel CLI, dotenv) lokale `.env`-Dateien automatisch anlegen.

---

**Gefundenes Problem (Naming-Konflikt):**

Der ursprüngliche Plan sagte: `js/config.js` gitignoren.

Das war falsch. `js/config.js` ist die bestehende App-Konfig-Datei — sie enthält:
- `LS_KEYS` (localStorage-Schlüssel)
- Pipeline-Stages
- Sector-Taxonomie

Diese Datei muss in git bleiben, sonst fehlen allen Entwicklern die App-Konstanten.

**Lösung:** Die neue Credentials-Datei heißt `js/env.js` (statt `js/config.js`). Gitignore-Eintrag entsprechend angepasst.

**Wie der Fehler entdeckt wurde:**  
`git ls-files js/config.js` zeigte, dass die Datei bereits getrackt ist. `git show HEAD:js/config.js` zeigte den Inhalt — eindeutig App-Konstanten, keine Credentials. Daraus war klar: falsches File gitignoren würde App-Konstanten aus der Versionskontrolle entfernen.

---

**Zusätzliches Problem (gelöschte Datei):**

`js/config.js` war lokal gelöscht (Fehler `File does not exist`), aber noch in git getrackt. `git status` zeigte ` D js/config.js` (D = deleted in working tree).

**Lösung:** `git checkout -- js/config.js` stellt die Datei vom letzten Commit wieder her, ohne andere Änderungen zu berühren.

**Warum das wichtig ist:**  
`js/config.js` wird in `index.html` per `<script>` geladen. Wenn die Datei fehlt, startet die App nicht — alle `LS_KEYS`-Referenzen wären `undefined`.

---

---

### Schritt 2 — `.env.example` anlegen (2026-04-28)

**Was:**  
Neue Datei `.env.example` im Root des Projekts angelegt.

**Wie:**  
Datei mit Platzhalter-Werten erstellt. Mit `git status` verifiziert, dass sie als `??` (untracked, nicht ignoriert) auftaucht — sie soll committed werden.

**Warum:**  
`.env.example` ist die "Anleitung" für jeden der das Projekt klont. Sie zeigt welche Umgebungsvariablen benötigt werden, ohne echte Keys preiszugeben. Konvention in fast jedem professionellen Projekt.

Inhalt:
- `SUPABASE_URL` — Supabase Projekt-URL
- `SUPABASE_ANON_KEY` — Öffentlicher Key (für Frontend)
- `SUPABASE_SERVICE_ROLE_KEY` — Admin-Key (nur für serverless functions)
- `ATTIO_API_KEY` — auskommentiert, noch nicht aktiv

---

### Schritt 3 — `js/env.example.js` anlegen (2026-04-28)

**Was:**  
Neue Datei `js/env.example.js` angelegt. (Im ursprünglichen Plan hieß sie `js/config.example.js` — umbenannt wegen Naming-Konflikt mit `js/config.js`.)

**Wie:**  
Datei mit Platzhalter-Werten für `SUPABASE_URL` und `SUPABASE_ANON_KEY` erstellt. Mit `git status` verifiziert dass sie als `??` erscheint.

**Warum:**  
Browser-seitig (Frontend) können keine `process.env`-Variablen verwendet werden — das ist Node.js-Syntax. Im Browser müssen Variablen als globale JS-Konstanten definiert sein. Deshalb gibt es eine separate `.js`-Datei für die Frontend-Credentials, zusätzlich zur `.env`-Datei für die serverless functions.

`js/env.js` wird per `<script>` in `index.html` geladen bevor `supabase-client.js` startet — so sind `SUPABASE_URL` und `SUPABASE_ANON_KEY` als globale Variablen verfügbar wenn der Client initialisiert wird.

`js/env.example.js` ist das committed Template dafür.

---

---

### Schritt 4 — `js/env.js` lokal erstellen (2026-04-28)

**Was:**  
`js/env.js` mit echten Supabase-Credentials lokal erstellt.

**Wie:**  
Datei manuell angelegt mit URL (`ggfjgzjevyemwbclvfpp.supabase.co`) und Anon Key.  
`git status --short js/env.js` gibt keinen Output — das bedeutet die Datei ist gitignored (korrekt).

**Warum:**  
Ohne diese Datei würde die App beim Laden abstürzen, weil `supabase-client.js` die Variablen `SUPABASE_URL` und `SUPABASE_ANON_KEY` erwartet. Die Datei existiert nur lokal — nie in git.

**Wichtig:** Der aktuelle Anon Key wird nach erfolgreichem Deployment in Phase G rotiert (Schritt 16). Bis dahin steht er noch hardcoded in `js/supabase-client.js` (wird in Phase B entfernt).

---

---

### Konzept: Wie `js/env.js` funktioniert

**Problem vorher:**  
Der Supabase-Key stand direkt in `js/supabase-client.js` hardcoded. Jeder mit Repo-Zugriff konnte ihn lesen.

**Lösung — 3 Teile spielen zusammen:**

**Teil 1 — `js/env.js` (gitignored, nur lokal)**  
Definiert `SUPABASE_URL` und `SUPABASE_ANON_KEY` als globale JS-Konstanten:
```js
const SUPABASE_URL      = 'https://...';
const SUPABASE_ANON_KEY = 'sb_publishable_...';
```

**Teil 2 — `index.html` Ladereihenfolge**  
`env.js` wird VOR `supabase-client.js` geladen:
```html
<script src="js/env.js"></script>
<script src="js/supabase-client.js"></script>
```
Der Browser lädt Skripte der Reihe nach. Wenn `supabase-client.js` startet, sind die Variablen aus `env.js` bereits im globalen Speicher verfügbar.

**Teil 3 — `js/supabase-client.js` liest die Variablen**  
```js
// vorher: hardcoded
const supabaseClient = window.supabase.createClient(
  'https://ggfjgzjevyemwbclvfpp.supabase.co',
  'sb_publishable_...'
);

// nachher: liest aus env.js
const supabaseClient = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_ANON_KEY
);
```

**In Production (Vercel):**  
Auf dem Server gibt es keine lokale `env.js`. Vercel injiziert die Werte als Umgebungsvariablen — wird in Phase F konfiguriert.

**Warum nicht einfach `process.env` verwenden?**  
`process.env` ist Node.js-Syntax und funktioniert nur auf dem Server. Im Browser (Frontend) gibt es kein `process` — deshalb müssen Variablen als globale JS-Konstanten definiert werden.

---

---

## Phase B — Script-Ladereihenfolge

### Schritt 5 — `index.html` Script-Order korrigieren (2026-04-28)

**Was:**  
`js/env.js` als neues `<script>`-Tag zwischen CDN und `supabase-client.js` eingefügt.

**Vorher:**
```html
<script src="...supabase.min.js"></script>
<script src="js/supabase-client.js"></script>
<script src="js/config.js"></script>
```

**Nachher:**
```html
<script src="...supabase.min.js"></script>
<script src="js/env.js"></script>
<script src="js/supabase-client.js"></script>
<script src="js/config.js"></script>
```

**Warum:**  
Browser führt Scripts in der Reihenfolge aus in der sie im HTML stehen. `supabase-client.js` verwendet `SUPABASE_URL` und `SUPABASE_ANON_KEY` — diese Variablen müssen bereits existieren wenn die Datei ausgeführt wird. `env.js` definiert sie, muss also zuerst geladen werden.

---

### Schritt 6 — `login.html` Script-Tag einfügen (2026-04-28)

**Was:**  
`js/env.js` auch in `login.html` eingefügt — gleiche Position wie in `index.html`.

**Warum:**  
`login.html` ist eine separate HTML-Seite mit eigenem Script-Block. Sie lädt `supabase-client.js` direkt — ohne `env.js` davor würde die Login-Seite mit "SUPABASE_URL is not defined" abstürzen.

---

### Schritt 7 — `js/supabase-client.js` hardcoded Keys ersetzen (2026-04-28)

**Was:**  
Zwei Änderungen in `js/supabase-client.js`:

1. Hardcoded URL + Key durch Variablen ersetzt:
```js
// vorher
const supabaseClient = window.supabase.createClient(
  'https://ggfjgzjevyemwbclvfpp.supabase.co',
  'sb_publishable_lv0jbhjnUHy3N0EQhhhUdQ_NAKjpwDO'
);

// nachher
const supabaseClient = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_ANON_KEY
);
```

2. `attio_api_key` aus dem `select()` entfernt:
```js
// vorher
.select('id, name, slug, attio_api_key')

// nachher
.select('id, name, slug')
```

**Warum Punkt 1:**  
Der Key steht jetzt nur noch in `js/env.js` (gitignored). In `supabase-client.js` (committed) gibt es keine Credentials mehr.

**Warum Punkt 2:**  
RLS (Row Level Security) in Supabase kann einzelne Spalten nicht verstecken — nur ganze Zeilen. `attio_api_key` ist ein sensitiver API-Key der nicht ans Frontend gelangen darf. Lösung: Spalte einfach nicht abfragen. Die Spalte wird in Phase C komplett aus der DB gedroppt.

---

---

## Phase C — Supabase DB Migrationen

### Schritt 8 — `attio_api_key` Column droppen (2026-04-28)

**Was:**  
```sql
ALTER TABLE public.funds DROP COLUMN IF EXISTS attio_api_key;
```

**Wie:**  
Migration über Supabase MCP Tool (`apply_migration`) ausgeführt. Danach mit `information_schema.columns` verifiziert — leeres Ergebnis bestätigt dass die Spalte nicht mehr existiert.

**Warum:**  
RLS (Row Level Security) in Supabase kann einzelne Spalten nicht verstecken, nur ganze Zeilen. `attio_api_key` ist ein sensibler Drittanbieter-Key der nicht ans Frontend darf. Da wir in Schritt 7 den `select()` bereits bereinigt haben, war die Spalte funktional tot — jetzt ist sie auch physisch weg. Der Key wird später als Vercel-Umgebungsvariable gespeichert wenn die Attio-Integration gebaut wird.

---

### Schritt 9 — 6 Performance-Indexes anlegen (2026-04-28)

**Was:**  
```sql
CREATE INDEX IF NOT EXISTS idx_fund_users_user_id      ON public.fund_users (user_id);
CREATE INDEX IF NOT EXISTS idx_submissions_fund_id     ON public.submissions (fund_id);
CREATE INDEX IF NOT EXISTS idx_submissions_contact_email ON public.submissions (contact_email);
CREATE INDEX IF NOT EXISTS idx_notes_fund_id           ON public.notes (fund_id);
CREATE INDEX IF NOT EXISTS idx_notes_submission_id     ON public.notes (submission_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_fund_id        ON public.pipeline (fund_id);
```

**Wie:**  
Eine Migration mit allen 6 Statements über `apply_migration` ausgeführt. Danach mit `pg_indexes` verifiziert — alle 6 Indexes bestätigt.

**Warum:**  
Ohne Indexes macht Postgres bei jeder Abfrage einen Full Table Scan — liest jede Zeile einzeln durch. Mit Indexes springt Postgres direkt zur richtigen Stelle.

Konkrete Beispiele:
- `idx_submissions_fund_id` — jede Abfrage filtert nach `fund_id`, ohne Index wächst die Ladezeit linear mit der Anzahl Submissions aller Funds
- `idx_submissions_contact_email` — Rate Limiting in Phase E prüft E-Mail-Adresse in den letzten 24h, ohne Index ist das ein Full Scan bei jedem Submit
- `idx_fund_users_user_id` — wird bei jedem Login aufgerufen um den Fund des Users zu finden

---

---

## Phase D — API Layer absichern

### Schritt 10 — `js/api.js` absichern (2026-04-28)

**Was:**  
Drei Änderungen in `js/api.js`:

**Änderung 1 — `apiLoadFund()` select fix:**
```js
// vorher
.select('*')

// nachher
.select('id, name, slug')
```

**Änderung 2 + 3 — Null-Guard für `apiLoadSubmissions` und `apiLoadAcceptedSubmissions`:**
```js
// vorher — fund_id war optional
async function apiLoadSubmissions(fund_id) {
  let query = supabaseClient.from('submissions').select('*').eq('status', 'pending')...;
  if (fund_id) query = query.eq('fund_id', fund_id);  // ← wenn null: ALLE submissions aller Funds
  ...
}

// nachher — fund_id ist required
async function apiLoadSubmissions(fund_id) {
  if (!fund_id) throw new Error('[apiLoadSubmissions] fund_id fehlt — kein Query ohne Fund-Filter');
  const { data, error } = await supabaseClient
    .from('submissions')
    .select('*')
    .eq('status', 'pending')
    .eq('fund_id', fund_id)   // ← immer gefiltert
    ...
}
```

**Warum Änderung 1:**  
`select('*')` holt alle Spalten aus der Tabelle — auch Spalten die das Frontend nicht braucht. Prinzip des minimalen Zugriffs: nur holen was benötigt wird.

**Warum Änderung 2+3:**  
Das ist die kritischste Änderung in Phase D. Das alte `if (fund_id)` Muster bedeutete: wenn `fund_id` aus irgendeinem Grund `null` ist (Auth-Fehler, Race Condition, Bug), werden alle Submissions aller Funds zurückgegeben. Fund A sieht Fund B's Deals.

Der neue Guard wirft sofort einen Fehler — die App zeigt nichts statt falsche Daten zu zeigen. Fail fast ist hier sicherer als silent failure.

---

---

## Phase E — Submit absichern

### Schritt 11 — `api/fund.js` auf SERVICE_ROLE_KEY umstellen (2026-04-28)

**Was:**  
`SUPABASE_ANON_KEY` → `SUPABASE_SERVICE_ROLE_KEY` in `api/fund.js`.

**Warum:**  
`api/fund.js` ist eine serverless function (läuft auf Vercel, nicht im Browser). Serverless functions haben Zugriff auf Umgebungsvariablen die nie ans Frontend gehen. Der Service Role Key bypassed RLS — auf dem Server ist das gewollt, weil der Server vertrauenswürdig ist. Der Anon Key ist für das Frontend gedacht, nicht für den Server.

---

### Schritt 12 — `api/submit.js` vollständige Überarbeitung (2026-04-28)

**Was:**  
Der Handler wurde um drei Sicherheitsblöcke erweitert, die VOR der eigentlichen Datenbankoperation laufen:

**Block 1 — Rate Limiting:**
```js
// Prüft: hat diese E-Mail in den letzten 24h bereits 3x submitted?
const since = new Date(Date.now() - 86400000).toISOString(); // 24h zurück
const rlRes = await fetch(`...submissions?contact_email=eq.${email}&submitted_at=gte.${since}&select=id`);
if (rlData.length >= 3) return res.status(429).json({ error: 'Zu viele Einreichungen...' });
```

**Block 2 — fund_id serverseitig ableiten:**
```js
// Client schickt ?fund=apex-ventures in der URL
// Server schlägt den Slug in der DB nach → erhält die echte fund_id
const fundSlug = req.query.fund;
const fundData = await fetch(`...funds?slug=eq.${fundSlug}&select=id`);
const fund_id = fundData[0].id;
```

**Block 3 — anon_id serverseitig generieren:**
```js
// Generiert z.B. "K-4821", prüft ob sie im Fund schon existiert
// Bis zu 5 Versuche, dann Fehler
const anon_id = await generateUniqueAnonId(fund_id);
```

**insertData — serverseitige Felder überschreiben body:**
```js
const insertData = {
  ...body,
  fund_id,           // aus Slug abgeleitet — client-Wert überschrieben
  anon_id,           // serverseitig generiert — client-Wert überschrieben
  status: 'pending', // immer hardcoded — client kann status nicht manipulieren
  ...
};
```

**Warum das wichtig ist:**  
Vorher konnte ein Angreifer im Request-Body `fund_id: "andere-fund-id"` und `status: "accepted"` schicken — der Server hätte das blind übernommen. Jetzt werden diese kritischen Felder immer serverseitig gesetzt, egal was der Client schickt.

---

### Schritt 13 — `submit/index.html` bereinigen (2026-04-28)

**Was:**  
Drei Änderungen im Submit-Formular:

1. `fund_id`, `anon_id`, `status: 'pending'` aus `submissionData` entfernt — der Server setzt diese jetzt selbst
2. Fetch-URL von `/api/submit` auf `/api/submit?fund=<slug>` geändert
3. 429-Handler eingefügt — zeigt deutschen Fehlertext wenn Rate Limit getroffen

**Warum:**  
Das Frontend soll keine sicherheitsrelevanten Felder mehr schicken — nicht weil der Server sie nicht überschreiben würde, sondern um den Contract klar zu halten: der Client schickt Formulardaten, der Server entscheidet alles andere.

---

---

## Phase F — Vercel Env Var setzen

### Schritt 14 — `SUPABASE_SERVICE_ROLE_KEY` in Vercel (2026-04-28)

**Was:**  
Im Vercel Dashboard unter **Environment Variables** eine neue Variable hinzugefügt:
- Key: `SUPABASE_SERVICE_ROLE_KEY`
- Value: `sb_secret_...` (sensitiv, nicht im Log gespeichert)
- Environments: Production and Preview

**Wie:**  
Vercel Dashboard → core-app → Environment Variables → Add Environment Variable → Sensitive aktiviert → Save.

**Warum:**  
`api/fund.js` und `api/submit.js` lesen `process.env.SUPABASE_SERVICE_ROLE_KEY` zur Laufzeit. Ohne diese Variable würden beide Functions mit HTTP 500 "Server misconfigured" antworten. Vercel injiziert Umgebungsvariablen beim Deployment — sie sind nur serverseitig verfügbar, nie im Browser-Bundle.

**Warum Sensitive aktiviert:**  
Vercel zeigt sensitive Variablen nach dem Speichern nicht mehr im Klartext an — schützt vor versehentlichem Ablesen über die Schulter oder in Screenshots.

---

---

## Phase G — End-to-End Tests

### Schritt 15 — Playwright Tests (2026-04-28)

**Test 1 — Submit Form (10/10 grün):**  
`submit-form.spec.js` — 10 verschiedene Startups durchs Formular submitted. Alle landen in der DB mit serverseitig generierter `anon_id` und `status: 'pending'`.

**Test 2 — Rate Limiting (1/1 grün):**  
`rate-limit.spec.js` — gleiche E-Mail 4x: erste 3 Submissions erfolgreich, 4. gibt HTTP 429 mit deutschem Fehlertext "Zu viele Einreichungen... 24 Stunden".

**Bugs die beim Schreiben des Rate-Limit Tests gefunden wurden:**

1. **Falsche Produktions-URL** — Playwright-Config hatte `core-app-gamma.vercel.app`, ich testete gegen `core-app-git-main-awees67s-projects.vercel.app`. Letztere URL ist die Deployment-Preview, nicht die echte Produktions-Domain. Fix: richtige URL nutzen.

2. **Falscher Sector-Value** — Test nutzte `'SaaS / Software'`, tatsächlicher Option-Value ist `'B2B SaaS'`. Fix: Wert aus `js/config.js` nachgelesen.

3. **Beschreibung zu kurz** — Formular verlangt min. 80 Zeichen. Test hatte nur 50. Fix: Text verlängert auf 120 Zeichen.

4. **Race Condition: `currentFund` null beim Submit** — `#fundName` startet mit "Laden..." im HTML. Test-Check `not.toHaveText('')` hat "Laden..." als non-empty akzeptiert und weitergemacht, bevor `loadFund()` fertig war. Beim Submit-Klick war `currentFund` noch null → "Kein gültiger Fonds geladen." Fix: `waitForFunction(() => currentFund?.id != null)` hinzugefügt — dieselbe Guard die in `submit-form.spec.js` bereits war.

5. **Test-Email bereits in DB** — Aus fehlgeschlagenen Testläufen lagen Submissions mit der Test-Email in der DB. Beim erneuten Test traf die erste Submission sofort das Rate Limit. Fix: `DELETE FROM submissions WHERE contact_email = 'ratelimit-test@playwright.local'` vor jedem Testlauf.

6. **Falsches Error-Element** — Test prüfte `#errorMsg2`, aber `showError()` schreibt in `#errorMsg`. Fix: Element-ID korrigiert.

---

---

### Schritt 16 — Anon Key rotieren (2026-04-28)

**Was:**  
1. Neuen Publishable Key `core_frontend` in Supabase erstellt (`sb_publishable_27NEL...`)
2. `js/env.js` lokal auf neuen Key aktualisiert
3. Vercel `SUPABASE_ANON_KEY` auf neuen Key aktualisiert (war noch alter Legacy JWT `eyJhbGci...`)
4. Alten `default` Key in Supabase gelöscht

**Warum:**  
Der alte Anon Key (`sb_publishable_lv0jbhj...`) stand in der Git-History von `js/supabase-client.js` — sichtbar für jeden mit Repo-Zugriff. Durch das Löschen ist er sofort ungültig. Alle Requests mit dem alten Key werden ab jetzt von Supabase abgelehnt.

---

## Woche 1 — Abgeschlossen ✅

Alle 16 Schritte aus dem Plan erfolgreich umgesetzt:
- Kein Key mehr in Git
- fund_id-Isolation garantiert (Null-Guards)
- Submit: rate limiting, serverseitige fund_id + anon_id, status hardcoded
- Service Role Key nur serverseitig
- 6 Performance-Indexes in DB
- attio_api_key aus DB entfernt
- 11/11 Playwright Tests grün

---

---

## Post-Woche-1 Bug — `js/env.js` nicht deployed (2026-04-28)

### Symptom

Workspace-Tests (Login → App → Fund-Name) schlugen alle fehl:

```
Error: expect(received).not.toContain(expected)
Expected substring: not "login.html"
Received string: "https://core-app-gamma.vercel.app/login.html"
```

Die App leitete jeden Besucher sofort zu `login.html` weiter — `getSession()` gab immer `null` zurück, auch mit gültigem Auth-State.

---

### Root Cause — Gitignored File nicht auf Vercel

In Schritt 1 wurde `js/env.js` zu `.gitignore` hinzugefügt. Damit war die Datei lokal vorhanden aber **nie committed** — und Vercel deployt nur was in git ist.

Was in Production passierte:
1. Browser lädt `index.html`
2. `<script src="js/env.js"></script>` → **HTTP 404**, Script wird silent ignoriert
3. `SUPABASE_URL` und `SUPABASE_ANON_KEY` sind `undefined`
4. `supabaseClient = createClient(undefined, undefined)` → broken client
5. `supabaseClient.auth.getSession()` → `null`
6. Auth Guard: `if (!session) → window.location.href = 'login.html'`

**Das Submit-Formular war davon nicht betroffen**, weil `submit/index.html` kein `supabase-client.js` lädt — es ruft nur `/api/submit` auf. Deshalb haben die Submit-Tests in Phase G bestanden, der Fehler blieb unentdeckt.

---

### Denkfehler

Der ursprüngliche Grund für das Gitignoren war: "Credentials nicht in git committen."

Das war für den Anon Key falsch. Der Anon/Publishable Key ist **per Design öffentlich** — er steht im Browser-Bundle jeder Supabase-App, ist für jeden sichtbar der die Seite öffnet, und ist durch RLS-Policies geschützt (nicht durch Geheimhaltung). Es gibt keinen Sicherheitsgewinn ihn aus git herauszuhalten.

**Was wirklich geheim ist:** der `SUPABASE_SERVICE_ROLE_KEY`. Dieser steht aber nur in `.env` und in Vercel-Umgebungsvariablen — nie im Frontend.

**Merkregel:**
- `.env` (Service Role Key, Drittanbieter-Keys) → gitignored ✅
- `js/env.js` (Supabase URL + Anon Key) → in git, public by design ✅

---

### Fix

1. `js/env.js` aus `.gitignore` entfernt  
2. Kommentar aktualisiert: `# Anon Key ist public by design, wird im Frontend benötigt`  
3. `js/env.js` committed und nach Vercel deployed  
4. `tests/auth.setup.js` auf neuen rotierten Key aktualisiert (hatte noch alten `lv0jbhj...` hardcoded)

**Ergebnis:** 11/11 workspace Tests grün. Alle Woche-1-Tests bestehen.

---

---

## RLS Hardening (2026-04-28)

### Vollständiges RLS-Audit

Nach Woche 1 wurden alle bestehenden Policies geprüft. Drei Lücken gefunden:

---

### Lücke 1 — KRITISCH: `submissions` INSERT mit `WITH CHECK = true`

**Was:**  
Die Policy "Anyone can submit" hatte `WITH CHECK = true` — d.h. jeder mit dem Anon Key konnte Submissions direkt in die Datenbank einfügen.

**Warum das gefährlich ist:**  
`api/submit.js` ist der einzige erlaubte Eingang für neue Submissions — er macht Rate Limiting, leitet fund_id serverseitig ab und validiert Pflichtfelder. Mit `WITH CHECK = true` konnte jemand diese Schutzschicht komplett umgehen und direkt über die Supabase REST API inserieren.

**Fix:**  
```sql
DROP POLICY "Anyone can submit" ON public.submissions;
```
Kein INSERT mehr via Anon Key. Nur der Service Role Key (in `api/submit.js`) kann inserieren.

**Verifiziert:**  
```bash
curl -X POST $SUPABASE_URL/rest/v1/submissions \
  -H "Authorization: Bearer $ANON_KEY" \
  -d '{...}'
# → HTTP 401
```

---

### Lücke 2 — `pipeline` UPDATE ohne WITH CHECK

**Was:**  
Die UPDATE-Policy hatte nur `USING`, kein `WITH CHECK`. Das bedeutet: ein User kann eigene Pipeline-Items finden und updaten, aber beim Update die `fund_id` auf eine fremde Fund ändern — und das Item so "verschieben".

**Fix:**  
```sql
DROP POLICY "Fund members can update pipeline" ON public.pipeline;
CREATE POLICY "Fund members can update pipeline"
  ON public.pipeline FOR UPDATE
  USING     (fund_id IN (SELECT fund_id FROM fund_users WHERE user_id = auth.uid()))
  WITH CHECK (fund_id IN (SELECT fund_id FROM fund_users WHERE user_id = auth.uid()));
```

**Merkregel:** Bei UPDATE braucht man immer beides: `USING` (welche Rows darf ich lesen/updaten) + `WITH CHECK` (welche Werte darf der neue Stand haben).

---

### Lücke 3 — `submissions` UPDATE ohne WITH CHECK

Gleiche Lücke wie bei Pipeline. Ein Fund-Member hätte beim Status-Update (`accepted`/`declined`) die `fund_id` mitändern können.

**Fix:** Gleiche Lösung — `WITH CHECK` hinzugefügt.

---

### Weitere Lücke — Rate Limiter in `api/submit.js`

**Was:**  
```js
if (contactEmail) {   // ← leer = kein Rate Limit
  // rate limit check...
}
```

Wenn jemand direkt `POST /api/submit` ohne `contact_email` aufruft, wurde Rate Limiting komplett übersprungen. Submissions ohne Email sind in der DB erlaubt (nullable).

**Fix:**  
```js
const contactEmail = body?.contact_email;
if (!contactEmail || typeof contactEmail !== 'string' || !contactEmail.includes('@')) {
  return res.status(400).json({ error: 'E-Mail-Adresse fehlt oder ist ungültig.' });
}
// Rate Limit läuft jetzt bedingungslos
```

---

### Finales RLS-Bild (vollständig)

| Tabelle | INSERT | SELECT | UPDATE | DELETE |
|---|---|---|---|---|
| `funds` | — (service role) | public ✅ | — | — |
| `fund_users` | — (service role) | eigene Zeile ✅ | — | — |
| `submissions` | — (service role) ✅ | fund_id ✅ | USING+CHECK ✅ | — |
| `pipeline` | WITH CHECK ✅ | fund_id ✅ | USING+CHECK ✅ | fund_id ✅ |
| `notes` | WITH CHECK ✅ | fund_id ✅ | — (immutable) ✅ | fund_id ✅ |
| `attio_pushes` | WITH CHECK ✅ | fund_id ✅ | — (log) ✅ | — (log) ✅ |

### Direkte Security-Tests (nicht über UI)

5 Tests direkt gegen die Supabase REST API mit dem Anon Key:

1. INSERT submissions → **HTTP 401** ✅
2. SELECT submissions ohne Login → **`[]`** ✅  
3. SELECT ohne Auth-Header → **`[]`** ✅
4. pipeline lesen als Anon → **`[]`** ✅
5. UPDATE submissions → **Content-Range: \*/0** (0 Zeilen betroffen) ✅

### 5 Playwright-Durchläufe hintereinander

22 Tests × 5 Läufe = **110 Tests, alle grün.** Cleanup zwischen Läufen funktioniert stabil.
