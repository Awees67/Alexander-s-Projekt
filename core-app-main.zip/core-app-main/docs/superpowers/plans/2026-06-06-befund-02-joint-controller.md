# Befund 02 — Joint Controller (Art. 26) vs. Auftragsverarbeiter (Art. 28)

**Audit-Datum:** 6. Juni 2026
**Schweregrad:** KRITISCH
**Kategorie:** B — Fehlinterpretation / Rechtsfehler
**Betrifft:** Datenschutzerklärung v5.6.2026, AVV mit APEX Ventures, api/submit.js, state.js, main.js

---

## Was ist das Problem?

Die Datenschutzerklärung behandelt den Plattformbetreiber durchgehend als reinen **Auftragsverarbeiter** des Fonds nach Art. 28 DSGVO. Das bedeutet laut Dokument: Der Plattformbetreiber führt nur aus, was der Fonds anweist. Der Fonds ist der alleinige Verantwortliche.

Das stimmt nicht mit der technischen Realität überein.

---

## Warum ist das ein Problem?

### Art. 28 vs. Art. 26 -- der Unterschied

**Auftragsverarbeiter (Art. 28):**
Handelt ausschliesslich nach Weisung des Verantwortlichen. Er entscheidet nicht, welche Daten gesammelt werden, warum sie gesammelt werden oder wie sie verarbeitet werden. Er führt nur aus.

**Gemeinsame Verantwortliche (Art. 26):**
Wenn zwei oder mehr Stellen gemeinsam festlegen, zu welchem Zweck und auf welche Weise Daten verarbeitet werden. Beide haften dann gemeinsam -- gesamtschuldnerisch.

### Was der Plattformbetreiber eigenständig entschieden hat

Der Plattformbetreiber hat folgende Entscheidungen getroffen, ohne Weisung des Fonds:

**1. Die 4 booleschen Merkmale (api/submit.js, Zeilen 251-254)**
Der Plattformbetreiber hat festgelegt, dass für jeden Gründer dauerhaft gespeichert wird:
- `has_repeat_founder`
- `has_prior_exit`
- `has_technical_founder`
- `has_domain_expert`

Der Fonds hat das nicht angeordnet. Der Plattformbetreiber hat entschieden, dass das relevante Datenkategorien über Personen sind.

**2. Die 11 Plausibilitätsregeln (api/submit.js, Zeilen 1-80)**
Welche 11 Regeln angewendet werden, welche Schwellenwerte gelten, welche Kennzahlen gegeneinander geprüft werden -- das hat der Plattformbetreiber allein definiert.

**3. Die 5 berechneten Kennzahlen (api/submit.js, Zeilen 226-240)**
ARR, ARPA, LTV, CAC Payback, Burn Multiple werden serverseitig berechnet und dauerhaft als Teil der Einreichung gespeichert. Der Fonds hat nicht angeordnet, dass diese Derivate existieren.

**4. Die Scoring-Architektur**
7 Regelgruppen, Normierung auf 0-100, gewichtete Summe -- das ist die Architektur des Signal-Scores. Der Fonds konfiguriert nur die Gewichtungen innerhalb dieser Struktur. Er entscheidet nicht, dass Wachstum überhaupt eine Kategorie ist.

### Die rechtliche Konsequenz

Die EDSA-Leitlinien 07/2020 unterscheiden zwischen:
- **Wesentliche Mittel** (essential means): Welche Daten, welche Betroffenen, wie lange, an wen -- nur der Verantwortliche bestimmt das.
- **Nicht-wesentliche Mittel** (non-essential means): Technische Architektur, Sicherheitsmassnahmen -- darf der Auftragsverarbeiter eigenständig bestimmen.

Die booleschen Merkmale und berechneten Kennzahlen sind keine technischen Implementierungsdetails -- das sind **Datenkategorien über Personen**, die der Plattformbetreiber eigenständig erfunden hat. Das ist Bestimmung wesentlicher Mittel -- und damit potenziell Art. 26.

### Was Art. 26 für dich bedeuten würde

- Der bestehende AVV ist das falsche Instrument -- Art. 26 braucht eine andere Vereinbarung.
- Du haftest **gesamtschuldnerisch** für Verstösse des Fonds. Datenpanne bei APEX Ventures -- du kannst direkt in Anspruch genommen werden.
- Gründer könnten Rechte (Auskunft, Löschung, Widerspruch) direkt bei dir geltend machen.
- Die Datenschutzerklärung wäre in der Rollenbeschreibung falsch.

---

## Die Lösung: Art. 28 wasserdicht machen

Das Ziel ist klar: Reiner Auftragsverarbeiter bleiben. Das ist erreichbar -- mit zwei parallelen Massnahmen: Vertrag und Code.

### Massnahme 1 -- AVV: Expliziter Weisungskatalog (anwaltlich aufsetzen lassen)

Der bestehende AVV wird um einen **Weisungskatalog** als Anlage erweitert. Darin beauftragt der Fonds schriftlich jede einzelne Verarbeitung:

> "Der Verantwortliche (Fonds) erteilt dem Auftragsverarbeiter (Plattformbetreiber) Weisung, folgende Verarbeitungen im Auftrag durchzuführen:
>
> 1. Berechnung und Speicherung folgender boolescher Merkmale aus den Gründerangaben: has\_repeat\_founder, has\_prior\_exit, has\_technical\_founder, has\_domain\_expert.
> 2. Berechnung und Speicherung folgender Kennzahlen: ARR, ARPA, LTV, CAC Payback, Burn Multiple.
> 3. Automatisierte Plausibilitätsprüfung anhand von elf definierten Regeln (Anlage X).
> 4. Berechnung eines Signal-Scores (0-100) auf Basis eines vom Verantwortlichen konfigurierten Regelwerks mit sieben Regelgruppen.
>
> Der Auftragsverarbeiter handelt für alle oben genannten Verarbeitungen ausschliesslich auf Weisung des Verantwortlichen. Änderungen am Umfang der Verarbeitungen bedürfen der schriftlichen Zustimmung des Verantwortlichen."

**Warum das hilft:** Der Fonds hat dann schriftlich entschieden, dass diese Datenkategorien existieren sollen. Du führst seine Weisung aus. Das ist klassisches Art. 28.

---

### Massnahme 2 -- Technische Kontrollmöglichkeit für den Fonds (Code-Änderung)

Der Fonds muss Features deaktivieren können. Nicht weil er das tun wird -- sondern weil die blosse Möglichkeit beweist, dass er der Entscheider ist, nicht du.

**Wichtig:** Das Frontend berechnet den Score aktuell **nochmal lokal** unabhängig vom Server (`state.js`, Zeile 191: `computeSignalIndex()`). Eine reine Server-Änderung reicht daher nicht -- beide Stellen müssen das Flag respektieren.

#### Schritt 1: Supabase -- `features`-Spalte in `funds`-Tabelle

```sql
ALTER TABLE funds
  ADD COLUMN IF NOT EXISTS features JSONB DEFAULT NULL;
```

Standardwert `null` = alle Features aktiv. Kein Fonds muss etwas konfigurieren. Alles läuft wie gehabt bis ein Fonds aktiv etwas abschaltet.

Einen Fonds deaktiviert der Plattformbetreiber mit einem SQL-Eintrag in Supabase:

```sql
UPDATE funds
SET features = '{"signal_score": false, "plausibility": false}'
WHERE slug = 'apex-ventures';
```

#### Schritt 2: api/submit.js -- Fund-Query erweitern

```javascript
// Vorher -- nur id laden:
`${SUPABASE_URL}/rest/v1/funds?slug=eq.${fundSlug}&select=id`

// Nachher -- id und features laden:
`${SUPABASE_URL}/rest/v1/funds?slug=eq.${fundSlug}&select=id,features`
```

Dann vor den Berechnungen:

```javascript
const features         = fundData[0].features || {};
const computeBooleans  = features.boolean_flags    !== false;
const runPlausibility  = features.plausibility     !== false;
const computeMetrics   = features.computed_metrics !== false;
const computeScore     = features.signal_score     !== false;
```

Berechnungen nur wenn Flag aktiv:

```javascript
const has_repeat_founder  = computeBooleans ? hasStrength('Repeat Founder') : null;
const has_prior_exit      = computeBooleans ? foundersArr.some(f => f.had_exit === true) : null;
const has_technical_founder = computeBooleans ? hasStrength('Technical') : null;
const has_domain_expert   = computeBooleans ? hasStrength('Domain Expert') : null;

const plaus = runPlausibility
  ? computePlausibility({ ...body, arr_eur, ltv_cac_ratio })
  : { status: null, checks: null, summary: null };
```

#### Schritt 3: main.js -- features beim Fonds-Load in window speichern

Dort wo der aktuelle Fonds geladen wird (`getCurrentFund()` oder ähnlich), das `features`-Objekt global verfügbar machen:

```javascript
window.fundFeatures = fundData.features || {};
```

#### Schritt 4: state.js Zeile 191 -- lokale Score-Berechnung absichern

```javascript
// Vorher:
signal_index: (typeof computeSignalIndex === 'function' && resolved_anon_id)
  ? computeSignalIndex(resolved_anon_id)
  : 0,

// Nachher:
signal_index: (
  window.fundFeatures?.signal_score !== false &&
  typeof computeSignalIndex === 'function' &&
  resolved_anon_id
)
  ? computeSignalIndex(resolved_anon_id)
  : null,
```

#### Schritt 5: Frontend -- null-Score sauber anzeigen

Überall wo `signal_index` angezeigt wird (renderers-submissions.js Zeile 143, renderers-pipeline.js Zeile 132) prüfen ob null:

```javascript
// Vorher:
let score = Math.round(sub.signal_index || 0);

// Nachher:
let score = sub.signal_index != null ? Math.round(sub.signal_index) : null;
// Anzeige: score !== null ? score : '—'
```

---

### Massnahme 3 -- Datenschutzerklärung: Abschnitt 1.2 anpassen

Den aktuellen Text um eine Begründung erweitern, warum der Plattformbetreiber Auftragsverarbeiter ist:

> "Der Plattformbetreiber hat die technische Infrastruktur der Plattform entwickelt und stellt sie dem Fonds als konfigurierbares Werkzeug zur Verfügung. Alle inhaltlichen Entscheidungen über den Umfang der Datenverarbeitung -- insbesondere welche Scoring-Merkmale berechnet werden, ob eine Plausibilitätsprüfung durchgeführt wird und wie der Signal-Score gewichtet ist -- trifft ausschliesslich der Fonds als Verantwortlicher. Der Plattformbetreiber handelt dabei ausschliesslich nach schriftlicher Weisung des Fonds gemäss dem abgeschlossenen Auftragsverarbeitungsvertrag nach Art. 28 DSGVO."

---

## Zusammenfassung: Was sich ändert

| Was | Wo | Aufwand |
|---|---|---|
| Weisungskatalog in AVV | Anwalt | Einmalig, ca. 1-2h Anwalt |
| `features`-Spalte in Supabase | Supabase SQL-Editor | 5 Minuten |
| Fund-Query in api/submit.js | api/submit.js, 1 Zeile | 10 Minuten |
| Feature-Flags vor Berechnungen | api/submit.js, ~10 Zeilen | 20 Minuten |
| features in window speichern | main.js, 1 Zeile | 5 Minuten |
| Score-Berechnung absichern | state.js, 3 Zeilen | 10 Minuten |
| Null-Score im Frontend | renderers-*.js, 2-3 Stellen | 20 Minuten |
| Abschnitt 1.2 Datenschutzerklärung | Datenschutzerklärung, 1 Absatz | 10 Minuten |

---

## Was anwaltlich zu klären bleibt

**Einziger offener Punkt:** Den aktualisierten AVV mit Weisungskatalog aufsetzen und prüfen lassen. Das ist Standardarbeit für einen DSGVO-erfahrenen Anwalt -- kein Grenzfall. Einmaliger Aufwand, schützt dauerhaft.

Zum Anwaltsgespräch mitnehmen:
1. Den bestehenden AVV mit APEX Ventures
2. Die Liste der vier Eigenentscheidungen aus diesem Bericht (boolesche Merkmale, Plausibilitätsregeln, Kennzahlen, Scoring-Architektur)
3. Die Frage: "Reicht der Weisungskatalog im AVV, oder braucht es zusätzlich die technische Abschaltmöglichkeit?"

---

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*
*Erstellt: 6. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
