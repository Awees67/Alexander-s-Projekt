# DSGVO Art. 13/14 + Multi-Fonds-Skalierung — Implementierungsplan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Die CORE-Plattform erfüllt Art. 13 und Art. 14 DSGVO korrekt für beliebig viele Fonds, ohne dass bei jedem neuen Fonds die Datenschutzerklärung manuell aktualisiert werden muss.

**Architecture:** Das Einreichungsformular zeigt die fondsspezifischen Verantwortlichen-Daten dynamisch aus der Datenbank an (Art. 13 Pflicht im Moment der Erhebung). Die zentrale Datenschutzerklärung beschreibt die Struktur und verweist auf diese dynamische Information. Ein neuer Abschnitt in der Datenschutzerklärung deckt Art. 14 für mitgenannte Personen (Mitgründer) ab.

**Tech Stack:** HTML, JavaScript (vanilla), Supabase (funds-Tabelle), kein Build-Step

---

## Hintergrund: Was hier gelöst wird

### Problem 1 — Art. 14 DSGVO fehlt vollständig (KRITISCH)

Gründer A trägt Daten über Gründer B ein (Name, LinkedIn, Equity-Anteil, Exit-Erfahrung). Gründer B hat nie eine Datenschutzinformation erhalten. Er ist betroffene Person nach Art. 14 DSGVO — mit Informationspflicht des Verantwortlichen (Fonds) innerhalb eines Monats nach Erhebung.

**Zwei Massnahmen nötig:**
1. Hinweis auf dem Formular: Wer Daten über Dritte einträgt, ist selbst verpflichtet, diese zu informieren (Art. 14 Abs. 4 DSGVO i.V.m. Praxis-Delegationsansatz).
2. Neuer Abschnitt in der Datenschutzerklärung: Vollständige Art.-14-Information für mitgenannte Personen.

### Problem 2 — Datenschutzerklärung nicht skalierbar auf mehrere Fonds (HOCH)

Art. 13 Abs. 1 lit. a DSGVO: Der Gründer muss beim Absenden **Namen und Kontaktdaten des Verantwortlichen** kennen. Der Verantwortliche ist der Fonds — nicht der Plattformbetreiber. Derzeit ist APEX Ventures GmbH hardcoded in der Datenschutzerklärung. Bei 10 Fonds bräuchte man 10 Versionen oder ein nicht-skalierbares Appendix.

**Lösung:** Fondsdaten dynamisch aus der Supabase `funds`-Tabelle ziehen und im Formular anzeigen. Die zentrale Datenschutzerklärung beschreibt die Struktur ("der zugeordnete Fonds, dessen Identität beim Absenden angezeigt wird") statt einzelne Fonds zu benennen.

---

## Voraussetzung: Supabase funds-Tabelle prüfen

Bevor du beginnst: Prüfe, ob die `funds`-Tabelle die nötigen Felder hat:

```sql
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'funds';
```

Benötigte Felder: `name`, `address`, `privacy_contact_email`. Falls nicht vorhanden: Migration zuerst (Task 0).

---

## Task 0: funds-Tabelle um Datenschutz-Pflichtfelder erweitern (falls nötig)

**Files:**
- Modify: Supabase via Migration

- [ ] **Schritt 1: Fehlende Spalten prüfen**

Führe in Supabase SQL-Editor aus:
```sql
SELECT column_name FROM information_schema.columns WHERE table_name = 'funds';
```

- [ ] **Schritt 2: Migration anlegen falls `address` oder `privacy_contact_email` fehlen**

```sql
ALTER TABLE funds 
  ADD COLUMN IF NOT EXISTS address TEXT,
  ADD COLUMN IF NOT EXISTS privacy_contact_email TEXT;
```

- [ ] **Schritt 3: APEX Ventures Daten eintragen**

```sql
UPDATE funds 
SET 
  address = 'Habsburgergasse 2/1a, 1010 Wien',
  privacy_contact_email = 'tim.hos@apex.at'
WHERE name = 'APEX Ventures' OR name ILIKE '%apex%';
```

Ergebnis prüfen: `SELECT name, address, privacy_contact_email FROM funds;`

- [ ] **Schritt 4: Commit (nur Migration-Datei, wenn lokal mit Supabase CLI)**

```bash
git add supabase/migrations/
git commit -m "feat: add privacy contact fields to funds table"
```

---

## Task 1: Dynamische Datenschutzinfo im Submit-Formular

**Ziel:** Beim Laden von `/submit` wird der zugeordnete Fonds aus Supabase geladen und die Datenschutzinfo dynamisch eingeblendet — inklusive Name, Adresse und Datenschutzkontakt des Fonds.

**Files:**
- Modify: `submit/index.html`
- Modify: `api/submit.js` (falls fund_id schon beim Laden bekannt ist)

### Wie die fund_id beim Formular ankommt

Das Formular muss wissen, welchem Fonds es zugeordnet ist. Typische Ansätze:
- URL-Parameter: `/submit?fund=apex-ventures`
- Subdomain: `apex.core-platform.com/submit`
- Hardcoded per Deployment (aktueller Stand)

Prüfe den aktuellen Stand in `submit/index.html` — suche nach `fund_id` oder `APEX`.

- [ ] **Schritt 1: fund_id-Quelle im Formular identifizieren**

```bash
grep -n "fund_id\|fund\|APEX\|fonds" submit/index.html | head -30
```

- [ ] **Schritt 2: Supabase-Abfrage für Fondsdaten ergänzen**

In `submit/index.html` oder dem zugehörigen JS, nach dem Supabase-Client-Import:

```javascript
async function loadFundPrivacyInfo(fundId) {
  const { data, error } = await supabaseClient
    .from('funds')
    .select('name, address, privacy_contact_email')
    .eq('id', fundId)
    .single();

  if (error || !data) return null;
  return data;
}
```

- [ ] **Schritt 3: Datenschutz-Info-Box im HTML ergänzen**

Direkt vor dem Absende-Button im Formular folgenden HTML-Block einfügen:

```html
<div id="privacy-notice-box" class="privacy-notice" role="region" aria-label="Datenschutzhinweis">
  <h4>Datenschutzhinweis (Art. 13 DSGVO)</h4>
  <p>
    Ihre Daten werden verarbeitet von:<br>
    <strong id="privacy-fund-name">[wird geladen...]</strong><br>
    <span id="privacy-fund-address"></span><br>
    Datenschutzkontakt: <a id="privacy-fund-email" href=""></a>
  </p>
  <p>
    Der Plattformbetreiber (Andreas Awees) verarbeitet Ihre Daten als Auftragsverarbeiter 
    im Auftrag des oben genannten Fonds. 
    <a href="/datenschutz" target="_blank">Vollständige Datenschutzerklärung</a>
  </p>
  <p class="art14-notice">
    <strong>Hinweis zu Mitgründerinnen und Mitgründern:</strong> 
    Wenn Sie Angaben zu weiteren Personen machen (z.B. Mitgründer, Co-Founder), 
    sind Sie als einreichende Person verpflichtet, diese Personen über die 
    Verarbeitung ihrer Daten zu informieren. 
    <a href="/datenschutz#art14" target="_blank">Mehr dazu in unserer Datenschutzerklärung</a>.
  </p>
</div>
```

- [ ] **Schritt 4: JS-Funktion zum Befüllen der Box**

```javascript
async function renderPrivacyNotice(fundId) {
  const fund = await loadFundPrivacyInfo(fundId);
  if (!fund) return; // Fallback: Box bleibt leer, statischer Text bleibt sichtbar

  document.getElementById('privacy-fund-name').textContent = fund.name;
  document.getElementById('privacy-fund-address').textContent = fund.address || '';
  const emailEl = document.getElementById('privacy-fund-email');
  emailEl.textContent = fund.privacy_contact_email || '';
  emailEl.href = `mailto:${fund.privacy_contact_email || ''}`;
}
```

Aufruf: `renderPrivacyNotice(FUND_ID)` beim Initialisieren des Formulars.

- [ ] **Schritt 5: Fallback für Fehlerfall definieren**

Falls Supabase nicht antwortet oder kein Fonds gefunden wird: Statischen Fallback-Text anzeigen:

```javascript
// In loadFundPrivacyInfo, bei error:
document.getElementById('privacy-fund-name').textContent = 
  'Den zuständigen Fonds (Kontakt: datenschutz@core-platform.com)';
```

- [ ] **Schritt 6: Manuell testen**

1. `/submit` im Browser öffnen
2. Prüfen: Wird Fondsname, Adresse und E-Mail korrekt angezeigt?
3. Prüfen: Stimmt die E-Mail mit `tim.hos@apex.at` überein?
4. Prüfen: Link zur Datenschutzerklärung funktioniert?
5. Prüfen: Art.-14-Hinweis sichtbar?

- [ ] **Schritt 7: Commit**

```bash
git add submit/index.html
git commit -m "feat: dynamic privacy notice on submit form (Art. 13 DSGVO, multi-fund)"
```

---

## Task 2: Datenschutzerklärung — Art. 14 Abschnitt ergänzen

**Ziel:** Neuer Abschnitt in der Datenschutzerklärung, der mitgenannte Personen (Mitgründer) vollständig nach Art. 14 DSGVO informiert.

**Files:**
- Modify: Die Datenschutzerklärung (HTML-Datei oder Quelle der `/datenschutz`-Seite)

Zuerst: Wo liegt die Datenschutzerklärung?

```bash
find . -name "datenschutz*" -o -name "privacy*" | grep -v node_modules | grep -v .git
```

- [ ] **Schritt 1: Datei finden und öffnen**

- [ ] **Schritt 2: Neuen Abschnitt nach dem bestehenden Abschnitt 9 (Rechte) einfügen**

Abschnitt mit Anchor `id="art14"` ergänzen:

```html
<section id="art14">
  <h2>17. Informationen für mitgenannte Personen (Art. 14 DSGVO)</h2>

  <p>
    Dieser Abschnitt richtet sich an Personen, deren Daten im Rahmen einer 
    Startup-Einreichung durch eine andere Person (z.B. einen Mitgründer) 
    übermittelt wurden — ohne dass sie selbst das Formular ausgefüllt haben.
  </p>

  <h3>Wer ist Verantwortlicher?</h3>
  <p>
    Der datenschutzrechtlich Verantwortliche für Ihre Daten ist der Venture-Capital-Fonds, 
    dem die Einreichung zugeordnet wurde. Dessen Identität und Kontaktdaten wurden der 
    einreichenden Person beim Absenden des Formulars angezeigt. Auf Anfrage teilen wir 
    Ihnen den zuständigen Fonds mit — wenden Sie sich dazu an: 
    <a href="mailto:awees6703@gmail.com">awees6703@gmail.com</a>.
  </p>

  <h3>Welche Daten wurden übermittelt?</h3>
  <p>
    Typischerweise: Name, Rolle im Unternehmen, LinkedIn-URL, Berufserfahrung (Jahre), 
    Ausbildung, Exit-Erfahrung, Stärken sowie ggf. Angaben zur Beteiligungsstruktur 
    (z.B. Eigenkapitalanteil). Diese Daten wurden von einer anderen Person im Rahmen 
    der Startup-Einreichung angegeben.
  </p>

  <h3>Woher stammen die Daten?</h3>
  <p>
    Die Daten stammen aus dem CORE-Einreichungsformular unter <code>/submit</code>, 
    das von einer anderen Person (z.B. einem Mitgründer) ausgefüllt wurde.
  </p>

  <h3>Zu welchem Zweck und auf welcher Rechtsgrundlage?</h3>
  <p>
    Zweck: Bewertung der Startup-Einreichung durch den zuständigen Fonds im Rahmen 
    seines Dealflow-Screenings.<br>
    Rechtsgrundlage: Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse des Fonds 
    an einer strukturierten Vorabprüfung von Einreichungen). Der einreichende Gründer 
    hat die Einreichung freiwillig vorgenommen und dabei Angaben zu Mitgründerinnen 
    und Mitgründern gemacht.
  </p>

  <h3>Wie lange werden die Daten gespeichert?</h3>
  <p>
    Für die Dauer der aktiven Fondsbeziehung (Pilotvertrag / SaaS-Nutzungsvertrag 
    zwischen Plattformbetreiber und Fonds). Nach Vertragsende: 30-tägige Exportfrist, 
    danach vollständige Löschung aus allen Systemen. Einzelheiten: siehe Abschnitt 8.
  </p>

  <h3>Ihre Rechte</h3>
  <p>
    Sie haben gegenüber dem zuständigen Fonds als Verantwortlichem dieselben Rechte 
    wie alle anderen betroffenen Personen: Auskunft (Art. 15), Berichtigung (Art. 16), 
    Löschung (Art. 17), Einschränkung (Art. 18), Widerspruch (Art. 21). 
    Wenden Sie sich mit Anfragen direkt an den zuständigen Fonds oder, falls Sie 
    dessen Kontaktdaten nicht kennen, an den Plattformbetreiber: 
    <a href="mailto:awees6703@gmail.com">awees6703@gmail.com</a>. 
    Wir leiten Ihre Anfrage innerhalb von 5 Werktagen an den Fonds weiter.
  </p>

  <h3>Beschwerderecht</h3>
  <p>
    Sie können jederzeit Beschwerde bei der Österreichischen Datenschutzbehörde 
    (dsb@dsb.gv.at, Barichgasse 40–42, 1030 Wien) einlegen.
  </p>
</section>
```

- [ ] **Schritt 3: Inhaltsverzeichnis der Datenschutzerklärung aktualisieren**

Abschnitt 17 im Inhaltsverzeichnis ergänzen:
```
17. Informationen für mitgenannte Personen (Art. 14 DSGVO)
```

- [ ] **Schritt 4: Abschnitt 1.2 anpassen — Fondsnennung generalisieren**

Den hardcoded Block für APEX Ventures GmbH umformulieren:

**Alt (skaliert nicht):**
```
Derzeit einziger Fonds im Pilotbetrieb:
APEX Ventures GmbH
Habsburgergasse 2/1a, 1010 Wien
E-Mail: tim.hos@apex.at
```

**Neu (skaliert auf beliebig viele Fonds):**
```
Der zuständige Fonds wird Ihnen beim Absenden des Einreichungsformulars namentlich 
angezeigt (Art. 13 Abs. 1 lit. a DSGVO). Die Identität des Fonds hängt davon ab, 
über welches Formular Sie einreichen. Auf schriftliche Anfrage teilen wir Ihnen 
jederzeit mit, welcher Fonds für Ihre Einreichung verantwortlich ist.

Aktuell im Pilotbetrieb: APEX Ventures GmbH, Habsburgergasse 2/1a, 1010 Wien 
(tim.hos@apex.at). Diese Liste wird bei Aufnahme weiterer Fonds nicht in dieser 
Erklärung aktualisiert — die Identität ergibt sich immer aus der Formularanzeige.
```

**Warum dieser Mittelweg:** Für den Pilotbetrieb ist Transparenz sinnvoll. Gleichzeitig wird klargestellt, dass die Quelle der Wahrheit das Formular ist, nicht dieses Dokument.

- [ ] **Schritt 5: Titel der Datenschutzerklärung anpassen**

```
Alt: "CORE Dealflow-Plattform — gemäß Art. 13 DSGVO und DSG 2018"
Neu: "CORE Dealflow-Plattform — gemäß Art. 13 und Art. 14 DSGVO und DSG 2018"
```

- [ ] **Schritt 6: Manuell prüfen**

1. `/datenschutz#art14` im Browser öffnen — springt der Anker korrekt?
2. Alle Rechte (15–21) im neuen Abschnitt vorhanden?
3. Kontakt-E-Mail klickbar?
4. Inhaltsverzeichnis zeigt Abschnitt 17?

- [ ] **Schritt 7: Commit**

```bash
git add [datenschutz-datei]
git commit -m "feat: add Art. 14 DSGVO section for co-founder data subjects"
```

---

## Task 3: Abschnitt 4 (Verarbeitungszwecke) — Verweis auf dynamische Formularanzeige

**Ziel:** Den Widerspruch in Abschnitt 4 bei `core_leads_v1` beheben (Befund 03 aus dem Audit) und den Verweis auf fondsspezifische Informationen korrekt formulieren.

**Files:**
- Modify: Datenschutzerklärung (gleiche Datei wie Task 2)

- [ ] **Schritt 1: Zeile "Interessentenanfragen (core_leads_v1)" in Abschnitt 4 korrigieren**

**Alt (widersprüchlich):**
```
Zweck: "Bearbeitung von Geschäftsanfragen potenzieller Fondskunden; 
Kontaktaufnahme durch den Plattformbetreiber"
Verantwortlicher: Fondsmanager als Gerätebetreiber
```

**Neu (konsistent):**
```
Zweck: "Bearbeitung von Geschäftsanfragen potenzieller Plattformkunden; 
die Daten verbleiben ausschließlich im Browser des Fondsmanagers und 
werden vom Fondsmanager als Gerätebetreiber eigenständig verwaltet."
Verantwortlicher: Fondsmanager als Gerätebetreiber
[Hinweis: Der Plattformbetreiber hat keinen Zugriff auf diese Daten 
und kann sie weder lesen noch für eigene Kontaktaufnahmen verwenden.]
```

- [ ] **Schritt 2: Commit**

```bash
git add [datenschutz-datei]
git commit -m "fix: remove contradictory 'Kontaktaufnahme durch Plattformbetreiber' for core_leads_v1"
```

---

## Task 4: Abschnitt 10 (Widerspruchsrecht) — Adressierungsfehler korrigieren

**Ziel:** Befund 10 aus dem Audit beheben: Widersprüche gegen core_leads_v1 können nicht an den Plattformbetreiber gehen, wenn er keinen Zugriff hat.

**Files:**
- Modify: Datenschutzerklärung

- [ ] **Schritt 1: Im Widerspruchsabschnitt korrigieren**

```
Alt: "Alle übrigen Widersprüche (IP-Adresse/Rate-Limiting, Server-Logs, 
Interessentenanfragen): an den Plattformbetreiber per E-Mail."

Neu: "Widerspruch gegen IP-Adresse/Rate-Limiting und Server-Logs: 
an den Plattformbetreiber (awees6703@gmail.com).

Widerspruch gegen Interessentenanfragen (core_leads_v1): 
Da diese Daten ausschließlich im Browser des Fondsmanagers gespeichert sind 
und der Plattformbetreiber keinen Zugriff darauf hat, richten Sie diesen 
Widerspruch bitte direkt an den zuständigen Fondsmanager."
```

- [ ] **Schritt 2: Commit**

```bash
git add [datenschutz-datei]  
git commit -m "fix: correct objection contact for core_leads_v1 (no server access)"
```

---

## Abschluss-Checkliste

- [ ] Supabase funds-Tabelle hat `address` und `privacy_contact_email`
- [ ] Submit-Formular zeigt Fondsdaten dynamisch an
- [ ] Art.-14-Hinweis auf dem Formular sichtbar (Mitgründer-Warnung)
- [ ] Datenschutzerklärung hat Abschnitt 17 (Art. 14) mit Anchor `#art14`
- [ ] Titel der Datenschutzerklärung nennt Art. 14
- [ ] Inhaltsverzeichnis hat Abschnitt 17
- [ ] Abschnitt 1.2: Fondsnennung skalierbar formuliert
- [ ] Abschnitt 4: core_leads_v1 Widerspruch in Zweck-Formulierung behoben
- [ ] Abschnitt 10: Widerspruchsadressierung für core_leads_v1 korrigiert
- [ ] Manuelle Tests: Formular zeigt korrekten Fonds, Anchor-Links funktionieren
- [ ] Anwaltliche Überprüfung des Art.-14-Abschnitts vor Go-Live (empfohlen)

---

## Was dieser Plan NICHT löst (separate Folge-Tasks)

Die folgenden Befunde aus dem Audit sind dokumentiert, werden hier aber bewusst nicht bearbeitet, weil sie anwaltliche Klärung erfordern:

- **Befund 02** (Joint Controller Art. 26): Muss anwaltlich bewertet werden bevor Code oder Dokumente geändert werden.
- **Befund 05** (Art. 22 / SCHUFA-Risiko): Erfordert Klarheit über UI-Verhalten (Sortierung, Filterung nach Score).
- **Befund 06** (DSFA-Begründung): Anwaltliche Überprüfung der DSFA-V-Schwelle.
- **Befunde 07-09** (lit. b für Derivate, DSFA, TKG): Werden in separatem Rechtsgutachten adressiert.

---

*Erstellt: 6. Juni 2026 | Audit-Grundlage: DSGVO-Audit CORE Datenschutzerklärung v5.6.2026*
