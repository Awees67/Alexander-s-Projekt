# Befund 05 — Art. 22 DSGVO: Der Signal-Score als unzulässige automatisierte Entscheidung

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** KRITISCH  
**Kategorie:** A — Fehlende Rechtsgrundlage für Kernfunktion  
**Betrifft:** Datenschutzerklärung v5.6.2026, js/custom-index.js, js/state.js (Zeile 191), js/renderers-pipeline.js (Zeile 132), api/submit.js, js/config.js (PIPELINE_TRANSITIONS)

---

## Was ist das Problem?

Der Signal-Score ist ein automatisch berechneter Wert zwischen 0 und 100, der jeder Startup-Einreichung zugewiesen wird. Er basiert auf einem Regelwerk mit 7 Gruppen (Revenue & Traction, Wachstum, Effizienz, Gründerteam, Markt, Plausibilität, Risiko), jeweils mit gewichteten Punkten, Caps und Schwellenwerten. Der Score wird serverseitig berechnet (api/submit.js), dauerhaft in Supabase gespeichert und zusätzlich clientseitig neu berechnet (state.js Zeile 191).

In der Pipeline-Ansicht (renderers-pipeline.js Zeile 132–133) wird der Score farblich markiert:
- **Grün** (≥ 70): potenziell interessant
- **Gelb** (40–69): abwartend
- **Rot** (< 40): nicht investitionswürdig

Aus diesem Score können Fonds-Mitarbeiter direkt die Pipeline-Status setzen: `In Review → Hot Deal`, `In Review → Watching`, `In Review → Declined` (config.js, PIPELINE_TRANSITIONS).

**Das Problem:** Dieser Ablauf kann unter **Art. 22 DSGVO** fallen — die Vorschrift für automatisierte Entscheidungen im Einzelfall, die natürliche Personen erheblich beeinflussen. Wenn Art. 22 greift und keine der drei engen Ausnahmen erfüllt ist, ist die Verarbeitung rechtswidrig.

---

## Warum ist das ein Problem?

### Art. 22 DSGVO — Die drei kumulativen Tatbestandsmerkmale

Art. 22 Abs. 1 DSGVO verbietet eine Entscheidung, die:

1. **ausschliesslich auf automatisierter Verarbeitung beruht**,
2. **rechtliche oder ähnlich erhebliche Wirkung** für die betroffene Person hat, und
3. eine **natürliche Person** betrifft.

Alle drei Merkmale müssen kumulativ vorliegen. Im Fall des Signal-Scores ist die Einschätzung für jedes Merkmal wie folgt:

---

#### Merkmal 1: „Ausschliesslich automatisiert" — Was das EuGH-Urteil C-634/21 dazu sagt

Der EuGH hat am 7. Dezember 2023 in der Rechtssache C-634/21 (SCHUFA Holding AG) entschieden, dass ein Score unter Art. 22 fällt, wenn er eine **„maßgebliche Rolle"** bei der Entscheidung spielt — auch wenn formal ein Mensch entscheidet.

**Wörtlich aus dem Urteil:** Eine automatisierte Entscheidung liegt vor, wenn der Score "eine maßgebliche Rolle spielt, auf deren Grundlage der Dritte die Entscheidung trifft" und er dabei dem Score ein "Übergewicht" zuordnet, das "von Menschen nicht überschrieben werden kann" oder de facto nicht überschrieben wird.

Das bedeutet: **Ein menschlicher Klick auf "Declined" schützt nicht**, wenn:
- Der Score das primäre Filterkriterium ist (Rot → Declined, Grün → Hot Deal)
- Die Farbcodierung (grün/gelb/rot) die Entscheidung praktisch vorwegnimmt
- Kein dokumentierter Überprüfungsprozess existiert, der substanzielle Abweichungen vom Score belegt
- Die menschliche Überprüfung als "Rubber-Stamping" (formales Absegnen ohne echte Prüfung) qualifiziert

**Für das CORE-Tool:** Die Kombination aus Zahlenscore + Farbcodierung + direktem Pipeline-Status ist genau das Muster, das der EuGH als "maßgebliche Rolle" definiert hat. Der Score ist sichtbar designt, um Entscheidungen zu leiten — das ist seine erklärte Funktion. Eine Behörde würde mit hoher Wahrscheinlichkeit "maßgebliche Rolle" bejahen.

Die EDSA-Leitlinien 05/2020 zu automatisierten Entscheidungen bestätigen: Rubber-Stamping ist keine substanzielle menschliche Überprüfung. Als Rubber-Stamping gilt: Der Prüfer hat keine echte Abweichungskompetenz, sieht keinen Kontext jenseits des Scores, und es gibt keinen Audit-Trail, der zeigt, dass Abweichungen jemals vorkommen.

**Einschätzung Merkmal 1:** Bejaht — das Risiko ist real und hoch.

---

#### Merkmal 2: „Rechtliche oder ähnlich erhebliche Wirkung"

Art. 22 schützt vor Entscheidungen, die erhebliche Auswirkungen auf eine Person haben. Beispiele aus den EDSA-Leitlinien: Kreditvergabe, Versicherungsprämien, Stellenbewerber-Screening.

**Für Gründer:** Eine VC-Investitionsentscheidung hat erhebliche wirtschaftliche Wirkung für natürliche Personen:
- Ein Gründer, dessen Einreichung auf Basis eines niedrigen Scores als "Declined" markiert wird, verliert die Chance auf Finanzierung — oft in einer existenziellen Phase des Unternehmens
- Der Score beeinflusst, ob ein Mensch (der Gründer) weitere Arbeit und Lebenszeit in das Startup investiert oder nicht
- Das Bundesverwaltungsgericht Wiesbaden (Vorlagefall für C-634/21) und der EuGH haben "ähnlich erhebliche Wirkung" weit ausgelegt

**Gegenargument:** Im B2B-Kontext ist das Startup eine juristische Person — und juristische Personen fallen nicht unter die DSGVO. Aber: Die Gründer sind **natürliche Personen**, deren Daten verarbeitet werden (Gründerprofile, has_repeat_founder, has_prior_exit, Eigenkapitalanteile). Der Score bewertet diese natürlichen Personen — nicht nur das Unternehmen. Das reicht für Art. 22.

**Einschätzung Merkmal 2:** Bejaht — die wirtschaftlichen Konsequenzen für Gründer sind erheblich.

---

#### Merkmal 3: „Natürliche Person"

Die Gründer sind natürliche Personen. Ihre Daten fliessen in den Score ein: Wiederholungsgründer-Status, Exit-Erfahrung, technisches Profil, Eigenkapitalanteil. Der Score ist nicht nur eine Bewertung des Unternehmens — er ist eine Bewertung des **Teams**, also natürlicher Personen.

**Einschätzung Merkmal 3:** Bejaht — ohne Zweifel.

---

### Referenzfall: Österreichische Datenschutzbehörde vs. KSV1870 (September 2025)

Die österreichische DSB hat KSV1870 im September 2025 untersagt, vollautomatisierte Bonitätsprüfungen ohne explizite Einwilligung durchzuführen. Die Parallele zum Signal-Score:

- KSV1870: Automatisierter Score → Entscheidung über Stromvertrag → ohne Wissen des Betroffenen
- CORE: Automatisierter Score → Entscheidung über VC-Finanzierung → ohne explizite Einwilligung der Gründer

Während der KSV-Fall B2C ist, wäre eine DSB-Prüfung von CORE vergleichbar strukturiert: natürliche Personen (Gründer), automatisierter Score, erhebliche wirtschaftliche Wirkung, keine Art.-22-Ausnahme.

---

### Aktueller Rechtszustand: Keine Ausnahme vorhanden

Art. 22 Abs. 2 erlaubt automatisierte Entscheidungen nur in drei engen Ausnahmen:

| Ausnahme | Inhalt | Anwendbar auf CORE? |
|---|---|---|
| **lit. a** | Notwendig für Vertragsschluss/-erfüllung mit der betroffenen Person | **Nein.** Der Vertrag besteht zwischen Fonds und Plattformbetreiber — nicht mit dem Gründer. Und "notwendig" ist der Score nicht: Investitionsentscheidungen können ohne automatisierten Score getroffen werden. |
| **lit. b** | Gesetzliche Grundlage in Unions- oder Mitgliedsrecht | **Nein.** Es gibt kein Gesetz, das VC-Scoring vorschreibt oder erlaubt. |
| **lit. c** | Explizite Einwilligung der betroffenen Person | **Nicht vorhanden.** Das aktuelle Submit-Formular enthält keine explizite, informierte Einwilligung zur automatisierten Score-Berechnung und ihrer Nutzung für Investitionsentscheidungen. |

**Ergebnis:** Keine der drei Ausnahmen ist aktuell erfüllt. Der Signal-Score ist damit in seiner aktuellen Form rechtswidrig nach Art. 22 Abs. 1 DSGVO.

---

## Die Lösung — nur wasserdichte Optionen

Es gibt zwei Wege, um Art. 22 zu erfüllen. Beide sind realisierbar — sie schliessen sich nicht aus und können kombiniert werden. Die Kombination beider Wege ist die einzig wirklich wasserdichte Lösung.

---

### Weg 1 — Explizite Einwilligung nach Art. 22 Abs. 2 lit. c (Pflichtmassnahme)

Die explizite Einwilligung ist die sauberste Ausnahme für ein VC-Screening-Tool. Sie erfordert, dass Gründer **vor** dem Absenden der Einreichung aktiv und informiert zustimmen.

**Was die Einwilligung erfüllen muss** (EDSA-Leitlinien 05/2020):

1. **Spezifisch** — nicht "Ich stimme der Datenverarbeitung zu", sondern: Ich stimme zu, dass ein automatisierter Score (0–100) aus meinen Angaben berechnet wird und dieser Score zur Vorbereitung von Investitionsentscheidungen des Fonds verwendet wird.

2. **Explizit** — aktives Opt-In (Checkbox, nicht vorgeklickt, nicht in AGB vergraben).

3. **Informiert** — der Gründer muss vor der Einwilligung verstehen: wie der Score berechnet wird (welche Kategorien, welche Logik), dass der Score dauerhaft gespeichert wird, dass er Recht auf Erklärung und Anfechtung hat.

4. **Freiwillig** — das ist der kritische Punkt. Wenn die Einwilligung Voraussetzung für die Einreichung ist und eine Einreichung ohne Einwilligung nicht möglich ist, ist sie nicht freiwillig im Sinne der DSGVO (Koppelungsverbot, Art. 7 Abs. 4). 

**Lösung für das Koppelungsproblem:** Die Einreichung muss auch **ohne Score-Einwilligung** möglich sein. Das bedeutet: Wenn ein Gründer die Einwilligung verweigert, wird kein Score berechnet und gespeichert. Der Fonds sieht die Einreichung ohne Score. Das ist der Befund 02 features-Flag in der Praxis — nicht nur als Kontrollinstrument für den Fonds, sondern als technische Grundlage für die Freiwilligkeit der Einwilligung.

**Konkrete Umsetzung im Submit-Formular:**

Direkt vor dem Absende-Button, als separate, nicht vorgeklickte Checkbox:

> ☐ **Ich stimme der automatisierten Score-Berechnung zu (optional)**
>
> Der Fonds nutzt ein automatisiertes Scoring-System, das aus meinen Angaben einen Signal-Score (0–100) berechnet. Dieser Score bewertet mein Startup in den Kategorien Revenue, Wachstum, Effizienz, Gründerteam und Markt anhand von Schwellenwerten und Regeln. Der Score wird dauerhaft gespeichert und dient dem Fonds als Entscheidungsunterstützung bei der Prüfung meiner Einreichung.
>
> Ich habe das Recht, den Score und seine Berechnung erklärt zu bekommen, Fehler zu beanstanden und einer erneuten menschlichen Prüfung meiner Einreichung zu verlangen. Diese Einwilligung ist freiwillig — meine Einreichung wird auch ohne Einwilligung entgegengenommen.
>
> [Mehr zur Score-Logik] [Datenschutzerklärung Abschnitt X]

**Speichern:** Der Einwilligungszeitpunkt, die angezeigte Textversion und das Ergebnis (erteilt / verweigert) müssen in Supabase mit der Submission gespeichert werden. Ohne diesen Datenbanknachweis ist die Einwilligung in einer Behördenprüfung nicht belegbar.

---

### Weg 2 — Systemdesign so gestalten, dass Art. 22 Abs. 1 nicht greift (technisch)

Art. 22 gilt nur, wenn die Entscheidung **ausschliesslich** automatisiert ist. Wenn eine substanzielle, dokumentierte menschliche Überprüfung zwischengeschaltet ist, greift Art. 22 Abs. 1 nicht. Das ist die zweite Massnahme — und sie ist auch dann notwendig, wenn Weg 1 (Einwilligung) gewählt wird, weil Art. 22 Abs. 3 für Ausnahmen nach lit. c ebenfalls "geeignete Massnahmen" verlangt.

**Was eine substanzielle menschliche Überprüfung bedeutet** (EDSA-Leitlinien 05/2020):

- Die überprüfende Person hat **echte Abweichungskompetenz** — sie kann und darf die Entscheidung unabhängig vom Score treffen
- Es existiert ein **Audit-Trail**, der zeigt, dass Abweichungen tatsächlich vorkommen
- Die überprüfende Person hat **Zugang zu den Rohdaten und der Score-Logik**, nicht nur zum Score
- Es gibt einen **dokumentierten Prozess** (wer prüft, wann, nach welchen Kriterien)

**Konkrete technische Umsetzung:**

**Massnahme 2a — Score nie als Primärfilter zeigen (UI-Änderung)**

Der Score darf nicht das erste sein, was ein Fonds-Mitarbeiter sieht. Die aktuelle Farbcodierung (rot/grün/gelb direkt in der Pipeline-Liste) macht den Score de facto zum Primärfilter. Stattdessen:
- Score in der Listenansicht optional / einklappbar machen
- Vollständige Submission immer zuerst zugänglich
- Score als "Hinweis" labeln, nicht als "Bewertung"

**Massnahme 2b — Pipeline-Status-Änderung mit obligatorischer Begründung**

Der Übergang von `In Review` zu `Declined` muss eine obligatorische Freitextbegründung erfordern — nicht nur ein Dropdown. Diese Begründung wird in Supabase gespeichert und bildet den Audit-Trail, der beweist, dass die Entscheidung vom Menschen getroffen wurde (ggf. abweichend vom Score).

**Massnahme 2c — Score-Overwrite-Funktion**

Fonds-Mitarbeiter müssen die Möglichkeit haben, einen manuellen Score-Wert zu erfassen (z.B. "manuell überschrieben auf 65, weil Gespräch mit Gründern positive Informationen gezeigt hat, die im Formular nicht abgebildet sind"). Dieser manuelle Override muss in der DB gespeichert und im UI sichtbar sein. Das beweist: das System ist kein automatischer Entscheider.

**Massnahme 2d — Audit-Log für Score-Zugänge**

Jedes Mal, wenn der Score einer Submission angezeigt wird (und die Submission danach einen Status-Wechsel erhält), wird das geloggt: wer hat den Score gesehen, wann, welcher Status wurde danach gesetzt, gab es ein Override. Dieses Log ist die technische Antwort auf eine Behördenanfrage "Können Sie beweisen, dass Menschen die Entscheidungen getroffen haben?"

---

### Weg 3 — Datenschutzerklärung: Art. 22 und Betroffenenrechte dokumentieren

Unabhängig davon, welcher Weg gewählt wird: Die Datenschutzerklärung muss Art. 22 explizit adressieren.

**Neuer Abschnitt in der Datenschutzerklärung:**

> **Automatisiertes Scoring und Ihre Rechte (Art. 22 DSGVO)**
>
> Ihre Einreichung wird von einem automatisierten Scoring-System bewertet (Signal-Score, 0–100). Das System berechnet einen Score aus Ihren Angaben zu Revenue, Wachstum, Effizienz, Gründerteam und Markt anhand eines gewichteten Regelwerks.
>
> **Rechtsgrundlage:** Ihre explizite Einwilligung nach Art. 22 Abs. 2 lit. c DSGVO, die Sie beim Absenden der Einreichung erteilen können.
>
> **Ihre Rechte nach Art. 22 Abs. 3 DSGVO:**
> - **Recht auf Erklärung:** Sie können jederzeit verlangen, dass wir Ihnen die Score-Logik erklären — welche Regelgruppen wie gewichtet wurden und warum Ihr Score diesen Wert hat.
> - **Recht auf Darlegung des eigenen Standpunkts:** Sie können uns Informationen mitteilen, die der Score nicht berücksichtigt hat, und eine erneute Prüfung verlangen.
> - **Recht auf menschliche Überprüfung:** Jede Einreichung wird von einem Investmentverantwortlichen des Fonds menschlich überprüft. Der Score ist ein Hilfsmittel, keine automatische Entscheidung.
> - **Widerruf der Einwilligung:** Sie können Ihre Einwilligung jederzeit widerrufen. Der bisher berechnete Score wird dann aus Ihrer Einreichung gelöscht.
>
> Für diese Rechte wenden Sie sich an: awees6703@gmail.com. Weiterleitung an den Fonds innerhalb von 5 Werktagen.

---

## Was "wasserdicht" konkret bedeutet — und was nicht ausreicht

| Massnahme | Schützt vor | Reicht allein? |
|---|---|---|
| Nur Einwilligung im Formular (Text) | Behördenanfrage zum Rechtsstatus | Nein — ohne Speichernachweis in DB und ohne Opt-out-Möglichkeit nicht freiwillig |
| Einwilligung + DB-Speicherung des Konsents | Behördenanfrage + Beweis | Nein — ohne technischen Opt-out (Einreichung ohne Score) ist Freiwilligkeit anfechtbar |
| Einwilligung + DB + Opt-out technisch | Koppelungsverbot | Nein — ohne Audit-Trail für menschliche Überprüfung bleibt Rubber-Stamping-Risiko |
| Alle Massnahmen kombiniert | Vollständige Art.-22-Konformität | **Ja** |

---

## Zusammenfassung: Was sich ändert

| Was | Wo | Aufwand |
|---|---|---|
| Opt-in Checkbox für Score-Einwilligung | Submit-Formular `/submit` | 30 Minuten |
| Einwilligungsdaten in Supabase speichern | `submissions`-Tabelle, neue Spalten `score_consent`, `score_consent_at`, `score_consent_text_version` | 20 Minuten |
| Einreichung ohne Score technisch ermöglichen | api/submit.js, state.js | 30 Minuten (Befund-02-Flag nutzen) |
| Score-Overwrite-Feld in Pipeline | Supabase `pipeline_items`-Tabelle + UI | 45 Minuten |
| Begründungspflicht bei `Declined` | config.js + UI (bereits teilweise vorhanden) | 20 Minuten |
| Audit-Log für Score-Zugänge | Supabase `activity_log` Tabelle | 30 Minuten |
| Neuer Abschnitt in Datenschutzerklärung | Datenschutzerklärung | 20 Minuten |
| Anwaltliche Prüfung Einwilligungstext | Anwalt | Einmalig, vor Produktivbetrieb |

---

## Was anwaltlich zu klären bleibt

Zwei Punkte erfordern anwaltliche Prüfung:

1. **Einwilligungstext:** Der exakte Wortlaut der Opt-in Checkbox muss anwaltlich geprüft werden — die DSGVO-Anforderungen an "informiert" und "spezifisch" sind für die österreichische DSB-Praxis streng.

2. **Koppelungsverbot:** Auch wenn technisch eine Einreichung ohne Score möglich ist — reicht das aus, um die Freiwilligkeit zu bejahen, wenn in der Praxis ein Fonds Einreichungen ohne Score kaum berücksichtigt? Das ist eine Grauzone, die nur ein Anwalt mit DSB-Kenntnis einschätzen kann.

---

*Quellen: EuGH C-634/21 (7. Dezember 2023); EDSA-Leitlinien 05/2020 zu automatisierten Entscheidungen; DSB-Entscheidung gegen KSV1870 (September 2025); Art. 22 DSGVO; Art. 7 Abs. 4 DSGVO (Koppelungsverbot).*

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
