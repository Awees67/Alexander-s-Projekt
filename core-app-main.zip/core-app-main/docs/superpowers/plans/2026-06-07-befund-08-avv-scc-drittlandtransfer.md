# Befund 08 — Art. 28 + Art. 44 ff. DSGVO: AVV fehlt, Drittlandtransfer ungesichert

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** HOCH  
**Kategorie:** C — Fehlende Pflichtverträge / ungesicherter Drittlandtransfer  
**Betrifft:** Supabase Inc. (Auftragsverarbeiter), Vercel Inc. (Auftragsverarbeiter), zukünftige E-Mail-Anbieter  
**Referenz:** Art. 28, 44–49, 83 Abs. 4 DSGVO; EU-SCC Beschluss 2021/914 + 2021/915; EDPB-Empfehlungen 01/2020; DSB Österreich (Januar/Mai 2022); EU-US Data Privacy Framework (Juli 2023); CJEU-Verfahren C-555/25 (Latombe-Berufung, anhängig)

---

## Überblick: Vier separate Probleme

| # | Problem | Norm | Schwere |
|---|---|---|---|
| 1 | Kein AVV mit Supabase | Art. 28 DSGVO | Kritisch — Verarbeitung läuft ohne Vertrag |
| 2 | Vercel-Functions laufen in den USA (kein vercel.json) | Art. 44 ff. DSGVO | Hoch — aktiver Drittlandtransfer ohne vollständige Absicherung |
| 3 | Auch mit fra1: Vercel-CDN/DDoS läuft durch US-Infrastruktur | Art. 44 ff. DSGVO | Mittel — strukturell nicht vollständig eliminierbar |
| 4 | Kein Plan für zukünftigen E-Mail-Anbieter | Art. 28 + Art. 44 ff. | Mittel — vorsorglich zu regeln |

---

## Problem 1 — Kein AVV mit Supabase (Art. 28 DSGVO)

### Was fehlt

Supabase Inc. verarbeitet als Auftragsverarbeiter personenbezogene Daten der Gründer: vollständige Einreichungsdaten, Finanzkennzahlen, Gründerprofile, Signal-Score, Pipeline-Status, Notes. Ohne Auftragsverarbeitungsvertrag (AVV) nach Art. 28 DSGVO ist diese Verarbeitung rechtswidrig — unabhängig vom Datenspeicherort, unabhängig von allen anderen Schutzmaßnahmen.

Ein AVV ist keine Formalität. Er ist die vertragliche Grundlage, auf der ein Verantwortlicher einem Auftragsverarbeiter erlaubt, mit seinen Personendaten zu arbeiten.

**Kritisch:** De facto-AVV durch AGB oder Datenschutzerklärung sind nach DSGVO nicht wirksam. Art. 28 Abs. 9 DSGVO verlangt ausdrücklich Schriftform (oder elektronisches Äquivalent) mit den acht spezifischen Pflichtklauseln. Der LfDI Baden-Württemberg stellt klar: "Eine Datenschutzerklärung und Allgemeine Geschäftsbedingungen ersetzen keinen AVV."

### Was Art. 28 DSGVO zwingend vorschreibt

Art. 28 Abs. 3 lit. a–h listet acht Pflichtklauseln, die jeder AVV enthalten muss:

| Klausel | Inhalt |
|---|---|
| **(a) Weisungsbindung** | Verarbeitung nur auf dokumentierte Weisung des Verantwortlichen — inkl. Drittlandübermittlungen |
| **(b) Vertraulichkeit** | Alle autorisierten Personen zur Vertraulichkeit verpflichtet |
| **(c) TOMs (Art. 32)** | Technische und organisatorische Schutzmaßnahmen als Vertragsanlage |
| **(d) Unterauftragsverarbeiter** | Nur mit schriftlicher Vorabgenehmigung; aktualisierte Liste vorhalten |
| **(e) Betroffenenrechte** | Unterstützung bei Auskunft, Berichtigung, Löschung nach Art. 15–22 |
| **(f) Art. 32–36-Pflichten** | Unterstützung bei Sicherheit, DSFA, Behördenkonsultation |
| **(g) Löschung/Rückgabe** | Nach Vertragsende: Daten löschen oder zurückgeben |
| **(h) Auditrechte** | Informationen bereitstellen; Überprüfungen und Inspektionen dulden |

Fehlt eine dieser Klauseln: AVV ist formell mangelhaft → eigenständiger Verstoß.

**Wichtige Praxisregel:** Die EU-Standard-Vertragsklauseln 2021 (SCC), Modul 2 (Controller → Processor), ersetzen den separaten AVV vollständig. Der EU-Durchführungsbeschluss 2021/915 stellt in Art. 1 ausdrücklich fest: Die SCC-Modul-2-Klauseln "erfüllen die Anforderungen an Verträge zwischen Verantwortlichen und Auftragsverarbeitern gemäß Artikel 28 Absatz 3 und 4." Der Supabase-DPA ist genau so aufgebaut — ein SCC-Modul-2-Dokument, das gleichzeitig Art. 28 und Art. 46 abdeckt.

### Die Supabase-DPA: Was vorhanden ist, was fehlt

Supabase stellt einen fertigen AVV (Data Processing Addendum, DPA) bereit:

- **Offizielle Seite:** [supabase.com/legal/dpa](https://supabase.com/legal/dpa)
- **PDF (Stand März 2025):** [Supabase DPA 250314.pdf](https://supabase.com/downloads/docs/Supabase+DPA+250314.pdf)
- **Inhalt:** SCC Modul 2 (Controller → Processor, EU-Kommission 2021); UK-Addendum; alle acht Art.-28-Pflichtklauseln; TOM-Anhang; Sub-Prozessor-Liste (Schedule 3); TIA
- **Unterzeichnung:** Self-Service im Supabase Dashboard → Organisation → **Legal Documents** (PandaDoc-Flow); abschließend als PDF herunterladen und archivieren

**Was aktuell fehlt:** Der DPA ist noch nicht abgeschlossen. Die gesamte Supabase-Verarbeitung läuft seit Beginn ohne rechtliche Grundlage nach Art. 28.

### Supabase Sub-Prozessoren (Schedule 3 der DPA, März 2025)

Die Sub-Prozessor-Liste enthält folgende US-Unternehmen, die personenbezogene Daten berühren können:

| Sub-Prozessor | Sitz | Funktion |
|---|---|---|
| Amazon Web Services, Inc. | Seattle, USA | Infrastruktur/Hosting (eu-central-1 für EU-Projekte) |
| Google LLC | Mountain View, USA | Infrastruktur / interne Tools |
| Fly.io, Inc. | Chicago, USA | Infrastruktur / Hosting |
| Supabase Pte. Ltd | Singapur | Konzerngesellschaft |
| Cloudflare, Inc. | San Francisco, USA | CDN / DDoS / Application Hosting |
| Twilio, Inc. | San Francisco, USA | Kommunikation (Auth SMS/E-Mail) |
| Stripe, Inc. | San Francisco, USA | Zahlungsabwicklung |
| HubSpot, Inc. | Cambridge, USA | CRM / Marketing |
| Vercel, Inc. | San Francisco, USA | Frontend-Hosting |
| PandaDoc, Inc. | San Francisco, USA | Dokumentenverwaltung |

**Cloudflare ist ein offizieller Sub-Prozessor**, nicht nur ein Infrastrukturpartner. Das bedeutet: Anfragen an Supabase durchlaufen Cloudflare-Server in den USA — ein weiterer US-Transferpunkt, auch wenn die Datenbankdaten in Frankfurt bleiben.

**Änderungen bei Sub-Prozessoren:** Supabase informiert Kunden bei Änderungen der Sub-Prozessor-Liste. Branchenübliche Frist: 30 Tage. Nach Eingang der Benachrichtigung hat der Verantwortliche das Recht zu widersprechen — im Widerspruchsfall entsteht ein außerordentliches Kündigungsrecht. Ohne aktiven Widerspruch gilt die Änderung als genehmigt. Das Art.-30-Verarbeitungsverzeichnis muss entsprechend aktualisiert werden.

### Bußgelddimension

Art. 83 Abs. 4 lit. a DSGVO erfasst Art.-28-Verstöße:

- **Bußgeldrahmen:** bis zu **10 Millionen Euro oder 2 % des weltweiten Jahresumsatzes** (höherer Betrag)
- **Kein täglicher Multiplikator:** DSGVO hat keine "pro-Tag"-Struktur; Dauer ist aber ein erschwerender Faktor in der EDPB-Berechnungsmethodik (Guidelines 04/2022)
- **Eskalationsrisiko:** Wenn die Aufsichtsbehörde einen Korrekturbefehl erlässt (Art. 58 Abs. 2 lit. d) und der Verantwortliche diesen ignoriert, droht ein zusätzlicher Verstoß nach Art. 83 Abs. 5 lit. e — mit dem höheren 20-Millionen-Rahmen

**Referenzfall:** Vodafone GmbH, BfDI, März 2025 — EUR 15 Millionen allein für unzureichende Überwachung der Auftragsverarbeiter nach Art. 28 Abs. 1 (inadäquate Selektion und kontinuierliche Kontrolle von Partnern). Das ist der höchste bisher bekannte Art.-28-spezifische Bußgeldbetrag in Deutschland.

---

## Problem 2 — Vercel: Serverless Functions laufen in den USA

### Was das Problem ist

`api/submit.js` und `api/fund.js` sind Vercel Serverless Functions. Ohne `vercel.json` mit Regionskonfiguration läuft jede Serverless Function in der Standardregion: **iad1 — Washington D.C., USA.**

Jede Einreichung über `/submit` wird in den USA verarbeitet: Name, E-Mail, Finanzdaten, Gründerprofile durchlaufen US-Server — bevor sie nach Supabase Frankfurt gespeichert werden. Das ist ein aktiver Drittlandtransfer nach Art. 44 DSGVO.

### Vercel-Compliance-Status: DPF + SCC, aber mit Einschränkungen

**Positiv:** Vercel ist **EU-US Data Privacy Framework (DPF)-zertifiziert** (seit 2023). Das bietet eine rechtliche Grundlage für EU→US-Transfers ohne separate TIA-Pflicht — solange das DPF gültig ist. Vercel stellt außerdem eine fertige DPA bereit:

- **URL:** [vercel.com/legal/dpa](https://vercel.com/legal/dpa)
- **Inhalt:** SCC Modul 2 (EU 2021), UK-Addendum, DPF-Basis, alle Art.-28-Klauseln
- **Unterzeichnung:** Download und interne Archivierung ausreichend; bei Enterprise-Verträgen individuell verhandelbar

**Vercel Infrastruktur bei fra1:** AWS ist Vercel's primäre Cloud-Infrastruktur. Auch bei fra1-Konfiguration laufen Function-Compute auf AWS eu-central-1 (Frankfurt) — was korrekt ist. Sub-Prozessoren umfassen jedoch auch Microsoft Azure, GCP und US-basierte AI-Dienste.

### Das DPF-Stabilitätsrisiko — verschärft durch aktuelle Entwicklungen

Das EU-US Data Privacy Framework ist politisch erheblich unter Druck:

| Ereignis | Datum | Relevanz |
|---|---|---|
| DPF-Angemessenheitsbeschluss EU-Kommission | 10. Juli 2023 | DPF in Kraft |
| General Court T-553/23: DPF bestätigt | 3. September 2025 | Erste Anfechtung abgewiesen |
| Latombe reicht Berufung beim CJEU ein | 31. Oktober 2025 | CJEU-Verfahren C-555/25 anhängig |
| Trump entlässt 3 von 5 PCLOB-Mitgliedern | 27. Januar 2025 | PCLOB faktisch handlungsunfähig |
| US District Court: Entlassungen rechtswidrig | 21. Mai 2025 | Wiedereinsetung angeordnet |
| DC Circuit Court: Wiedereinsetung ausgesetzt | 1. Juli 2025 | PCLOB weiter gelähmt |
| Supreme Court-Verfahren Trump v. Slaughter | Anhängig | Entscheidend für PCLOB-Zukunft |

**Das PCLOB (Privacy and Civil Liberties Oversight Board)** war das zentrale unabhängige Aufsichtsgremium, das die EU-Kommission als Säule des DPF-Angemessenheitsbeschlusses bezeichnet hat. Es ist derzeit handlungsunfähig. Die EU-Kommission hat formale Bedenken geäußert, den Beschluss aber noch nicht ausgesetzt.

**Max Schrems / noyb** hat angekündigt, eine breitere CJEU-Klage vorzubereiten — auf Basis der Trump-Exekutivorder und der PCLOB-Situation. Ein "Schrems III"-Szenario ist juristisch realistisch.

**Wenn DPF invalidiert wird:** Vercel's DPA enthält SCCs als Fallback. SCCs erfordern dann allerdings eine TIA — und unter österreichischer DSB-Doktrin (Google Analytics 2022) sind SCCs allein für US-Transfers problematisch, wenn US-Geheimdienstgesetze den Empfänger erfassen.

---

## Problem 3 — Fra1 löst den Drittlandtransfer nicht vollständig

### Was fra1 macht — und was nicht

**fra1 aktivieren** ist die richtige und wichtige Maßnahme. Aber sie eliminiert den Drittlandtransfer nicht vollständig:

**Was fra1 bewirkt:**
- Serverless Function-Compute läuft in Frankfurt (AWS eu-central-1)
- Daten, die Funktionen verarbeiten, bleiben während der Verarbeitung in der EU
- Latenz für EU-Nutzer verbessert sich
- Wesentlicher Compliance-Schritt

**Was fra1 nicht bewirkt:**

> *"Some data will always pass through Vercel's data centres in the USA, as the DDoS prevention system works properly by transmitting IP addresses (among other information)."* — Vercel

Konkret bleiben folgende US-Datenpunkte bestehen:

1. **CDN-Schicht:** Alle Anfragen terminieren zunächst am nächsten Point of Presence (PoP) im globalen Vercel-Netzwerk — inkl. US-PoPs. TLS-Terminierung, DDoS-Abwehr und Routing laufen global, nicht nur fra1.
2. **DDoS-Schutz:** IP-Adressen (personenbezogene Daten) und Request-Metadaten durchlaufen die US-Infrastruktur des DDoS-Systems.
3. **Control Plane:** Deployment-Infrastruktur, Logging und Management-Systeme sind US-basiert (Vercel Inc., San Francisco).
4. **Sub-Prozessor-Kette:** AWS, Azure, GCP operieren als US-Unternehmen unter US-Recht — CLOUD Act und FISA 702 gelten unabhängig vom physischen Rechenzentrumsstandort.

**Fazit:** fra1 ist notwendig und minimiert den Transfer erheblich — aber auch mit fra1 bleibt ein struktureller US-Bezug. Der Transfer ist durch DPF + SCC abgedeckt, aber nicht eliminiert.

### Konfiguration fra1

**Via `vercel.json`** (empfohlen — Code-as-Config):

```json
{
  "regions": ["fra1"]
}
```

**Via Vercel Dashboard:** Project Settings → Functions → Region → Frankfurt, Germany (fra1) → Save

**Verfügbarkeit:** fra1 ist auf **allen Plänen** verfügbar (Hobby, Pro, Enterprise) — keine Planupgrade nötig.

---

## US-Geheimdienstrecht: Realistische Einschätzung für CORE

### CLOUD Act (2018)

Der CLOUD Act verpflichtet US-Unternehmen, Daten auf richterliche Anordnung herauszugeben — unabhängig vom physischen Speicherort. Voraussetzungen: Durchsuchungsbefehl, Richterliche Genehmigung, konkreter Verdacht auf eine spezifische Straftat.

**Realistische Wahrscheinlichkeit für VC-Dealflow-Daten:** < 0,01 % pro Jahr — ausschließlich relevant wenn eine bestimmte Person oder ein Unternehmen in der Gründerliste unter Strafverfolgung (Betrug, Sanktionsverstöße, Geldwäsche) steht. DACH-VC-Dealflow hat kein relevantes Profil als US-Strafverfolgungsziel.

### FISA Section 702

FISA 702 ermächtigt die NSA zur Geheimdienstüberwachung von Nicht-US-Personen im Ausland ohne Richtervorbehalt. Nach der RISAA-Erweiterung (2024) könnte Supabase technisch als "Electronic Communications Service Provider" gelten.

Supabase's eigenes TIA (März 2025): *"Supabase hat bis dato keinen einzigen FISA-Antrag erhalten."* Upstream-FISA-702-Befehle richten sich gegen Internet-Backbone-Anbieter — nicht gegen SaaS-Datenbankdienste.

**Realistische Wahrscheinlichkeit für CORE:** Nahe null. VC-Pitch-Decks und Finanzkennzahlen von DACH-Startups sind kein nachrichtendienstliches Sammlungsziel.

### Technische Schutzmaßnahme (EDPB Tier 1)

Der EDPB (Empfehlungen 01/2020) identifiziert **clientseitige Verschlüsselung mit EU-seitig kontrollierten Schlüsseln** als primäre technische Supplementärmaßnahme für US-Transfers. Konkret: Wenn CORE die sensibelsten Felder (Gründer-PII, Finanzdaten) vor dem `INSERT` in Supabase verschlüsselt und die Schlüssel in einem EU-kontrollierten Key Management System (z.B. AWS KMS eu-central-1 in einem separaten EU-Account) verwaltet, ist Supabase's Datenbank auch bei einem CLOUD-Act-Warrant nur Chiffretext.

**Für CORE heute:** Das Risiko ist gering genug, dass diese Maßnahme nicht sofort erforderlich ist — sie ist aber die robusteste Lösung für eine zukünftige Skalierung der Plattform. Supabase Vault (Transparent Column Encryption) schützt hingegen nicht vor Behördenzugriffen, weil Supabase die Schlüssel hält.

---

## Problem 4 — Zukünftiger E-Mail-Anbieter

### Warum jetzt relevant

Das Outreach-Modul sendet bereits E-Mails an Gründer (Befund 03 bestätigt: Modul aktiv in Betrieb). Wenn ein dedizierter transaktionaler E-Mail-Anbieter integriert wird, entstehen sofort AVV- und Drittlandtransfer-Pflichten für alle verarbeiteten E-Mail-Adressen und Metadaten.

### Anbietervergleich mit korrekter EU-Transfer-Einschätzung

**Wichtige Vorbemerkung:** Kein der unten aufgeführten Anbieter bietet einen vollständig US-freien Datenpfad. Alle nutzen entweder US-Muttergesellschaften oder US-Sub-Prozessoren. Die Unterschiede liegen im Grad der Exposition und in der Verfügbarkeit von Transfermechanismen.

| Anbieter | Primärer Datenspeicher | US-Exposition | Transfermechanismus | AVV |
|---|---|---|---|---|
| **Brevo** (Sendinblue SAS, Paris) | OVH Frankreich/Deutschland + GCP Belgien | Twilio (US), Google LLC (US-Muttergesell.) | SCC + DPF | Automatisch in AGB; countersigniertes AVV auf Anfrage |
| **MailerSend** (MailerLite UAB, Litauen) | GCP Belgien | Bandwidth (US), Stripe (US), Google LLC | SCC + DPF | Automatisch in ToU (Stand Feb. 2026) |
| **SendGrid** (Twilio Inc., USA) | US-primär; EU-Residency als kostenpfl. Add-on (Pro/Premier) | US-Konzern | SCC + DPF | Automatisch in ToS |
| **Resend** | US-Metadaten; EU nur Versandregion | Gesamt-US-Speicher | SCC + DPF | Self-Service DPA |
| **Postmark** (ActiveCampaign) | USA — keine EU-Server geplant | Gesamt-US-Speicher | SCC (kein DPF bestätigt) | Vorhanden |

**Empfehlung:** Brevo oder MailerSend — beide EU-ansässig als Unternehmen, Primärspeicher in EU-Rechenzentren, DPF-zertifiziert, AVV unkompliziert. Der Transfer über US-Sub-Prozessoren (Google LLC-Mutter bei GCP Belgien, Twilio/Bandwidth) ist durch SCC + DPF abgedeckt.

**Praktischer Unterschied:** Brevo bietet auf dem Free-Plan **300 E-Mails/Tag (9.000/Monat)** — ausreichend für CORE's aktuelles Volumen. MailerSend hat den Free-Plan im Dezember 2025 auf 500 E-Mails/Monat mit 100/Tag-Limit reduziert — für Produktionsbetrieb nicht geeignet.

---

## Wie AVV und SCC zusammenhängen — Praxiserklärung

| | AVV / DPA (Art. 28) | SCC (Art. 46) |
|---|---|---|
| **Rechtsgrundlage** | Art. 28 DSGVO | Art. 46 DSGVO |
| **Zweck** | Regelt die Beziehung Verantwortlicher → Auftragsverarbeiter | Legitimiert Datentransfer in Drittländer ohne Angemessenheitsbeschluss |
| **Geographie** | Immer erforderlich — auch bei EU-internem Outsourcing | Nur bei Transfer in Nicht-EU/EWR-Länder ohne Angemessenheitsbeschluss |
| **Kombination** | Bei US-Anbietern: beides nötig — AUSSER die SCC 2021 Modul 2 deckt beides ab (was bei Supabase + Vercel der Fall ist) | |

**Praxisregel:** Supabase- und Vercel-DPA sind beide nach SCC-Modul-2-Muster strukturiert → ein Dokument, das Art. 28 UND Art. 46 erfüllt. Kein separates AVV nötig — nur unterschreiben und archivieren.

---

## Die Lösung

### Massnahme 1 — Supabase DPA sofort abschließen (dringend, ~30 Minuten)

1. Supabase Dashboard → Organisation → **Legal Documents**
2. DPA via PandaDoc-Flow unterzeichnen
3. Signierten DPA als PDF herunterladen und in internem Compliance-Ordner archivieren
4. Transfer Impact Assessment (TIA) ebenfalls herunterladen: [Supabase TIA 250314.pdf](https://supabase.com/downloads/docs/Supabase+TIA+250314.pdf)
5. Im Art.-30-Verarbeitungsverzeichnis unter "Supabase" mit Datum eintragen

Der Supabase-DPA ist vollständig, juristisch solide und entspricht DSGVO-Standard. Eine anwaltliche Prüfung ist optional.

---

### Massnahme 2 — Vercel: fra1-Region konfigurieren (~10 Minuten)

**`vercel.json`** im Projektstamm erstellen oder ergänzen:

```json
{
  "regions": ["fra1"]
}
```

Anschließend deployen (`vercel deploy`). Ab sofort laufen Function-Compute in Frankfurt.

Vercel-DPA herunterladen und archivieren: [vercel.com/legal/dpa](https://vercel.com/legal/dpa). Im Art.-30-Verarbeitungsverzeichnis unter "Vercel" mit Datum eintragen.

**DPF-Monitoring:** Quartalsweise prüfen ob Vercel noch auf der DPF-Teilnehmerliste steht: [dataprivacyframework.gov](https://www.dataprivacyframework.gov/list). Wenn DPF invalidiert wird: Vercel-DPA enthält SCC als Fallback — kein Handlungsbedarf, aber TIA sollte dann erstellt werden.

---

### Massnahme 3 — Art.-30-Verarbeitungsverzeichnis: beide Anbieter vollständig eintragen

| Feld | Supabase | Vercel |
|---|---|---|
| Name | Supabase Inc. | Vercel Inc. |
| Sitz | San Francisco, USA | San Francisco, USA |
| Verarbeitungszweck | Datenbankhosting (Submissions, Pipeline, Notes, Score) | Serverless Function Execution (api/submit.js, api/fund.js) |
| Datenkategorien | Finanzdaten, Gründerprofile, Kontaktdaten, Score | Finanzdaten, Gründerprofile (während Funktionsausführung) |
| Transfermechanismus | SCC Modul 2 + TIA | DPF + SCC Modul 2 |
| AVV-Datum | [Datum eintragen] | [Datum eintragen] |
| Region | eu-central-1 (Frankfurt) | fra1 (Frankfurt) nach Konfiguration |
| Sub-Prozessoren | AWS, Google, Cloudflare, Twilio u.a. (laut Schedule 3) | AWS, Azure, GCP u.a. (laut sub-processors list) |

---

### Massnahme 4 — Sub-Prozessor-Monitoring einrichten

Supabase informiert bei Änderungen der Sub-Prozessor-Liste. Empfehlung:
- E-Mail-Benachrichtigungen von Supabase zu Änderungen aktivieren
- Bei jeder Änderung: Art.-30-Verarbeitungsverzeichnis aktualisieren
- Widerspruchsrecht binnen der Frist prüfen; bei kritischen neuen Sub-Prozessoren aktiv entscheiden

---

### Massnahme 5 — E-Mail-Anbieter beim Onboarding sofort korrekt einrichten

Beim Onboarding eines E-Mail-Anbieters (Empfehlung: Brevo):

1. AVV / DPA sofort beim Kontoanlegen akzeptieren und archivieren
2. EU-Versandregion explizit konfigurieren
3. Anbieter ins Art.-30-Verarbeitungsverzeichnis eintragen
4. DPF-Zertifizierung des Anbieters verifizieren: [dataprivacyframework.gov](https://www.dataprivacyframework.gov/list)

---

## Was nicht vollständig wasserdicht ist

**Risiko 1 — Vercel CDN/DDoS:** Auch mit fra1 durchlaufen IP-Adressen und Request-Metadaten US-Infrastruktur (DDoS-System, globales PoP-Netz). Das ist architektonisch bei Vercel nicht vollständig eliminierbar. Unter österreichischer DSB-Doktrin (stricte Linie: SCCs allein nicht ausreichend bei US-Geheimdienstrecht) besteht ein theoretisches Restrisiko. Für CORE's Daten (keine sensiblen Kategorien nach Art. 9) ist das in der Praxis tolerierbar — muss aber im Art.-30-Verarbeitungsverzeichnis dokumentiert sein.

**Risiko 2 — DPF-Invalidierung (Schrems III):** Wenn der CJEU das DPF invalidiert, entfällt der Vercel-Compliance-Vorteil. Fallback (SCC) ist im Vercel-DPA enthalten, erfordert aber dann eine TIA. Mitigation: fra1-Konfiguration reduziert das Exposure bereits jetzt.

**Risiko 3 — Supabase nicht DPF-zertifiziert:** Supabase erscheint nicht auf der DPF-Teilnehmerliste. Der Transfer basiert ausschließlich auf SCC + TIA. Unter österreichischer DSB-Doktrin ist das die schwächere Position. Realistische Sanktionswahrscheinlichkeit für VC-Dealflow-Daten ist niedrig — aber das Risiko ist nicht null. Mitigation: TIA herunterladen und archivieren, Supabase EU-Region aktiv lassen.

**Risiko 4 — Cloudflare als Supabase-Sub-Prozessor:** Cloudflare ist ein US-Unternehmen und offizieller Supabase-Sub-Prozessor. Cloudflare-Infrastruktur berührt Anfragen auch bei EU-Region-Konfiguration. Durch Supabase-DPA (SCC) abgedeckt, aber strukturell nicht eliminierbar.

---

## Zusammenfassung: Was sich ändert

| Was | Wo | Aufwand | Priorität |
|---|---|---|---|
| Supabase DPA unterzeichnen | Supabase Dashboard → Legal Documents | 30 Minuten | **Sofort** |
| Supabase TIA herunterladen + archivieren | supabase.com/downloads/... | 5 Minuten | **Sofort** |
| `vercel.json` mit fra1 erstellen | Projektstamm, 3 Zeilen | 10 Minuten | **Diese Woche** |
| Vercel DPA herunterladen + archivieren | vercel.com/legal/dpa | 5 Minuten | **Diese Woche** |
| Art.-30-Verarbeitungsverzeichnis anlegen | Internes Dokument | 30–60 Minuten | **Diese Woche** |
| DPF-Monitoring (Vercel quartalsweise) | Intern | 10 Min/Quartal | Laufend |
| Sub-Prozessor-Monitoring (Supabase) | Intern | 10 Min bei Änderung | Laufend |
| E-Mail-Anbieter: DPA + EU-Region beim Onboarding | Beim Anbieter-Setup | 30 Minuten | Beim Onboarding |

**Gesamtaufwand für sofortige Compliance: ca. 2 Stunden — ohne Anwalt erforderlich.**

---

## Was anwaltlich zu klären bleibt

Befund 08 ist der einzige Befund in diesem Audit, bei dem der überwiegende Teil der Lösung **ohne Anwalt umsetzbar ist** — die Anbieter liefern fertige, konforme Verträge.

Optional anwaltlich sinnvoll:
- Wenn ein Fonds-LP oder Investor eine Due-Diligence-Prüfung der DSGVO-Compliance verlangt: TIA-Review durch österreichischen DSGVO-Anwalt für die Supabase-Situation
- Wenn CORE zu einer dominanten DACH-VC-Plattform skaliert: erneute Einschätzung zur Client-Side-Encryption als architektonische Schutzmaßnahme

---

*Quellen: DSGVO Art. 28, 44–49, 83; EU-Durchführungsbeschluss 2021/915 (SCC Controller→Processor); EU-SCC 2021/914 (Modul 2); Supabase DPA (März 2025) supabase.com/legal/dpa; Supabase TIA (März 2025); Vercel DPA vercel.com/legal/dpa; Vercel DPF-Zertifizierung (2023); EDPB-Empfehlungen 01/2020 (Supplementary Measures); EDPB Guidelines 04/2022 (Fines Calculation); DSB Österreich: Google Analytics (DSB-D123.270/0009-DSB/2021, Januar 2022); EU-US Data Privacy Framework (Juli 2023); General Court T-553/23 (3. September 2025); CJEU C-555/25 (Latombe, anhängig); BfDI: Vodafone EUR 15M (März 2025); Supabase Sub-Prozessor-Liste (Schedule 3, DPA März 2025); dataprivacyframework.gov; WKO Mustervertrag Auftragsverarbeitung.*

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
