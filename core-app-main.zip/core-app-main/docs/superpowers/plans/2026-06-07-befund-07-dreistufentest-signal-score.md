# Befund 07 — Art. 6 Abs. 1 lit. f: Dreistufentest für den Signal-Score nicht dokumentiert

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** HOCH  
**Kategorie:** B — Fehlende Dokumentation / Rechtsfehler  
**Betrifft:** Datenschutzerklärung v5.6.2026, custom-index.js (Signal-Score Engine), Art.-30-Verarbeitungsverzeichnis (nicht vorhanden)

---

## Was ist das Problem?

Der Signal-Score wird in Befund 04 und 05 korrekt unter Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse) verortet. Art. 6 Abs. 1 lit. f ist jedoch **keine selbsterfüllende Rechtsgrundlage** — sie gilt nur, wenn der sogenannte **Dreistufentest** (Legitimate Interest Assessment, LIA) bestanden und **dokumentiert** ist.

Dieser Test besteht aus drei kumulativen Prüfschritten:

1. **Berechtigtes Interesse** — hat der Fonds ein legitimes, klar benanntes Interesse?
2. **Erforderlichkeit** — ist die konkrete Verarbeitung zur Erreichung dieses Interesses notwendig?
3. **Interessenabwägung** — überwiegt das Interesse des Fonds die Rechte und Interessen der betroffenen Gründer?

Alle drei Schritte müssen bestanden **und schriftlich dokumentiert** sein — vor Beginn der Verarbeitung (Art. 5 Abs. 2 DSGVO, Rechenschaftspflicht). Für den Signal-Score auf CORE existiert keine solche Dokumentation.

---

## Was ist der rechtliche Rahmen?

### EDSA-Leitlinien zum berechtigten Interesse (Oktober 2024)

Der Europäische Datenschutzausschuss (EDSA) hat im Oktober 2024 Leitlinien veröffentlicht, die den Dreistufentest verbindlich konkretisieren. Der deutsche Bundesbeauftragte für den Datenschutz (BfDI) hat diese als massgebliche Auslegungshilfe anerkannt. Die Leitlinien stellen klar:

- Das berechtigte Interesse muss **spezifisch und konkret** benannt sein — vage Effizienzinteressen genügen nicht.
- Die Erforderlichkeit gilt nur, wenn **keine gleichwertigen, weniger eingriffsintensiven Alternativen** bestehen.
- Die Interessenabwägung muss **schriftlich dokumentiert** und **überprüfbar** sein — implizite Abwägungen reichen nicht.
- Die Beweislast liegt beim Verantwortlichen.

### EuGH C-252/21 — Meta v. Bundeskartellamt (4. Juli 2023)

Der EuGH hat klargestellt: Auch wirtschaftlich starke Unternehmen können lit. f nicht pauschal für Datenverarbeitungen behaupten, die über das objektiv Notwendige hinausgehen. Das Interesse muss **proportional zum Eingriff** sein.

### EuGH C-634/21 — SCHUFA (7. Dezember 2023)

Wenn ein Score bei Ablehnungsentscheidungen eine "massgebliche Rolle" spielt, hat die betroffene Person ein Recht auf "aussagekräftige Informationen über die involvierte Logik". Dieses Recht kann **nicht unter Verweis auf Geschäftsgeheimnisse verweigert** werden.

### EuGH C-203/22 — Scoring-Transparenz (27. Februar 2025)

Das jüngste Urteil des EuGH bestätigt: Bei automatisiertem Scoring, das zu nachteiligen Entscheidungen führt (Ablehnung einer Einreichung), ist Transparenz über die Bewertungslogik **zwingend**. Betroffene müssen eine verständliche Erläuterung erhalten, nicht nur den Rohwert.

---

## Die drei Prüfstufen im Kontext des Signal-Scores

### Stufe 1 — Berechtigtes Interesse

**Einschätzung: Begründbar, aber nicht dokumentiert**

Der Fonds hat ein wirtschaftliches Interesse an effizientem Dealflow-Screening — das ist ein anerkanntes berechtigtes Interesse im B2B-Kontext. Investment-Firmen, Banken und Asset Manager wenden lit. f für Gegenpartei-Screening routinemässig an. Gründer, die eine Einreichung machen, erwarten eine Bewertung.

Das Interesse muss jedoch **konkret und präzise formuliert** sein — nicht "wir wollen effizient screenen", sondern:

> "Der Fonds hat ein berechtigtes wirtschaftliches Interesse daran, aus den eingereichten Rohdaten von Gründern automatisiert einen standardisierten Thesis-Match-Indikator (Signal-Score) zu berechnen, um bei [X] Einreichungen pro Monat eine konsistente, nachvollziehbare und effiziente Erstbewertung anhand der fondsinternen Investitionsthese zu ermöglichen — und damit den manuellen Review-Aufwand von ca. [X] Stunden/Monat auf ein tragbares Mass zu reduzieren."

Diese Formulierung existiert nirgends — weder in der Datenschutzerklärung noch intern.

**Risiko:** Ohne konkrete Benennung fehlt die Basis für die gesamte lit.-f-Argumentation. Im Prüffall kann eine Datenschutzbehörde das Interesse als "nicht belegt" zurückweisen.

---

### Stufe 2 — Erforderlichkeit

**Einschätzung: Hohes Risiko — schwerste Prüfstufe**

Die Erforderlichkeit ist die strengste der drei Prüfstufen. Die Frage lautet: Kann das berechtigte Interesse **nicht ebenso gut mit weniger eingriffsintensiven Mitteln** erreicht werden?

#### Zu prüfende Alternativen

| Alternative | Eingriffsintensität | Eignung |
|---|---|---|
| Manuelles Screening jeder Einreichung | Niedriger | Zeitlich nicht skalierbar (>120h/Monat bei 200+ Einreichungen) |
| Keyword-basiertes Filtern (MRR, Sektor) | Deutlich niedriger | Verfehlt ca. 15 % der relevanten Einreichungen (annahmegemäss) |
| Standardisierter Fragebogen + manuelles Scoring | Mittel | Funktioniert, aber setzt erheblichen manuellen Aufwand voraus |
| Automatisiertes Scoring mit vollständiger Transparenz | Gleich hoch | Gleiche Effizienz — höhere Legitimität |
| Opt-in-Scoring (nur mit Einwilligung) | Niedriger | Verengt die Stichprobe und verzerrt das Sample |

**Was der Fonds dokumentieren muss:**

Für jede dieser Alternativen muss der Fonds belegen, warum sie das berechtigte Interesse **nicht gleichwertig erfüllen**. Beispiel: "Keyword-Filterung scheitert, weil unser Thesis-Match von der kombinierten Bewertung von Revenue, Effizienz und Gründerprofil abhängt — nicht von einzelnen Kennzahlen."

Diese Dokumentation existiert nicht.

**Risiko:** Wenn ein Gründer die Verarbeitung anficht und der Fonds keine Alternativenprüfung vorweisen kann, ist Stufe 2 nicht bestanden. Das macht die gesamte lit.-f-Grundlage anfechtbar.

---

### Stufe 3 — Interessenabwägung

**Einschätzung: Mittleres Risiko — abhängig von Transparenz und Kontrolle**

Die Abwägung ist nicht von vornherein zugunsten des Fonds entschieden. Sie hängt davon ab, welche Schutzmassnahmen vorhanden sind.

#### Faktoren zugunsten des Fonds

- **Freiwillige Einreichung**: Gründer wählen aktiv, ihr Unternehmen bei einem Fonds einzureichen. Die Bewertung ist ein erwartbarer Teil des Prozesses.
- **Berufliche und finanzielle Daten**: Keine sensiblen Kategorien nach Art. 9 DSGVO (Gesundheit, Religion, politische Überzeugungen). Der Eingriff in die Privatsphäre ist geringer als bei Verbraucherkreditscoring (SCHUFA-Fall).
- **B2B-Kontext**: Gründer sind keine schutzbedürftigen Verbraucher. Sie handeln im geschäftlichen Umfeld und erwarten professionelle Bewertungen.
- **Kein externer Datentransfer**: Der Score wird nicht an Dritte verkauft oder veröffentlicht. Die Verarbeitung ist fondsintertern.
- **Beiderseitiger Nutzen**: Der Fonds bewertet; der Gründer sucht Kapital. Das Screening dient auch dem Gründer, weil es schnelle Rückmeldung ermöglicht.

#### Faktoren zugunsten der Gründer

- **Intransparenz der Bewertungslogik**: Gründer kennen die Scoring-Regeln nicht. Sie können falsche Prämissen nicht korrigieren. Nach EuGH C-203/22 (Februar 2025) ist das bei nachteiligen Entscheidungen unzulässig.
- **Kein Recht auf Erläuterung**: Gründer erhalten keinen Zugang zu ihrem Score oder einer Erklärung der Logik. Nach EuGH C-634/21 (SCHUFA) besteht dieses Recht, wenn der Score die Entscheidung massgeblich beeinflusst.
- **Strukturelles Machtgefälle**: Gründer brauchen Kapital; Fonds kontrollieren den Zugang. Bei wachsender Marktdurchdringung von CORE könnten Gründer faktisch keine Alternative haben. Der EuGH (C-252/21) hat Machtgefälle ausdrücklich als abwägungsrelevant anerkannt.
- **Diskriminierungsrisiko durch Opazität**: Wenn der Signal-Score implizit auf Merkmale reagiert, die Gründer nicht kennen (z.B. Bewertungsstrafe für Einzelgründer-Teams), entsteht eine strukturell diskriminierende Wirkung ohne Korrektivmöglichkeit.
- **Kein formales Widerspruchsrecht** gegen den Score als solchen (obwohl Art. 21 Abs. 1 DSGVO genau das auslöst, wenn lit. f die Grundlage ist).

#### Das Abwägungsergebnis

Die Interessenabwägung fällt zugunsten des Fonds aus **nur wenn** mindestens folgende Schutzmassnahmen implementiert sind:

1. Gründer werden über die Existenz und den Zweck des Scores informiert (Art. 13)
2. Gründer können auf Anfrage eine Erklärung ihres Scores erhalten
3. Fondsmitarbeiter können den Score manuell überschreiben
4. Es existiert eine dokumentierte Human-Override-Rate als Nachweis echter menschlicher Prüfung

Ohne diese Massnahmen überwiegen die Gründerinteressen — und Stufe 3 ist nicht bestanden.

---

## Das Rubber-Stamping-Risiko

Wenn in der Praxis nahezu alle Ablehnungsentscheidungen mit niedrigem Signal-Score korrelieren und Fondsmitarbeiter den Score faktisch nie überschreiben, entsteht das sogenannte "Rubber-Stamping"-Risiko:

**Rechtliche Konsequenz 1 — Stufe 3 fällt nachträglich weg**

Wenn das berechtigte Interesse auf "effizienter Einsatz menschlicher Expertise" aufgebaut ist, aber in der Praxis die Entscheidung vollständig vom Algorithmus getroffen wird, war die Interessenbehauptung unrichtig. Die Interessenabwägung gilt rückwirkend als nicht bestanden.

**Rechtliche Konsequenz 2 — Art. 22 Abs. 1 wird auslösbar**

Der EuGH hat in C-634/21 klargestellt: Wenn ein Score für die Entscheidung "massgeblich" ist, gilt Art. 22 DSGVO. Massgeblich kann auch faktisch bedeuten (nicht nur formal). Fonds, die Einreichungen faktisch automatisch nach Score ablehnen, verlieren den Schutz des "manuellen Entscheids" — auch wenn formal eine Person auf "Ablehnen" klickt.

**Empfehlung:** Der Fonds muss eine **Human-Override-Log** führen — nicht als Beleg, dass er immer abweicht, sondern als Nachweis, dass menschliche Entscheidung tatsächlich stattfindet. Eine Override-Rate von 3–8 % über sechs Monate ist ein starkes Indiz für echtes menschliches Urteil.

---

## Die Lösung

### Massnahme 1 — Legitimate Interest Assessment (LIA) erstellen

Ein formales LIA-Dokument ist zu erstellen. Es dokumentiert alle drei Prüfstufen, muss datiert und unterschrieben sein und bildet das juristische Fundament für lit. f. Es ist kein Teil der Datenschutzerklärung — es ist ein internes Governance-Dokument, das bei einer Behördenprüfung vorgelegt werden kann.

**Pflichtinhalt:**

| Abschnitt | Inhalt |
|---|---|
| Verarbeitungsbeschreibung | Was wird verarbeitet, zu welchem Zweck, welche Kategorien |
| Stufe 1: Berechtigtes Interesse | Konkrete Formulierung des Fondsinteresses, Bezug zur Investitionsstrategie |
| Stufe 2: Erforderlichkeit | Alternativen geprüft und verworfen (mit Begründung) |
| Stufe 3: Interessenabwägung | Faktoren für/gegen den Fonds, Schutzmassnahmen, Ergebnis |
| Überprüfungsrhythmus | Jährliche Aktualisierung verpflichtend |
| Unterschriften | DSB/Anwalt + Fondsleitungsebene (GP/CIO) |

**Format:** PDF, versioniert, im internen Compliance-Ordner. Cross-Referenz im Art.-30-Verarbeitungsverzeichnis.

**Wer erstellt es:** Plattformbetreiber liefert die technische Beschreibung (Scoring-Logik, Datenfelder); Fonds-Anwalt strukturiert die Rechtsprüfung; Fondsführung unterzeichnet.

---

### Massnahme 2 — Recht auf Score-Erläuterung implementieren

Nach EuGH C-634/21 und C-203/22 haben Gründer, die eine negative Entscheidung erhalten, ein Recht auf verständliche Erläuterung der Bewertungslogik. Das muss technisch umsetzbar sein:

**Mindestanforderung:** Auf Anfrage eines Gründers kann der Fonds eine standardisierte Erläuterung übermitteln:

> "Ihre Einreichung hat im fondsinternen Thesis-Match-Indikator einen Wert von [X]/100 erhalten. Dieser Indikator bewertet Einreichungen anhand der folgenden Kategorien: Umsatz und Traktion (Gewichtung: X %), Wachstum (X %), Effizienz (X %), Gründerteam (X %), Markt (X %), Plausibilität (X %), Risiko (X %). In Ihrer Einreichung lagen folgende Kategorien unter dem Schwellenwert des Fonds: [Kategorien]."

Diese Erläuterung muss **nicht die genauen Regelformeln** offenlegen, aber die Bewertungslogik auf Kategorienebene transparent machen. Das ist die Mindestanforderung nach aktuellem EuGH-Stand.

---

### Massnahme 3 — Art. 21 DSGVO: Widerspruchsrecht in der Datenschutzerklärung nennen

Da lit. f die Rechtsgrundlage für den Signal-Score ist, löst das automatisch Art. 21 Abs. 1 DSGVO aus: Gründer können der Verarbeitung widersprechen. Dieser Widerspruch muss:

- In der Datenschutzerklärung **explizit erwähnt** sein
- Technisch umsetzbar sein (im Falle eines Widerspruchs: Score für diese Einreichung auf `null` setzen, keine Neuberechnung)
- Nicht zur Löschung der gesamten Einreichung führen müssen (nur der Score ist betroffen)

---

### Massnahme 4 — Human-Override-Log führen (Rubber-Stamping-Schutz)

Fondsmitarbeiter sollten bei jeder Entscheidung, die vom Signal-Score abweicht, eine kurze Notiz hinterlegen. Das ist bereits heute als "Notes"-Funktion vorhanden. Was fehlt: die strukturierte Auswertbarkeit.

Konkret: In der internen Governance (nicht zwingend in der Plattform) quartalsweise prüfen, ob die Override-Rate > 0 ist. Falls ja: dokumentieren. Falls nein: prüfen, ob der Score faktisch autonom entscheidet (= Art.-22-Risiko).

Diese Überprüfung gehört in den jährlichen DSFA-Review (Befund 06).

---

### Massnahme 5 — Datenschutzerklärung: Scoring transparent nennen

Gründer müssen gemäss Art. 13 Abs. 2 lit. f DSGVO informiert werden, wenn ihre Daten für Profiling verwendet werden. In der Datenschutzerklärung fehlt dieser Hinweis. Er muss ergänzt werden:

> "Im Rahmen der Einreichungsbewertung berechnet der Fonds aus den eingereichten Rohdaten automatisiert einen fondsinternen Thesis-Match-Indikator (Signal-Score). Dieser Indikator fasst die Übereinstimmung Ihrer Einreichung mit der Investitionsthese des Fonds numerisch zusammen und dient dem Fondsteam als Orientierungshilfe bei der manuellen Erstbewertung. Die Entscheidung über eine Weiterbearbeitung Ihrer Einreichung trifft stets ein Mitarbeiter des Fonds auf Basis einer eigenständigen Prüfung. Rechtsgrundlage: Art. 6 Abs. 1 lit. f DSGVO. Sie können gemäss Art. 21 DSGVO der Berechnung des Thesis-Match-Indikators für Ihre Einreichung widersprechen."

---

## Was nicht vollständig wasserdicht ist

**Risiko 1 — Erforderlichkeitsnachweis ist anspruchsvoll**

Die Erforderlichkeit (Stufe 2) erfordert den Nachweis, dass Keyword-Filtering oder manuelles Screening das berechtigte Interesse nicht gleichwertig erfüllen können. Dieser Nachweis ist intern zu führen und muss auf konkreten Zahlen (Einreichungsvolumen, Zeitaufwand, Fehlerquote) basieren — nicht auf Allgemeinbehauptungen.

**Risiko 2 — EuGH C-203/22 setzt Transparenzlatte hoch**

Das Urteil vom Februar 2025 lässt wenig Spielraum für Scoring-Opazität. Wenn CORE keine Score-Erläuterungsmöglichkeit auf Anfrage implementiert, ist das Urteil ein direktes Risiko — insbesondere wenn ein Gründer Beschwerde erhebt.

**Risiko 3 — CORE als Marktgateway**

Wenn CORE zur dominanten Einreichungsplattform im DACH-Raum wird, wächst das Gewicht der Machtasymmetrie in der Interessenabwägung. Ein Marktgatekeeper-Argument (analog EuGH C-252/21) könnte Stufe 3 kippen. Das ist heute kein akutes Risiko, muss aber im LIA regelmässig neu bewertet werden.

---

## Zusammenfassung: Was sich ändert

| Was | Wo | Aufwand |
|---|---|---|
| Legitimate Interest Assessment (LIA) erstellen | Internes Governance-Dokument (PDF) | Anwaltlich, einmalig, 4–8 Stunden |
| Score-Erläuterung auf Anfrage implementieren | Prozess + ggf. Plattform | 2–4 Stunden technisch, 1 Stunde Textvorlage |
| Art. 21 Widerspruchsrecht in Datenschutzerklärung | Datenschutzerklärung | 15 Minuten |
| Scoring-Absatz in Datenschutzerklärung | Datenschutzerklärung | 20 Minuten |
| Human-Override-Log (Governance) | Intern, quartalsweise | 30 Minuten/Quartal |
| LIA-Aktualisierung | Jährlich | 1–2 Stunden |

---

## Was anwaltlich zu klären bleibt

Das Legitimate Interest Assessment (LIA) für den Signal-Score ist die kernjuristische Leistung dieses Befunds. Es kann nicht ohne externen DSGVO-Anwalt vollständig erstellt werden. Mitzubringen zum Gespräch:

1. Die vollständige Liste der Datenfelder, die in den Signal-Score einfliessen (aus custom-index.js)
2. Die Anzahl der monatlichen Einreichungen (für die Erforderlichkeitsbegründung)
3. Eine ehrliche Einschätzung der Override-Rate (wie oft weicht der Fonds tatsächlich vom Score ab?)
4. Den Text der geplanten Datenschutzerklärungspassage zur Gegenkontrolle

---

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*  
*Rechtsquellen: EDSA-Leitlinien berechtigtes Interesse (Oktober 2024); EuGH C-252/21; EuGH C-634/21; EuGH C-203/22; DSGVO Art. 6 Abs. 1 lit. f, Art. 21, Art. 30.*
