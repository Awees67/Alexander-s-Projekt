# Scoring Engine Refactor — Arbeitslog

Ziel: Schrittweise Bereinigung von `custom-index.js` + `signal-index.js`
auf Basis des Senior-Dev Reviews vom 2026-04-28.

---

## Identifizierte Probleme (priorisiert)

| ID | Priorität | Problem | Status |
|---|---|---|---|
| P0 | Kritisch | DOM-Code in `computeCustomIndexV6` | ✅ Erledigt |
| P1 | Hoch | Kein Gruppen-Gewichtungssystem / Group Caps | ✅ Erledigt |
| P2 | Mittel | Scoring-Lücken in Bändern (Silent Gaps) | ✅ Erledigt |
| P3 | Mittel | Founder-Scoring zu dünn (nur 4 Binärflags) | ✅ Erledigt |
| P4 | Niedrig | Plausibility + Score nicht integriert | ✅ Erledigt |
| P5 | Niedrig | `max_score: 85` willkürlich, nicht normiert | ✅ Erledigt |

---

## P0 — DOM-Code aus Compute-Funktion extrahieren

**Problem:**
`computeCustomIndexV6()` enthielt einen `try{}catch(_){}` Block der DOM-Elemente
abfragt und Event-Listener bindet. Das bedeutete: bei jeder Score-Berechnung
(auch im Batch für alle 30 Startups) wurden DOM-Queries und Binding-Versuche ausgeführt.

**Lösung:**
- Neues `bindRulesetSelectorUI(rules)` extrahiert — reine UI-Bindungsfunktion.
- `computeCustomIndexV6` ist jetzt eine pure function: Input → Output, kein DOM.
- `bindRulesetSelectorUI(rules)` wird einmalig in `renderCustomIndexUI` aufgerufen.

**Geänderte Dateien:**
- `js/custom-index.js` — Extraktion + Aufruf in `renderCustomIndexUI`

**Vorher:**
```js
function computeCustomIndexV6(anonOrStartup){
  const rules = getCustomRulesV6();
  try{
    // DOM-Queries + Event-Binding (77 Zeilen)
    ...
  }catch(_){}
  // eigentliche Berechnung
}
```

**Nachher:**
```js
function bindRulesetSelectorUI(rules){ /* DOM-Binding hier */ }

function computeCustomIndexV6(anonOrStartup){
  const rules = getCustomRulesV6();
  if(!rules.enabled) return { score: null, breakdown: [], enabled:false };
  // eigentliche Berechnung — pure
}
```

---

## P1 — Group Caps

**Problem:**
Alle Gruppen stackten linear ohne Obergrenze. Ein Startup mit perfekter Retention
(bis ~35 Pkt aus einer Gruppe) konnte fehlende Revenue-Metriken überkompensieren.

**Lösung:**
- `cap` Feld pro Gruppe im Schema — optionales Feld, kein Breaking Change
- Compute-Loop akkumuliert jetzt per-Group in `groupRawScore`, wendet dann
  `Math.min(groupRawScore, g.cap)` an — Penalties passieren ungecappt durch
- Schema-Version auf 4 gebumpt, Migration-Check aktualisiert

**Caps (Default-Ruleset):**
| Gruppe | Cap |
|---|---|
| Revenue & Traction | 20 |
| Growth | 14 |
| Unit Economics | 18 |
| Retention | 15 |
| Kapitaleffizienz | 13 |
| Valuation & Cap Table | 12 |
| Team & Founders | 17 |

**Geänderte Dateien:**
- `js/custom-index.js` — Schema + Compute-Loop + Migration

---

## P2 — Scoring-Lücken

**Problem:**
Bestimmte Wertebereiche triggerten keine Regel — weder positiv noch negativ (Silent Gaps).
Für VCs sind diese Zonen irreführend: ein stagnantes Startup sieht genauso aus wie keines.

**Geschlossene Gaps:**

| KPI | Gap | Neue Regel | Punkte |
|---|---|---|---|
| Growth MoM | 0–2.99% | `r_grw_gap` — "stagnierend" | -3 |
| LTV/CAC (Seed/Pre-A) | 2x–2.99x | `r_ltv_s_gap` — "akzeptabel" | +2 |
| NRR (Seed/Pre-A) | 95–99.99% | `r_nrr_s_gap` — "solide Retention" | +2 |

**Bewusst offen gelassene Gaps:**
- Gross Margin 30–59% (Early): intentional neutral — "mittelmäßig, aber kein KO"
- Burn Multiple 1.5x–2.99x: intentional neutral — informativ, nicht bestrafend

**Geänderte Dateien:**
- `js/custom-index.js` — 3 neue Rules in growth / unit_economics / retention Gruppe

---

## P3 — Founder-Scoring erweitern

**Problem:**
Nur 4 binäre Flags (`has_repeat_founder`, `has_prior_exit`, `has_technical_founder`,
`has_domain_expert`). Die reichen Daten in `founders[].years_experience` und
`founders[].had_exit` wurden nicht fürs Scoring genutzt.

**Lösung:**

*Neue computed fields in `main.js` (`buildStartupFromSubmission`):*
- `max_founder_experience` — `Math.max(...founders.map(f => f.years_experience))`, null wenn keine Daten
- `founders_with_exit_count` — Anzahl Founders mit `had_exit === true`

*Neue KPIs in kpi_map (`custom-index.js`):*
- `FOUNDER_EXPERIENCE_YEARS` → `s.max_founder_experience`
- `FOUNDERS_WITH_EXIT_COUNT` → `s.founders_with_exit_count`

*Neue Regeln in team-Gruppe:*
| Rule ID | KPI | Bedingung | Punkte |
|---|---|---|---|
| `r_exp_1` | FOUNDER_EXPERIENCE_YEARS | 5–10 Jahre | +2 |
| `r_exp_2` | FOUNDER_EXPERIENCE_YEARS | ≥ 10 Jahre | +3 |
| `r_exit2` | FOUNDERS_WITH_EXIT_COUNT | ≥ 2 Exits | +3 |
| `r_own_1` | FOUNDER_OWNERSHIP_PCT | ≥ 50% | +3 |

Nur positive Signale — keine Penalties auf fehlende Daten (null → skip_rule greift).
Group cap 17 verhindert Überkompensation.

**Geänderte Dateien:**
- `js/main.js` — 2 computed fields in `buildStartupFromSubmission`
- `js/custom-index.js` — 2 neue KPIs in kpi_map, 4 neue Regeln in team-Gruppe

---

## P4 — Plausibility + Score Integration

**Problem:**
Score und Plausibility-Check waren vollständig getrennt. Ein Startup konnte
75/85 Punkte haben und gleichzeitig 2 Hard-Fails haben — ohne sichtbare Konsequenz.

**Lösung:**
- Neue Felder im `scoring`-Schema: `plausibility_hard_penalty: -8`, `plausibility_soft_penalty: -3`
- Im Compute-Loop nach dem Group-Loop, vor dem finalen `clamp`: Plausibility-Fails
  werden als Score-Penalties eingerechnet und als `group_id: "plausibility"` ins Breakdown aufgenommen
- Nur für `_from_submission: true` Startups — Mock-Daten werden nicht bestraft
- Gespeicherte `plausibility_checks` aus Supabase haben Vorrang vor `computePlausibility()`

**Penalty-Logik:**
| Typ | Penalty |
|---|---|
| Hard Fail (z.B. Ownership > 100%) | -8 Pkt |
| Soft Fail (z.B. LTV/CAC fehlt) | -3 Pkt |

Im Score Breakdown Popover sichtbar — user sieht genau warum der Score reduziert wurde.

**Geänderte Dateien:**
- `js/custom-index.js` — Schema + Compute-Loop

---

## P5 — max_score Normierung

**Problem:**
`max_score: 85` war willkürlich. "Perfektes Startup = 85" ist für User unintuitiv.
Die Regel-Punkte addierten sich zu theoretisch ~109 (Summe aller Group Caps),
die 85er-Grenze verbarg das ohne Erklärung.

**Lösung:**
- `max_score` auf **100** geändert — universell verständlich
- Alle Fallback-Werte `?? 85` auf `?? 100` aktualisiert (3 Dateien)
- `schema_version` auf **5** gebumpt, Migration-Check auf `< 5`
- Score-Farbschwellen proportional skaliert (Basis: alter Wert / 85 * 100):

| Funktion | Alt | Neu |
|---|---|---|
| `getScoreColorClass` — Rot | ≤ 15 | ≤ 18 |
| `getScoreColorClass` — Orange | ≤ 30 | ≤ 35 |
| `getScoreColorClass` — Gelb | ≤ 48 | ≤ 56 |
| `sigClassFromScore` — HIGH | ≥ 60 | ≥ 70 |
| `sigClassFromScore` — MID | ≥ 30 | ≥ 35 |

**Geänderte Dateien:**
- `js/custom-index.js` — max_score, schema_version, Migration, Fallback
- `js/signal-index.js` — getScoreColorClass, sigClassFromScore, Fallback
- `js/renderers-weekly-top5.js` — Fallback

---
