# Befund 09 — Plattformbetreiber als eigenständiger Verantwortlicher

**Datum:** 07. Juni 2026
**Projekt:** CORE — Dealflow Screening Platform
**Schweregrad:** KRITISCH
**Artikel:** Art. 5 Abs. 1 lit. b DSGVO (Zweckbindung), Art. 5 Abs. 1 lit. e DSGVO (Speicherbegrenzung), Art. 26 DSGVO (gemeinsame Verantwortlichkeit), Art. 13/14 DSGVO (Informationspflichten)
**Status:** Offen

---

## 1. Zusammenfassung

CORE verarbeitet personenbezogene Daten von Startup-Gründerinnen und -Gründern (eingereicht über das Submit-Formular) im Auftrag der VC-Fonds, die die Plattform nutzen. Soweit handelt CORE als Auftragsverarbeiter (Art. 28 DSGVO) — dies ist in Befund 08 adressiert.

Dieser Befund behandelt eine davon zu trennende Verarbeitung: **CORE als Plattformbetreiber nutzt dieselben Daten für eigene Zwecke** — Benchmarking, historische Vergleiche und Marktanalysen — ohne dass ein VC-Fonds diese Verarbeitung angeordnet hätte. Für diesen eigenständigen Zweck ist CORE **eigenständiger Verantwortlicher** im Sinne von Art. 4 Nr. 7 DSGVO.

Diese Rollendopplung ist datenschutzrechtlich hoch komplex und birgt erhebliche Haftungsrisiken, wenn sie nicht sauber strukturiert und dokumentiert wird.

---

## 2. Sachverhalt

### 2.1 Datenherkunft

Gründerinnen und Gründer reichen Bewerbungen über `/submit/index.html` ein. Die Daten werden serverseitig in die Supabase-Tabelle `submissions` geschrieben. Jeder Eintrag enthält personenbezogene Angaben (Name, E-Mail, LinkedIn, Hochschule, Werdegang, Unternehmensdaten).

### 2.2 Primärverarbeitung (Auftragsverarbeitung)

Der VC-Fonds entscheidet über Screening, Pipeline-Einstufung und Investitionsentscheidungen. CORE stellt hierfür die technische Infrastruktur. In dieser Rolle ist der VC-Fonds **Verantwortlicher**, CORE ist **Auftragsverarbeiter** (Art. 28 DSGVO).

### 2.3 Sekundärverarbeitung (eigenständige Verantwortlichkeit)

Der Plattformbetreiber (CORE) verfolgt darüber hinaus eigene Zwecke:

| Zweck | Beschreibung |
|---|---|
| Benchmarking | Vergleich von Startup-Qualitätsmerkmalen über Fonds hinweg |
| Historische Vergleiche | Longitudinale Analyse von Gründer-Karriereverläufen und Erfolgsquoten |
| Marktanalyse | Identifikation von Mustern ("Gründer von Uni X mit Hintergrund Y erzielen Outcome Z") |
| Produktverbesserung | Kalibrierung des Signal-Score-Algorithmus auf Basis realer Outcomes |

Diese Zwecke sind **nicht von dem VC-Fonds angewiesen** — CORE entscheidet selbst über Zweck und Mittel dieser Verarbeitung. Damit ist CORE für diese Verarbeitung **eigenständiger Verantwortlicher**.

### 2.4 Faktische Speicherpraxis

Die Daten verbleiben **unbegrenzt** in der CORE-Datenbank — auch nach dem Ende der Geschäftsbeziehung mit einem VC-Fonds. Es existiert keine automatische Löschroutine, keine definierten Löschfristen, kein differenziertes Konzept zwischen Auftragsverarbeitung und eigenständiger Verarbeitung.

### 2.5 "Anonym aber spezifisch"

Der Plattformbetreiber beabsichtigt, Analysen zu erstellen, die faktisch pseudonymisierte Daten enthalten: "Gründer von Universität X mit Karrierehintergrund Y und Investitionssumme Z haben in 78 % der Fälle Outcome A erzielt." Solche Aussagen sind **nicht anonym**, auch wenn kein Name genannt wird — sie erfüllen die Singling-out-Kriterien des Erwägungsgrunds 26 DSGVO und des Anonymisierungsleitfadens des EDSA (2023).

---

## 3. Rechtliche Analyse

### 3.1 Art. 5 Abs. 1 lit. b DSGVO — Zweckbindung

#### Grundsatz

Personenbezogene Daten dürfen nur für festgelegte, eindeutige und legitime Zwecke erhoben und nicht in einer mit diesen Zwecken nicht zu vereinbarenden Weise weiterverarbeitet werden.

#### Problem: Zweckänderung ohne Rechtsgrundlage

Die Gründerinnen und Gründer haben ihre Daten für den Zweck der Bewerbung bei einem VC-Fonds eingereicht. Die anschließende Nutzung durch CORE für Benchmarking, Marktanalyse und Produktkalibrierung ist eine **Zweckänderung** (Weiterverarbeitung für anderen Zweck).

Eine solche Weiterverarbeitung ist nach Art. 6 Abs. 4 DSGVO nur zulässig, wenn:
1. eine separate Einwilligung vorliegt (Art. 6 Abs. 1 lit. a), **oder**
2. eine gesetzliche Grundlage besteht, **oder**
3. die Kompatibilitätsprüfung nach Art. 6 Abs. 4 DSGVO positiv ausfällt.

**Kompatibilitätsprüfung (Art. 6 Abs. 4 DSGVO):**

| Kriterium | Bewertung |
|---|---|
| Verbindung zwischen Zwecken | Gering — Bewerbung beim Fonds ≠ Plattformbetreiber-Benchmarking |
| Kontext der Erhebung | Gründer erwartet Verarbeitung durch Fonds, nicht durch CORE eigenständig |
| Art der Daten | Sensibel (Karrieredaten, finanzielle Daten, Hochschule) |
| Konsequenzen | Dauerhafter Verbleib in CORE-DB, potenzielle Cross-Fonds-Nutzung |
| Garantien | Noch keine differenzierten Garantien vorhanden |

**Ergebnis:** Die Kompatibilitätsprüfung fällt negativ aus. Die Weiterverarbeitung für CORE-eigene Zwecke ist ohne separate Rechtsgrundlage unzulässig.

#### Art. 89 DSGVO — Ausnahme für Forschung und Statistik

Art. 89 DSGVO erlaubt Weiterverarbeitung für Archivzwecke im öffentlichen Interesse, wissenschaftliche oder historische Forschungszwecke oder statistische Zwecke, wenn geeignete Garantien vorhanden sind. Diese Ausnahme gilt **nicht** für kommerzielle Marktanalysen eines privaten Plattformbetreibers. CORE's Benchmarking ist nicht wissenschaftliche Forschung im Sinne von Art. 89 DSGVO.

### 3.2 Art. 5 Abs. 1 lit. e DSGVO — Speicherbegrenzung

#### Grundsatz

Personenbezogene Daten dürfen in einer Form, die die Identifizierung der betroffenen Personen ermöglicht, nur so lange gespeichert werden, wie es für die Zwecke, für die sie verarbeitet werden, erforderlich ist.

#### Problem: Unbegrenzte Speicherung ohne Rechtsgrundlage

CORE speichert alle Submissions dauerhaft. Eine Differenzierung nach Zweck existiert nicht:

| Verarbeitungszweck | Erforderliche Speicherdauer | Aktuelle Praxis |
|---|---|---|
| Screening durch den Fonds (Art. 28) | Bis Ende der AVV-Laufzeit oder Ablauf gesetzlicher Aufbewahrungsfristen | Unbegrenzt |
| Benchmarking durch CORE | Eigene Rechtsgrundlage erforderlich (s.o.) | Unbegrenzt |
| Historische Marktanalyse | Eigene Rechtsgrundlage erforderlich | Unbegrenzt |

Ohne festgelegte und dokumentierte Löschfristen für jeden Verarbeitungszweck liegt ein Verstoß gegen Art. 5 Abs. 1 lit. e DSGVO vor. Der EuGH hat in mehreren Entscheidungen betont, dass das Fehlen eines Löschkonzepts nicht durch nachträgliche Behauptungen heilt (vgl. EuGH C-817/19, Ligue des droits humains, Rn. 94 ff.).

#### Pseudonymisierung als Kompromiss

Eine datenschutzkonforme Lösung für Langzeitspeicherung zu Analysezwecken könnte die **echte Pseudonymisierung** sein: Trennung des Schlüssels (personenbezogene Identifikatoren) vom Analysedatensatz, mit dem Schlüssel in einer separaten, zugriffsbeschränkten Tabelle. Nach einem definierten Zeitraum wird der Schlüssel gelöscht — der Analysedatensatz bleibt und ist dann faktisch anonym.

Dies ist aber eine technische Maßnahme, die erst **nach** Klärung der Rechtsgrundlage greift.

### 3.3 Pseudonymisierung vs. Anonymisierung — "Anonym aber spezifisch"

#### Rechtsrahmen

Erwägungsgrund 26 DSGVO: Daten gelten als anonym, wenn die betroffene Person "nicht oder nicht mehr identifizierbar ist." Die EDSA-Leitlinien zur Anonymisierung (05/2014, bestätigt 2023) nennen drei Tests:
1. **Singling-out:** Kann eine Person herausgegriffen werden?
2. **Linkability:** Können Datensätze verknüpft werden?
3. **Inference:** Können Informationen über eine Person abgeleitet werden?

#### Bewertung von CORE's "anonym aber spezifisch"

Die geplanten Aussagen ("Gründer von Uni X mit Hintergrund Y haben Erfolgsquote Z") sind in der Kombination der Merkmale **hochgradig spezifisch**. In kleinen Populationen (DACH-VC-Ökosystem ist überschaubar) ermöglichen kombinierte Merkmale (Hochschule + Karrierehintergrund + Gründungsjahr + Investitionssumme) die Identifizierung konkreter Personen — insbesondere für andere Marktteilnehmer.

**Ergebnis:** Diese Daten sind **pseudonymisiert, nicht anonym**. Die DSGVO findet vollumfänglich Anwendung.

#### Relevante Rechtsprechung

- **EuGH C-252/21 (Meta/Bundeskartellamt, Juli 2023):** Verknüpfung von Daten aus verschiedenen Quellen zur Profilerstellung ist datenschutzrechtlich relevant, auch wenn Einzeldaten harmlos erscheinen.
- **EDSA Opinion 5/2019 (Anonymisierung):** Techniken, die nicht alle drei Tests bestehen, gelten nicht als Anonymisierung.
- **BayLDA Bescheid 2024 (Analytics-Daten):** Aggregierte Website-Statistiken wurden als personenbezogen eingestuft, weil Einzelpersonen in kleinen Gruppen identifizierbar waren.

### 3.4 Art. 26 DSGVO — Gemeinsame Verantwortlichkeit

#### Wann liegt gemeinsame Verantwortlichkeit vor?

Der EuGH hat in **C-40/17 (Fashion ID)** und **C-210/16 (Wirtschaftsakademie)** klargestellt: Gemeinsame Verantwortlichkeit liegt vor, wenn zwei oder mehr Stellen **gemeinsam über Zwecke und Mittel** einer Verarbeitung entscheiden — auch wenn sie unterschiedliche Verarbeitungsphasen steuern oder unterschiedliche Interessen verfolgen.

#### Anwendung auf CORE

Für die **primäre Verarbeitung** (Screening durch den Fonds) liegt eine klare Auftragsverarbeitung vor: Der Fonds gibt Zweck und Mittel vor, CORE führt aus.

Für die **sekundäre Verarbeitung** (Benchmarking, Marktanalyse) entscheidet CORE allein — reine eigenständige Verantwortlichkeit.

**Grenzfall — zukünftige Cross-Fonds-Funktionen:** Wenn CORE in Zukunft Benchmarking-Ergebnisse an Fonds zurückspielt ("Euer Deal-Flow liegt 20 % über dem Plattformdurchschnitt"), und der Fonds diese Daten zur Entscheidungsfindung nutzt, entsteht eine **gemeinsame Verarbeitung im Sinne von Art. 26 DSGVO**. Dies erfordert:
- Eine schriftliche Vereinbarung zwischen CORE und jedem Fonds (Art. 26 Abs. 1 Satz 2 DSGVO)
- Klare Zuordnung der Pflichten (Betroffenenrechte, Datenschutzverletzungen, Informationspflichten)
- Wesentlicher Inhalt dieser Vereinbarung muss den Betroffenen zugänglich gemacht werden (Art. 26 Abs. 2 Satz 2 DSGVO)

Dieses Risiko ist heute latent, wird aber akut, sobald CORE Benchmarking-Daten an Fonds zurückspielt.

### 3.5 Art. 13/14 DSGVO — Informationspflichten

#### Aktuelle Situation

Gründerinnen und Gründer werden (gemäß Planung) über die Datenschutzerklärung informiert. Die aktuelle Datenschutzerklärung deckt jedoch die **eigenständige Verarbeitung durch CORE** nicht ab — sie adressiert primär die Auftragsverarbeitung für den Fonds.

#### Erforderliche Informationen (Art. 13 DSGVO)

Für die eigenständige Verarbeitung durch CORE als Verantwortlicher müssen zusätzlich mitgeteilt werden:

| Art. 13 Element | Inhalt für CORE's eigenständige Verarbeitung |
|---|---|
| Zweck der Verarbeitung | Benchmarking, historische Marktanalyse, Produktkalibrierung |
| Rechtsgrundlage | Einwilligung (Art. 6 Abs. 1 lit. a) oder berechtigtes Interesse (Art. 6 Abs. 1 lit. f) mit Dreistufentest |
| Dauer der Speicherung | Konkrete Fristen oder Kriterien für die Festlegung |
| Empfänger | Ob Analyseergebnisse an Fonds oder Dritte weitergegeben werden |
| Recht auf Widerspruch | Bei berechtigtem Interesse (Art. 21 Abs. 1 DSGVO) |
| Recht auf Einschränkung | Art. 18 DSGVO |
| Recht auf Löschung | Art. 17 DSGVO — wann und unter welchen Bedingungen |

#### Besondere Herausforderung: Zeitpunkt der Information

Gründerinnen und Gründer reichen über das Submit-Formular ein, ohne zu wissen, dass ihre Daten dauerhaft für CORE's eigene Zwecke gespeichert werden. Die Information muss **zum Zeitpunkt der Erhebung** erfolgen (Art. 13 Abs. 1 DSGVO) — also im Submit-Formular selbst.

---

## 4. Risikobewertung

| Risiko | Wahrscheinlichkeit | Schwere | Gesamtrisiko |
|---|---|---|---|
| Zweckänderung ohne Rechtsgrundlage (Art. 5(1)(b)) | Hoch | Kritisch | **Kritisch** |
| Unbegrenzte Speicherung ohne Löschkonzept (Art. 5(1)(e)) | Hoch | Hoch | **Hoch** |
| Pseudonymisierung ≠ Anonymisierung (Fehleinschätzung) | Mittel | Hoch | **Hoch** |
| Fehlende Art. 13-Information für CORE-eigene Zwecke | Hoch | Mittel | **Hoch** |
| Zukünftige Art. 26-Pflichten (Cross-Fonds-Benchmarking) | Mittel (latent) | Hoch | **Mittel-Hoch** |

**Bußgeldrisiko:** Verstöße gegen Art. 5 DSGVO (Grundsätze) sind nach Art. 83 Abs. 5 DSGVO mit bis zu 20 Mio. EUR oder 4 % des weltweiten Jahresumsatzes bedroht — die höchste Bußgeldkategorie.

---

## 5. Handlungsbedarf

### 5.1 Sofortmaßnahmen (vor Go-Live mit Benchmarking)

**Schritt 1 — Rechtsgrundlage definieren:**

CORE muss für die eigenständige Verarbeitung eine Rechtsgrundlage festlegen. Zwei Optionen:

**Option A — Einwilligung (Art. 6 Abs. 1 lit. a DSGVO):**
- Im Submit-Formular explizite Einwilligung für CORE's eigenständige Verarbeitung einholen
- Granular: separate Checkbox für "Benchmarking und Marktanalyse durch CORE"
- Widerrufbar — erfordert technische Löschpflicht bei Widerruf
- Vorteil: Klare Rechtsgrundlage, politisch robust
- Nachteil: Opt-out-Rate reduziert Datenbasis

**Option B — Berechtigtes Interesse (Art. 6 Abs. 1 lit. f DSGVO):**
- Dreistufentest gemäß EDSA-Leitlinien (Oktober 2024) — analog zu Befund 07
- Interessenabwägung: Plattformverbesserung vs. Erwartungshaltung der Gründer
- Ergebnis des Dreistufentests ist **offen und nicht trivial** — gegenwärtig unklar, ob er positiv ausfällt
- Vorteil: Kein Opt-out-Risiko
- Nachteil: Angreifbar, hoher Dokumentationsaufwand

**Empfehlung:** Option A (Einwilligung) — bei einem nicht-trivialen Dreistufentest und angesichts des KRITISCH-Befunds ist Einwilligung die rechtssichere Wahl.

**Schritt 2 — Löschkonzept erstellen:**

- Differenzierte Löschfristen pro Verarbeitungszweck definieren
- Für Auftragsverarbeitung (Art. 28): Frist aus AVV ableiten
- Für eigenständige Verarbeitung: separate Frist festlegen (z.B. 5 Jahre nach letzter Fondsbeziehung)
- Technische Umsetzung: Löschroutine in Supabase (scheduled functions oder manueller Löschprozess mit Nachweis)

**Schritt 3 — Datenschutzerklärung ergänzen:**

Die Datenschutzerklärung muss explizit die eigenständige Verarbeitung durch CORE abdecken:
- Zweck (Benchmarking, Marktanalyse, Produktkalibrierung)
- Rechtsgrundlage (Einwilligung)
- Speicherdauer (konkrete Frist)
- Empfänger (ob Analyseergebnisse weitergegeben werden)
- Betroffenenrechte für diese separate Verarbeitung

**Schritt 4 — Submit-Formular anpassen:**

- Separate Einwilligungsbox für CORE's eigenständige Verarbeitung
- Verlinkung auf Datenschutzerklärung (Abschnitt zur eigenständigen Verarbeitung)
- Formular darf erst nach Bestätigung abschicken können (kein Pre-ticked-Checkbox)

### 5.2 Mittelfristige Maßnahmen

**Technisches Pseudonymisierungskonzept:**

Für Langzeit-Analysezwecke Trennung in:
1. **Identifikatortabelle** (Name, E-Mail, LinkedIn, anon_id) — mit kurzer Aufbewahrungsfrist
2. **Analysedatentabelle** (anon_id, Merkmale, Outcomes) — mit längerer Aufbewahrungsfrist

Nach Ablauf der Frist für die Identifikatortabelle: Löschen des Schlüssels → Analysedaten werden faktisch anonym.

**Art. 26-Vereinbarung vorbereiten (für Cross-Fonds-Benchmarking):**

Sobald CORE Benchmarking-Ergebnisse an Fonds zurückspielt, Art. 26-Vereinbarung abschließen:
- Klare Zuständigkeiten für Betroffenenrechte
- Anlaufstelle für Betroffene
- Benachrichtigungspflichten bei Datenpannen

---

## 6. Offene Fragen (für CORE-Rechtsberatung)

1. **Dreistufentest für berechtigtes Interesse:** Bevor Option B (berechtigtes Interesse) in Betracht gezogen wird, muss ein formaler Dreistufentest durchgeführt werden — Ergebnis ist offen.

2. **Cross-Fonds-Benchmarking:** Ist geplant, dass Fonds Benchmarking-Ergebnisse sehen? Falls ja, sofortige Art. 26-Analyse erforderlich.

3. **Retroaktive Einwilligung:** Für bereits gespeicherte Submissions (vor Implementierung der Einwilligungslösung) muss geklärt werden, ob und wie Einwilligung nachgeholt werden kann — oder ob diese Daten gelöscht werden müssen.

---

## 7. Relevante Rechtsnormen

| Artikel | Inhalt |
|---|---|
| Art. 4 Nr. 7 DSGVO | Definition Verantwortlicher |
| Art. 5 Abs. 1 lit. b DSGVO | Zweckbindungsgrundsatz |
| Art. 5 Abs. 1 lit. e DSGVO | Speicherbegrenzungsgrundsatz |
| Art. 6 Abs. 4 DSGVO | Kompatibilitätsprüfung bei Zweckänderung |
| Art. 13/14 DSGVO | Informationspflichten bei Erhebung |
| Art. 17 DSGVO | Recht auf Löschung |
| Art. 21 DSGVO | Widerspruchsrecht (bei berechtigtem Interesse) |
| Art. 26 DSGVO | Gemeinsame Verantwortlichkeit |
| Art. 28 DSGVO | Auftragsverarbeitung |
| Art. 83 Abs. 5 DSGVO | Bußgeldrahmen (bis 20 Mio. EUR / 4 % Jahresumsatz) |
| EwG 26 DSGVO | Anonymisierungsdefinition |
| Art. 89 DSGVO | Ausnahme für Forschung und Statistik (nicht anwendbar) |

## 8. Relevante Rechtsprechung

| Entscheidung | Relevanz |
|---|---|
| EuGH C-40/17 (Fashion ID) | Gemeinsame Verantwortlichkeit bei unterschiedlichen Verarbeitungsphasen |
| EuGH C-210/16 (Wirtschaftsakademie) | Gemeinsame Verantwortlichkeit — auch ohne formalen Vertrag |
| EuGH C-252/21 (Meta/Bundeskartellamt) | Zweckbindung bei Datenzusammenführung aus verschiedenen Quellen |
| EuGH C-817/19 (Ligue des droits humains) | Fehlendes Löschkonzept heilt nicht durch nachträgliche Behauptungen |
| EDSA Opinion 5/2019 | Anonymisierungstests (Singling-out, Linkability, Inference) |
| EDSA-Leitlinien 09/2021 (Art. 26) | Anforderungen an gemeinsame Verantwortlichkeitsvereinbarungen |

---

## 9. Fazit

CORE befindet sich in einer Rollendopplung: Auftragsverarbeiter für den Fonds und eigenständiger Verantwortlicher für eigene Analysezwecke. Diese Rollendopplung ist rechtlich zulässig, muss aber sauber strukturiert und dokumentiert werden.

**Gegenwärtig fehlen:**
- Eine Rechtsgrundlage für die eigenständige Verarbeitung (Zweckänderung ohne Einwilligung = Verstoß gegen Art. 5 Abs. 1 lit. b)
- Differenzierte Löschfristen (unbegrenzte Speicherung = Verstoß gegen Art. 5 Abs. 1 lit. e)
- Informationen in der Datenschutzerklärung zur eigenständigen Verarbeitung (Verstoß gegen Art. 13 DSGVO)
- Technische Garantien für den Pseudonymisierungsschutz

Alle drei Verstöße betreffen die Grundsätze nach Art. 5 DSGVO — die höchste Bußgeldkategorie. Die Maßnahmen unter Abschnitt 5.1 müssen **vor** dem Start der Benchmarking-Funktion umgesetzt sein.

---

*Erstellt im Rahmen des systematischen DSGVO-Audits von CORE, 07. Juni 2026.*
*Dieser Befund stellt keine anwaltliche Beratung dar. Für rechtlich verbindliche Einschätzungen ist qualifizierter Rechtsrat einzuholen.*
