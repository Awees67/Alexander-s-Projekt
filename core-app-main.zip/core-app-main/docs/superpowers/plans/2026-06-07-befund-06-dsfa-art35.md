# Befund 06 — Art. 35 DSGVO: Datenschutz-Folgenabschätzung (DSFA) fehlt — zwingend erforderlich

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** KRITISCH  
**Kategorie:** A — Fehlende Pflichtdokumentation, Verarbeitung ohne vorherige DSFA  
**Betrifft:** Gesamtsystem — api/submit.js, js/custom-index.js, js/state.js, js/config.js (PIPELINE_TRANSITIONS), Supabase-Datenbankstruktur, Datenschutzerklärung v5.6.2026  
**Referenz:** Art. 35 DSGVO, Art. 36 DSGVO, Art. 83 Abs. 4 DSGVO; EDSA-Leitlinien WP248 rev.01; österreichische DSFA-V (BGBl II Nr. 278/2018)

---

## Was ist das Problem?

Art. 35 DSGVO verpflichtet den Verantwortlichen, **vor Aufnahme** einer risikoreichen Verarbeitungstätigkeit eine Datenschutz-Folgenabschätzung (DSFA) durchzuführen. Eine DSFA ist eine strukturierte, dokumentierte Vorabprüfung: Was wird mit Personendaten gemacht, welche Risiken entstehen für die Betroffenen, und welche Massnahmen begrenzen diese Risiken?

**Für CORE existiert keine DSFA.** Das Scoring-System ist in Betrieb — Gründerdaten werden verarbeitet, ein Signal-Score wird berechnet, Pipeline-Entscheidungen werden davon beeinflusst. Das ist nicht der Zustand, der vor einer DSFA erlaubt wäre. Die DSFA war Voraussetzung, nicht Nachschritt.

Das ist kein formaler Dokumentationsmangel. Eine fehlende DSFA bei einer Verarbeitung, die zwingend eine erfordert, ist ein eigenständiger Verstoss nach Art. 83 Abs. 4 DSGVO — mit einem Bussgelddrahmen von bis zu 10 Millionen Euro oder 2 % des weltweiten Jahresumsatzes.

---

## Warum ist eine DSFA für CORE zwingend?

Die DSFA-Pflicht wird durch **vier unabhängige, kumulierende Auslöser** begründet. Es reicht ein einziger — bei CORE treffen alle vier zu.

---

### Auslöser 1 — Art. 35 Abs. 1 DSGVO: Grundtatbestand (hohes Risiko)

Art. 35 Abs. 1 DSGVO löst die DSFA-Pflicht aus, wenn eine Verarbeitung "aufgrund der Art, des Umfangs, der Umstände und der Zwecke der Verarbeitung voraussichtlich ein hohes Risiko für die Rechte und Freiheiten natürlicher Personen zur Folge" hat.

Die Verarbeitung in CORE ist risikoreich aus folgenden Gründen:

**Art der Verarbeitung:** Automatisierte Bewertung von Personen (Profiling nach Art. 4 Nr. 4 DSGVO) mit direktem Einfluss auf Investitionsentscheidungen. Die Gründer werden nicht nur identifiziert, sondern kategorisiert und mit einem quantitativen Urteil versehen, das dauerhaft gespeichert wird.

**Zweck der Verarbeitung:** Das Ziel des Scores ist explizit, Investitionsentscheidungen zu steuern. Das ist kein Nebenzweck — es ist die erklärte Funktion des Systems.

**Umstände:** Gründer in einer frühen Phase ihres Unternehmens sind auf Kapitalzugang angewiesen. Ein falscher Score kann sie von Gesprächen ausschliessen, die für das Fortbestehen ihres Unternehmens — und damit für ihren Lebensunterhalt — entscheidend sind.

**Einschätzung Auslöser 1:** Bejaht.

---

### Auslöser 2 — Art. 35 Abs. 3 lit. a DSGVO: Automatisches Regelbeispiel

Art. 35 Abs. 3 lit. a DSGVO nennt drei Regelbeispiele, bei denen eine DSFA **immer** erforderlich ist — ohne dass eine Einzelfallprüfung des Risikos nötig wäre. Einschlägig für CORE ist lit. a:

> "systematische und umfassende Bewertung persönlicher Aspekte natürlicher Personen, die sich auf automatisierte Verarbeitung einschliesslich Profiling gründet und die ihrerseits als Grundlage für Entscheidungen dient, die Rechtswirkung gegenüber natürlichen Personen entfalten oder diese in ähnlich erheblicher Weise beeinträchtigen."

**Prüfung jedes Tatbestandsmerkmals:**

| Merkmal | CORE-Sachverhalt | Erfüllt? |
|---|---|---|
| Systematische Bewertung | Signal-Score wird bei jeder Einreichung automatisch berechnet — kein Einzelfall, sondern Standardprozess | ✓ |
| Persönliche Aspekte natürlicher Personen | has_repeat_founder, has_prior_exit, years_experience, education, exit_detail — das sind Merkmale der Gründer als Personen | ✓ |
| Automatisierte Verarbeitung | Score wird serverseitig ohne menschliches Zutun berechnet (api/submit.js) und clientseitig erneut berechnet (state.js Zeile 191) | ✓ |
| Profiling | Regeldefinition Art. 4 Nr. 4: automatisierte Verarbeitung zur Bewertung persönlicher Aspekte — erfüllt | ✓ |
| Grundlage für Entscheidungen | Der Score dient dem Fondsmitarbeiter als primäre Entscheidungsgrundlage bei der manuellen Pipeline-Einstufung. Art. 35 Abs. 3 lit. a verlangt keine *ausschliesslich* automatisierte Entscheidung — das ist der strengere Massstab von Art. 22 Abs. 1. Art. 35 genügt es, dass automatisiertes Profiling als informationelle Grundlage für menschliche Entscheidungen mit erheblicher Wirkung dient. | ✓ |
| Ähnlich erhebliche Beeinträchtigung | Declined = kein Investment-Gespräch mit diesem Fonds; wirtschaftlich erheblich für Gründer in der Kapitalaufnahmephase | ✓ |

**Alle sechs Tatbestandsmerkmale sind erfüllt. Das ist ein Regelbeispiel — keine Auslegungsfrage, keine Grauzone. Die DSFA ist zwingend.**

---

### Warum Art. 35 auch bei manuellen Entscheidungen greift — Abgrenzung zu Art. 22

Dieser Punkt ist zentral und muss explizit klargestellt werden, weil er zunächst kontraintuitiv wirkt.

**Befund 05 (v2) hat festgestellt:** Art. 22 Abs. 1 DSGVO greift nicht, weil der Pipeline-Status bei CORE *immer* manuell von einem Fondsmitarbeiter gesetzt wird. Der Signal-Score ist ein informativer Thesis-Match-Indikator — kein automatischer Entscheidungsauslöser.

**Diese Feststellung ändert nichts an der DSFA-Pflicht aus Art. 35.** Der Grund liegt in einem bewussten gesetzgeberischen Unterschied:

| Norm | Wortlaut (Entscheidungsmerkmal) | Rechtsfolge |
|---|---|---|
| **Art. 22 Abs. 1** | Entscheidung *"ausschliesslich"* auf automatisierter Verarbeitung | Verbot automatisierter Entscheidungen (mit Ausnahmen) |
| **Art. 35 Abs. 3 lit. a** | Automatisiertes Profiling *"dient als Grundlage"* für erhebliche Entscheidungen | Pflicht zur Datenschutz-Folgenabschätzung |

Art. 22 schützt vor vollautomatischen Entscheidungen ohne menschliches Zutun. Art. 35 ist ein Vorsorge-Instrument mit niedrigerem Auslöseschwellenwert — er greift bereits wenn automatisiertes Profiling *mitentscheidend* ist, auch wenn ein Mensch das letzte Wort hat.

**Konkretes Beispiel:** Ein Fondsmitarbeiter prüft eine Einreichung mit Signal-Score 28/100. Er sieht den Score, liest die Einreichung, klickt auf "Declined". Die Entscheidung ist manuell — Art. 22 greift nicht. Aber: Die automatisch berechneten Gründerprofile (has_repeat_founder: false, has_prior_exit: false) und der Score haben seine Entscheidung informiert und strukturiert. Das automatisierte Profiling *diente als Grundlage* für die erhebliche Entscheidung — Art. 35 Abs. 3 lit. a ist erfüllt.

Der EDSA bestätigt diese Lesart in WP248 rev.01 ausdrücklich: Art. 35 hat eine breitere Erfassungsreichweite als Art. 22. DSFA-Pflicht und Art.-22-Anwendbarkeit sind zwei getrennte Prüfungen.

---

### Auslöser 3 — Österreichische DSFA-V (BGBl II Nr. 278/2018): Nationale Muss-Liste

Art. 35 Abs. 4 DSGVO erlaubt nationalen Aufsichtsbehörden, eine Liste von Verarbeitungsarten zu erstellen, für die eine DSFA stets erforderlich ist. Österreich hat diese Befugnis genutzt: Die **Datenschutz-Folgenabschätzung-Verordnung (DSFA-V, BGBl II Nr. 278/2018)** ist seit November 2018 in Kraft.

Die DSFA-V enthält unter § 2 (Muss-Liste) folgende für CORE einschlägige Kategorie:

> Verarbeitungsvorgänge, die die **Evaluierung oder Klassifizierung von natürlichen Personen** — einschliesslich der Erstellung von Profilen und Prognosen — betreffen, welche Merkmale zur **wirtschaftlichen Situation, persönlichen Präferenzen und Interessen, Zuverlässigkeit oder des Verhaltens** der Person betreffen, **basierend ausschliesslich auf automatisierter Verarbeitung** und die **negative rechtliche, finanzielle oder physische Wirkungen** für die betroffene Person haben können.

**Für CORE:** Der Signal-Score bewertet die wirtschaftliche Situation des Startups (Revenue, Burn, LTV) und persönliche Aspekte der Gründer (Zuverlässigkeit als Unternehmer: has_repeat_founder, has_prior_exit). Die Evaluierung basiert auf automatisierter Verarbeitung. Die Wirkung ist finanziell (kein Zugang zu Investitionsgesprächen). Alle Tatbestandsmerkmale der österreichischen Muss-Liste sind erfüllt.

**Einschätzung Auslöser 3:** Bejaht — Österreichische Pflichtliste erfasst das System explizit.

---

### Auslöser 4 — EDSA-Leitlinien WP248 rev.01: Mindestens 3 von 9 Kriterien erfüllt

Die Europäische Datenschutzausschuss (EDSA) hat in den Leitlinien WP248 rev.01 neun Kriterien definiert. **Bei zwei oder mehr zutreffenden Kriterien** ist eine DSFA regelmässig erforderlich. Die Bewertung für CORE:

| Nr. | Kriterium | CORE-Einschätzung | Erfüllt? |
|---|---|---|---|
| 1 | Bewertung / Scoring / Profiling natürlicher Personen | Signal-Score bewertet Gründer nach 7 Regelgruppen — Kernfunktion des Tools | **JA** |
| 2 | Automatisierte Entscheidung mit Rechtswirkung oder ähnlich erheblicher Wirkung | Befund 05 (v2) hat klargestellt, dass Art. 22 Abs. 1 nicht greift (Pipeline-Status ist immer manuell). Für dieses EDSA-Kriterium ist das irrelevant: WP248 prüft nicht Art. 22, sondern ob die Verarbeitung zu Entscheidungen führt, die Betroffene erheblich beeinträchtigen — und das tut sie: Declined = kein Investitionsgespräch, erhebliche finanzielle Wirkung | **JA** |
| 3 | Systematische Überwachung | Keine kontinuierliche Beobachtung, einmalige Einreichung | NEIN |
| 4 | Sensible Datenkategorien (Art. 9/10 DSGVO) | Keine Gesundheits-, Religions-, Ethnizitätsdaten | NEIN |
| 5 | Daten schutzbedürftiger Personengruppen | Gründer sind keine schutzbesonderen Gruppen per se | GRAU |
| 6 | Entscheidung, die Betroffene von Rechten oder Diensten ausschliesst | Declined = kein Zugang zu Investitionsgespräch mit diesem Fonds | **JA** |
| 7 | Innovative Technologie (neu, ungetestet) | Regelbasiertes Scoring ist keine KI, aber Kombination mit Profiling und Pipeline ist für VC-Kontext neuartig | GRAU |
| 8 | Grosser Umfang der Verarbeitung | Aktuell Pilotbetrieb — begrenzte Gründerzahl; könnte bei Skalierung relevant werden | NEIN (aktuell) |
| 9 | Zusammenführung von Datensätzen aus verschiedenen Quellen | Aktuell nur Formulardaten; wenn LinkedIn-Daten integriert werden: JA | GRAU |

**Ergebnis: Mindestens 3 Kriterien eindeutig erfüllt (1, 2, 6) — DSFA-Schwelle überschritten.**

---

## Die volle Tragweite: Was eine fehlende DSFA bedeutet

### Zeitpunkt: Die DSFA war vor Beginn der Verarbeitung fällig

Art. 35 Abs. 1 DSGVO verlangt die DSFA "vorab" — also bevor die Verarbeitung aufgenommen wird. CORE verarbeitet bereits echte Gründerdaten. Das bedeutet: die Verarbeitung läuft ohne die erforderliche Vorabprüfung. Nachträglich eine DSFA zu erstellen mindert den Verstoss — es beseitigt ihn nicht rückwirkend.

### Konsequenz für Art. 36: Möglicherweise vorherige Behördenkonsultation erforderlich

Art. 36 DSGVO verlangt, dass der Verantwortliche die Aufsichtsbehörde **vor Aufnahme der Verarbeitung** konsultiert, wenn die DSFA "ein hohes Risiko zur Folge hätte, sofern der Verantwortliche keine Massnahmen zur Eindämmung des Risikos trifft."

Das bedeutet praktisch: Wenn die DSFA durchgeführt wird und zum Ergebnis kommt, dass das Restrisiko trotz Massnahmen noch hoch ist, muss die **österreichische Datenschutzbehörde (DSB)** konsultiert werden — bevor das System weiter in Betrieb bleibt.

Die DSB hat dann bis zu **8 Wochen** (verlängerbar um 6 weitere Wochen) Zeit für eine schriftliche Antwort. In dieser Zeit darf das System nicht für neue Verarbeitungen genutzt werden. Die DSB kann Empfehlungen aussprechen oder Massnahmen anordnen.

**Praktische Konsequenz:** Wenn die DSFA ergibt, dass die Massnahmen aus Befund 05 (Einwilligung, Audit-Trail, manuelle Überprüfung) ausreichend sind, um das Risiko zu senken, entfällt die Konsultationspflicht. Wenn nicht — muss die DSB eingeschaltet werden, bevor das System mit echten Gründerdaten weiterläuft.

### Sanktionen bei fehlender DSFA

Art. 83 Abs. 4 DSGVO erfasst Verstösse gegen Art. 35 und Art. 36:

> "Geldbussen von bis zu 10 000 000 EUR oder im Fall eines Unternehmens von bis zu 2 % seines gesamten weltweiten vorjährigen Jahresumsatzes"

Da der Plattformbetreiber eine natürliche Person ist, gilt kein Unternehmensumsatz als Deckel — es greift der Absolutbetrag von bis zu 10 Millionen Euro. Die DSB Österreich hat in der Vergangenheit (Österreichische Post AG) auch grosse Bußgelder verhängt. Der Einzelfall-Massstab (Anzahl Betroffener, Schwere, Kooperation) bestimmt die tatsächliche Höhe.

---

## Die Lösung — was eine wasserdichte DSFA für CORE enthalten muss

Eine DSFA ist kein juristisches Standardformular. Sie muss die konkrete Verarbeitung beschreiben und für CORE bedeutet das: detailliert, technisch präzise und ehrlich. Hier ist der vollständige Pflichtinhalt nach Art. 35 Abs. 7 DSGVO mit konkreter Ausfüllung für CORE:

---

### Pflichtinhalt (a) — Systematische Beschreibung der Verarbeitungsvorgänge und ihrer Zwecke

**Was dokumentiert werden muss:**

**Datenquellen:** Das Submit-Formular unter `/submit` erhebt von der einreichenden Person sowie den genannten Mitgründern folgende Kategorien:

*Unternehmensdaten:* Unternehmensname, Beschreibung, Sektor, Stage, Gründungsland, Teamgrösse, Zielmärkte, MRR, Wachstumsrate, Burn Rate, Runway, Paying Customers, Net New ARR, Gross Margin, Revenue Churn, CAC, NRR, Logo Churn, TAM, SAM, Ticket-Grösse, Valuation, Total Raised, Investor Count, Cap-Table-Struktur (Founder-Anteile in %, ESOP %, Employee-Equity %).

*Gründerdaten (pro Gründer):* Vollständiger Name, Rolle, LinkedIn-URL, Vorherige Firmen, Vorherige Rollen, Jahre Berufserfahrung, Ausbildung, Stärken-Tags (Checkboxen), Exit-Erfahrung (boolean), Exit-Details (Freitext).

*Kontaktdaten:* E-Mail-Adresse der einreichenden Person (contact_email), Name.

**Serverseite Ableitungen** (api/submit.js):
- Finanzkennzahlen: arr_eur, arpa_eur, acv_eur, ltv_eur, cac_payback_months, ltv_cac_ratio, burn_multiple (5 Kennzahlen)
- Boolesche Gründermerkmale: has_repeat_founder, has_prior_exit, has_technical_founder, has_domain_expert (4 Merkmale)
- Plausibilitätsprüfung: 11 Regeln ergeben status (ok/warning/fail), checks (Einzelergebnisse), summary

**Clientseitige Score-Berechnung** (js/custom-index.js + state.js Zeile 191):
- Signal-Score (0–100) aus 7 Regelgruppen mit gewichteten Punkten und Caps
- Score wird in window-State gespeichert und in pipeline_items persistiert

**Zweck:** Dealflow-Screening des Fonds — strukturierte Vorabprüfung von Startup-Einreichungen zur Entscheidung, ob ein Investitionsgespräch aufgenommen wird.

**Berechtigtes Interesse:** Art. 6 Abs. 1 lit. f — berechtigtes wirtschaftliches Interesse des Fonds an effizientem Dealflow-Screening (für Rohdaten: lit. b; für Ableitungen: lit. f gemäss Befund 04).

**Empfänger:** Fonds-Mitarbeiter mit Zugang zur CORE-Plattform. Kein Transfer an Dritte ausser Attio CRM (geplant).

**Speicherort:** Supabase Frankfurt (EU), Vercel Serverless (EU-Region).

---

### Pflichtinhalt (b) — Bewertung der Notwendigkeit und Verhältnismässigkeit

**Was dokumentiert werden muss:**

**Notwendigkeit der Gründerdaten:** Die Bewertung von Gründerprofilen ist für VC-Investitionsentscheidungen ein Standardkriterium — Investoren entscheiden nach "Team, Markt, Produkt". Die Erhebung von Berufsbiographie, Exit-Erfahrung und technischen Stärken ist notwendig für den Investitionszweck.

**Verhältnismässigkeit der Ableitungen:** Hier ist Begründungsbedarf:
- `ltv_eur` aus drei Rohdaten berechnet: notwendig um LTV/CAC-Ratio zu beurteilen ohne dass Fonds-Mitarbeiter rechnen müssen — vertretbar.
- `has_repeat_founder` aus Stärken-Tags: notwendig um Wiederholungsgründer-Bonus zu berechnen — aber: ist eine permanente boolesche Kategorisierung einer Person verhältnismässig gegenüber einer nur kurzzeitig gespeicherten Bewertung? Diese Frage muss die DSFA ehrlich beantworten und ggf. eine kürzere Speicherdauer für die Ableitungen empfehlen.
- Plausibilitätsprüfung mit 11 Regeln: notwendig zur Qualitätssicherung der Einreichungsdaten — vertretbar.
- Signal-Score 0–100: Notwendigkeit hängt davon ab ob ein milderes Mittel (z.B. kein aggregierter Score, nur Einzelkennzahlen) den Zweck gleich gut erfüllen würde. Die DSFA muss diese Abwägung dokumentieren und begründen, warum ein aggregierter Score notwendig ist.

**Verhältnismässigkeitsprüfung ist keine Formalität.** Wenn die DSFA zu dem Ergebnis kommt, dass bestimmte Ableitungen nicht notwendig sind, muss die Verarbeitung entsprechend angepasst werden.

---

### Pflichtinhalt (c) — Bewertung der Risiken für Rechte und Freiheiten der Betroffenen

**Was dokumentiert werden muss — konkrete Risiken für Gründer:**

**Risiko 1 — Falschklassifizierung durch algorithmischen Fehler:**
Der Score kann einen validen Gründer systematisch falsch bewerten, wenn seine Situation nicht dem Regelwerk entspricht (z.B. ein erfolgreicher B2B-Gründer mit niedrigem MRR aber hohem ACV und langen Sales-Cycles). Wahrscheinlichkeit: mittel. Schadensausmass: hoch (verpasste Finanzierungschance).

**Risiko 2 — Diskriminierungseffekte durch Score-Gewichtung:**
Wenn Score-Gewichte systematisch bestimmte Gründerprofile (z.B. First-Time-Founders ohne Exit, Gründer aus nicht-technischen Sektoren) benachteiligen, ohne dass das sachlich gerechtfertigt ist, kann der Score diskriminierende Wirkung haben — auch ohne diskriminierende Absicht. Das ist schwer nachzuweisen ohne regelmässigen Bias-Audit.

**Risiko 3 — Mangelnde Transparenz der Score-Logik:**
Gründer wissen nicht, nach welchen Kriterien sie bewertet werden. Ein Gründer, der als "Declined" markiert wird, erhält keine Erklärung. Das verletzt das Recht auf Transparenz (Art. 13/14 DSGVO) und das Recht auf Erklärung bei automatisierten Entscheidungen (Art. 22 Abs. 3).

**Risiko 4 — Dauerspeicherung negativer Bewertungen:**
Ein Score von 23/100 mit Status "Declined" bleibt dauerhaft in Supabase gespeichert. Es gibt keine Löschfrist. Ein Gründer, der ein Jahr später mit verbessertem Unternehmen nochmals einreicht, hat seinen historischen Score im System — was eine faire Neubewertung beeinträchtigen kann.

**Risiko 5 — Datenpanne (Supabase-Sicherheitslücke):**
Bei einer Datenpanne bei Supabase Frankfurt wären vollständige Gründerprofile, Finanzdaten, Eigenkapitalanteile und Scoring-Ergebnisse exponiert. Das Schadensausmass wäre erheblich (Geschäftsgeheimnisse, persönliche Daten).

**Risiko 6 — Sekundärnutzung durch den Fonds:**
Wenn der Fonds die Daten über den vereinbarten Zweck (Dealflow-Screening) hinaus verwendet — z.B. für Marktanalysen oder Weitergabe an Co-Investoren — ohne dass das in der Datenschutzerklärung steht, ist das ein separater Verstoss.

---

### Pflichtinhalt (d) — Abhilfemassnahmen zur Risikoreduzierung

**Was dokumentiert werden muss — konkrete Massnahmen:**

**Massnahme zu Risiko 1 (Falschklassifizierung):**
Verpflichtende menschliche Überprüfung vor jeder "Declined"-Entscheidung, dokumentiert im Audit-Trail. Gründer haben Recht auf Darlegung ihres Standpunkts (Art. 22 Abs. 3) — konkret: Widerspruchsverfahren per E-Mail an awees6703@gmail.com, Weiterleitung an Fonds innerhalb 5 Werktage. Diese Massnahmen wurden in Befund 05 detailliert.

**Massnahme zu Risiko 2 (Diskriminierung):**
Jährlicher Bias-Audit: Verteilung der Scores nach Gründer-Charakteristika (Erstgründer vs. Wiederholungsgründer, Sektor, Stage) prüfen ob systematische Ungleichbehandlung vorliegt. Kein technisch aufwändiger Prozess — ein SQL-Export und eine Pivottabelle genügen als Minimalmassnahme.

**Massnahme zu Risiko 3 (Transparenz):**
Öffentliche Dokumentation der Score-Kategorien (nicht notwendigerweise aller Schwellenwerte) auf der Plattformwebsite. Art.-22-Abs.-3-konforme Erklärung auf Anfrage (wer kann erklären, was die Kategorien sind und wie sie gewichtet wurden).

**Massnahme zu Risiko 4 (Dauerspeicherung):**
Maximale Speicherdauer für Signal-Score und boolesche Ableitungen: 24 Monate nach letzter Aktivität mit der Einreichung, dann automatische Nullsetzung der abgeleiteten Felder (nicht Löschung der Einreichung). Technisch: Supabase-Job oder serverseitige Löschfunktion.

**Massnahme zu Risiko 5 (Datenpanne):**
Supabase RLS ist bereits implementiert (CLAUDE.md). Zusätzlich: Datenpannen-Prozess nach Art. 33 DSGVO dokumentieren (72-Stunden-Meldepflicht an DSB, Gründer-Benachrichtigung bei hohem Risiko nach Art. 34).

**Massnahme zu Risiko 6 (Sekundärnutzung):**
AVV mit Fonds enthält Zweckbindungsklausel. Der Fonds darf Daten nur für Dealflow-Screening nutzen. Jede andere Nutzung erfordert eine neue Rechtsgrundlage und muss im AVV stehen.

---

## Prozess: Wie die DSFA wasserdicht erstellt wird

### Schritt 1 — Wer erstellt die DSFA?

Eine DSFA kann intern erstellt werden — ein externer Anwalt ist nicht zwingend. Aber der Text muss technisch präzise (Datenfluss, Score-Logik, Datenbankstruktur) und juristisch korrekt (Art.-35-Abs.-7-Inhalte, Risikoeinschätzung) sein. Empfehlung: Technischen Teil selbst erstellen, juristischen Teil und Risikoabwägung durch österreichischen Datenschutzanwalt prüfen lassen.

**Wer ist für die DSFA verantwortlich?**

Der Verantwortliche nach DSGVO ist der Fonds (APEX Ventures GmbH) — nicht der Plattformbetreiber. Das bedeutet: Die DSFA muss formal vom Fonds durchgeführt und unterzeichnet werden. Der Plattformbetreiber liefert die technische Dokumentation als Grundlage.

**Praktische Umsetzung:** Der Plattformbetreiber erstellt die Teile (a) und (b) der DSFA (technische Beschreibung, Notwendigkeitsprüfung), der Fonds trägt die Risikoabwägung (c) und die Massnahmendokumentation (d). Gemeinsame Unterzeichnung.

### Schritt 2 — Was als Ergebnis herauskommen muss

Drei mögliche DSFA-Ergebnisse:

| Ergebnis | Bedeutung | Nächster Schritt |
|---|---|---|
| **Risiko gering / mittel** | Massnahmen aus Befund 05 sind ausreichend | DSFA dokumentieren, in Art.-30-Verzeichnis eintragen, Verarbeitung kann fortgesetzt werden |
| **Risiko hoch, aber durch Massnahmen gemindert** | Massnahmen aus Befund 05 bringen das Risiko auf akzeptables Niveau | Massnahmen umsetzen, dann DSFA dokumentieren |
| **Risiko hoch, nicht ausreichend gemindert** | Massnahmen reichen nicht aus | DSB Österreich konsultieren (Art. 36) bevor Verarbeitung fortgesetzt wird |

### Schritt 3 — Art. 36: Wann muss die DSB konsultiert werden?

Wenn die DSFA zu Ergebnis 3 kommt, gilt: **Verarbeitung stoppen, DSB konsultieren, auf Antwort warten.** Die DSB hat 8 Wochen (verlängerbar auf 14 Wochen) Zeit. Erst nach ihrer Stellungnahme darf die Verarbeitung aufgenommen/fortgesetzt werden.

**Kontakt DSB Österreich:**  
Österreichische Datenschutzbehörde  
Barichgasse 40–42, 1030 Wien  
dsb@dsb.gv.at | dsb.gv.at  
Konsultationsverfahren: [dsb.gv.at/konsultation](https://dsb.gv.at/ueber-die-datenschutzbehoerde/konsultationsverfahren)

### Schritt 4 — Wo wird die DSFA aufbewahrt?

Die DSFA ist nicht öffentlich — sie ist ein internes Dokument. Sie muss aber:
- Im Art.-30-Verarbeitungsverzeichnis referenziert sein
- Auf Anfrage der DSB vorgelegt werden können
- Bei wesentlichen Änderungen am System (neue Regelgruppen, neue Datenkategorien, neuer Fonds) aktualisiert werden

Die DSFA ist **kein einmaliges Dokument** — sie muss den Lebenszyklus des Systems begleiten.

---

## Zusammenfassung: Was sich ändert

| Was | Wer | Aufwand |
|---|---|---|
| Technische Beschreibung der Verarbeitung (DSFA-Teil a+b) | Plattformbetreiber + Anwalt | 3–5h |
| Risikoabwägung und Massnahmendokumentation (DSFA-Teil c+d) | Fonds + Anwalt | 2–3h |
| Gemeinsame Unterzeichnung der DSFA | Fonds + Plattformbetreiber | 30 Min |
| Referenz im Art.-30-Verarbeitungsverzeichnis | Plattformbetreiber | 15 Min |
| DSFA-Ergebnis prüfen: Art. 36 erforderlich? | Anwalt | Im Rahmen DSFA-Erstellung |
| DSB-Konsultation falls Ergebnis "hohes Restrisiko" | Fonds | 8–14 Wochen Behördenverfahren |
| Technische Massnahmen aus DSFA-Ergebnis | Plattformbetreiber | Abhängig vom Massnahmenkatalog |

---

## Was anwaltlich zu klären bleibt

**Drei Punkte erfordern zwingend anwaltliche Beteiligung:**

1. **Erstellung und Review der DSFA:** Die Risikoabwägung (Teil c) und die Einschätzung ob Massnahmen ausreichen (Teil d) sind rechtliche Urteile — kein technischer Prozess. Ein österreichischer DSGVO-Anwalt muss die DSFA miterstellen und bestätigen, dass das Ergebnis vertretbar ist.

2. **Art.-36-Entscheidung:** Ob die DSFA zum Ergebnis "hohes Restrisiko, DSB-Konsultation erforderlich" führt — das ist eine rechtliche Einschätzung, keine technische. Falsch eingeschätzt in beide Richtungen: Zu streng → unnötiger Behördenaufwand. Zu lax → Verstoss gegen Art. 36.

3. **Verhältnismässigkeit des Scores (DSFA-Teil b):** Die Frage, ob ein aggregierter Score (0–100) verhältnismässig ist gegenüber alternativen Designs (nur Einzelkennzahlen, kein gespeicherter Score), ist eine rechtliche Abwägung — nicht nur eine Product-Entscheidung.

---

*Quellen: Art. 35, 36, 83 DSGVO; EDSA-Leitlinien WP248 rev.01 (Datenschutz-Folgenabschätzung); österreichische DSFA-V BGBl II Nr. 278/2018; DSB Österreich Konsultationsverfahren (dsb.gv.at); Erläuterungen zur DSFA-V (DSB); EDSA-Leitlinien 05/2020 (Einwilligung); EuGH C-634/21 (7. Dezember 2023).*

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
