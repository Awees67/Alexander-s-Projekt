# Befund 13 — Datenschutzerklärung: Vollständigkeit und aktuelle Lücken

**Datum:** 07. Juni 2026
**Projekt:** CORE — Dealflow Screening Platform
**Schweregrad:** KRITISCH
**Betroffene Normen:** Art. 13 DSGVO (Informationspflicht bei Erhebung), Art. 14 DSGVO (Informationspflicht bei Drittweitergabe), Art. 12 DSGVO (Transparenz), Art. 83 Abs. 5 lit. b DSGVO (Bußgeld), nDSG (Schweiz, seit 01.09.2023)
**Status:** Handlungsbedarf identifiziert

---

## 1. Sachverhalt — Ist-Zustand bei CORE

CORE verarbeitet personenbezogene Daten auf zwei Wegen:

1. **Gründer reichen Bewerbung ein** über `/submit/index.html` → Informationspflicht nach **Art. 13 DSGVO** (Daten direkt bei Betroffenen erhoben)
2. **Mitgründer werden nicht direkt informiert** → Informationspflicht nach **Art. 14 DSGVO** (Befund 01, bereits erfasst)

### 1.1 Verfügbare DSE-Dokumente

Aus dem CLAUDE.md und den vorherigen Befunden ergibt sich, dass eine Datenschutzerklärung existiert (referenziert in `/submit/index.html`), aber mehrere kritische Lücken aufweist:

| Anforderung | Art. 13 DSGVO | Ist-Stand |
|---|---|---|
| Identität und Kontaktdaten des Verantwortlichen | Abs. 1 lit. a | Unklar — "CORE" ohne vollständige Rechtsform, Adresse |
| Kontaktdaten Datenschutzbeauftragter (falls vorhanden) | Abs. 1 lit. b | Nicht bekannt |
| Verarbeitungszwecke und Rechtsgrundlagen | Abs. 1 lit. c/d | Teilweise (für Fonds-Screening), NICHT für CORE-eigene Zwecke (Benchmarking) |
| Berechtigte Interessen (wenn Art. 6 Abs. 1 lit. f Grundlage) | Abs. 1 lit. d | Nicht angegeben |
| Empfänger der Daten | Abs. 1 lit. e | Nur generisch "VC-Fonds" — **kein dynamischer Verweis auf den konkreten Fonds** |
| Drittlandtransfers (Supabase, Vercel) | Abs. 1 lit. f | Unklar ob dokumentiert |
| Speicherdauer oder Kriterien dafür | Abs. 2 lit. a | Nicht definiert (Befund 11) |
| Betroffenenrechte (Auskunft, Löschung, Berichtigung, Einschränkung, Widerspruch, Portabilität) | Abs. 2 lit. b–e | Unklar ob vollständig |
| Widerrufsrecht bei Einwilligung | Abs. 2 lit. c | Unklar |
| Beschwerderecht bei Aufsichtsbehörde | Abs. 2 lit. d | Unklar |
| Pflicht zur Bereitstellung (vertraglich/gesetzlich) | Abs. 2 lit. e | Nicht kommuniziert |
| Automatisierte Entscheidungsfindung (Art. 22) | Abs. 2 lit. f | Nicht thematisiert (Signal-Score erläutert?) |

### 1.2 Kritische strukturelle Lücken

#### Lücke A: CORE-eigene Zwecke nicht transparent

Die DSE deckt (bestenfalls) die Verarbeitung im Auftrag des jeweiligen VC-Fonds ab. Die eigenständige Verarbeitung durch CORE (Benchmarking, Cross-Fonds-Analyse, Produktkalibrierung — Befund 09) ist in keiner DSE-Version beschrieben. Gründer haben damit keine Information über:
- Wer der Verantwortliche für diese Zwecke ist (CORE, nicht der Fonds)
- Welche Rechtsgrundlage gilt (Einwilligung? Berechtigte Interessen?)
- Wie lange Daten für diese Zwecke gespeichert werden
- Welche Rechte sie gegenüber CORE (nicht dem Fonds) geltend machen können

#### Lücke B: Dynamische Fondsanzeige fehlt

Ein Gründer, der über die CORE-Submit-Strecke einreicht, muss wissen, **welcher VC-Fonds** seine Daten erhält. Empfänger sind nach Art. 13 Abs. 1 lit. e DSGVO zu nennen. Wenn verschiedene Fonds dieselbe Submit-URL nutzen, muss die DSE den konkreten Fonds dynamisch ausweisen (oder mindestens eine Kategorienbeschreibung mit klarem Identifikationsweg).

Der EDSA hat in seiner Stellungnahme vom 7. Oktober 2024 zu Auftragsverarbeitern klargestellt: Der Verantwortliche (Fonds) muss sicherstellen, dass die betroffene Person über alle Empfänger informiert ist. CORE als Auftragsverarbeiter muss dem Fonds die notwendigen Informationen liefern — fehlt die Infrastruktur dafür, kann der Fonds seine Art. 13-Pflicht nicht erfüllen.

#### Lücke C: Schweizer Fonds und nDSG

Wenn CORE auch Schweizer VC-Fonds bedient (oder Gründer aus der Schweiz Bewerbungen einreichen), greift seit 01.09.2023 das revidierte Schweizer Datenschutzgesetz (nDSG). Wesentliche Unterschiede zur DSGVO:
- **Informationspflicht**: Vergleichbar mit Art. 13 DSGVO, aber mit anderen Formulierungsanforderungen
- **Datenschutzerklärung ist Pflicht**: Explizit gefordert bei jeder Datenerhebung
- **Internationaler Datentransfer**: Strengere Anforderungen als DSGVO — Empfängerländer müssen als "angemessenes Schutzniveau" eingestuft sein oder Schutzmaßnahmen getroffen werden
- **Einwilligung**: nDSG erlaubt Datenbearbeitung grundsätzlich ohne Einwilligung, wenn informiert wird; DSGVO braucht Rechtsgrundlage
- **Bußgelder**: Bis CHF 250.000, aber **persönlich gegen natürliche Personen** (Geschäftsführer), nicht gegen das Unternehmen

---

## 2. Rechtsgrundlage

### Art. 13 Abs. 1 DSGVO — Pflichtangaben bei direkter Erhebung

> „Werden personenbezogene Daten bei der betroffenen Person erhoben, so teilt der Verantwortliche der betroffenen Person zum Zeitpunkt der Erhebung dieser Daten Folgendes mit: [a–f]"

Zeitpunkt: Die Information muss **bei Erhebung** vorliegen, also vor oder bei Absenden des Submit-Formulars.

### Art. 13 Abs. 2 DSGVO — Weitere Pflichtangaben

Ergänzende Angaben, die für eine faire und transparente Verarbeitung notwendig sind (Speicherdauer, Betroffenenrechte, Widerrufsrecht, Beschwerderecht, automatisierte Entscheidungen).

### Art. 12 Abs. 1 DSGVO — Transparenzgebot

> „Der Verantwortliche trifft geeignete Maßnahmen, um der betroffenen Person alle Informationen [...] in präziser, transparenter, verständlicher und leicht zugänglicher Form in einer klaren und einfachen Sprache zu übermitteln."

### Art. 83 Abs. 5 lit. b DSGVO — Bußgeldrisiko

Verstöße gegen Art. 12, 13, 14 DSGVO können mit Bußgeldern bis zu **20 Mio. EUR oder 4 % des weltweiten Jahresumsatzes** bestraft werden. Die DSE-Lücken zählen zu den häufigsten Bußgeldtatbeständen in der DSGVO-Praxis.

### EDSA-Stellungnahme 07.10.2024 — Empfängerangaben bei Auftragsverarbeitern

Der EDSA hat klargestellt, dass Auftragsverarbeiter (hier: CORE) proaktiv die zur Erfüllung der Art.-13-Informationspflicht notwendigen Informationen an den Verantwortlichen (Fonds) liefern müssen — insbesondere Identität, Kontaktdaten und verarbeitete Datenkategorien. Fehlt diese Infrastruktur, kann der Verantwortliche seine Pflicht nicht erfüllen.

### nDSG (Schweiz) — Art. 19/20 nDSG

Art. 19 nDSG entspricht im Kern Art. 13 DSGVO: Pflicht zur Information bei Erhebung von Personendaten. Art. 20 nDSG regelt die Informationspflicht bei Weiterbearbeitung. Besonderheit: nDSG greift auch für **Unternehmen außerhalb der Schweiz**, wenn sie Daten von Personen in der Schweiz bearbeiten (Marktortprinzip, Art. 3 Abs. 2 nDSG) — analog DSGVO Art. 3 Abs. 2.

---

## 3. Rechtliche Analyse

### 3.1 Fehlen von CORE-eigenen Verarbeitungszwecken in der DSE

Wie in Befund 09 festgestellt, ist CORE für Benchmarking und Marktanalyse eigenständiger Verantwortlicher. Eine DSE, die nur die Auftragsverarbeitung für VC-Fonds beschreibt, deckt diese Zwecke nicht ab. Damit fehlt für die eigenständige CORE-Verarbeitung **jede Art.-13-Information** — ein klarer Verstoß.

### 3.2 Dynamische Fondsidentifikation ist technisch lösbar

Die Herausforderung bei Multi-Mandanten-SaaS (mehrere Fonds, eine Submit-URL) kann durch zwei Ansätze gelöst werden:
1. **Fondsindividuelle Submit-URLs** mit fondsindividueller DSE — technisch sauber, aber aufwändig
2. **Dynamische Anzeige des Fondsnamens** auf der Submit-Seite + Verweis auf die fondsindividuelle DSE in der Bestätigungs-E-Mail

Option 2 ist bei CORE sofort umsetzbar, da `window.fundName` bereits aus Supabase geladen wird.

### 3.3 Signal-Score und Art. 13 Abs. 2 lit. f DSGVO

Art. 13 Abs. 2 lit. f verlangt bei automatisierten Entscheidungen einschließlich Profiling Informationen über „die involvierte Logik sowie die Tragweite und die angestrebten Auswirkungen". Der Signal-Score wird in der DSE vermutlich nicht erwähnt. Auch wenn Art. 22 DSGVO (automatisierte Einzelentscheidungen) nicht greift (Befund 05v2), muss der Signal-Score als Profiling-Maßnahme transparent gemacht werden, wenn er für Screening-Entscheidungen genutzt wird.

### 3.4 Beschwerderecht und zuständige Behörde

Art. 13 Abs. 2 lit. d verlangt Hinweis auf das Beschwerderecht bei der zuständigen Aufsichtsbehörde. Die DSE muss die konkrete Behörde benennen (z.B. BfDI, zuständiges Landesamt, DSB Wien). Ohne diese Angabe ist die DSE unvollständig.

### 3.5 nDSG: Erhöhtes persönliches Haftungsrisiko

Im Gegensatz zur DSGVO, die Unternehmen (juristische Personen) mit Bußgeldern belegt, richten sich nDSG-Sanktionen **gegen natürliche Personen** (Geschäftsführer, Datenschutzverantwortliche). Bei Verstößen gegen die Informationspflichten drohen Bußgelder bis CHF 250.000 persönlich. Wenn CORE mit Schweizer Fonds oder Schweizer Gründern arbeitet, besteht dieses Risiko.

---

## 4. Handlungsbedarf

### Sofortmaßnahmen (0–4 Wochen)

1. **DSE-Audit durchführen** — Vollständige Prüfung der aktuellen Datenschutzerklärung gegen die Checkliste aus Art. 13 Abs. 1 und Abs. 2 DSGVO. Alle fehlenden Angaben identifizieren und ergänzen.

2. **CORE-eigene Verarbeitungszwecke in DSE aufnehmen** — Separate Sektion "Verarbeitung durch CORE als eigenständigen Verantwortlichen" mit:
   - Zweck: Benchmarking, Produktverbesserung, Marktanalysen
   - Rechtsgrundlage: Einwilligung (Art. 6 Abs. 1 lit. a) oder berechtigte Interessen (Art. 6 Abs. 1 lit. f mit Dreistufentest)
   - Speicherdauer
   - Widerspruchsrecht

3. **Dynamische Fondsnamenanzeige** — In der Submit-Strecke den Namen des Fonds (aus `window.fundName`) prominent vor dem Formular anzeigen: "Sie bewerben sich bei [Fondsname]. Ihre Daten werden verarbeitet von [Fondsname] (Verantwortlicher) und CORE Platform GmbH (Auftragsverarbeiter)."

4. **Beschwerderecht: Konkrete Behörde benennen** — Je nach CORE-Hauptsitz: BfDI (Bund), zuständiges Landesamt oder DSB Wien. Kontaktdaten in DSE einfügen.

### Mittelfristige Maßnahmen (1–3 Monate)

5. **Signal-Score transparent machen** — Abschnitt in DSE: "CORE berechnet einen sog. Signal-Score als Hilfsmittel für Fondsmitarbeiter. Dieser Score ist kein automatisierter Entscheid, sondern ein visuelles Screening-Hilfsmittel. Die Entscheidung über Investitionen trifft ausschließlich der jeweilige Fonds."

6. **Fondsindividuelle DSE-Strecke aufbauen** — Bei jedem Fonds-Onboarding: Fondsname, Rechtsform, Adresse, Datenschutzkontakt in CORE hinterlegen. Auf Submit-Seite dynamisch in DSE-Link einbinden.

7. **Drittlandtransfer vollständig dokumentieren** — Supabase (AWS Frankfurt), Vercel (US-Serverless, ggf. Drittlandtransfer!) in DSE mit Rechtsgrundlage (SCCs, Angemessenheitsbeschluss) nennen.

8. **nDSG-Kompatibilitätsprüfung** — Falls Schweizer Fonds oder Schweizer Gründer betroffen: DSE um nDSG-spezifische Angaben ergänzen (Beauftragter in der Schweiz nach Art. 14 nDSG? Datenschutzerklärung auf Deutsch für CH ausreichend?).

### Langfristig (3–12 Monate)

9. **Jährliche DSE-Überprüfung** — Formaler Prozess: bei jeder wesentlichen Produktänderung und mindestens einmal jährlich auf Vollständigkeit und Aktualität prüfen.

10. **Two-Controller-Informationsmodell** — Da CORE sowohl Auftragsverarbeiter (für Fonds) als auch eigenständiger Verantwortlicher (für Benchmarking) ist, braucht jeder dieser Rollen eine eigene transparente Darstellung. Modell: Eine übergreifende DSE mit zwei klar getrennten Abschnitten, oder zwei separate Dokumente.

---

## 5. Fazit

Die Datenschutzerklärung von CORE weist mehrere kritische Lücken auf: Die eigenständigen CORE-Verarbeitungszwecke (Benchmarking, Marktanalyse) sind nicht transparent gemacht, der konkrete VC-Fonds als primärer Empfänger wird nicht dynamisch ausgewiesen, Speicherfristen fehlen, und das Signal-Score-Profiling wird nicht erläutert. Diese Lücken betreffen die Grundlage des Vertrauensverhältnisses mit den Gründern und sind gleichzeitig die am häufigsten sanktionierte Kategorie im DSGVO-Bußgeldregime. Für Schweizer Fonds kommt das persönliche Haftungsrisiko nach nDSG hinzu.

**Schweregrad: KRITISCH** — Fehlende Art.-13-Informationen sind eigenständig bußgeldbewährt (Art. 83 Abs. 5 lit. b: bis 20 Mio. EUR / 4 % Jahresumsatz). Die Lücken sind mit verhältnismäßig geringem Aufwand zu schließen; das Unterlassen ist nicht verhältnismäßig.

---

*Quellen: Art. 13 DSGVO (dejure.org), Art. 12 Abs. 1 DSGVO, Art. 83 Abs. 5 lit. b DSGVO, EDSA-Stellungnahme 07.10.2024 (Rechenschaftspflichten bei Auftragsverarbeitern), nDSG Art. 19/20 (datenschutzkanzlei.de, netaccess.ch), Art. 3 Abs. 2 nDSG (Marktortprinzip), Art. 14 nDSG (Beauftragter in der Schweiz)*
