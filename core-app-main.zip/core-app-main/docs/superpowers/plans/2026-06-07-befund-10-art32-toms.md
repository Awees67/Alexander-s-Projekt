# Befund 10 — Art. 32 DSGVO: Technische und organisatorische Maßnahmen (TOMs)

**Datum:** 07. Juni 2026  
**Schweregrad:** HOCH  
**Status:** Handlungsbedarf identifiziert  
**Betroffene Norm:** Art. 32 DSGVO, ErwGr. 83, BSI-Grundschutz, NIS-2-Umsetzungsgesetz (DE, ab 06.12.2025)

---

## 1. Sachverhalt — Ist-Zustand bei CORE

CORE betreibt eine B2B-SaaS-Plattform, auf der Startup-Gründer personenbezogene Daten (Name, E-Mail, Geschäftsdaten, ggf. Lebensläufe) über ein Einreichungsformular übermitteln. Die Daten werden in einer Supabase-Datenbank (Region: Frankfurt, eu-central-1) gespeichert und von mehreren VC-Fonds verarbeitet.

**Dokumentierte TOMs (Ist-Stand):**

| Maßnahme | Status |
|---|---|
| Supabase Row Level Security (RLS) | Implementiert — fund_id-Isolation auf SELECT/INSERT/UPDATE/DELETE |
| Service Role Key serverseitig | Implementiert — kein Client-seitiger Zugriff |
| Rate Limiting auf /api/submit.js | Implementiert |
| 6 Datenbankindizes | Implementiert |
| Magic Link Auth (kein Passwort) | Implementiert |
| Supabase Frankfurt (EU-Hosting) | Implementiert |

**Fehlende / nicht dokumentierte TOMs:**

| Maßnahme | Status |
|---|---|
| Verschlüsselung at-rest (schriftlich dokumentiert) | Unklar — Supabase verschlüsselt standardmäßig, aber kein AVV-Anhang mit TOM-Dokumentation vorhanden |
| Verschlüsselung in transit (TLS-Version, Cipher-Suites) | Unklar — HTTPS gesetzt, aber keine Protokollversion dokumentiert |
| Zugriffsprotokollierung (Audit Log) | Nicht nachgewiesen — wer greift wann auf welche Daten zu? |
| Backup-Konzept und Wiederherstellungszeiten (RTO/RPO) | Nicht dokumentiert — Supabase bietet automatische Backups, aber kein CORE-eigenes Konzept |
| Penetrationstest / Schwachstellenanalyse | Nicht durchgeführt / nicht dokumentiert |
| Sicherheitskonzept / Informationssicherheitsrichtlinie | Nicht vorhanden |
| Mitarbeiterschulungen Datenschutz | Nicht dokumentiert |
| Verpflichtung auf Vertraulichkeit (Mitarbeiter/Auftragnehmer) | Nicht dokumentiert |
| Notfall- und Wiederherstellungsplan (Business Continuity) | Nicht vorhanden |
| Pseudonymisierung oder Anonymisierung (wo anwendbar) | Nicht umgesetzt (anon_id existiert, aber company_name bleibt im Klartext) |

---

## 2. Rechtsgrundlage

### Art. 32 Abs. 1 DSGVO

> „Der Verantwortliche und der Auftragsverarbeiter treffen unter Berücksichtigung des Stands der Technik, der Implementierungskosten und der Art, des Umfangs, der Umstände und der Zwecke der Verarbeitung sowie der unterschiedlichen Eintrittswahrscheinlichkeit und Schwere des Risikos für die Rechte und Freiheiten natürlicher Personen geeignete technische und organisatorische Maßnahmen, um ein dem Risiko angemessenes Schutzniveau zu gewährleisten."

Art. 32 Abs. 1 lit. a–d DSGVO nennt konkret:
- **lit. a:** Pseudonymisierung und Verschlüsselung
- **lit. b:** Vertraulichkeit, Integrität, Verfügbarkeit und Belastbarkeit
- **lit. c:** Wiederherstellung der Verfügbarkeit (Backup/Recovery)
- **lit. d:** Verfahren zur regelmäßigen Überprüfung, Bewertung und Evaluierung (Penetrationstests, Audits)

### Art. 32 Abs. 2 DSGVO

Die Risikobewertung muss Vernichtung, Verlust, Veränderung, unbefugte Offenlegung und unbefugten Zugang einschließen — bei CORE besonders relevant angesichts sensibler Startup-Investitionsdaten.

### ErwGr. 83 DSGVO

> „Der Verantwortliche sollte die mit der Verarbeitung verbundenen Risiken bewerten und Maßnahmen ergreifen, um diese Risiken zu mindern, wie z.B. Verschlüsselung."

### NIS-2-Umsetzungsgesetz (Deutschland, ab 06.12.2025)

Das NISG-2-Umsetzungsgesetz verschärft die Anforderungen an Cybersicherheitsmaßnahmen. Für SaaS-Anbieter, die Dienste für Unternehmen in Deutschland erbringen, gelten erhöhte Mindestanforderungen: Risikoanalysen, Sicherheitskonzepte, Vorfallmanagementsysteme, Business-Continuity-Pläne, Supply-Chain-Sicherheit. Die Überschneidung mit DSGVO-TOMs ist erheblich.

### Art. 28 Abs. 3 lit. c DSGVO

Im Rahmen des AVV muss CORE als Auftragsverarbeiter dem Fonds gegenüber dokumentiert nachweisen, welche TOMs er einsetzt. Ohne TOM-Dokumentation ist der AVV unvollständig und damit rechtswidrig.

---

## 3. Rechtliche Analyse

### 3.1 Formale Dokumentationslücke (Art. 5 Abs. 2, Art. 32 DSGVO)

Das Rechenschaftsprinzip (Art. 5 Abs. 2 DSGVO) verlangt, dass CORE die Einhaltung der DSGVO **nachweisen** kann. Ohne eine schriftliche TOM-Dokumentation — unabhängig davon, ob die Maßnahmen technisch implementiert sind — besteht eine formale Verletzung. Aufsichtsbehörden und Auftraggeber-Fonds können die Dokumentation verlangen; fehlt sie, droht ein Bußgeld unabhängig vom tatsächlichen Sicherheitsniveau.

### 3.2 Fehlende Zugriffsprotokollierung

Die Verarbeitung sensibler Investitionsdaten durch mehrere Fondsmitarbeiter ohne Zugriffsprotokoll widerspricht dem Stand der Technik. Bei einem Datenpannenfall kann CORE weder Art noch Umfang unbefugter Zugriffe rekonstruieren, was die 72h-Meldepflicht (Art. 33) faktisch unmöglich macht.

### 3.3 Backup ohne dokumentiertes RTO/RPO

Supabase bietet automatische Backups; diese sind jedoch nicht in einem CORE-eigenen Business-Continuity-Plan dokumentiert. Die Verfügbarkeitsanforderung (Art. 32 Abs. 1 lit. b: „die Belastbarkeit der Systeme") ist ohne definierte Recovery-Ziele nicht nachweisbar erfüllt.

### 3.4 Kein Penetrationstest

Art. 32 Abs. 1 lit. d DSGVO fordert „Verfahren zur regelmäßigen Überprüfung". Ein einmaliger oder nie durchgeführter Penetrationstest erfüllt diese Anforderung nicht. Insbesondere die Serverless-API (Vercel, api/submit.js) und die RLS-Konfiguration sollten regelmäßig geprüft werden.

### 3.5 Verhältnismäßigkeit

CORE ist ein frühes B2B-SaaS-Produkt. Art. 32 DSGVO schreibt keine Goldstandard-Sicherheit vor, sondern einen **risikoangemessenen** Ansatz. Die verarbeiteten Daten umfassen Startup-Gründerdaten (potenziell wirtschaftlich sensitiv) und mehrere Fondsmandanten — das Risiko ist als MITTEL bis HOCH einzustufen. Ein vollständiges ISMS wäre überdimensioniert, aber eine schriftliche TOM-Dokumentation mit Basis-Controls ist zwingend.

---

## 4. Handlungsbedarf

### Sofortmaßnahmen (0–4 Wochen)

1. **TOM-Dokument erstellen** — Schriftliche Zusammenfassung aller implementierten technischen und organisatorischen Maßnahmen als Anhang zum AVV. Mindestens: Verschlüsselung (at-rest/in-transit), Zugriffskontrollen (RLS, Service Role Key), Authentifizierung (Magic Link), Hosting-Standort (Frankfurt), Rate Limiting.

2. **Supabase-Datenbankeinstellungen dokumentieren** — pg_crypt / AES-256 at-rest (Supabase-Standard), TLS 1.2/1.3 in transit. Supabase-Sicherheitsseite als Nachweis referenzieren.

3. **Backup-Policy** — Supabase-Backup-Einstellungen (Point-in-Time Recovery, Retention) schriftlich festhalten. RTO/RPO definieren (z.B. RTO: 4h, RPO: 24h).

### Mittelfristige Maßnahmen (1–3 Monate)

4. **Zugriffsprotokollierung einrichten** — Supabase bietet Audit-Logging. Aktivieren und Retention-Zeitraum definieren (mind. 6 Monate empfohlen).

5. **Vertraulichkeitsverpflichtung** — Alle Mitarbeiter und Auftragnehmer, die Zugang zu Produktionsdaten haben, schriftlich auf Vertraulichkeit verpflichten.

6. **Einmaliger Penetrationstest** — Fokus auf: RLS-Bypass-Versuche, API-Injection, Auth-Bypass. Ergebnis dokumentieren, Findings beheben.

7. **Mitarbeiterschulungen** — Jährliche Datenschutz-Grundschulung (kann als Online-Kurs erfolgen), Teilnahme dokumentieren.

### Langfristig (3–12 Monate)

8. **Jährliche TOM-Überprüfung** — Formaler Review-Prozess, wann immer sich die Infrastruktur ändert oder neue Fondsmandate ongeboardet werden.

9. **NIS-2-Gap-Analyse** — Prüfen, ob CORE unter den Anwendungsbereich des NIS-2-Umsetzungsgesetzes fällt (Größe, Sektor). Falls ja: erweiterte Anforderungen umsetzen.

---

## 5. Fazit

CORE hat einen soliden technischen Unterbau (RLS, serverseitige Keys, EU-Hosting), aber die **schriftliche TOM-Dokumentation fehlt vollständig**. Dies ist die gravierendste Lücke, da ohne Dokumentation das Rechenschaftsprinzip nicht erfüllt werden kann. Zugriffsprotokollierung und Backup-Konzept sind zusätzliche Lücken, die das Risiko im Schadensfall erhöhen. Priorität: Sofortiges Erstellen eines TOM-Dokuments als AVV-Anhang.

**Schweregrad: HOCH** — Keine unmittelbare Datenschutzverletzung, aber erhebliche Compliance-Lücke mit Bußgeldrisiko bei Aufsichtsbehörden-Prüfung oder Kundennachfrage.

---

*Quellen: Art. 32 DSGVO (dsgvo-gesetz.de), ErwGr. 83, Art. 28 Abs. 3 lit. c DSGVO, NIS-2-Umsetzungsgesetz DE (06.12.2025), Art. 5 Abs. 2 DSGVO (Rechenschaftsprinzip)*
