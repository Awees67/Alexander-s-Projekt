# Detailansicht + App-Header Redesign (Design System v2) — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Detailansicht (Modal) und globalen App-Header 1:1 auf das Detail-Mockup (Design System v2, Dark) umstellen — inkl. zweier neuer Datenfelder (`founded_year`, `net_new_mrr_eur`) mit DB-Migrationen.

**Architecture:** Das Detail-Modal (`openModalWithStartup` in `js/renderers-modals.js`) hat bereits alle 8 Sektionen des Mockups — der Großteil ist CSS-Re-Skin der 108 `dv-*`-Regeln (alle im `!important`-Block ab `styles/main.css:1961`, Tokens `--text-*`/`--surface-*`). Dark-Styling wird über **scoped v2-Tokens am Modal-Root** erreicht (Detail immer dark, unabhängig vom Theme-Toggle — Doku: „kein separates Light-Mode-CSS"). Header: Brand-Bar + `viewnav-bar` werden zu EINEM 52px-Header zusammengelegt (Doku §5), fix dark, alle bestehenden Button-/Tab-IDs bleiben. Das Modal rückt unter den sticky Header (`top:52px`), Nav-Klick bei offenem Modal schließt es.

**Tech Stack:** Vanilla HTML/CSS/JS, Supabase (MCP-Migrationen), Puppeteer/Playwright-Verifikation lokal.

---

## Analyse-Ergebnis: Mockup vs. Ist-Zustand

### Bereits vorhanden (nur Re-Skin / Relabel)
| Mockup-Element | Ist-Zustand | Maßnahme |
|---|---|---|
| 8 Sektionen (Kontext … Cap Table) | identische Struktur in `renderers-modals.js:195-300` | CSS |
| Custom Score 86 + „Standard Screening" + ⓘ Breakdown | `dv-score-block` mit `rulesetName` komplett da | CSS |
| Notes-Sidebar (Autor, Zeit, Ctrl-Enter) | `dv-notes`, Supabase-backed | CSS |
| ARPA/ACV/LTV/CAC Payback/Burn Multiple | DB-Spalten + Rows existieren | CSS/Farben |
| Cap Table 3 Zeilen + investor_pct | seit Commit `5e43438` | — |
| „Round Size" / „Raised to Date" | heißt „Ticket" / „Total Raised" | Relabel (kein DB-Impact) |
| Topbar ← Zurück · Weiter → · Compare · Pipeline · Push to CRM · Anfrage senden · ✕ | `dv-topbar` mit allen Buttons/IDs | CSS/Anordnung |

### Neu / DB-Impact
1. **`founded_year`** („Gegründet 2024"): existiert nirgends. → Migration, Submit-Formularfeld (optional), Mapping, Detail-Zeile. Altdaten: NULL → „—" (kein Backfill möglich).
2. **`net_new_mrr_eur`** statt `net_new_arr_eur`: Semantikwechsel monatlich/jährlich. → Migration + Backfill `/12`. Burn-Multiple-Formel rechnet bereits monatlich (`burn/(arr/12)`) → **Scores ändern sich nicht**. Alte Spalte bleibt (Altdaten, wie `esop_pct`).

### Bewusste 1:1-Folgen (Mockup-Treue)
- Kontext-Sektion: **Teamgröße-Zeile entfällt** (Daten bleiben in DB/Cards), dafür „Gegründet". Pitch-Deck-Zeile bleibt konditional (Mockup-Fixture hat nur keine Deck-URL).
- Header ist fix dark; alte Views (Dashboard, Übersicht …) bleiben übergangsweise hell darunter. „Dark Mode"-Toggle bleibt funktional für die Alt-Views.

### Fallstricke
- `openModalWithStartup` ist monkey-gepatcht (`custom-index.js:1440`, `._ciV6`): **Name + Signatur `(s, list)` nicht ändern**, nur Funktionskörper.
- Alle `dv-*`-Styles liegen im `!important`-Block — Änderungen DORT machen, keine zweite Ebene davor.
- `js/main.js:16-19` berechnet Burn-Multiple-Fallback aus `net_new_arr_eur` — mit umstellen.
- Score-Ring-Regel aus CLAUDE.md: keine zweite Ring-Funktion einführen; Mockup-Score ist reine Zahl (`dv-score-number`), kein Ring → ok.

---

## Datei-Map
- **Modify:** `index.html` (Header-Markup: Brand ◈ CORE + Subline, Tabs in Header, Fund-Badge `id="fundBadge"`, Utils)
- **Modify:** `styles/main.css` (neuer Header-Block; `dv-*` Re-Skin im `!important`-Block; scoped Tokens `.modal{--bg:…}`)
- **Modify:** `js/renderers-modals.js` (Gegründet-Zeile, Teamgröße raus, Net New MRR, Relabels, Vorzeichen-Format `−€38.000`/`+41 %`, Semantikfarben §8)
- **Modify:** `js/main.js` (Mapping `founded_year` + `net_new_mrr_eur`, Burn-Multiple-Fallback, Fund-Badge befüllen, Modal-Close bei Nav-Klick)
- **Modify:** `js/custom-index.js` (Metrik `NET_NEW_ARR_EUR` → `NET_NEW_MRR_EUR`; unbekannte Keys in gespeicherten Regeln = „missing", unkritisch)
- **Modify:** `api/submit.js` (Burn Multiple aus `net_new_mrr_eur`; SQL-Kommentarblock; optionale Soft-Plausibility `founded_year` 1990–heute)
- **Modify:** `submit/index.html` (Feld „Gegründet (Jahr)" in Unternehmen; „Net New ARR" → „Net New MRR", id `net_new_mrr_eur`, Hint „Netto-Neuzugänge MRR diesen Monat")
- **Modify:** `tests/submit-form.spec.js`, `scripts/fixtures.mjs`, `scripts/fill-form.mjs` (neue Felder, MRR-Werte = ARR/12)
- **DB (Supabase MCP):** 2 Migrationen (s.u.)

## DB-Migrationen
```sql
-- 1) add_founded_year
ALTER TABLE submissions ADD COLUMN IF NOT EXISTS founded_year int;

-- 2) add_net_new_mrr_eur
ALTER TABLE submissions ADD COLUMN IF NOT EXISTS net_new_mrr_eur numeric;
UPDATE submissions
SET net_new_mrr_eur = ROUND(net_new_arr_eur / 12.0, 0)
WHERE net_new_mrr_eur IS NULL AND net_new_arr_eur IS NOT NULL;
```
Verifikation nach Backfill: `SELECT count(*) FILTER (WHERE net_new_arr_eur IS NOT NULL AND net_new_mrr_eur IS NULL)` = 0.

## Tasks

### Task 1: DB-Migrationen
- [x] `add_founded_year` via MCP `apply_migration`
- [x] `add_net_new_mrr_eur` + Backfill via MCP `apply_migration`
- [x] Verify-Query (Backfill vollständig, Stichprobe arr/12)

### Task 2: Backend (`api/submit.js`)
- [x] `netNewArr`-Ableitung ersetzen: `const netNewMrr = body.net_new_mrr_eur || (body.net_new_arr_eur ? body.net_new_arr_eur/12 : null)` (Fallback für alte Clients); `burn_multiple = burn / netNewMrr`
- [x] Soft-Plausibility-Regel `founded_year_range` (1990 ≤ Jahr ≤ aktuelles Jahr, nur wenn angegeben)
- [x] SQL-Kommentarblock um beide Spalten ergänzen
- [x] `node --check`, Commit

### Task 3: Submit-Formular
- [x] Feld „Gegründet (Jahr)" (optional, `type=number`, min 1990 max aktuelles Jahr) in Sektion Unternehmen
- [x] „Net New ARR (€)" → „Net New MRR (€)", id `net_new_mrr_eur`, Hint laut Mockup; Payload-Keys `founded_year`, `net_new_mrr_eur` (alter Key entfällt)
- [x] Inline-JS Syntax-Check, Commit

### Task 4: Header 1:1 (index.html + main.css)
- [x] Markup: ein `<header>`: Brand (◈ accent + „CORE"/„Dealflow Infrastruktur") · Nav (7 Tabs, IDs `topTab*` unverändert) · Utils (Fund-Badge-Pill `#fundBadge`, `#navScore`, `#openFilterBtn`, `#toggleThemeBtn`, `#navWeeklyTop5`); alte `viewnav-bar` entfällt
- [x] CSS §5/§6: 52px sticky, `#111827`, Tabs inaktiv `--ts`/hover `--as`/aktiv accent+schwarz, Ghost-/Accent-Outline-Buttons, Fund-Badge §11 — Header fix dark (eigene Hex, nicht theme-abhängig)
- [x] `main.js`: `#fundBadge` aus `window.fundName` befüllen; aktive-Tab-Klasse prüfen (bestehende Logik weiterverwenden)
- [x] Visuelle Prüfung beide Themes (Header bleibt dark), Commit

### Task 5: Detail-Modal Re-Skin + Inhalt
- [x] Scoped Tokens auf `.modal` (`--bg #0b0f1a`, `--surface #111827`, `--s2 #1a2235`, `--tp/--ts/--tm`, accent/ok/bad/warn)
- [x] `dv-*`-Block restylen: Topbar (Anordnung wie Mockup), Hero (Tags: Stage-Farbe §8, Plausibility text-only), Score-Block, Sektionen/`dv-pgrid`, Founder-Cards (`--s2`), Notes-Sidebar
- [x] Modal `top:52px` (Header sichtbar); Nav-Klick schließt Modal (in `main.js` vor `renderCurrent()`)
- [x] Inhalt: Gegründet-Zeile (`s.founded_year ?? "—"`), Teamgröße-Zeile raus, „Net New MRR" (`s.net_new_mrr_eur`), Relabels Round Size/Raised to Date, Burn als `−€…` rot, Wachstum `+… %` grün, CAC Payback/Runway accent-grün laut Mockup
- [x] `main.js`-Mapping: `founded_year`, `net_new_mrr_eur` (+ Fallback arr/12), Burn-Multiple-Fallback auf MRR
- [x] `custom-index.js`: Metrik umbenennen
- [x] Commit

### Task 6: Tests & Fixtures
- [x] `fixtures.mjs`/`fill-form.mjs`: `net_new_arr_eur` → `net_new_mrr_eur` (Wert/12, gerundet), `founded_year` ergänzen
- [x] `submit-form.spec.js`: Fill-Zeilen für beide Felder
- [x] Commit

### Task 7: Verifikation (wie beim Submit-Redesign)
- [x] Playwright-Suite lokal (echte api/-Handler + Supabase-REST-Stub mit aktueller Live-Spaltenliste) → 10/10
- [x] Payload-Check: `net_new_mrr_eur` + `founded_year` im Insert, `burn_multiple` korrekt (= burn/netNewMrr)
- [x] Live-DB-Smoke: Insert mit beiden Feldern, dann Delete (separates Statement!)
- [x] App-Smoke (Puppeteer, gemockter Supabase): Modal-Screenshot vs. Mockup, Header-Screenshot, Konsole fehlerfrei
- [x] Screenshots an User, Push

## Risiken
- **Theme-Clash (akzeptiert):** dunkler Header + Detail über hellen Alt-Views bis zum nächsten Mockup.
- **Gespeicherte Scoring-Regeln** mit `NET_NEW_ARR_EUR` evaluieren als „missing" (defensiv, `custom-index.js:601`) — kein Crash, ggf. Regel neu anlegen.
- **Alte Submit-Clients** (offene Tabs) senden `net_new_arr_eur` — API-Fallback /12 fängt das ab.
