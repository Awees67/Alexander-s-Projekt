# Befund 05 (Revision 2) — Art. 22 DSGVO und Profiling: Der Signal-Score als Thesis-Match-Indikator

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** MITTEL  
**Kategorie:** B — Fehlende Transparenz und Dokumentation; Profiling ohne vollständige Art.-13-Information  
**Betrifft:** Datenschutzerklärung v5.6.2026, js/custom-index.js, js/state.js, js/config.js, submit/index.html  
**Referenz:** Art. 4 Nr. 4, Art. 13, Art. 22 DSGVO; EDSA-Leitlinien WP251 rev.01; BVwG W256 2235360-1 (1. September 2025, AMS-Algorithmus)

---

## Korrektur gegenüber erster Berichtversion

Die erste Version dieses Befunds hat Art. 22 Abs. 1 DSGVO als anwendbar eingestuft und die Pflicht zur expliziten Einwilligung der Gründer (Art. 22 Abs. 2 lit. c) gefordert. Diese Einschätzung war zu streng und beruhte auf einer unvollständigen Beschreibung des Systems.

**Was in der ersten Version nicht berücksichtigt wurde:**

Der Pipeline-Status (Hot Deal, Watching, Declined) wird **ausschliesslich manuell** vom Fonds-Mitarbeiter gesetzt. Es gibt keine automatische Statusänderung. Der Signal-Score ist ein visueller Thesis-Match-Indikator im Dashboard — er zeigt, wie gut ein Startup die konfigurierten Investitionsthesen des Fonds erfüllt. Fonds konfigurieren ihre eigenen Scoring-Regeln (kein vorgefertigtes Default-Regelwerk). Der Score löst keine Entscheidung aus — er informiert den Menschen, der die Entscheidung trifft.

Diese architektonische Realität verändert die Rechtslage grundlegend.

---

## Was ist das Problem?

Zwei getrennte Fragen müssen beantwortet werden:

**Frage 1:** Fällt das System unter Art. 22 DSGVO (automatisierte Entscheidung)?

**Frage 2:** Welche DSGVO-Pflichten entstehen durch das Profiling (Art. 4 Nr. 4), auch wenn Art. 22 nicht gilt?

---

## Frage 1: Greift Art. 22 DSGVO?

### Der Tatbestand: "ausschliesslich auf automatisierter Verarbeitung beruhende Entscheidung"

Art. 22 Abs. 1 DSGVO schützt betroffene Personen vor Entscheidungen, die **ausschliesslich** auf automatisierter Verarbeitung beruhen und erhebliche Wirkung haben. Das Schlüsselwort ist "ausschliesslich".

**EDSA-Leitlinien WP251 rev.01 (vom EDPB bestätigt)** definieren klar:

> "Solely automated decision-making is the ability to make decisions by technological means **without human involvement**."

Und weiter:

> "Automated decisions can be made with or without profiling; **profiling can take place without making automated decisions**."

Das bedeutet: Profiling und automatisierte Entscheidung sind **zwei verschiedene Vorgänge**. Profiling, das dazu dient, Menschen bei Entscheidungen zu unterstützen, fällt nicht unter Art. 22 — es ist kein Fall von Art. 22, sondern von Art. 4 Nr. 4 in Verbindung mit Art. 6.

### Der österreichische Referenzfall: BVwG W256 2235360-1 (1. September 2025)

Das österreichische Bundesverwaltungsgericht hat am 1. September 2025 in einem direkt einschlägigen Fall entschieden: Das Arbeitsmarktchancen-Assistenzsystem (AMAS) des AMS, das Beschäftigungschancen automatisch berechnet und in drei Kategorien einteilt, **verstösst nicht gegen Art. 22 DSGVO** — weil ausreichende menschliche Einflussnahme besteht.

**Warum der Fall direkt auf CORE anwendbar ist:**

| AMAS (AMS-Algorithmus) | CORE (Signal-Score) |
|---|---|
| System berechnet automatisch einen Score für Personen | System berechnet automatisch einen Score für Einreichungen |
| Score teilt Personen in Kategorien ein (hoch/mittel/niedrig) | Score zeigt farblich Thesis-Match-Grad (grün/gelb/rot) |
| AMS-Berater entscheiden manuell über Massnahmen | Fonds-Mitarbeiter setzt Pipeline-Status immer manuell |
| Berater können Score ignorieren und überschreiben | Fonds-Mitarbeiter kann Score ignorieren und anders entscheiden |
| **Ergebnis: Kein Verstoss Art. 22** | **Analoge Einschätzung: Art. 22 nicht anwendbar** |

**Die Kriterien, die das BVwG für ausreichende menschliche Einflussnahme festgelegt hat:**

1. **Aktive Beteiligung** — der Mensch sieht nicht nur das Ergebnis, sondern ist aktiv am Entscheidungsprozess beteiligt
2. **Eigene Beurteilung** — er berücksichtigt Faktoren, die das System nicht erfasst
3. **Echte Abweichungskompetenz** — er ist ausdrücklich berechtigt und befähigt, vom System-Output abzuweichen
4. **Dokumentationspflicht bei Abweichung** — Abweichungen werden aktiv festgehalten
5. **Schulung** — der Entscheider versteht, was das System misst und was es nicht misst
6. **Institutionelle Kontrolle** — es gibt Mechanismen sicherzustellen, dass echte Überprüfung stattfindet

Das Gericht hat das AMAS klar als **Assistenzsystem** (kein automatischer Entscheider) eingestuft.

### Anwendung auf CORE

Der Signal-Score bei CORE erfüllt die Voraussetzungen eines Assistenzsystems nach dem BVwG-Massstab:

- Der Fonds-Mitarbeiter setzt den Pipeline-Status **immer manuell** — kein technischer Mechanismus setzt ihn automatisch
- Der Score ist explizit als Thesis-Match-Indikator designt, nicht als Entscheidungsträger
- Der Fonds-Mitarbeiter kann jeden Score ignorieren und anders entscheiden
- Die Farbcodes (grün/gelb/rot) sind Dashboard-Indikatoren, keine Handlungsanweisungen

**Rechtliche Einschätzung:** Art. 22 Abs. 1 DSGVO **greift nicht**, solange die Architektur des Systems — manuelle Pipeline-Status-Setzung, Score nur als Informations-Werkzeug — erhalten bleibt und dokumentiert ist.

### Was Art. 22 trotzdem gefährlich werden lässt: Rubber-Stamping

Die EDSA-Leitlinien WP251 warnen ausdrücklich:

> "A controller cannot avoid the Article 22 provisions by fabricating human involvement. If someone routinely applies automatically generated profiles to individuals **without any actual influence on the result**, this would still be a decision based solely on automated processing."

Das Risiko: Wenn in der Praxis jeder rote Score automatisch zu "Declined" führt — nicht weil jemand so entschieden hat, sondern weil niemand noch mal hinschaut — dann ist das faktisch eine automatisierte Entscheidung, auch wenn technisch der Mensch klickt.

**Für CORE bedeutet das:** Art. 22 bleibt irrelevant, solange der Fonds-Mitarbeiter substanziell entscheidet. Wenn die Praxis aber zeigt, dass rote Scores immer abgelehnt werden ohne echte Prüfung, könnte eine Behörde trotzdem Art. 22 arguieren.

**Einschätzung Frage 1:** Art. 22 Abs. 1 greift **nicht** — das System ist ein Assistenzsystem, keine automatische Entscheidungsmaschine. Risiko bleibt nur bei faktischem Rubber-Stamping.

---

## Frage 2: Welche Pflichten entstehen durch das Profiling (Art. 4 Nr. 4)?

Auch wenn Art. 22 nicht greift, bleibt eine eigenständige Pflichtenlage aus dem Profiling.

### Was Profiling nach Art. 4 Nr. 4 DSGVO bedeutet

> "jede Art der automatisierten Verarbeitung personenbezogener Daten, die darin besteht, dass diese personenbezogenen Daten verwendet werden, um bestimmte persönliche Aspekte, die sich auf eine natürliche Person beziehen, zu bewerten"

Der Signal-Score bewertet Gründer nach ihren beruflichen Merkmalen (has_repeat_founder, has_prior_exit, years_experience etc.) und deren Unternehmenskennzahlen. Das ist Profiling — unabhängig davon, ob daraus eine automatisierte Entscheidung folgt.

### Pflicht 1 — Rechtsgrundlage (Art. 6 Abs. 1)

Profiling braucht eine Rechtsgrundlage. Die korrekte Grundlage ist **Art. 6 Abs. 1 lit. f** (berechtigtes Interesse) — nicht lit. b — weil das Scoring über die für die Vertragserfüllung notwendige Verarbeitung hinausgeht. Das wurde in **Befund 04** detailliert behandelt: Die Interessenabwägung muss dokumentiert sein.

### Pflicht 2 — Transparenz gegenüber Gründern (Art. 13 Abs. 2 lit. f)

Art. 13 Abs. 2 lit. f DSGVO verlangt explizit: Wenn Profiling stattfindet, muss der Verantwortliche die betroffene Person über "das Bestehen einer automatisierten Entscheidungsfindung einschliesslich Profiling gemäss Artikel 22 Absätze 1 und 4 und — zumindest in diesen Fällen — aussagekräftige Informationen über die involvierte Logik sowie die Tragweite und die angestrebten Auswirkungen einer derartigen Verarbeitung" informieren.

**Die Formulierung ist entscheidend:** Art. 13 Abs. 2 lit. f spricht von Profiling "gemäss Art. 22 Absätze 1 und 4" — also nur bei automatisierten **Entscheidungen**. Da Art. 22 hier nicht greift, ist lit. f nicht direkt anwendbar.

**Aber:** Art. 5 Abs. 1 lit. a (Transparenzgrundsatz) und Art. 13 Abs. 1 insgesamt verlangen, dass Betroffene über alle wesentlichen Aspekte der Verarbeitung informiert werden. Dass über sie ein Score berechnet und dauerhaft gespeichert wird, der dem Fonds-Team als Screening-Werkzeug dient — das ist ein wesentlicher Aspekt, der in der Datenschutzerklärung stehen muss.

**Aktueller Stand:** Die Datenschutzerklärung erwähnt den Score nicht. Gründer wissen nicht, dass ein Score über sie existiert. Das ist eine **Art.-13-Lücke**.

### Pflicht 3 — Dokumentation der Menschlichkeit (Beweislast)

Art. 5 Abs. 2 DSGVO (Rechenschaftspflicht): Der Verantwortliche muss nachweisen können, dass die DSGVO eingehalten wird. Wenn eine Behörde fragt "Wie stellen Sie sicher, dass Art. 22 nicht greift?" — muss die Antwort dokumentiert sein.

Das BVwG hat im AMS-Fall ausdrücklich gelobt, dass das AMS **Schulungen, interne Kontrollen und Ombudsleute** hatte, die sicherstellten, dass menschliche Überprüfung tatsächlich stattfand. Für CORE fehlt eine entsprechende Dokumentation.

### Pflicht 4 — Fairness-Grundsatz (Art. 5 Abs. 1 lit. a)

Jeder Score, der Personen bewertet, muss fair sein — das bedeutet: Er darf keine systematischen Verzerrungen produzieren, die bestimmte Gründerprofile ohne sachlichen Grund benachteiligen. Das gilt unabhängig von Art. 22.

---

## Die Lösung — wasserdichte Massnahmen

### Massnahme 1 — Kein Default-Regelwerk (Architekturentscheidung)

Der Score darf erst existieren, wenn der Fonds aktiv ein Regelwerk konfiguriert hat. Kein Default-Regelwerk, das automatisch jeden Score berechnet. Diese Änderung hat drei Wirkungen:

- Sie dokumentiert, dass **der Fonds** entschieden hat, ein Scoring-System zu nutzen (stärkt Art.-28-Position, Befund 02)
- Sie stellt sicher, dass Fonds ohne Konfiguration keine Scores sehen — was technisch beweist, dass der Score ein optionales Analyse-Werkzeug ist
- Sie ist die technische Umsetzung des Konfigurationsprinzips aus dem AMS-Fall: Das System ist ein Assistenzsystem, kein automatischer Entscheider

### Massnahme 2 — Score klar als "Thesis-Match-Indikator" labeln (UI)

In der UI muss unmissverständlich klar sein, was der Score ist: ein Hilfswerkzeug, kein Urteil. Konkrete Umsetzung:

- Label über dem Score: **"Thesis-Match"** oder **"Screening-Indikator"** — nicht "Score", nicht "Bewertung"
- Tooltip bei Hover: "Zeigt, wie gut dieses Startup deine konfigurierten Investitionsthesen erfüllt. Alle Pipeline-Entscheidungen triffst du."
- Keine automatischen Handlungsempfehlungen aus dem Score

Diese Labeling-Massnahme ist keine Kosmetik — sie ist die Dokumentation des Systemcharakters als Assistenzsystem.

### Massnahme 3 — Datenschutzerklärung: Profiling und Score transparent machen (Art. 13)

Neuer Abschnitt in der Datenschutzerklärung:

> **Automatisierte Analyse Ihrer Einreichung (Profiling nach Art. 4 Nr. 4 DSGVO)**
>
> Aus den Angaben in Ihrer Einreichung berechnet die Plattform automatisch einen Screening-Indikator (0–100), der zeigt, wie gut Ihr Startup die Investitionsthesen des zuständigen Fonds erfüllt. Der Screening-Indikator ist ein internes Analyse-Werkzeug für Fonds-Mitarbeiter. Alle Entscheidungen über den Status Ihrer Einreichung werden ausschliesslich von Mitarbeitern des Fonds getroffen — keine Entscheidung folgt automatisch aus dem Indikator.
>
> **Rechtsgrundlage:** Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse des Fonds an einem strukturierten Dealflow-Screening). Der Fonds hat ein legitimes wirtschaftliches Interesse, Einreichungen anhand seiner Investitionsthesen zu analysieren. Die Berechnung betrifft ausschliesslich berufliche und unternehmerische Kennzahlen.
>
> **Ihre Rechte:** Sie können gemäss Art. 21 DSGVO jederzeit der Berechnung und Speicherung des Screening-Indikators widersprechen. Wenden Sie sich dazu an awees6703@gmail.com. Auf Anfrage erklären wir Ihnen, nach welchen Kriterien der Indikator berechnet wird.

### Massnahme 4 — Dokumentation der menschlichen Entscheidung (Rechenschaftspflicht)

Um im Fall einer Behördenprüfung belegen zu können, dass Art. 22 nicht greift, braucht es eine minimale Dokumentation der menschlichen Entscheidungspraxis. Die einfachste Umsetzung:

Der bereits existierende Pipeline-Audit-Trail (wer hat wann welchen Status gesetzt) ist diese Dokumentation — er muss nur erhalten und abrufbar bleiben. Zusätzlich empfehlenswert: eine kurze interne Policy ("Score ist Screening-Hilfsmittel, Status-Entscheidung liegt immer beim Fonds-Mitarbeiter") die beim Fonds-Onboarding unterschrieben wird.

### Massnahme 5 — Jährlicher Fairness-Check (Art. 5 lit. a)

Einmal jährlich: Export der Score-Verteilung analysieren, ob systematische Muster erkennbar sind, die bestimmte Gründerprofile ohne sachlichen Grund benachteiligen (z.B. Erstgründer, Gründer aus bestimmten Sektoren, bestimmte Stage-Kombinationen). Das ist kein aufwändiger Prozess — ein SQL-Export und eine einfache Auswertung genügen.

---

## Zusammenfassung: Was sich ändert

| Was | Wo | Aufwand |
|---|---|---|
| Kein Default-Regelwerk — Score erst nach aktiver Fondskonfiguration | custom-index.js / Onboarding-Prozess | 30 Min technisch + Prozessanpassung |
| Score als "Thesis-Match-Indikator" labeln in der UI | renderers-pipeline.js, renderers-submissions.js | 30 Min |
| Tooltip / Erklärungstext im Dashboard | UI | 20 Min |
| Neuer Abschnitt in Datenschutzerklärung | Datenschutzerklärung | 20 Min |
| Pipeline-Audit-Trail erhalten und abrufbar | Supabase (bereits vorhanden) | 0 Min — sicherstellen dass nicht gelöscht wird |
| Interne Policy für Fonds-Onboarding | Dokument | 30 Min |
| Jährlicher Fairness-Check | SQL + Analyse | 2h/Jahr |

---

## Was anwaltlich zu klären bleibt

**Ein Punkt** erfordert anwaltliche Bestätigung:

Die Einschätzung, dass Art. 22 nicht greift, beruht auf dem BVwG-Urteil vom 1. September 2025 (W256 2235360-1) und den EDSA-Leitlinien WP251. Ein österreichischer Datenschutzanwalt sollte bestätigen, dass das konkrete CORE-Design — Score als Thesis-Match-Indikator, manueller Pipeline-Status — mit dieser Rechtsprechung vereinbar ist. Das ist eine Stunden-Aufgabe, keine komplexe Analyse.

---

## Einordnung: Was sich gegenüber Version 1 ändert

| | Befund 05 Version 1 | Befund 05 Version 2 (diese Version) |
|---|---|---|
| Schweregrad | KRITISCH | MITTEL |
| Art. 22 greift? | Ja — explizite Einwilligung erforderlich | Nein — Score ist Assistenzsystem, manueller Status |
| Hauptreferenz | EuGH C-634/21 (SCHUFA) | BVwG W256 2235360-1 (AMS-Algorithmus, Sept. 2025) |
| Hauptpflicht | Einwilligungsmechanismus aufbauen | Transparenz (Art. 13) + Dokumentation |
| Technischer Aufwand | Hoch (Consent-System, DB-Änderungen) | Gering (Labeling, Datenschutzerklärung, Policy) |

---

*Quellen: Art. 4 Nr. 4, Art. 5, Art. 6, Art. 13, Art. 22 DSGVO; EDSA-Leitlinien WP251 rev.01 (Automated Decision-Making and Profiling); BVwG W256 2235360-1 (1. September 2025, AMS-Algorithmus); EuGH C-634/21 (7. Dezember 2023, SCHUFA).*

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026, überarbeitet auf Basis präzisierter Systemarchitektur.*
