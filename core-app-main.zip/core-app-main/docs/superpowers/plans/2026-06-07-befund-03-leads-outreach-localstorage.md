# Befund 03 — `core_leads_v1` und `core_outreach_v2`: Verarbeitung ohne Rechtsgrundlage und ohne Erwähnung in der Datenschutzerklärung

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** HOCH  
**Kategorie:** C — Lücke / fehlende Pflichtangabe  
**Betrifft:** Datenschutzerklärung v5.6.2026, js/state.js (LS_KEYS), js/config.js, js/renderers-inbox.js

---

## Was ist das Problem?

Es gibt zwei localStorage-Schlüssel, die **personenbezogene Daten von Dritten** speichern — Daten, die weder in der Datenschutzerklärung erwähnt werden noch eine dokumentierte Rechtsgrundlage haben.

**`core_leads_v1`** — speichert pro Eintrag (state.js Zeilen 90–101):
- `name` — vollständiger Name einer Person
- `email` — E-Mail-Adresse
- `firm` — Arbeitgeber
- `msg` — Nachrichtentext
- `anon_id`, `display_label`, `ts`

Das sind Kontaktdaten von Interessenten (Investoren, Leads), die sich irgendwo eingetragen haben.

**`core_outreach_v2`** — speichert pro Eintrag (state.js Zeilen 491–504):
- `contact_name`, `contact_email` — direkte Personendaten des kontaktierten Gründers
- `sent_at` — wann die E-Mail gesendet wurde
- `status` — aktueller Outreach-Status (z.B. `anfrage_gesendet`, `keine_antwort`)
- `followup_sent` — ob ein Follow-up versendet wurde
- Verknüpft mit `anon_id` eines Gründers

Das ist ein vollständiger Outreach-Tracker: wann wurde wem eine E-Mail geschickt, was war der Status, wann wurde nachgefasst.

---

## Warum ist das ein Problem?

### 1. Nicht in der Datenschutzerklärung erwähnt

Die Datenschutzerklärung beschreibt ausschliesslich die Verarbeitung von Gründer-Einreichungsdaten über Supabase. `core_leads_v1` und `core_outreach_v2` kommen nirgends vor. Das verletzt **Art. 13 DSGVO** — betroffene Personen werden nicht informiert, dass ihre Daten gespeichert werden.

### 2. Keine Rechtsgrundlage dokumentiert

Art. 6 Abs. 1 DSGVO verlangt für jede Verarbeitung eine Rechtsgrundlage. Für diese beiden Datensätze ist keine definiert:

- `core_leads_v1`: Wer sind diese Personen? Haben sie eingewilligt? Berechtigtes Interesse wofür genau?
- `core_outreach_v2`: Auf welcher Grundlage wird Datum, Status und Verlauf der Kontaktaufnahme mit Gründern gespeichert?

### 3. Speicherort: localStorage — kein sicheres System

localStorage liegt auf dem Endgerät des Benutzers (Fonds-Mitarbeiter). Das bedeutet:

- Keine Zugriffskontrolle
- Keine Verschlüsselung
- Keine Löschfrist (technisch)
- Kein Audit-Trail
- Wer Zugang zum Browser hat, hat Zugang zu diesen Personendaten

### 4. Löschfristen fehlen völlig

Die Datenschutzerklärung (Abschnitt 8) definiert Löschfristen nur für Submissions in Supabase. Für localStorage-Daten existiert keine Frist — theoretisch bleiben `core_leads_v1` und `core_outreach_v2` unbegrenzt gespeichert. Das verstösst gegen **Art. 5 Abs. 1 lit. e DSGVO** (Speicherbegrenzung).

### 5. TKG 2021 bei `core_outreach_v2` (Österreich)

Das österreichische Telekommunikationsgesetz 2021 (§ 174 TKG 2021, Umsetzung der ePrivacy-Richtlinie 2002/58/EG) reguliert, unter welchen Bedingungen E-Mails zu Werbezwecken versendet werden dürfen. Wenn über das Outreach-Modul E-Mails an Gründer gesendet werden, ohne dass diese ausdrücklich zugestimmt haben, kann das eine separate TKG-Verletzung darstellen — unabhängig von der DSGVO.

Mögliche Argumentation gegen TKG-Pflicht: Gründer haben eine Einreichung gemacht und erwarten eine Rückmeldung — das könnte als berechtigtes Interesse ausreichen. Aber diese Einschätzung muss **explizit dokumentiert** und anwaltlich bestätigt sein, bevor das Outreach-Modul produktiv genutzt wird.

---

## Die Lösung

### Massnahme 1 — Datenschutzerklärung erweitern (sofort, kein Anwalt nötig)

Zwei neue Unterabschnitte in die Datenschutzerklärung einfügen:

**Zu `core_leads_v1` (Interessenten-Daten):**

> "Der Fonds-Nutzer der Plattform kann Kontaktdaten von Interessenten (Name, E-Mail-Adresse, Firma, Nachricht) lokal auf seinem Endgerät speichern (Browser-localStorage). Diese Daten verlassen das Endgerät nicht — sie werden nicht an Server übertragen und sind ausschliesslich dem jeweiligen Browser-Nutzer zugänglich. Rechtsgrundlage: Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse des Fonds an der Nachverfolgung von Geschäftsanfragen). Speicherdauer: bis zur aktiven Löschung durch den Nutzer, spätestens 12 Monate."

**Zu `core_outreach_v2` (Outreach-Tracking):**

> "Das Outreach-Modul speichert den Verlauf der Kontaktaufnahme mit Gründern (Name, E-Mail-Adresse, Sendedatum, Kommunikationsstatus, Follow-up-Status) lokal auf dem Endgerät des Fonds-Nutzers (Browser-localStorage). Diese Daten verlassen das Endgerät nicht. Rechtsgrundlage: Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse des Fonds an der Nachverfolgung von Investor-Gründer-Kommunikation im Rahmen des Dealflow-Prozesses). Speicherdauer: automatische Löschung nach 6 Monaten oder bei Löschung des Browser-Profils."

### Massnahme 2 — Technisch: Automatische Löschfrist implementieren

localStorage hat keine eingebaute Ablaufzeit. Beim App-Start muss geprüft werden, ob Einträge älter als die dokumentierte Frist sind, und diese müssen automatisch entfernt werden. Das ist die technische Entsprechung zur dokumentierten Speicherfrist — ohne sie ist die Fristangabe in der Datenschutzerklärung eine leere Zusage.

Konkret: In `main.js` beim App-Start eine Funktion aufrufen, die `core_leads_v1` (älter als 12 Monate) und `core_outreach_v2` (älter als 6 Monate) bereinigt.

### Massnahme 3 — Rechtsgrundlage für Outreach-E-Mails klären (anwaltlich, vor Produktivbetrieb)

Bevor das Outreach-Modul aktiv genutzt wird: Anwaltlich klären, ob E-Mails an Gründer unter § 174 TKG 2021 fallen und ob eine explizite Einwilligung benötigt wird. Mitbringen zum Gespräch:

1. Mustert-E-Mail, die über das Outreach-Modul versandt werden soll
2. Die Tatsache, dass Gründer zuvor eine Einreichung gemacht haben (mögliche Basis für berechtigtes Interesse)
3. Die Frage: Reicht die Einreichung als implizite Zustimmung zur Kontaktaufnahme, oder braucht es ein explizites Opt-in?

### Massnahme 4 — Mittelfristig: Migration zu Supabase

localStorage ist kein geeigneter Ort für personenbezogene Daten in einem produktiven B2B-SaaS:

- Kein zentrales Backup
- Kein Audit-Trail
- Keine fund_id-Isolation (bei mehreren Fonds auf einem Gerät)
- Keine Möglichkeit, DSGVO-Anfragen (Auskunft, Löschung nach Art. 17) zentral zu beantworten

Mittelfristig gehören beide Datensätze in Supabase mit RLS und fund_id-Isolation.

---

## Zusammenfassung: Was sich ändert

| Was | Wo | Aufwand |
|---|---|---|
| Unterabschnitt zu `core_leads_v1` einfügen | Datenschutzerklärung | 10 Minuten |
| Unterabschnitt zu `core_outreach_v2` einfügen | Datenschutzerklärung | 10 Minuten |
| Automatische Löschfrist bei App-Start | main.js, ~10 Zeilen | 20 Minuten |
| TKG-Einschätzung für Outreach-E-Mails | Anwalt | Einmalig, vor Produktivbetrieb |
| Migration zu Supabase | api.js, state.js | Mittelfristig, bei nächstem Backend-Sprint |

---

## Was anwaltlich zu klären bleibt

Einziger offener Punkt: TKG 2021 § 174 — ob das Outreach-Modul eine explizite Einwilligung der Gründer erfordert oder ob die Einreichung als ausreichende Grundlage gilt. Das ist eine österreichische Besonderheit, die von einem lokal ansässigen DSGVO/TKG-Anwalt beurteilt werden muss.

---

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
