# Submit-Formular Redesign (CORE Design System v2) — Implementation Plan

**Goal:** Das Submit-Formular (`submit/index.html`) vom hellen Blau-Design auf das CORE Design System v2 (Dark-First, Teal-Akzent) umstellen — exakt nach Mockups + Design-Doku.

**Architecture:** `submit/index.html` ist eine Standalone-Seite (eigenes CSS, eigenes JS, kein Bezug zu `styles/main.css`). Reines visuelles Redesign: alle Feld-IDs, das Submission-Payload und der API-Kontrakt (`/api/submit`) bleiben unverändert. Neu hinzu kommt nur die Progress-Anzeige („n / 7 Sektionen") als rein clientseitige UI.

**Tech Stack:** Vanilla HTML/CSS/JS, IBM Plex Sans/Mono (Google Fonts).

---

## Design-Tokens (aus coredesignsystemv2.pdf)

```css
--bg:#0b0f1a; --surface:#111827; --s2:#1a2235;
--border:rgba(255,255,255,0.06);
--tp:#f0f4ff; --ts:#8892a4; --tm:#4e5a72;
--accent:#00dfc1; --as:rgba(0,223,193,0.08);
--ok:#10b981; --bad:#ef4444;
```

## Scope-Entscheidung (Backend-Kontrakt)

Mockup zeigt Feld-Abweichungen, die **NICHT** übernommen werden, weil sie den
Backend-Kontrakt brechen würden (`api/submit.js` + `submissions`-Tabelle):
- „Net New MRR (€)" statt `net_new_arr_eur` (Design-Doku §13)
- Vereinfachte Founder-Felder („Vorherige Stationen", „Prior Exit" als Text)

→ Follow-up-Task, wenn Backend-Migration gewünscht.

**Update (gleicher Tag):** Cap Table wurde auf Wunsch doch vollständig auf den
Standard aus Design-Doku §12 migriert (inkl. DB):
- Formular: ESOP-Feld entfernt, `investor_pct` („Vergeben Investoren (%)") neu,
  `employees_pct` → „Vergeben Mitarbeiter (%)"
- DB-Migrationen: `add_investor_pct_cap_table_standard` (Spalte + Backfill als
  Rest zu 100) und `fold_esop_into_founder_pct` (ESOP-Pool zählt per §12 zu
  founder_pct). Alle 20 Bestandszeilen summieren exakt auf 100%.
  `esop_pct`-Spalte bleibt als Altdaten erhalten, wird nicht mehr geschrieben.
- Code: `api/submit.js` (Plausibility-Regel), `js/main.js` (Mapping),
  `js/utils.js` (Plausibility), `js/custom-index.js` (Metrik `INVESTOR_PCT`
  statt `ESOP_PCT`), `js/renderers-modals.js` (Detail-Cap-Table: 3 Zeilen,
  keine „Verfügbar"-Zeile), Tests + Fixtures/Fill-Scripts.

## Tasks

### Task 1: Komplettes Restyle von `submit/index.html`
**Files:** Modify: `submit/index.html`

- [x] CSS-Tokens auf v2 umstellen, `color-scheme: dark`
- [x] Header: 52px sticky, `--surface`, ◈-Logo (accent), „CORE" + Subline „Dealflow Infrastruktur"
- [x] Hero: Fund-Badge (Pill, `--as`-BG, Accent-Dot) → H1 „Startup Bewerbung" → Subtitle → Progress-Bar
- [x] Cards: `--surface`, Radius 12px, Padding 22px 24px; Section-Title accent uppercase mit Linie rechts
- [x] Inputs/Selects/Textareas: `--s2`, Radius 8px, Padding 9px 12px, Fokus accent + 3px Glow; Zahlen IMMER Plex Sans (Mono-Regel `.mono input` entfernen — Slashed-Zero-Verbot)
- [x] Zielmärkte/Stärken als Chips: Checkbox versteckt, `:has(:checked)` → accent Text + Border + `--as` BG
- [x] Founder-Cards: `--s2`-BG, innere Inputs `--surface` (eine Ebene dunkler, wie Mockup)
- [x] Buttons: Primary-CTA accent/schwarz Radius 10px; „+ Founder" als Ghost-Button
- [x] Error/Success/Loading-Overlay dark umstylen
- [x] Progress-JS: 7 Sektionen mit Completion-Prädikaten, Update bei input/change
- [x] Verifikation (statisch): JS-Syntax OK, Payload-Keys identisch, alle referenzierten IDs vorhanden, v2-Tokens gesetzt
- [ ] Visuelle Verifikation gegen Mockups — in der Remote-Umgebung kein Browser verfügbar (Playwright-CDN von Netzwerk-Policy blockiert) → manuell im Browser prüfen
- [x] Commit

## Verifikation
- Statisch geprüft: `submissionData`-Keys unverändert ggü. HEAD, keine IDs entfernt (nur `progressFill`/`progressLabel` neu), `node --check` auf dem Inline-Script grün, `.mono input`-Regel entfernt
- Offen (manuell): `npx serve .` → `/submit/index.html?fund=…` öffnen und gegen die 3 Mockup-Screenshots vergleichen
