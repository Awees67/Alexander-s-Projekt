# Befund 12 — Art. 33/34 DSGVO: Datenpannenmeldung und Incident-Response-Prozess

**Datum:** 07. Juni 2026
**Projekt:** CORE — Dealflow Screening Platform
**Schweregrad:** HOCH
**Betroffene Normen:** Art. 33 DSGVO (Meldepflicht an Behörde), Art. 34 DSGVO (Benachrichtigung Betroffener), Art. 28 Abs. 3 lit. f DSGVO (AVV-Pflicht), Art. 5 Abs. 2 DSGVO (Rechenschaftsprinzip)
**Status:** Handlungsbedarf identifiziert

---

## 1. Sachverhalt — Ist-Zustand bei CORE

CORE betreibt eine Supabase-Datenbank (Frankfurt, eu-central-1) mit personenbezogenen Daten von Startup-Gründern aus mehreren VC-Fonds. Ein Datenpannen-Szenario (z.B. RLS-Fehlkonfiguration, kompromittierter Service Role Key, unbefugter Datenbankzugriff) würde potenziell Daten mehrerer Fonds und aller ihrer Startup-Submissions betreffen.

### 1.1 Was heute fehlt

| Aspekt | Ist-Stand |
|---|---|
| Dokumentierter Incident-Response-Plan | Nicht vorhanden |
| Interne Meldeschwelle (ab wann ist es eine Datenpanne?) | Nicht definiert |
| Meldeprozess an Aufsichtsbehörde | Nicht dokumentiert |
| Meldeprozess an betroffene Fonds (Kettenmeldung) | Nicht im AVV geregelt |
| Meldeprozess an betroffene Gründer | Nicht vorhanden |
| Dokumentationsregister für Datenpannen (Art. 33 Abs. 5) | Nicht geführt |
| Benennung eines internen Ansprechpartners für Datenpannen | Nicht definiert |

### 1.2 Technische Risikofaktoren bei CORE

- **RLS-Konfiguration**: Fehler in Row Level Security könnten dazu führen, dass ein Fonds auf Daten anderer Fonds zugreift (horizontale Datenexpansion)
- **Service Role Key**: Kompromittierung würde vollen Datenbankzugriff ohne RLS-Einschränkung ermöglichen
- **Vercel Serverless Functions**: `api/submit.js` ist öffentlich erreichbar — ein Injection- oder Authentication-Bypass-Angriff wäre eine Datenpanne
- **Magic Link Auth**: Abgefangene Magic Links ermöglichen unbefugten Zugang zu Fondsdaten
- **Multi-Fonds-Architektur**: Eine Panne betrifft potenziell mehrere Verantwortliche (VC-Fonds) gleichzeitig

---

## 2. Rechtsgrundlage

### Art. 33 Abs. 1 DSGVO — Meldepflicht des Verantwortlichen

> „Im Falle einer Verletzung des Schutzes personenbezogener Daten meldet der Verantwortliche diese unverzüglich und möglichst binnen 72 Stunden, nachdem ihm die Verletzung bekannt wurde, der gemäß Artikel 55 zuständigen Aufsichtsbehörde, es sei denn, dass die Verletzung des Schutzes personenbezogener Daten voraussichtlich nicht zu einem Risiko für die Rechte und Freiheiten natürlicher Personen führt."

Die 72-Stunden-Frist beginnt, sobald CORE **Kenntnis** von der Verletzung erlangt — nicht ab dem Zeitpunkt der Verletzung selbst.

### Art. 33 Abs. 2 DSGVO — Kettenmeldung des Auftragsverarbeiters

> „Wenn die Verletzung des Schutzes personenbezogener Daten bei einem Auftragsverarbeiter eingetreten ist, meldet dieser sie dem Verantwortlichen unverzüglich, nachdem ihm die Verletzung bekannt geworden ist."

**Für CORE bedeutet dies:**
- Wenn CORE als **Auftragsverarbeiter** fungiert (für VC-Fonds): CORE muss den Fonds **unverzüglich** (in der Praxis: innerhalb 24 Stunden, wie im AVV zu regeln) informieren.
- Der Fonds als **Verantwortlicher** muss dann innerhalb der 72-Stunden-Gesamtfrist an die Behörde melden.
- Wenn CORE als **eigenständiger Verantwortlicher** fungiert (Benchmarking): CORE meldet selbst an die Behörde.

### Art. 33 Abs. 3 DSGVO — Mindestinhalt der Meldung

Die Meldung muss enthalten:
- Art der Verletzung (Kategorie und ungefähre Zahl betroffener Personen und Datensätze)
- Name und Kontaktdaten des Datenschutzbeauftragten oder sonstiger Ansprechpartner
- Voraussichtliche Folgen der Verletzung
- Ergriffene oder vorgeschlagene Maßnahmen zur Behebung und Abmilderung

### Art. 33 Abs. 5 DSGVO — Dokumentationspflicht

> „Der Verantwortliche dokumentiert Verletzungen des Schutzes personenbezogener Daten einschließlich aller im Zusammenhang damit stehenden Fakten, von deren Auswirkungen und der ergriffenen Abhilfemaßnahmen."

Auch wenn eine Meldung an die Behörde nicht erforderlich ist (geringes Risiko), muss die Datenpanne **intern dokumentiert** werden.

### Art. 34 DSGVO — Benachrichtigung Betroffener

Wenn die Datenpanne **voraussichtlich ein hohes Risiko** für die Rechte und Freiheiten der betroffenen Personen (Gründer) zur Folge hat, müssen diese **unverzüglich** benachrichtigt werden — ohne unangemessene Verzögerung (kein 72-h-Limit, aber faktisch so schnell wie möglich).

Ausnahmen (Art. 34 Abs. 3):
- Daten waren verschlüsselt und der Key nicht kompromittiert
- Täter wurde identifiziert und Schaden abgewendet
- Benachrichtigung wäre unverhältnismäßiger Aufwand → öffentliche Bekanntmachung statt Einzelbenachrichtigung

### Art. 28 Abs. 3 lit. f DSGVO — AVV-Pflicht

Der AVV muss die Unterstützung des Auftragsverarbeiters bei der Meldepflicht des Verantwortlichen regeln. Ohne entsprechende AVV-Klausel fehlt die vertragliche Basis für die Kettenmeldung.

---

## 3. Rechtliche Analyse

### 3.1 Kettenmeldung bei CORE ist ungeregelt

Die kritischste Lücke: Weder der AVV noch ein internes Dokument regelt, wie CORE im Fall einer Datenpanne die betroffenen VC-Fonds informiert. Bei einer Panne, die mehrere Fonds betrifft, wäre CORE verpflichtet, jeden betroffenen Fonds **unverzüglich** zu informieren — ohne definierte Kontaktpersonen und ohne Eskalationsprozess ist dies in der Praxis nicht umsetzbar.

### 3.2 72-Stunden-Frist und fehlende Monitoring-Infrastruktur

Ohne Zugriffsprotokollierung (→ Befund 10) und ohne automatisierte Anomalieerkennung kann CORE eine Datenpanne möglicherweise erst Tage nach dem Ereignis bemerken. Die 72-Stunden-Frist läuft ab Kenntnis — aber wenn die Kenntnis durch fehlende Logs um Tage verzögert wird, beginnt die Frist faktisch erst dann. Aufsichtsbehörden werten verzögertes Erkennen durch unzureichende TOMs jedoch als erschwerend.

### 3.3 Zuständige Aufsichtsbehörde(n) im DACH-Raum

CORE hat seinen Hauptsitz/seine Hauptniederlassung in Deutschland oder Österreich (unklar aus den Unterlagen). Die zuständige Behörde richtet sich nach der **Hauptniederlassung des Verantwortlichen** (Art. 56 Abs. 1 DSGVO — One-Stop-Shop-Prinzip):

| Standort CORE | Federführende Behörde |
|---|---|
| Deutschland | Zuständige Landesdatenschutzbehörde (z.B. BayLDA, LfDI BW, BlnBDI — je nach Bundesland) |
| Österreich | Datenschutzbehörde (DSB, dsb.gv.at) |

Wenn VC-Fonds in verschiedenen EU-Staaten ansässig sind, können zusätzlich betroffene Aufsichtsbehörden dieser Länder informiert werden müssen (Art. 33 Abs. 1 i.V.m. Art. 4 Nr. 22 DSGVO).

Für die VC-Fonds als Verantwortliche gilt entsprechendes: Jeder Fonds meldet an seine eigene zuständige Behörde.

### 3.4 Hohes Risiko bei CORE-Datenpanne

Angesichts der Sensibilität der Daten (Startup-Gründer mit Karrieredaten, Investitionssummen, Businessplänen), der Mehrmandantenfähigkeit und der wirtschaftlichen Bedeutung ist bei einer Datenpanne von einem **hohen Risiko** für Betroffene auszugehen — womit Art. 34 DSGVO (Benachrichtigung der Gründer) regelmäßig ausgelöst würde.

### 3.5 Konsequenzen fehlender Meldung

Eine nicht oder verspätet eingereichte Meldung nach Art. 33 DSGVO kann nach Art. 83 Abs. 4 lit. a DSGVO mit Bußgeldern bis zu **10 Mio. EUR oder 2 % des weltweiten Jahresumsatzes** bestraft werden. Hinzu kommt Reputationsschaden gegenüber Fonds-Kunden.

---

## 4. Handlungsbedarf

### Sofortmaßnahmen (0–4 Wochen)

1. **Incident-Response-Plan (IRP) erstellen** — Einseiter mit Eskalationsablauf:
   - Wer erkennt die Panne? (Monitoring, Nutzerhinweis, Behördenhinweis)
   - Wer wird zuerst informiert? (intern: Gründer CORE, dann Fonds)
   - Ab welcher Schwelle wird gemeldet? (Risikobewertung: gering/mittel/hoch)
   - An welche Behörde wird gemeldet?
   - Wer schreibt die Meldung? Wer genehmigt sie?

2. **AVV-Ergänzung: Kettenmeldepflicht** — Im AVV mit jedem Fonds festschreiben:
   - CORE informiert den Fonds unverzüglich, spätestens innerhalb von **24 Stunden** nach Kenntnis einer Datenpanne (Art. 33 Abs. 2 DSGVO)
   - CORE unterstützt den Fonds bei der Erstellung der Behördenmeldung (Art. 28 Abs. 3 lit. f)
   - Benennung eines Ansprechpartners bei CORE für Datenpannen

3. **Kontaktliste aller Fonds anlegen** — Für jeden Fonds: Ansprechpartner für Datenschutz-Notfälle mit Mobilnummer und E-Mail (nicht nur reguläre Geschäftskontakte).

4. **Datenpannen-Register einrichten** — Einfaches Dokument (Google Sheets/Notion): Datum, Beschreibung, betroffene Daten, ergriffene Maßnahmen, ob gemeldet (ja/nein/Begründung). Pflicht nach Art. 33 Abs. 5 DSGVO auch bei nicht meldepflichtigen Pannen.

### Mittelfristige Maßnahmen (1–3 Monate)

5. **Meldeformulare vorbereiten** — Vorlage für Behördenmeldung nach Art. 33 Abs. 3 DSGVO und Vorlage für Betroffenenbenachrichtigung nach Art. 34 Abs. 2 DSGVO. Viele Datenschutzbehörden bieten Online-Meldeportale (z.B. dsb.gv.at in Österreich).

6. **Risikobewertungsmatrix** — Tabelle zur schnellen Einschätzung: Welche Datenkategorie, wie viele Betroffene, welche Art der Verletzung, welches Risikopotenzial → daraus: Meldepflicht ja/nein, Art-34-Pflicht ja/nein.

7. **Monitoring und Alerting** — Supabase bietet Audit Logging und kann mit Alerting (z.B. via PagerDuty oder einfachen Webhook) verbunden werden. Ziel: automatische Benachrichtigung bei anomalen Zugriffsmustern.

### Langfristig (3–6 Monate)

8. **Jährliche IRP-Übung** — Tabletop-Übung: "Was würden wir tun, wenn heute unser Service Role Key kompromittiert wird?" — Prozesse testen, Lücken identifizieren, dokumentieren.

---

## 5. Fazit

CORE hat keinen dokumentierten Prozess für den Fall einer Datenpanne. Die 72-Stunden-Frist nach Art. 33 DSGVO, die Kettenmeldepflicht gegenüber VC-Fonds (Art. 33 Abs. 2), die potenziell notwendige Benachrichtigung von Gründern (Art. 34) und das interne Datenpannen-Register (Art. 33 Abs. 5) sind allesamt ungeregelt. Angesichts der Mehrmandantenfähigkeit und der wirtschaftlichen Sensibilität der Daten ist das Risikopotenzial einer Datenpanne bei CORE hoch.

**Schweregrad: HOCH** — Fehlender Incident-Response-Plan ist kein unmittelbarer Datenschutzverstoß, aber im Pannenfall unmittelbar haftungsrelevant: Verspätete oder fehlende Meldung nach Art. 33 DSGVO ist eigenständig bußgeldbewährt (Art. 83 Abs. 4 lit. a: bis 10 Mio. EUR / 2 % Jahresumsatz).

---

*Quellen: Art. 33 DSGVO (dsgvo-gesetz.de), Art. 34 DSGVO, Art. 28 Abs. 3 lit. f DSGVO, Art. 83 Abs. 4 lit. a DSGVO, GDD-Praxishilfe Checkliste Meldung Datenschutzverletzungen (2025), LDI NRW Meldepflicht-Leitfaden, DataAgenda: Datenpannen bei Auftragsverarbeitern, Art. 56 DSGVO (One-Stop-Shop)*
