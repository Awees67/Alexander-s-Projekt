# Befund 11 — Art. 17 DSGVO: Recht auf Löschung (technische Umsetzbarkeit)

**Datum:** 07. Juni 2026
**Projekt:** CORE — Dealflow Screening Platform
**Schweregrad:** HOCH
**Betroffene Normen:** Art. 17 DSGVO, Art. 7 Abs. 3 DSGVO, Art. 28 Abs. 3 lit. g DSGVO, Art. 5 Abs. 1 lit. e DSGVO (Speicherbegrenzung), Art. 5 Abs. 2 DSGVO (Rechenschaftsprinzip)
**Status:** Handlungsbedarf identifiziert

---

## 1. Sachverhalt — Ist-Zustand bei CORE

Ein Startup-Gründer, der seine Bewerbung über `/submit/index.html` eingereicht hat, möchte seine personenbezogenen Daten löschen lassen. Heute gibt es dafür keinen definierten Prozess.

### 1.1 Datenhaltung in CORE

Personenbezogene Daten von Gründern sind in folgenden Supabase-Tabellen gespeichert:

| Tabelle | Inhalte |
|---|---|
| `submissions` | Name, E-Mail, LinkedIn, Hochschule, Unternehmensdaten, Pitch-Inhalte |
| `pipeline_items` | Pipeline-Einstufungen durch VC-Fondsmitarbeiter (fund_id + anon_id) |
| `notes` | Notizen der Fondsmitarbeiter zum jeweiligen Startup |
| `activity_log` | Aktionsverlauf (aktuell localStorage, perspektivisch Supabase) |
| `leads` / `outreach` | Kontaktdaten für Outreach-Kampagnen (localStorage: `core_demo_leads_v4`, `core_outreach_v1`) |

### 1.2 Fehlende Infrastruktur

- Es existiert kein Löschantrags-Formular oder definierter Kontaktweg für Betroffene.
- Es gibt kein dokumentiertes Verfahren, wie auf Löschanträge reagiert wird.
- Es ist unklar, ob Datenbankconstraints (CASCADE DELETE) zwischen den Tabellen vorhanden sind.
- Daten in `localStorage` des Fondsmitarbeiters (leads, outreach, activity) werden bei einer DB-Löschung **nicht automatisch** gelöscht.
- Backups bei Supabase enthalten die Daten weiterhin — keine definierte Policy für Backup-Bereinigung.
- Keine Löschbestätigung / kein Nachweis für die betroffene Person.

### 1.3 Koordinierte Aktion des EDSA 2025

Der Europäische Datenschutzausschuss (EDSA) hat das Recht auf Löschung nach Art. 17 DSGVO zur koordinierten Aktion 2025 erklärt. 32 nationale Aufsichtsbehörden prüfen aktiv die Umsetzung. CORE muss im Fall einer Prüfung nachweisen können, dass Löschanträge vollständig und fristgerecht bearbeitet wurden.

---

## 2. Rechtsgrundlage

### Art. 17 Abs. 1 DSGVO — Löschpflicht

> „Die betroffene Person hat das Recht, von dem Verantwortlichen zu verlangen, dass sie betreffende personenbezogene Daten unverzüglich gelöscht werden, und der Verantwortliche ist verpflichtet, personenbezogene Daten unverzüglich zu löschen, sofern einer der folgenden Gründe zutrifft: [...]"

Relevante Löschgründe für Gründer-Anfragen:
- **lit. a:** Daten sind für den Zweck nicht mehr notwendig (Bewerbung abgelehnt, keine Investition)
- **lit. b:** Einwilligung widerrufen (soweit Einwilligung Rechtsgrundlage war)
- **lit. c:** Widerspruch nach Art. 21 DSGVO (berechtigte Interessen)

### Art. 17 Abs. 2 DSGVO — Informationspflicht gegenüber Dritten

Wenn CORE Daten öffentlich gemacht oder an Dritte (VC-Fonds) weitergegeben hat, muss CORE die Empfänger über den Löschantrag informieren. Dies ist bei CORE besonders komplex, da dieselben Daten **mehreren Fonds** zugänglich sein können (Cross-Fonds-Funktionalität).

### Art. 28 Abs. 3 lit. g DSGVO — Pflicht des Auftragsverarbeiters

Als Auftragsverarbeiter muss CORE dem Fonds gegenüber:
> „alle personenbezogenen Daten nach Abschluss der Erbringung der Verarbeitungsleistungen nach Wahl des Verantwortlichen [...] löscht oder zurückgibt und vorhandene Kopien löscht [...]"

Dies gilt auch für Backups.

### Art. 5 Abs. 1 lit. e DSGVO — Speicherbegrenzung

Personenbezogene Daten dürfen nur so lange gespeichert werden, wie es für den Verarbeitungszweck notwendig ist. Da CORE keine Löschfristen definiert hat, verstößt die unbegrenzte Speicherung gegen den Grundsatz der Speicherbegrenzung.

### OLG Dresden, Urteil 2024 — Nachweispflicht bei Löschung

Das OLG Dresden hat 2024 entschieden, dass eine formlose Bestätigung der Datenlöschung durch einen Auftragsverarbeiter nicht ausreicht. Es bedarf einer **formellen Bescheinigung**, die konkret aufzeigt, wann, wie und durch wen die Löschung erfolgte. Dies gilt entsprechend auch für CORE gegenüber Betroffenen und Fonds.

### Art. 12 Abs. 3 DSGVO — Fristen

Auf einen Löschantrag muss der Verantwortliche **unverzüglich, spätestens innerhalb eines Monats** antworten. Verlängerung auf drei Monate bei Komplexität möglich, aber zu begründen.

---

## 3. Rechtliche Analyse

### 3.1 Doppelrolle schafft Komplexität

CORE agiert gleichzeitig als:
1. **Auftragsverarbeiter** für VC-Fonds → Löschung nur auf Weisung des Fonds (Art. 28)
2. **Eigenständiger Verantwortlicher** für Benchmarking/Produktverbesserung → eigenständige Löschpflicht gegenüber Gründern (Art. 17)

Diese Doppelrolle erzeugt ein Koordinationsproblem: Wenn ein Gründer die Löschung verlangt, muss CORE entscheiden, in welcher Rolle es handelt und welche Pflichten gelten. Im schlimmsten Fall verweist CORE den Gründer an den Fonds, der Fonds an CORE — der Gründer erhält keine Antwort.

### 3.2 Fehlende CASCADE-Constraints

Ohne Datenbankconstraints, die ein `DELETE` in `submissions` automatisch auf `pipeline_items`, `notes` und `activity_log` kaskadieren, müssen Löschungen manuell in jeder Tabelle durchgeführt werden. Fehler dabei sind wahrscheinlich und können zu Phantom-Daten führen — ein datenschutzrechtliches Risiko.

### 3.3 localStorage als blinder Fleck

Die `core_demo_leads_v4` und `core_outreach_v1`-Daten liegen in localStorage des Fondsmitarbeiters. Eine serverseitige Löschung in Supabase erreicht diese Daten nicht. CORE hat technisch keinen Zugriff auf localStorage des Nutzers — eine vollständige Löschung ist hier faktisch unmöglich, ohne dass der Fonds aktiv mitwirkt.

### 3.4 Backup-Daten

Supabase-Backups enthalten gelöschte Daten für die gesamte Retention-Periode (in der Regel 7–30 Tage je nach Plan). Die DSGVO verlangt keine sofortige Löschung aus Backups, aber CORE muss sicherstellen, dass wiederhergestellte Backups keine "zurückgekehrten" gelöschten Daten ins Produktionssystem bringen.

### 3.5 Kein Löschnachweis

Ohne einen formalen Lösch-Workflow kann CORE das Rechenschaftsprinzip (Art. 5 Abs. 2) nicht erfüllen. Bei einem Betroffenenbeschwerde-Verfahren bei einer Aufsichtsbehörde hätte CORE keine dokumentierten Belege.

---

## 4. Handlungsbedarf

### Sofortmaßnahmen (0–4 Wochen)

1. **Kontaktweg für Betroffene einrichten** — Eine dedizierte E-Mail-Adresse (z.B. `datenschutz@core-platform.io`) als Anlaufstelle für Löschanträge. Diese Adresse muss in der Datenschutzerklärung kommuniziert werden.

2. **Internes Löschverfahren dokumentieren** — Schriftliche SOP: Wer empfängt den Antrag? Wer führt die Löschung durch? Wer bestätigt sie? Welche Tabellen sind betroffen? Zieldauer: max. 30 Tage.

3. **Datenbankschema prüfen und CASCADE DELETEs einrichten:**
   ```sql
   -- Beispiel: submissions löschen kaskadiert auf abhängige Tabellen
   ALTER TABLE pipeline_items
     ADD CONSTRAINT fk_submission
     FOREIGN KEY (submission_id)
     REFERENCES submissions(id)
     ON DELETE CASCADE;

   ALTER TABLE notes
     ADD CONSTRAINT fk_submission
     FOREIGN KEY (submission_id)
     REFERENCES submissions(id)
     ON DELETE CASCADE;
   ```
   Für `activity_log` nach Supabase-Migration analog.

### Mittelfristige Maßnahmen (1–3 Monate)

4. **Löschbestätigung als formaler Prozessschritt** — Nach Löschung aus allen Tabellen: Automatisierte oder manuelle Bestätigung per E-Mail an den Gründer mit Zeitstempel und Liste der gelöschten Datenkategorien (OLG Dresden 2024).

5. **Fonds-Koordination im AVV regeln** — Klare Regelung im AVV: Bei Löschantrag eines Gründers informiert CORE den Fonds (Art. 17 Abs. 2 DSGVO), der Fonds ist für seine localStorage-Daten selbst verantwortlich. CORE löscht serverseitig und bestätigt.

6. **Löschfristen definieren** — Ablaufschem für automatische Löschung: z.B. Submissions ohne Pipeline-Aktion nach 24 Monaten löschen (Basis: Art. 5 Abs. 1 lit. e). In DSE und Verarbeitungsverzeichnis dokumentieren.

7. **localStorage-Hinweis an Fonds** — Bei Fondsonboarding darauf hinweisen, dass localStorage-Daten (leads, outreach) in der Verantwortung des Fonds liegen. Empfehlung: Verlagerung in Supabase auch für leads/outreach-Daten.

### Langfristig (3–6 Monate)

8. **Self-Service-Löschfunktion prüfen** — Gründer-Login oder Antragsstrecke, über die Gründer ihre Daten selbst einsehen und Löschung beantragen können (empfohlen, nicht zwingend).

9. **Backup-Policy für Löschfälle** — Dokumentieren, dass Backups nach Ablauf der Retention-Periode automatisch gelöscht werden und wiederhergestellte Backups vor Produktivierung auf bereits gelöschte Records geprüft werden.

---

## 5. Fazit

Das Recht auf Löschung nach Art. 17 DSGVO ist bei CORE technisch und prozessual nicht vollständig umsetzbar. Die Schwachstellen sind: fehlende CASCADE-Constraints, unkontrollierbares localStorage, kein dokumentierter Lösch-Workflow und kein Löschnachweis. Angesichts der koordinierten EDSA-Prüfaktion 2025 zu genau diesem Thema ist dringender Handlungsbedarf gegeben.

**Schweregrad: HOCH** — Kein unmittelbares Bußgeldrisiko, aber erhebliches Risiko bei Betroffenenbeschwerden und Aufsichtsbehördenprüfungen. Bei nachgewiesener Missachtung von Löschanträgen können Bußgelder nach Art. 83 Abs. 5 lit. b DSGVO bis zu 20 Mio. EUR oder 4 % des weltweiten Jahresumsatzes verhängt werden.

---

*Quellen: Art. 17 DSGVO (dejure.org), Art. 28 Abs. 3 lit. g DSGVO, Art. 5 Abs. 1 lit. e DSGVO, OLG Dresden (2024) — Datenpanne bei Auftragsverarbeiter, EDSA Koordinierte Aktion 2025 zu Art. 17 DSGVO (cmshs-bloggt.de), Art. 12 Abs. 3 DSGVO*
