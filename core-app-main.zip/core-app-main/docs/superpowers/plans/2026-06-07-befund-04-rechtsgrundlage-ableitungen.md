# Befund 04 — Art. 6 Abs. 1 lit. b: Rechtsgrundlage für abgeleitete Kennzahlen überdehnt

**Audit-Datum:** 7. Juni 2026  
**Schweregrad:** MITTEL  
**Kategorie:** B — Fehlinterpretation / Rechtsfehler  
**Betrifft:** Datenschutzerklärung v5.6.2026, api/submit.js (Zeilen 226–254)

---

## Was ist das Problem?

Die Datenschutzerklärung nennt als primäre Rechtsgrundlage für die Verarbeitung von Gründerdaten **Art. 6 Abs. 1 lit. b DSGVO** — Verarbeitung zur Erfüllung eines Vertrags oder zur Durchführung vorvertraglicher Massnahmen.

Das trägt für die Rohdaten der Einreichung: Gründer füllen das Formular aus, um eine Einreichung beim Fonds zu machen. Das ist ein vorvertraglicher Schritt — lit. b ist korrekt.

Das Problem liegt bei den **serverseitig berechneten und dauerhaft gespeicherten Ableitungen** (api/submit.js, Zeilen 226–254):

- `arr_eur` — Annual Recurring Revenue (aus MRR × 12)
- `arpa_eur` — Average Revenue Per Account
- `ltv_eur` — Customer Lifetime Value (aus ARPA, Gross Margin, Churn)
- `cac_payback_months` — CAC Payback Period
- `burn_multiple` — Burn im Verhältnis zu Net New ARR
- `has_repeat_founder`, `has_prior_exit`, `has_technical_founder`, `has_domain_expert` — boolesche Gründermerkmale

Diese Werte hat der Gründer **nicht eingegeben**. Der Plattformbetreiber hat sie berechnet, kategorisiert und dauerhaft gespeichert. Sie sind neue Datenpunkte — Ableitungen aus den Rohdaten.

---

## Warum ist das ein Problem?

### Lit. b deckt nur objektiv Notwendiges

Der EuGH hat (u.a. C-252/21, Facebook/Bundeskartellamt) klargestellt: Art. 6 Abs. 1 lit. b darf nur herangezogen werden, wenn die Verarbeitung **objektiv unerlässlich** ist, um den Vertragszweck zu erfüllen. Es reicht nicht, dass die Verarbeitung nützlich oder wirtschaftlich sinnvoll ist.

Der Gründer möchte eine Einreichung beim Fonds machen. Dafür braucht der Fonds seine Rohdaten: MRR, CAC, Burn, Gründerprofile. Das ist lit. b.

Ob der Server daraus `ltv_eur` berechnet, `burn_multiple` ableitet und diese Werte dauerhaft als eigenständige Datenpunkte speichert — das ist **keine objektive Notwendigkeit** für den Vorgang "Einreichung entgegennehmen". Der Fonds könnte die Kennzahlen selbst berechnen, oder gar nicht. Der Gründer hat nicht darum gebeten, dass Derivate über ihn gespeichert werden.

### Boolesche Merkmale sind Profiling nach Art. 4 Nr. 4

`has_repeat_founder: true` ist ein kategorisierendes Urteil über eine Person. Es wird aus Angaben abgeleitet und dauerhaft gespeichert. Das erfüllt die Definition von Profiling nach Art. 4 Nr. 4 DSGVO — automatisierte Verarbeitung zur Bewertung persönlicher Aspekte. Profiling auf Basis von lit. b ist nur möglich, wenn es für die Vertragserfüllung objektiv notwendig ist. Das ist hier nicht gegeben.

### Die korrekte Rechtsgrundlage wäre lit. f — aber mit Konsequenzen

Art. 6 Abs. 1 lit. f erlaubt die Verarbeitung bei berechtigtem Interesse — für VC-Screening-Kennzahlen gut argumentierbar. Aber lit. f bringt zwei Pflichten mit:

1. **Dreistufenprüfung muss dokumentiert sein** — berechtigtes Interesse benennen, Notwendigkeit prüfen, Interessenabwägung durchführen. Diese Dokumentation gehört ins interne Art.-30-Verarbeitungsverzeichnis, nicht nur in die Datenschutzerklärung.

2. **Widerspruchsrecht nach Art. 21 DSGVO** — lit. f löst automatisch das Recht aus, der Verarbeitung zu widersprechen. Wenn ein Gründer der Speicherung von `ltv_eur` oder `has_prior_exit` widerspricht, muss diese Verarbeitung eingestellt und die gespeicherten Ableitungen gelöscht werden — ausser es bestehen zwingende schutzwürdige Gründe, die überwiegen. Das ist heute technisch nicht umsetzbar, weil keine Möglichkeit besteht, einzelne Felder einer Submission selektiv zu löschen.

---

## Die Lösung

### Massnahme 1 — Datenschutzerklärung: Rechtsgrundlage trennen und lit. f dokumentieren

Die Datenschutzerklärung muss klar zwischen Rohdaten (lit. b) und Ableitungen (lit. f) unterscheiden:

| Verarbeitung | Rechtsgrundlage |
|---|---|
| Rohdaten der Einreichung (MRR, CAC, Gründerprofile) | Art. 6 Abs. 1 lit. b |
| Berechnete Kennzahlen (ARR, LTV, Burn Multiple etc.) | Art. 6 Abs. 1 lit. f |
| Boolesche Gründermerkmale (Repeat Founder, Prior Exit etc.) | Art. 6 Abs. 1 lit. f |
| Plausibilitätsprüfung und Signal-Score | Art. 6 Abs. 1 lit. f |

Für lit. f in der Datenschutzerklärung (Kurzfassung):

> "Berechtigtes Interesse (Art. 6 Abs. 1 lit. f): Der Fonds hat ein berechtigtes wirtschaftliches Interesse daran, aus den eingereichten Rohdaten standardisierte Kennzahlen (ARR, ARPA, LTV, CAC Payback, Burn Multiple) und Teammerkmale (Repeat Founder, Prior Exit, technisches Profil) automatisiert abzuleiten und dauerhaft zu speichern, um Einreichungen vergleichbar zu machen und das Dealflow-Screening zu strukturieren. Das Interesse des Fonds überwiegt: die Ableitung betrifft ausschliesslich berufliche und finanzielle Kennzahlen, keine sensiblen Datenkategorien nach Art. 9 DSGVO, und der Gründer nimmt die Einreichung freiwillig vor in dem Wissen, dass der Fonds die Daten für eine Investitionsbewertung nutzt."

### Massnahme 2 — Widerspruchsrecht in der Datenschutzerklärung explizit nennen

Da lit. f als Grundlage gilt, muss Art. 21 explizit erwähnt werden:

> "Sie können gemäss Art. 21 Abs. 1 DSGVO jederzeit der Berechnung und Speicherung abgeleiteter Kennzahlen und Teammerkmale aus Ihrer Einreichung widersprechen. Im Fall eines Widerspruchs werden diese Ableitungen aus Ihrer Einreichung gelöscht. Die Einreichung selbst (Rohdaten) bleibt davon unberührt, sofern keine gesonderte Löschanfrage gestellt wird."

### Massnahme 3 — Technisch: Selektive Löschung einzelner Felder ermöglichen

Das Widerspruchsrecht ist nur erfüllbar, wenn technisch möglich. Konkret: Eine Admin-Funktion (oder API-Endpoint) muss es erlauben, für eine einzelne Submission die berechneten Felder (`arr_eur`, `ltv_eur`, `burn_multiple`, `has_repeat_founder` etc.) auf `null` zu setzen, ohne die gesamte Einreichung zu löschen. Das ist eine überschaubare technische Massnahme — ein SQL-Update auf spezifische Spalten.

### Massnahme 4 — Intern: Interessenabwägung im Art.-30-Verarbeitungsverzeichnis dokumentieren

Der Text in der Datenschutzerklärung ist die Kurzfassung für Betroffene. Die eigentliche rechtliche Dokumentation der Interessenabwägung gehört ins interne Verarbeitungsverzeichnis nach Art. 30 DSGVO — datiert, mit Nennung der betroffenen Datenkategorien, des Zwecks und der Abwägungsergebnisse. Ohne dieses Verzeichnis ist die Datenschutzerklärung ein Text ohne juristisches Fundament.

---

## Was nicht vollständig wasserdicht ist

Lit. f ist die richtige Rechtsgrundlage — aber zwei Risiken bleiben:

**Risiko 1:** Wenn ein Gründer widerspricht und die technische Möglichkeit zur selektiven Löschung nicht besteht, ist das Widerspruchsrecht faktisch nicht erfüllbar. Das ist ein eigenständiger Verstoss gegen Art. 21 DSGVO.

**Risiko 2:** Die Interessenabwägung muss intern dokumentiert sein. Ein DSB kann bei einer Prüfung das Art.-30-Verzeichnis anfordern — steht dort nichts zur Abwägung, hilft der Text in der Datenschutzerklärung allein nicht.

---

## Zusammenfassung: Was sich ändert

| Was | Wo | Aufwand |
|---|---|---|
| Rechtsgrundlagen-Tabelle (lit. b vs. lit. f) einfügen | Datenschutzerklärung | 15 Minuten |
| Art.-21-Widerspruchsrecht für Ableitungen ergänzen | Datenschutzerklärung | 10 Minuten |
| Selektive Löschung berechneter Felder | api oder Supabase Admin | 30 Minuten |
| Interessenabwägung dokumentieren | Art.-30-Verarbeitungsverzeichnis | Einmalig, anwaltlich |

---

## Was anwaltlich zu klären bleibt

Die Interessenabwägung für lit. f muss formal dokumentiert werden — das ist Standardarbeit für einen DSGVO-Anwalt. Mitbringen: die Liste der abgeleiteten Felder aus api/submit.js (Zeilen 226–254) und die Beschreibung des Zwecks (Dealflow-Screening, Vergleichbarkeit von Einreichungen).

---

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 7. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
