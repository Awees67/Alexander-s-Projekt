# Implementierungsplan: Backend Hardening Woche 1

**Datum:** 2026-04-28  
**Spec:** `docs/superpowers/specs/2026-04-28-backend-hardening-pre-pilot-design.md` (V3)  
**Ziel:** Alle P0-Sicherheitslücken schließen. Danach: kein Key in Git, kein manipulierbarer Submit, fund_id-Isolation garantiert.

---

## Ausführungsreihenfolge

### Phase A — Git & Env (keine App-Auswirkung)

**Schritt 1: `.gitignore` erweitern**  
Datei: `.gitignore`  
Hinzufügen am Ende:
```
# Environment variables — niemals committen
.env
.env.local
.env.*.local

# Supabase client config — enthält anon key
js/config.js
```
Verify: `git status` zeigt `js/config.js` NICHT als untracked wenn die Datei danach erstellt wird.

---

**Schritt 2: `.env.example` anlegen**  
Datei: `.env.example` (neue Datei, wird committed)
```
# Supabase
SUPABASE_URL=https://DEIN-PROJEKT-ID.supabase.co
SUPABASE_ANON_KEY=sb_publishable_XXXXXXXXXX
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.XXXXXXXXXX

# Attio — noch nicht aktiv, Platzhalter für Woche 4+
# ATTIO_API_KEY=
```

---

**Schritt 3: `js/config.example.js` anlegen**  
Datei: `js/config.example.js` (neue Datei, wird committed)
```js
// Kopiere diese Datei zu js/config.js und trage echte Werte ein.
// js/config.js ist in .gitignore — wird niemals committed.
// Neue Keys erhältst du in: Supabase Dashboard → Project Settings → API
const SUPABASE_URL      = 'https://DEIN-PROJEKT-ID.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_XXXXXXXXXXXXXXXXXXXXXXXXXX';
```

---

**Schritt 4: `js/config.js` lokal erstellen**  
Datei: `js/config.js` (lokal, NICHT committed, bereits in .gitignore nach Schritt 1)
```js
const SUPABASE_URL      = 'https://ggfjgzjevyemwbclvfpp.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_lv0jbhjnUHy3N0EQhhhUdQ_NAKjpwDO'; // wird später rotiert
```
Verify: `git status` zeigt `js/config.js` NICHT (gitignored).

---

### Phase B — Script-Ladereihenfolge (App läuft nach dieser Phase)

**Schritt 5: `index.html` — Script-Order korrigieren**  
Datei: `index.html`, Zeilen 414-416  
Vorher:
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
<script src="js/supabase-client.js"></script>
<script src="js/config.js"></script>
```
Nachher:
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
<script src="js/config.js"></script>
<script src="js/supabase-client.js"></script>
```
Verify: Browser-Konsole nach Reload zeigt keine "SUPABASE_URL is not defined" Fehler.

---

**Schritt 6: `login.html` — config.js Script-Tag einfügen**  
Datei: `login.html`, nach Zeile 146  
Vorher:
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
<script src="js/supabase-client.js"></script>
```
Nachher:
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
<script src="js/config.js"></script>
<script src="js/supabase-client.js"></script>
```
Verify: `login.html` lädt ohne Konsolen-Fehler.

---

**Schritt 7: `js/supabase-client.js` — hardcoded Keys ersetzen + attio_api_key entfernen**  
Datei: `js/supabase-client.js`

Änderung 1 — Zeilen 1-4:
```js
// Vorher:
const supabaseClient = window.supabase.createClient(
  'https://ggfjgzjevyemwbclvfpp.supabase.co',
  'sb_publishable_lv0jbhjnUHy3N0EQhhhUdQ_NAKjpwDO'
);

// Nachher:
const supabaseClient = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_ANON_KEY
);
```

Änderung 2 — getCurrentFund() Zeile 28:
```js
// Vorher:
.select('id, name, slug, attio_api_key')

// Nachher:
.select('id, name, slug')
```
Verify: App lädt, Fund-Name erscheint, keine Konsolen-Fehler.

---

### Phase C — Supabase DB (SQL-Migrationen)

**Schritt 8: DB-Migration — `attio_api_key` Column droppen**  
Ausführen in Supabase SQL Editor:
```sql
ALTER TABLE public.funds
DROP COLUMN IF EXISTS attio_api_key;
```
Verify: `SELECT column_name FROM information_schema.columns WHERE table_name = 'funds';` — `attio_api_key` erscheint nicht mehr.

---

**Schritt 9: DB-Migration — 6 Indexes anlegen**  
Ausführen in Supabase SQL Editor (alle auf einmal):
```sql
CREATE INDEX IF NOT EXISTS idx_fund_users_user_id
  ON public.fund_users (user_id);

CREATE INDEX IF NOT EXISTS idx_submissions_fund_id
  ON public.submissions (fund_id);

CREATE INDEX IF NOT EXISTS idx_submissions_contact_email
  ON public.submissions (contact_email);

CREATE INDEX IF NOT EXISTS idx_notes_fund_id
  ON public.notes (fund_id);

CREATE INDEX IF NOT EXISTS idx_notes_submission_id
  ON public.notes (submission_id);

CREATE INDEX IF NOT EXISTS idx_pipeline_fund_id
  ON public.pipeline (fund_id);
```
Verify: Kein SQL-Fehler. Alle 6 `CREATE INDEX` Befehle erfolgreich.

---

### Phase D — API Layer absichern

**Schritt 10: `js/api.js` — `apiLoadFund` select fix + null fund_id guards**  

Änderung 1 — `apiLoadFund()` Zeile 8:
```js
// Vorher:
.select('*')

// Nachher:
.select('id, name, slug')
```

Änderung 2 — `apiLoadSubmissions()` Zeile 27-33 (null guard):
```js
async function apiLoadSubmissions(fund_id) {
  if (!fund_id) throw new Error('[apiLoadSubmissions] fund_id ist required — kein Query ohne Fund-Filter');
  const { data, error } = await supabaseClient
    .from('submissions')
    .select('*')
    .eq('status', 'pending')
    .eq('fund_id', fund_id)
    .order('submitted_at', { ascending: false });
  if (error) throw error;
  return data || [];
}
```

Änderung 3 — `apiLoadAcceptedSubmissions()` Zeile 35-41 (null guard):
```js
async function apiLoadAcceptedSubmissions(fund_id) {
  if (!fund_id) throw new Error('[apiLoadAcceptedSubmissions] fund_id ist required — kein Query ohne Fund-Filter');
  const { data, error } = await supabaseClient
    .from('submissions')
    .select('*')
    .eq('status', 'accepted')
    .eq('fund_id', fund_id)
    .order('submitted_at', { ascending: false });
  if (error) throw error;
  return data || [];
}
```
Verify: App lädt submissions korrekt, keine Fehler in Konsole.

---

### Phase E — Submit absichern (kritischste Phase)

**Schritt 11: `api/fund.js` — SERVICE_ROLE_KEY**  
Datei: `api/fund.js`
```js
// Vorher:
const { SUPABASE_URL, SUPABASE_ANON_KEY } = process.env;
if (!SUPABASE_URL || !SUPABASE_ANON_KEY) { ... }
// headers: apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}`

// Nachher:
const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) { ... }
// headers: apikey: SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
```

---

**Schritt 12: `api/submit.js` — vollständige Überarbeitung**  
Datei: `api/submit.js`

Reihenfolge der Änderungen:
1. Zeile 154: `SUPABASE_ANON_KEY` → `SUPABASE_SERVICE_ROLE_KEY`
2. Nach der Env-Prüfung: Rate Limiting Block einfügen (erste Operation!)
3. Vor der plausibility-Berechnung: fund_id aus `req.query.fund` ableiten
4. Nach fund_id: `generateAnonId()` + `generateUniqueAnonId()` Funktionen + `await generateUniqueAnonId(fund_id)`
5. `insertData`: `fund_id`, `anon_id`, `status: 'pending'` hinzufügen (überschreibt body-Felder)
6. Insert-Headers: `SUPABASE_ANON_KEY` → `SUPABASE_SERVICE_ROLE_KEY`

Vollständige Struktur des überarbeiteten Handlers (nach `computePlausibility`-Funktion):
```js
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) return res.status(500).json({ error: 'Server misconfigured' });

  const body = req.body;

  // 1. Rate Limiting (immer zuerst)
  const contactEmail = body?.contact_email;
  if (contactEmail) {
    const since = new Date(Date.now() - 86400000).toISOString();
    const rlRes = await fetch(
      `${SUPABASE_URL}/rest/v1/submissions?contact_email=eq.${encodeURIComponent(contactEmail)}&submitted_at=gte.${since}&select=id`,
      { headers: { apikey: SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` } }
    );
    const rlData = await rlRes.json();
    if (Array.isArray(rlData) && rlData.length >= 3) {
      return res.status(429).json({ error: 'Zu viele Einreichungen von dieser E-Mail-Adresse. Bitte warte 24 Stunden.' });
    }
  }

  // 2. fund_id aus URL-Parameter ableiten
  const fundSlug = req.query.fund;
  if (!fundSlug) return res.status(400).json({ error: 'Fund-Parameter fehlt. URL muss ?fund=<slug> enthalten.' });

  const fundRes = await fetch(
    `${SUPABASE_URL}/rest/v1/funds?slug=eq.${encodeURIComponent(fundSlug)}&select=id`,
    { headers: { apikey: SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` } }
  );
  const fundData = await fundRes.json();
  if (!fundRes.ok || !Array.isArray(fundData) || fundData.length === 0) {
    return res.status(404).json({ error: 'Fonds nicht gefunden. Bitte prüfe den Link.' });
  }
  const fund_id = fundData[0].id;

  // 3. anon_id serverseitig generieren
  function generateAnonId() {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const letter = letters[Math.floor(Math.random() * letters.length)];
    const num = Math.floor(1000 + Math.random() * 9000);
    return letter + '-' + num;
  }
  async function generateUniqueAnonId(fund_id) {
    for (let attempt = 0; attempt < 5; attempt++) {
      const candidate = generateAnonId();
      const checkRes = await fetch(
        `${SUPABASE_URL}/rest/v1/submissions?fund_id=eq.${fund_id}&anon_id=eq.${candidate}&select=id`,
        { headers: { apikey: SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` } }
      );
      const existing = await checkRes.json();
      if (!Array.isArray(existing) || existing.length === 0) return candidate;
    }
    throw new Error('Konnte keine eindeutige anon_id generieren');
  }
  const anon_id = await generateUniqueAnonId(fund_id);

  // 4. Berechnungen (bestehende Logik bleibt)
  const mrr   = body.mrr_eur           || null;
  // ... (alle bestehenden Berechnungen bleiben unverändert) ...

  // 5. Plausibility (bestehend)
  const plaus = computePlausibility({ ...body, arr_eur, ltv_cac_ratio });

  // 6. insertData — serverseitige Felder überschreiben body
  const insertData = {
    ...body,
    fund_id,           // aus Slug abgeleitet
    anon_id,           // serverseitig generiert
    status: 'pending', // immer hardcoded
    arr_eur,
    // ... (alle anderen berechneten Felder bleiben) ...
    plausibility_status: plaus.status,
    plausibility_checks: plaus.checks,
    plausibility_summary: plaus.summary,
  };

  // 7. Insert mit SERVICE_ROLE_KEY
  const response = await fetch(`${SUPABASE_URL}/rest/v1/submissions`, {
    method: 'POST',
    headers: {
      apikey: SUPABASE_SERVICE_ROLE_KEY,
      Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      'Content-Type': 'application/json',
      Prefer: 'return=minimal',
    },
    body: JSON.stringify(insertData),
  });
  // ...
}
```

---

**Schritt 13: `submit/index.html` — Body bereinigen + `?fund=` + 429-Handler**  

Änderung 1 — `submissionData` Objekt (Zeilen ~817-857):  
Felder `fund_id`, `anon_id` und `status: 'pending'` aus dem Objekt entfernen.

Änderung 2 — Fetch-URL:
```js
// Vorher:
const res = await fetch('/api/submit', { ... });

// Nachher:
const fundSlug = currentFund?.slug
  || new URLSearchParams(window.location.search).get('fund')
  || new URLSearchParams(window.location.search).get('f');

const res = await fetch('/api/submit?fund=' + encodeURIComponent(fundSlug || ''), { ... });
```

Änderung 3 — Nach dem fetch: 429-Handler einfügen:
```js
if (res.status === 429) {
  const err = await res.json();
  document.getElementById('submitBtn').disabled = false;
  document.getElementById('loadingOverlay').style.display = 'none';
  showError(err.error || 'Zu viele Einreichungen. Bitte in 24 Stunden erneut versuchen.');
  return;
}
```
Verify: Submit-Formular mit `?fund=<slug>` funktioniert End-to-End.

---

### Phase F — Vercel Env Var setzen

**Schritt 14: `SUPABASE_SERVICE_ROLE_KEY` in Vercel setzen**  
In Vercel Dashboard: Project → Settings → Environment Variables  
Variable: `SUPABASE_SERVICE_ROLE_KEY`  
Wert: Service Role Key aus Supabase Dashboard → Project Settings → API → `service_role` (secret)  
Umgebungen: Production + Preview + Development

Verify: Vercel Deployment hat Zugriff auf die neue Variable.

---

### Phase G — End-to-End Tests + Key-Rotation

**Schritt 15: Deployment-Tests**  
1. Submit-Formular End-to-End: Submission landet in korrektem Fund mit serverseitig generierter `anon_id`
2. Rate Limit: Gleiche E-Mail 4x → 4. gibt HTTP 429 mit deutschem Text
3. Login → App lädt → Fund-Name sichtbar

**Schritt 16: Anon Key rotieren** (nur nach erfolgreichem Test 3)  
1. Supabase Dashboard → Project Settings → API → "Roll anon key"
2. `js/config.js` lokal mit neuem Key aktualisieren
3. Vercel → `SUPABASE_ANON_KEY` auf neuen Wert setzen

---

## Gesamtübersicht

| # | Datei | Art |
|---|---|---|
| 1 | `.gitignore` | Edit |
| 2 | `.env.example` | Neu |
| 3 | `js/config.example.js` | Neu |
| 4 | `js/config.js` | Neu (lokal) |
| 5 | `index.html` | Edit (2 Tags tauschen) |
| 6 | `login.html` | Edit (1 Tag einfügen) |
| 7 | `js/supabase-client.js` | Edit (2 Stellen) |
| 8 | Supabase SQL | Migration (attio_api_key drop) |
| 9 | Supabase SQL | Migration (6 Indexes) |
| 10 | `js/api.js` | Edit (3 Stellen) |
| 11 | `api/fund.js` | Edit (Service Role Key) |
| 12 | `api/submit.js` | Edit (vollständige Überarbeitung) |
| 13 | `submit/index.html` | Edit (3 Stellen) |
| 14 | Vercel Dashboard | Env Var setzen |
| 15 | Browser | End-to-End Tests |
| 16 | Supabase + Vercel | Key-Rotation |
