# Befund 01 — Art. 14 DSGVO fehlt + Multi-Fonds-Skalierung

**Audit-Datum:** 6. Juni 2026  
**Schweregrad:** KRITISCH  
**Kategorie:** C (Lücke / fehlende Pflichtangabe)  
**Betrifft:** Datenschutzerklärung v5.6.2026, Submit-Formular /submit

---

## Was ist das Problem?

Das Einreichungsformular erlaubt, dass Gründer A Daten über Gründer B einträgt:

- Name, Rolle, LinkedIn-URL von Gründer B
- Berufserfahrung, Ausbildung, Exit-Erfahrung von Gründer B
- Eigenkapitalanteil von Gründer B (z.B. "45 %")

Gründer B hat das Formular nie selbst ausgefüllt. Er hat keine Datenschutzinformation erhalten. Trotzdem verarbeitet der Fonds seine personenbezogenen Daten — inklusive Finanzdaten über sein Eigentum.

Die aktuelle Datenschutzerklärung ist im Titel auf "Art. 13 DSGVO" ausgerichtet und deckt ausschliesslich Personen ab, die Daten selbst einreichen. Für Gründer B existiert **keine Datenschutzinformation**.

## Warum ist das rechtlich ein Problem?

Die DSGVO unterscheidet zwei Szenarien:

- **Art. 13**: Daten werden direkt bei der betroffenen Person erhoben. Informationspflicht entsteht im Moment der Erhebung.
- **Art. 14**: Daten werden **nicht** bei der betroffenen Person erhoben, sondern bei einem Dritten. Informationspflicht entsteht trotzdem — spätestens innerhalb eines Monats nach Erhebung, oder bei der ersten Kommunikation mit der Person.

Art. 14 verlangt zusätzlich zu allen Art.-13-Pflichtangaben: **die Datenquelle** (aus welcher Quelle die Daten stammen).

Verletzung von Art. 14 ist bussgeldfähig nach Art. 83 Abs. 4 DSGVO (bis 10 Mio. EUR oder 2 % Jahresumsatz). Da der Plattformbetreiber eine natürliche Person ist, besteht persönliche und unbegrenzte Haftung.

## Zusätzlich entdecktes Problem: Datenschutzerklärung nicht skalierbar auf mehrere Fonds

Im gleichen Zuge wurde festgestellt: Die Datenschutzerklärung nennt APEX Ventures GmbH hardcoded als einzigen Fonds. Das verletzt Art. 13 Abs. 1 lit. a DSGVO bei jedem weiteren Fonds, der auf die Plattform kommt — denn Gründer müssen beim Absenden **Namen und Kontaktdaten des Verantwortlichen** kennen, und der Verantwortliche ist der Fonds, nicht der Plattformbetreiber.

Bei 10 Fonds bräuchte man entweder 10 Versionen der Datenschutzerklärung oder ein Appendix-System, das bei jedem neuen Fonds eine neue Version der Datenschutzerklärung und eine Benachrichtigungsrunde aller bestehenden Gründer auslöst. Beides ist nicht skalierbar.

### Gewählter Lösungsansatz: Dynamische Fondsdaten aus der Datenbank

Die fondsspezifische Datenschutzinformation wird **nicht** in der Datenschutzerklärung hinterlegt, sondern **direkt am Formular dynamisch aus der Supabase `funds`-Tabelle** gezogen und angezeigt. Die zentrale Datenschutzerklärung beschreibt nur noch die Struktur ("der zuständige Fonds wird beim Absenden angezeigt"), ohne einzelne Fonds namentlich zu benennen.

**Warum das Art. 13 Abs. 1 lit. a DSGVO erfüllt:**
Art. 13 verlangt die Information "zum Zeitpunkt der Erhebung" — das ist das Formular, nicht die Datenschutzseite. Wenn das Formular beim Absenden den korrekten Fonds (Name, Adresse, Datenschutzkontakt) anzeigt, ist die Pflicht erfüllt. Die Datenschutzerklärung muss den Fonds nicht namentlich kennen.

**Was die Supabase `funds`-Tabelle dafür benötigt:**

Die Tabelle braucht drei Felder, die bei jedem Fonds-Onboarding befüllt werden:

| Feld | Inhalt | Beispiel |
|---|---|---|
| `name` | Vollständiger Rechtsname des Fonds | APEX Ventures GmbH |
| `address` | Postanschrift (Strasse, PLZ, Ort) | Habsburgergasse 2/1a, 1010 Wien |
| `privacy_contact_email` | E-Mail für Datenschutzanfragen | tim.hos@apex.at |

**Was das Formular anzeigt (Info-Box vor dem Absende-Button):**

> "Ihre Einreichung wird verarbeitet von:
> **[Fondsname]**, [Adresse]
> Datenschutzkontakt: [privacy_contact_email]
>
> Der Plattformbetreiber (Andreas Awees) verarbeitet Ihre Daten als Auftragsverarbeiter im Auftrag des oben genannten Fonds. Vollständige Datenschutzerklärung: [Link]"

**Was die Datenschutzerklärung (Abschnitt 1.2) dann sagt:**

> "Der zuständige Fonds wird Ihnen beim Absenden des Einreichungsformulars namentlich angezeigt (Art. 13 Abs. 1 lit. a DSGVO). Die Identität des Fonds hängt davon ab, über welches Formular Sie einreichen. Auf schriftliche Anfrage teilen wir Ihnen jederzeit mit, welcher Fonds für Ihre Einreichung verantwortlich ist — wenden Sie sich dazu an awees6703@gmail.com.
>
> Aktuell im Pilotbetrieb: APEX Ventures GmbH, Habsburgergasse 2/1a, 1010 Wien (tim.hos@apex.at). Diese Angabe wird bei Aufnahme weiterer Fonds nicht in dieser Erklärung aktualisiert — die massgebliche Information ergibt sich immer aus der Formularanzeige beim Einreichen."

**Vorteil dieser Lösung:**
- Jeder neue Fonds: Eintrag in `funds`-Tabelle (5 Minuten) -- keine neue Version der Datenschutzerklärung nötig
- Art. 13 Abs. 1 lit. a immer erfüllt, weil die Information fondsspezifisch und aktuell ist
- Kein Benachrichtigungsaufwand gegenüber bestehenden Gründern bei neuem Fonds-Onboarding

---

## Massnahme 1 — Dynamische Fondsdaten + Art.-14-Hinweis auf dem Submit-Formular

Das Formular erhält eine Info-Box direkt vor dem Absende-Button mit zwei Teilen:

**Teil A -- Fondsdaten dynamisch aus Supabase (Art. 13):**
Name, Adresse und Datenschutzkontakt-E-Mail des zuständigen Fonds werden aus der `funds`-Tabelle geladen und angezeigt. Kein statischer Text, kein hardcoded Fondsname. Neuer Fonds = neuer Datenbankeintrag, keine neue Datenschutzerklärung.

**Teil B -- Art.-14-Pflichthinweis für Mitgründer-Daten:**

> "Wenn Sie Angaben zu weiteren Personen machen (z.B. Mitgründerinnen und Mitgründer), sind Sie als einreichende Person verpflichtet, diese Personen über die Verarbeitung ihrer Daten zu informieren. Informationen dazu finden Sie in unserer Datenschutzerklärung unter Abschnitt 17 (Informationen nach Art. 14 DSGVO)."

**Warum reicht das rechtlich aus:** Art. 14 Abs. 4 DSGVO erlaubt, die Informationspflicht auf die einreichende Person zu übertragen, wenn der Verantwortliche die Daten nicht direkt erhebt und es unverhältnismässig wäre, jeden Mitgründer selbst zu kontaktieren. Voraussetzung: der Hinweis ist **sichtbar, klar und mit direktem Link zur Art.-14-Information** versehen.

---

## Massnahme 2 — Neuer Abschnitt 17 in der Datenschutzerklärung (Art. 14)

Der folgende Text ist als neuer Abschnitt 17 in die Datenschutzerklärung einzufügen. Anker: `id="art14"`. Das Inhaltsverzeichnis und der Dokumententitel sind entsprechend zu aktualisieren.

**Titel anpassen:**  
Alt: `"gemäß Art. 13 DSGVO und DSG 2018"`  
Neu: `"gemäß Art. 13 und Art. 14 DSGVO und DSG 2018"`

---

### Abschnitt 17: Informationen für mitgenannte Personen (Art. 14 DSGVO)

Dieser Abschnitt richtet sich an Personen, deren Daten im Rahmen einer Startup-Einreichung durch eine andere Person (z.B. einen Mitgründer) übermittelt wurden — ohne dass sie selbst das Formular ausgefüllt haben.

**Wer ist Verantwortlicher?**

Der datenschutzrechtlich Verantwortliche für Ihre Daten ist der Venture-Capital-Fonds, dem die Einreichung zugeordnet wurde. Dessen Identität und Kontaktdaten wurden der einreichenden Person beim Absenden des Formulars angezeigt. Auf Anfrage teilen wir Ihnen den zuständigen Fonds mit — wenden Sie sich dazu an: awees6703@gmail.com. Wir leiten Ihre Anfrage innerhalb von 5 Werktagen an den Fonds weiter.

**Welche Daten wurden übermittelt?**

Typischerweise: Name, Rolle im Unternehmen, LinkedIn-URL, Berufserfahrung (Jahre), Ausbildung, Exit-Erfahrung, Stärken sowie ggf. Angaben zur Beteiligungsstruktur (z.B. Eigenkapitalanteil). Diese Daten wurden von einer anderen Person im Rahmen der Startup-Einreichung angegeben. Prozentuale Eigenkapitalanteile, die mit Ihrem Namen verknüpft sind, stellen personenbezogene Daten dar (EuGH C-17/22 und C-18/22, 12.09.2024).

**Woher stammen die Daten? (Art. 14 Abs. 2 lit. f DSGVO)**

Die Daten stammen aus dem CORE-Einreichungsformular unter /submit, das von einer anderen Person (z.B. einem Mitgründer oder Co-Founder) ausgefüllt wurde.

**Zu welchem Zweck und auf welcher Rechtsgrundlage?**

Zweck: Bewertung der Startup-Einreichung durch den zuständigen Fonds im Rahmen seines Dealflow-Screenings, einschliesslich der Bewertung des Gründerteams als zentralem Investitionskriterium.

Rechtsgrundlage: Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse des Fonds an einer strukturierten Vorabprüfung von Einreichungen). Das berechtigte Interesse überwiegt: VC-Fonds haben ein legitimes wirtschaftliches Interesse an der Bewertung vollständiger Gründerteams; die Verarbeitung beschränkt sich auf berufliche Qualifikationsdaten; die einreichende Person hat die Einreichung freiwillig vorgenommen und dabei Angaben zu Teammitgliedern gemacht.

Widerspruch: Sie können gemäss Art. 21 Abs. 1 DSGVO jederzeit und ohne Begründung Widerspruch gegen diese Verarbeitung einlegen. Wenden Sie sich dazu an den zuständigen Fonds oder an awees6703@gmail.com.

**Wie lange werden die Daten gespeichert?**

Für die Dauer der aktiven Fondsbeziehung (Laufzeit des Pilotvertrags / SaaS-Nutzungsvertrags zwischen Plattformbetreiber und Fonds). Nach Vertragsende: 30-tägige Exportfrist, danach vollständige Löschung aus allen Systemen gemäss Auftragsverarbeitungsvertrag. Einzelheiten: siehe Abschnitt 8 dieser Erklärung.

**Ihre Rechte als betroffene Person**

Sie haben gegenüber dem zuständigen Fonds als Verantwortlichem dieselben Rechte wie alle anderen betroffenen Personen:

- Auskunft (Art. 15 DSGVO): Sie können erfahren, welche Daten über Sie gespeichert sind.
- Berichtigung (Art. 16 DSGVO): Unrichtige Daten sind auf Verlangen zu korrigieren.
- Löschung (Art. 17 DSGVO): Sie können die Löschung Ihrer Daten verlangen, soweit keine Aufbewahrungspflichten entgegenstehen.
- Einschränkung (Art. 18 DSGVO): Sie können eine eingeschränkte Verarbeitung verlangen.
- Widerspruch (Art. 21 DSGVO): Sie können der Verarbeitung jederzeit widersprechen (Rechtsgrundlage: Art. 6 Abs. 1 lit. f).

Wenden Sie sich mit Anfragen direkt an den zuständigen Fonds oder, falls Ihnen dessen Kontaktdaten nicht bekannt sind, an den Plattformbetreiber: awees6703@gmail.com. Wir leiten Ihre Anfrage innerhalb von 5 Werktagen an den Fonds weiter.

**Beschwerderecht**

Sie können jederzeit Beschwerde bei der Österreichischen Datenschutzbehörde einlegen — ohne vorherige Kontaktaufnahme mit dem Verantwortlichen:

Österreichische Datenschutzbehörde  
Barichgasse 40-42, 1030 Wien  
dsb@dsb.gv.at | www.dsb.gv.at

---

## Offene Fragen (anwaltlich zu klären)

1. **Art. 14 Abs. 4 Delegation:** Reicht der Formular-Hinweis ("Sie sind verpflichtet, Mitgründer zu informieren") tatsächlich als Delegationsgrundlage, oder muss der Fonds als Verantwortlicher selbst aktiv Mitgründer kontaktieren? Bei aktiviv bekannten E-Mail-Adressen von Mitgründern (die im Formular stehen) könnte eine direkte Benachrichtigungspflicht entstehen.

2. **Rechtsgrundlage Mitgründer-Daten:** Ist lit. f für Mitgründer-Profildaten tragfähig, oder müsste hier eine Einwilligung des Mitgründers eingeholt werden? (Zu verifizieren anhand DSB-Praxis Österreich.)

---

*Dieser Bericht ist kein Rechtsgutachten und ersetzt keine anwaltliche Beratung.*  
*Erstellt: 6. Juni 2026 im Rahmen des DSGVO-Audits der CORE Datenschutzerklärung.*
