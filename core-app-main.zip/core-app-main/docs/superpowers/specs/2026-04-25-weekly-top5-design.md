# Top 5 Deals der Woche — Design Spec
**Datum:** 2026-04-25
**Status:** Draft
**Scope:** js/renderers-weekly-top5.js (neu), js/main.js, index.html

---

## Problem

Das Dealflow-Volumen wächst. Analysts brauchen eine schnelle Übersicht der besten unbearbeiteten Deals ohne manuell zu filtern und sortieren. Insbesondere Deals die keine Pipeline-Stage haben und länger unbearbeitet bleiben gehen unter.

---

## Lösung

Ein **"★ Top 5 Woche"-Button** im Header öffnet ein Modal mit den 5 besten unbearbeiteten Deals des gewählten Zeitraums, gerankt nach Peer-Percentile innerhalb der eigenen Stage-Gruppe.

---

## Architektur

### Betroffene Dateien

| Datei | Änderung |
|---|---|
| `js/main.js` | `submitted_at` in `buildStartupFromSubmission()` ergänzen |
| `index.html` | Button in `header-utils` + Script-Tag + Event-Listener |
| `js/renderers-weekly-top5.js` | **Neue Datei** — gesamte Top-5-Logik |

**Nicht angefasst:** `renderers-cards.js`, `custom-index.js`, `signal-index.js`, `state.js`, alle anderen Renderer.

### Script-Load-Order

Aktuelle Reihenfolge in `index.html` (relevant):
- Zeile 423: `signal-index.js` → stellt `computeSignalIndex()` bereit
- Zeile 425: `custom-index.js` → stellt `computeCustomIndexV6()` bereit
- Zeile 436: `renderers-modals.js`
- **Zeile 437 (neu):** `renderers-weekly-top5.js` ← hier einfügen
- Zeile 438: `renderers.js` (verschiebt sich auf 439)
- Zeile 439: `main.js` (verschiebt sich auf 440)

`renderers-weekly-top5.js` wird **zwischen `renderers-modals.js` und `renderers.js`** eingehängt. Damit stehen alle Abhängigkeiten sicher zur Verfügung: `window.startups`, `escapeHTML()`, `getPipeline()`, `computeSignalIndex()`, `computeCustomIndexV6()`.

---

## Begriffsdefinitionen

**"Pipeline-Stage"** = ein Startup ist in der Pipeline wenn `getPipeline()` einen Eintrag mit matching `anon_id` enthält. Dies ist unabhängig vom `stage`-Feld (= Funding-Stage: Pre-Seed, Seed, Series A, etc.).

**"Unbearbeitet"** = nicht in `getPipeline()` enthalten.

---

## Daten & Algorithmus

### Schritt 1 — submitted_at mappen (main.js)

In `buildStartupFromSubmission()` eine Zeile ergänzen, direkt nach `_from_submission`:

```js
submitted_at: sub.submitted_at || sub.created_at || null,
```

### Schritt 2 — Kandidaten filtern

```js
function getWeeklyTop5Candidates(days) {
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  const pipelineIds = new Set(getPipeline().map(p => p.anon_id));

  return (window.startups || []).filter(s =>
    !pipelineIds.has(s.anon_id) &&
    s.submitted_at !== null &&
    new Date(s.submitted_at).getTime() >= cutoff
  );
}
```

Candidates ohne `submitted_at` werden ausgeschlossen. Die Zeitfenster-Filterung ist **inklusiv** — alle Submissions mit `submitted_at >= cutoff` (d.h. eingereicht innerhalb der letzten N×24 Stunden) werden eingeschlossen. Eine Submission die exakt zum Cutoff-Zeitpunkt liegt ist enthalten.

### Schritt 3 — Peer-Score berechnen

`signal_index` ist **keine direkte Property** auf Startup-Objekten — Score wird via `computeSignalIndex(anon_id)` berechnet (Proxy auf `computeCustomIndexV6().score`, gecacht).

```js
function computePeerRank(startup) {
  const peerGroup = (window.startups || [])
    .filter(s => (s.stage || '') === (startup.stage || ''))
    .map(s => ({ anon_id: s.anon_id, score: computeSignalIndex(s.anon_id) }))
    .sort((a, b) => b.score - a.score);

  const rank = peerGroup.findIndex(s => s.anon_id === startup.anon_id) + 1;
  const total = peerGroup.length;
  // "Top X%" = Startup ist besser als (100 - X)% der Peers
  // rank=1, total=74 → ceil(1/74*100) = 2 → "Top 2%"
  // Singleton (total=1): topPercent=null → kein % anzeigen
  const topPercent = total > 1 ? Math.ceil((rank / total) * 100) : null;

  return { rank, total, topPercent };
}
```

**Stage-Gruppen-Regeln:**
- Startups mit `stage === null` oder `stage === ""` bilden eine eigene Peer-Gruppe und werden als `stage || "Unbekannt"` behandelt
- Bei nur 1 Startup in der Gruppe: Peer-Badge zeigt `"#1 von 1 [Stage]"` ohne Prozentzahl
- Peer-Gruppe umfasst **alle** `window.startups` (nicht nur den Zeitraum) für einen stabilen Vergleichswert

### Schritt 4 — Top 5 sortieren

Kandidaten nach `topPercent` aufsteigend sortieren (niedrigster Wert = bester Rang), erste 5 nehmen.

Bei Gleichstand (selber `topPercent`): sekundär nach absolutem Score absteigend.

### Schritt 5 — "Warum Top 5"-Text generieren

`computeCustomIndexV6(anon_id)` gibt zurück:
```js
{
  score: number,
  breakdown: [
    {
      rule_id: string,
      kpi: string,
      points: number,       // positiv = Bonus, negativ = Penalty
      note: string,         // human-readable Label, z.B. "MRR 20–80k€ (Seed)"
      skipped: true | undefined,  // true wenn KPI fehlt und skip_rule Policy
      actual_value: number | null
    },
    ...
  ],
  enabled: boolean
}
```

Extraktion der Top-3-Gründe:
```js
function buildWhyText(anon_id) {
  const res = computeCustomIndexV6(anon_id);
  const top3 = (res.breakdown || [])
    .filter(r => r.points > 0 && !r.skipped)
    .sort((a, b) => b.points - a.points)
    .slice(0, 3);

  if (!top3.length) return null; // null = kein Text → Fallback im HTML-Builder
  return top3.map(r => `${escapeHTML(r.note)} (+${r.points} Pkt)`).join(', ');
}
```

`buildWhyText()` gibt `null` zurück wenn keine positiven Regeln vorhanden. Die Fallback-Anzeige liegt in `buildWeeklyTop5RowHTML()`:

```js
const whyText = buildWhyText(startup.anon_id);
const whyContent = whyText ?? 'Relativ bester Deal im Zeitraum.';
```

---

## UI

### Modal DOM-Struktur

Das Modal rendert in einem **eigenen Backdrop-Element** mit `id="weeklyTop5Backdrop"` — unabhängig von `modalBackdrop` (dem Detail-Modal). Kein Eingriff in die bestehende Modal-Infrastruktur.

```html
<!-- in index.html, nach #modalBackdrop -->
<div id="weeklyTop5Backdrop" class="modal-backdrop" aria-hidden="true" style="display:none;">
  <div class="top5-modal"></div>
</div>
```

`openWeeklyTop5Modal()` setzt `style.display = "flex"` und `aria-hidden = "false"`. Schliessen setzt beides zurück.

### Button (index.html — header-utils)

```html
<button class="header-util-btn header-util-btn--top5" id="navWeeklyTop5">★ Top 5 Woche</button>
```

CSS-Ergänzung in `main.css` (unter den bestehenden `.header-util-btn` Regeln):
```css
.header-util-btn--top5 {
  background: rgba(255,255,255,0.92);
  color: var(--accent);
  border-color: rgba(255,255,255,0.9);
  font-weight: 800;
}
[data-theme="dark"] .header-util-btn--top5 {
  background: rgba(75,150,245,0.18);
  color: var(--accent);
  border-color: rgba(75,150,245,0.35);
}
```

### Modal-Struktur

```
┌─ Topbar (44px) ──────────────────────────────────────┐
│ ★ Top 5 Deals — unbearbeitet              [✕]        │
├─ Timebar ─────────────────────────────────────────────┤
│ Zeitraum: [7 Tage*] [14 Tage] [30 Tage] [90 Tage]   │
│                              18 ohne Stage · 5 gerankt│
├─ Deals-Liste (overflow-y: auto) ──────────────────────┤
│  #1 L-3847  [Seed]                         Score: 71  │
│     MRR €64k  Growth +22%  NRR 118%  Runway 19 Mo.   │
│     Warum: MRR 20–80k€ Seed (+8 Pkt), NRR... Top 2%  │
│                                          #1 von 74 Seeds│
│  #2–#5 ...                                            │
├─ Footer ──────────────────────────────────────────────┤
│ Nur ohne Pipeline-Stage · Peer-Rang innerhalb Stage   │
└───────────────────────────────────────────────────────┘
```

### Score-Anzeige

Die **Score-Zahl** (z.B. 71) = Rückgabe von `computeSignalIndex(anon_id)` — absoluter Score auf der 0–85 Skala.

Der **Peer-Badge** (z.B. "Top 2%") = `topPercent` aus `computePeerRank()`.

Beide werden nebeneinander angezeigt:
```
71        ← computeSignalIndex()
/ 85
Top 2%    ← topPercent aus computePeerRank()
#1 von 74 Seeds
```

### Meta-Text (Timebar rechts)

```
"[N] ohne Stage · [M] gerankt"
```
- **N** = Anzahl Kandidaten ohne Pipeline-Eintrag im gewählten Zeitfenster (unabhängig ob 5 oder weniger)
- **M** = tatsächlich angezeigte Deals (≤ 5)

Beispiel: 18 Submissions in 7 Tagen ohne Pipeline-Stage → 5 gerankt → `"18 ohne Stage · 5 gerankt"`

### Design-Tokens

Alle Klassen und Tokens sind exakt wie im Rest der App:

| Element | Klasse / Token |
|---|---|
| Modal Backdrop | `--overlay` rgba, `position: fixed; inset: 0` |
| Modal Container | `--surface-raised`, `--border-default`, `border-radius: var(--radius)` |
| Topbar | wie `.dv-topbar`: `height: 44px`, `--border-default` bottom |
| Schliessen-Button | `.dv-btn dv-btn-close` |
| Zeit-Buttons | `.dv-btn` + `.dv-btn.active` für aktiven Zeitraum |
| Deal-Karten | `--surface-raised`, `--border-default`, `border-radius: 8px` |
| Stage-Badge | Mapping: `"Pre-Seed"` → `dv-pill-preseed`, `"Seed"` → `dv-pill-seed`, `"Pre-Series A"` → `dv-pill-prea`, `"Series A"` → `dv-pill-a`, `"Series B"` → `dv-pill-a` |
| Stage null/leer | `.dv-pill` ohne Stage-Klasse, Text: "Unbekannt" |
| **Neue CSS-Klassen in main.css** | `dv-pill-preseed`, `dv-pill-prea`, `dv-pill-a` existieren noch nicht — werden nach `.dv-pill-seed` ergänzt: `css .dv-pill-preseed { color: #7c3aed; border-color: rgba(124,58,237,0.3); } [data-theme="dark"] .dv-pill-preseed { color: #a78bfa; border-color: rgba(167,139,250,0.3); } .dv-pill-prea { color: #059669; border-color: rgba(5,150,105,0.3); } [data-theme="dark"] .dv-pill-prea { color: #34d399; border-color: rgba(52,211,153,0.3); } .dv-pill-a { color: var(--score-ring-medium); border-color: rgba(245,158,11,0.3); }` |
| Score-Zahl | `font-family: var(--font-data)`, 28px |
| Score-Farbe | `.high` (≥ 70) `--score-ring-high`, `.mid` (≥ 40) `--score-ring-medium`, `.low` (< 40) `--score-ring-low` — identisch mit `renderers-modals.js:57` |
| Peer-Badge | `topPercent !== null`: inline badge mit Farbe nach Score. `topPercent === null` (Singleton): nur `"#1 von 1 [Stage]"` anzeigen, kein Badge |
| Peer-Badge Single | `--score-ring-medium` Farbe (kein high/low) |
| "Warum Top 5"-Box | `--surface-overlay`, `--border-subtle`, `border-radius: 5px` |
| Footer | `--surface-overlay`, `--text-tertiary`, `--border-default` top |

### Visuelle Sonderfälle

| Element | Regel |
|---|---|
| #1-Karte | `border-color: var(--accent)`, `background: var(--accent-subtle)` |
| Rank-Badge #1 | Gold: `background: rgba(245,158,11,0.12)`, `color: var(--score-ring-medium)` |
| Peer-Badge bei 1er-Gruppe | Kein Badge-Container. Nur Text `"#1 von 1 [Stage]"` in `--score-ring-medium` Farbe. Gleiche visuelle Behandlung wie regulärer Peer-Zähler, aber ohne %-Zahl und ohne Badge-Rahmen. |
| Zeitfenster-Default | 7 Tage aktiv beim Öffnen |

---

## Edge Cases

| Fall | Verhalten |
|---|---|
| < 5 Kandidaten | Zeige nur verfügbare Deals. Meta: `"3 ohne Stage · 3 gerankt"` |
| `submitted_at: null` | Startup wird aus Kandidaten ausgeschlossen |
| `stage === null/""` | Peer-Gruppe "Unbekannt", Badge zeigt `dv-pill` ohne Stage-Klasse |
| Peer-Gruppe hat 1 Startup | Badge: `"#1 von 1 [Stage]"`, Farbe `score-ring-medium`, kein % |
| Keine positiven Scoring-Regeln | "Warum"-Box: `"Relativ bester [Stage] im Zeitraum."` |
| 0 Kandidaten im Zeitraum | Leerer State in Deals-Liste: zentrierter Text `"Keine unbearbeiteten Deals in diesem Zeitraum."`. Topbar und Timebar bleiben sichtbar. Footer ausgeblendet. |
| Gleichstand beim topPercent | Sekundär nach absolutem Score absteigend sortieren |

---

## Was sich NICHT ändert

- Bestehende Modal-Infrastruktur (`modalBackdrop`, `renderers-modals.js`) — kein Eingriff
- Scoring-Engine (`custom-index.js`, `signal-index.js`) — wird nur gelesen
- Pipeline-Logik (`state.js`) — wird nur gelesen via `getPipeline()`
- Alle anderen Views und Renderer

---

## Implementierungsreihenfolge

1. **`js/main.js`** — `submitted_at` in `buildStartupFromSubmission()` ergänzen
2. **`styles/main.css`** — `.header-util-btn--top5` CSS-Regeln ergänzen
3. **`index.html`** — Button in `header-utils`, Script-Tag nach `renderers-modals.js`
4. **`js/renderers-weekly-top5.js`** — neue Datei mit folgenden Funktionen in dieser Reihenfolge:
   - `computePeerRank(startup)` — Peer-Score Berechnung
   - `getWeeklyTop5Candidates(days)` — Kandidaten filtern
   - `buildWhyText(anon_id)` — "Warum Top 5"-Text generieren
   - `buildWeeklyTop5RowHTML(startup, rank, peerData)` — HTML für eine Deal-Zeile
   - `renderWeeklyTop5Modal(days)` — Modal-HTML rendern und einfügen
   - `openWeeklyTop5Modal()` — Button-Handler, öffnet Modal mit Default 7 Tage
5. **`js/main.js`** — Event-Listener: `document.getElementById('navWeeklyTop5').addEventListener('click', openWeeklyTop5Modal)`
