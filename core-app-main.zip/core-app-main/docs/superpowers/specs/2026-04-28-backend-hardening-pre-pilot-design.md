# Spec: Backend Hardening vor Pilot-Launch
**Datum:** 2026-04-28  
**Version:** V3 (nach Final-Review)  
**Autor:** Claude (im Auftrag von Abdullah Awees)  
**Status:** Final  
**Ziel:** Alle kritischen Sicherheits- und Persistenz-Schwächen schließen bevor der erste echte VC-Fonds ongeboardet wird.  
**Scope:** 3 Wochen Vollzeit-Arbeit. Kein Attio-Integration. Kein UI-Redesign. Kein Feature-Scope-Creep.

---

## 1. Kontext & Ausgangslage

### 1.1 Projektarchitektur
- **Frontend:** Statisches HTML/CSS/JS, kein Build-Schritt, kein Framework
- **Backend:** Vercel Serverless Functions in `api/*.js` (Node.js)
- **Datenbank:** Supabase PostgreSQL, Region `eu-central-1` (Frankfurt), Projekt-ID `ggfjgzjevyemwbclvfpp`
- **Auth:** Supabase Magic Link (kein Passwort)
- **Hosting:** Vercel (aktuell Free Tier, Pro-Upgrade am Ende von Woche 3)

### 1.2 Aktuelle Script-Ladereihenfolge in `index.html`
Dies ist die tatsächliche Reihenfolge (aus `index.html:414-436`, Stand 28.04.26):

```
1.  supabase.min.js (CDN)
2.  js/supabase-client.js    ← PROBLEM: config.js wird nach ihr geladen
3.  js/config.js             ← existiert noch nicht, Platzhalter in HTML bereits vorhanden
4.  js/utils.js
5.  js/state.js
6.  js/api.js
7.  js/signal-index.js
8.  js/filters.js
9.  js/custom-index.js
10. js/activity.js
11. js/renderers-helpers.js → ... → js/renderers-weekly-top5.js → js/renderers.js
12. js/main.js               ← muss immer letzte sein
```

**Bekanntes Problem:** `js/config.js` ist in `index.html` bereits als Platzhalter eingetragen, aber an Position 3 — nach `js/supabase-client.js`. Das wird in Abschnitt 3.1 korrigiert.

### 1.3 Aktuelle Supabase-Datenbank (Stand 28.04.26)

| Tabelle | Rows | RLS aktiv | Policies |
|---|---|---|---|
| `funds` | 1 | Ja | 1 — `qual: true` (KRITISCH) |
| `submissions` | 45 | Ja | 3 |
| `pipeline` | 3 | Ja | 4 |
| `notes` | 0 | Ja | 3 |
| `attio_pushes` | 0 | Ja | 2 |
| `fund_users` | 3 | Ja | 1 (nur SELECT) |

**Fehlende Tabellen:**
- `activity_log` — fehlt komplett
- `scoring_rules` — fehlt komplett
- `outreach` — fehlt komplett

### 1.4 Was bereits korrekt funktioniert
- Magic Link Auth + Auth Guard in `main.js`
- Fund-Load beim App-Start: `getCurrentFund()` → `window.fundName`
- Pipeline vollständig Supabase-backed (`js/api.js` + `js/state.js`)
- Notes vollständig Supabase-backed
- Plausibility Check server-seitig in `api/submit.js`
- `escapeHTML()` in allen Renderers — kein XSS-Risiko
- `fund_users` write-protected (kein User kann sich selbst Fondszugang geben)

---

## 2. Vollständige Problem-Liste

### P0 — Zwingend vor erstem Pilot-User

| # | Problem | Fundstelle | Konsequenz wenn nicht gefixt |
|---|---|---|---|
| P0-1 | `funds` RLS Policy `qual: true` — jeder liest alle Tabellen-Spalten ohne Auth | Supabase, Policy "Anyone can read funds by slug" | `attio_api_key` (sobald gesetzt) öffentlich lesbar ohne Login |
| P0-2 | `attio_api_key` in `getCurrentFund()` Select | `js/supabase-client.js:28` | Key landet im Browser jedes eingeloggten Users |
| P0-3 | `attio_api_key` in `apiLoadFund()` via `select('*')` | `js/api.js:8` | Key landet im Browser |
| P0-4 | `anon_id` client-generiert ohne Kollisionsschutz | `submit/index.html:763-768` | Duplikate möglich (1:234.000), manipulierbar |
| P0-5 | `fund_id` kommt ungeprüft vom Client | `submit/index.html:818` | Submissions in beliebige Fonds einspeisbar |
| P0-6 | `status: 'pending'` kommt vom Client | `submit/index.html:857` | Client kann `status: 'accepted'` setzen |
| P0-7 | Supabase Anon Key hardcoded im Git-Repo | `js/supabase-client.js:1-4` | Key nicht rollbar ohne Code-Änderung |
| P0-8 | `.gitignore` schützt keine `.env`-Dateien | `.gitignore` | Service Role Key könnte aus Versehen committed werden |

### P1 — In Woche 1–2

| # | Problem | Fundstelle |
|---|---|---|
| P1-1 | Null `fund_id` → kein Filter → alle Submissions aller Fonds sichtbar | `js/api.js:27-40` |
| P1-2 | Fehlende DB-Indexes → Performance-Degradierung | Supabase |
| P1-3 | Scoring Rules in localStorage → kein Team-Sync, Datenverlust | `js/custom-index.js` |
| P1-4 | `activity_log` nur localStorage → kein geteilter Team-Kontext | `js/state.js:341-347` |
| P1-5 | `outreach` nur localStorage → kein Team-Kontext | `js/state.js:490-509` |

### P2 — In Woche 2–3

| # | Problem | Fundstelle |
|---|---|---|
| P2-1 | Kein Rate Limiting auf Submit | `api/submit.js` |
| P2-2 | Plausibility-Logik doppelt mit unterschiedlichem Kontext — dokumentiert aber nicht konsolidiert | `api/submit.js` + `js/utils.js` |
| P2-3 | Kein `vercel.json` → keine garantierte Region, kein Function-Timeout | Root |

---

## 3. Woche 1 — Security Foundation

### 3.1 Env-Variablen aufräumen und Keys aus Git entfernen

#### 3.1.1 `.gitignore` aktualisieren

**Datei:** `.gitignore`  
**Aktion:** Folgende Zeilen am Ende der Datei hinzufügen. Bestehende Einträge nicht anfassen.

```
# Environment variables — niemals committen
.env
.env.local
.env.*.local

# Supabase client config — enthält anon key
js/config.js
```

**Hinweis:** `js/config.local.js` ist bereits in `.gitignore`. Neu ist der Eintrag für `js/config.js` (ohne `.local`). Beide bleiben.

#### 3.1.2 `js/config.example.js` anlegen (wird committed, kein echter Key)

**Datei:** `js/config.example.js`  
**Aktion:** Neue Datei erstellen. Wird in Git committed. Enthält nur Platzhalter, nie echte Werte.

```js
// Kopiere diese Datei zu js/config.js und trage echte Werte ein.
// js/config.js ist in .gitignore — wird niemals committed.
// Neue Keys erhältst du in: Supabase Dashboard → Project Settings → API
const SUPABASE_URL     = 'https://DEIN-PROJEKT-ID.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_XXXXXXXXXXXXXXXXXXXXXXXXXX';
```

#### 3.1.3 `js/config.js` lokal anlegen (gitignored, wird nicht committed)

**Datei:** `js/config.js` (lokal, existiert nicht in Git)  
**Aktion:** Datei lokal erstellen. Enthält den echten (vorerst alten) Anon Key.

```js
const SUPABASE_URL     = 'https://ggfjgzjevyemwbclvfpp.supabase.co';
const SUPABASE_ANON_KEY = '<aktueller-anon-key>';  // wird in Schritt 3.1.6 rotiert
```

#### 3.1.4 Script-Ladereihenfolge in `index.html` korrigieren

**Problem:** `js/config.js` ist in `index.html` aktuell an Position 3 (nach `supabase-client.js`). Da `supabase-client.js` die Variablen `SUPABASE_URL` und `SUPABASE_ANON_KEY` aus `config.js` benötigt, muss `config.js` **vor** `supabase-client.js` geladen werden.

**Datei:** `index.html`  
**Aktion:** Die zwei Script-Tags tauschen.

**Vorher (Zeilen 414–416):**
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
<script src="js/supabase-client.js"></script>
<script src="js/config.js"></script>
```

**Nachher:**
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
<script src="js/config.js"></script>
<script src="js/supabase-client.js"></script>
```

#### 3.1.5 Script-Ladereihenfolge in `login.html` ergänzen

**Problem:** `login.html` hat keinen `js/config.js`-Tag. Da `login.html` ebenfalls `js/supabase-client.js` lädt, muss `config.js` auch hier ergänzt werden.

**Datei:** `login.html`  
**Aktion:** Einen Script-Tag zwischen CDN und `supabase-client.js` einfügen.

**Vorher (Zeilen 146–147):**
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
<script src="js/supabase-client.js"></script>
```

**Nachher:**
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
<script src="js/config.js"></script>
<script src="js/supabase-client.js"></script>
```

#### 3.1.6 `js/supabase-client.js` auf Config-Variablen umstellen

**Datei:** `js/supabase-client.js:1-4`  
**Aktion:** Hardcodierte Werte durch Config-Variablen ersetzen.

**Vorher:**
```js
const supabaseClient = window.supabase.createClient(
  'https://ggfjgzjevyemwbclvfpp.supabase.co',
  'sb_publishable_lv0jbhjnUHy3N0EQhhhUdQ_NAKjpwDO'
);
```

**Nachher:**
```js
const supabaseClient = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_ANON_KEY
);
```

**Voraussetzung:** `js/config.js` muss vorher geladen sein (durch Schritte 3.1.4 und 3.1.5 sichergestellt).

#### 3.1.7 Anon Key rotieren

**Aktion nach Deployment der obigen Änderungen:**
1. Supabase Dashboard öffnen → Project Settings → API
2. "Roll anon key" klicken → neuen Key kopieren
3. `js/config.js` lokal aktualisieren: neuen Key eintragen
4. Vercel Dashboard → Project → Settings → Environment Variables → `SUPABASE_ANON_KEY` auf neuen Wert setzen

**Hinweis zum alten Key in Git-History:** Der alte Key (`sb_publishable_lv0jbhjnUHy3N0EQhhhUdQ_NAKjpwDO`) bleibt in der Git-History — das ist akzeptabel, da der alte Key nach dem Rollieren deaktiviert ist und der Anon Key per Supabase-Design sowieso öffentlich zugänglich ist (geschützt durch RLS). Ein History-Rewrite via `git filter-repo` ist optional aber kein Security-Muss.

#### 3.1.8 `.env.example` anlegen

**Datei:** `.env.example` (neu, wird committed)  
**Aktion:** Datei mit allen Server-seitigen Env Vars anlegen. Nur Platzhalter, keine echten Werte.

```
# Supabase
SUPABASE_URL=https://DEIN-PROJEKT-ID.supabase.co
SUPABASE_ANON_KEY=sb_publishable_XXXXXXXXXX
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.XXXXXXXXXX

# Attio — noch nicht aktiv, Platzhalter für Woche 4+
# ATTIO_API_KEY=
```

**Wo echte Werte gesetzt werden:** Vercel Dashboard → Project → Settings → Environment Variables. Alle drei Variablen für **Production**, **Preview** und **Development** setzen.

---

### 3.2 `funds`-Tabelle absichern

#### 3.2.1 Problem und Lösung

**Problem:** Die RLS-Policy "Anyone can read funds by slug" hat `qual: true`. Das bedeutet: jeder Browser, jedes Script, jeder Curl-Aufruf kann ohne Auth-Session `SELECT * FROM funds` ausführen.

**Wichtiger Hinweis zu Supabase RLS:** RLS ist Row-Level Security, nicht Column-Level Security. Es ist technisch nicht möglich, einzelne Spalten via RLS zu verstecken. Die einzige sichere Lösung: die `attio_api_key`-Spalte aus der `funds`-Tabelle entfernen.

**Konsequenz:** Der Attio API Key lebt künftig ausschließlich als Vercel Environment Variable `ATTIO_API_KEY`. Wenn die Attio-Integration später gebaut wird, liest `api/attio.js` den Key aus `process.env.ATTIO_API_KEY` — nie aus der Datenbank oder dem Client.

**Die bestehende `qual: true` Policy bleibt** — sie ist nach dem Column-Drop sicher, weil `attio_api_key` dann nicht mehr existiert.

#### 3.2.2 `attio_api_key` Column droppen

**Migration — in Supabase SQL Editor ausführen:**
```sql
-- Vor Ausführung prüfen: attio_api_key wird in keiner aktiven Funktion verwendet
-- Stand 28.04.26: pipelinePushToCRM() setzt nur status='Synced', ruft keine Attio-API auf
ALTER TABLE public.funds 
DROP COLUMN IF EXISTS attio_api_key;
```

#### 3.2.3 `getCurrentFund()` in `js/supabase-client.js` bereinigen

**Datei:** `js/supabase-client.js:28`

**Vorher:**
```js
.select('id, name, slug, attio_api_key')
```

**Nachher:**
```js
.select('id, name, slug')
```

#### 3.2.4 `apiLoadFund()` in `js/api.js` bereinigen

**Datei:** `js/api.js:8`

**Vorher:**
```js
.select('*')
```

**Nachher:**
```js
.select('id, name, slug')
```

---

### 3.3 Submit-Formular absichern

#### 3.3.1 Überblick der Änderungen

Das Submit-Formular schickt drei Felder die der Server nie vom Client akzeptieren darf:
- `anon_id` — client-generiert, kollisionsanfällig, manipulierbar
- `fund_id` — kommt aus dem Client, beliebiger Wert möglich
- `status: 'pending'` — Client könnte `status: 'accepted'` senden

**Lösung:**
- `fund_id`: Wird nicht mehr im Body übermittelt. Der Server leitet sie aus dem URL-Query-Parameter `?fund=<slug>` ab.
- `anon_id`: Wird serverseitig in `api/submit.js` generiert. Client-seitige `generateAnonId()`-Funktion im Formular bleibt als Fallback für die UI-Validierung, aber der Server ignoriert body.anon_id komplett.
- `status`: Wird im Server immer auf `'pending'` hardcoded.

#### 3.3.2 `submit/index.html` — Body bereinigen und Slug übergeben

**Datei:** `submit/index.html`

**Änderung 1 — `submissionData`-Objekt:** Die Felder `fund_id`, `anon_id` und `status` aus dem Objekt entfernen.

**Vorher (Zeilen 817-857, relevante Felder):**
```js
const submissionData = {
  fund_id: currentFund.id,        // ← ENTFERNEN
  anon_id: generateAnonId(),       // ← ENTFERNEN
  company_name: val('company_name'),
  // ... alle anderen Felder bleiben ...
  status: 'pending',              // ← ENTFERNEN
};
```

**Nachher:**
```js
const submissionData = {
  // fund_id wird serverseitig aus ?fund= abgeleitet
  // anon_id wird serverseitig generiert
  company_name: val('company_name'),
  // ... alle anderen Felder bleiben unverändert ...
  // status wird serverseitig auf 'pending' gesetzt
};
```

**Änderung 2 — Fetch-URL:** Den `?fund=<slug>`-Parameter an die Submit-URL anhängen.

**Vorher (Zeile 859):**
```js
const res = await fetch('/api/submit', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(submissionData),
});
```

**Nachher:**
```js
// currentFund.slug ist aus dem loadFund()-Aufruf bereits bekannt
const fundSlug = currentFund?.slug 
  || new URLSearchParams(window.location.search).get('fund') 
  || new URLSearchParams(window.location.search).get('f');

const res = await fetch('/api/submit?fund=' + encodeURIComponent(fundSlug || ''), {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(submissionData),
});
```

**Hinweis:** `currentFund` wird in `loadFund()` gesetzt (Zeile 735: `currentFund = data`). Das Objekt enthält `id`, `name` und `slug`. Kein zweiter API-Call nötig.

#### 3.3.3 `api/submit.js` — Vollständige Überarbeitung

**Datei:** `api/submit.js`

Die folgenden Änderungen werden in dieser Reihenfolge vorgenommen:

**Änderung 1 — Env Vars aktualisieren:**

**Vorher (Zeile 154):**
```js
const { SUPABASE_URL, SUPABASE_ANON_KEY } = process.env;
if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  return res.status(500).json({ error: 'Server misconfigured' });
}
```

**Nachher:**
```js
const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  return res.status(500).json({ error: 'Server misconfigured' });
}
```

`SUPABASE_ANON_KEY` wird komplett aus `api/submit.js` entfernt. Die Datei verwendet ab sofort ausschließlich `SUPABASE_SERVICE_ROLE_KEY`.

**Änderung 2 — Rate Limiting als erstes (vor jedem anderen DB-Call):**

```js
// Rate Limiting — MUSS als erste Operation laufen, bevor Fund-Lookup oder Plausibility
const contactEmail = req.body?.contact_email;
if (contactEmail) {
  const since = new Date(Date.now() - 86400000).toISOString(); // 24h zurück
  const rlRes = await fetch(
    `${SUPABASE_URL}/rest/v1/submissions?contact_email=eq.${encodeURIComponent(contactEmail)}&submitted_at=gte.${since}&select=id`,
    {
      headers: {
        apikey: SUPABASE_SERVICE_ROLE_KEY,
        Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      },
    }
  );
  const rlData = await rlRes.json();
  if (Array.isArray(rlData) && rlData.length >= 3) {
    return res.status(429).json({
      error: 'Zu viele Einreichungen von dieser E-Mail-Adresse. Bitte warte 24 Stunden.'
    });
  }
}
```

**Änderung 3 — `fund_id` serverseitig aus Slug ableiten:**

```js
// fund_id aus URL-Parameter ableiten — body.fund_id wird nie verwendet
const fundSlug = req.query.fund;
if (!fundSlug) {
  return res.status(400).json({ error: 'Fund-Parameter fehlt. URL muss ?fund=<slug> enthalten.' });
}

const fundRes = await fetch(
  `${SUPABASE_URL}/rest/v1/funds?slug=eq.${encodeURIComponent(fundSlug)}&select=id`,
  {
    headers: {
      apikey: SUPABASE_SERVICE_ROLE_KEY,
      Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
    },
  }
);
const fundData = await fundRes.json();
if (!fundRes.ok || !Array.isArray(fundData) || fundData.length === 0) {
  return res.status(404).json({ error: 'Fonds nicht gefunden. Bitte prüfe den Link.' });
}
const fund_id = fundData[0].id;
```

**Änderung 4 — `anon_id` serverseitig generieren mit Kollisionsschutz:**

```js
// anon_id serverseitig generieren — body.anon_id wird ignoriert
function generateAnonId() {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const letter = letters[Math.floor(Math.random() * letters.length)];
  const num = Math.floor(1000 + Math.random() * 9000);
  return letter + '-' + num;
}

// Kollisionsschutz: bis zu 5 Versuche, dann Fehler
async function generateUniqueAnonId(fund_id) {
  for (let attempt = 0; attempt < 5; attempt++) {
    const candidate = generateAnonId();
    const checkRes = await fetch(
      `${SUPABASE_URL}/rest/v1/submissions?fund_id=eq.${fund_id}&anon_id=eq.${candidate}&select=id`,
      {
        headers: {
          apikey: SUPABASE_SERVICE_ROLE_KEY,
          Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        },
      }
    );
    const existing = await checkRes.json();
    if (!Array.isArray(existing) || existing.length === 0) {
      return candidate; // keine Kollision
    }
  }
  throw new Error('Konnte keine eindeutige anon_id generieren');
}

const anon_id = await generateUniqueAnonId(fund_id);
```

**Änderung 5 — `insertData` mit serverseitig abgeleiteten Werten:**

```js
const insertData = {
  ...body,
  fund_id,              // serverseitig abgeleitet — überschreibt body.fund_id (falls vorhanden)
  anon_id,              // serverseitig generiert — überschreibt body.anon_id (falls vorhanden)
  status: 'pending',    // immer hardcoded — überschreibt body.status (falls vorhanden)
  arr_eur,
  paying_customers,
  arpa_eur,
  acv_eur,
  ltv_eur,
  cac_payback_months,
  ltv_cac_ratio,
  burn_multiple,
  notes,
  founder_count,
  has_repeat_founder,
  has_prior_exit,
  has_technical_founder,
  has_domain_expert,
  plausibility_status: plaus.status,
  plausibility_checks: plaus.checks,
  plausibility_summary: plaus.summary,
};
```

**Änderung 6 — Insert mit SERVICE ROLE KEY:**

**Vorher:**
```js
const response = await fetch(`${SUPABASE_URL}/rest/v1/submissions`, {
  method: 'POST',
  headers: {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
    ...
  },
  body: JSON.stringify(insertData),
});
```

**Nachher:**
```js
const response = await fetch(`${SUPABASE_URL}/rest/v1/submissions`, {
  method: 'POST',
  headers: {
    apikey: SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
    'Content-Type': 'application/json',
    Prefer: 'return=minimal',
  },
  body: JSON.stringify(insertData),
});
```

**Warum SERVICE ROLE KEY für den Insert:** Der Service Role Key bypassed RLS. Das bedeutet: die bestehende `submissions` INSERT-Policy (`with_check: true`) ist für api/submit.js irrelevant, weil der Server sie ohnehin umgeht. Die Policy bleibt als Safety-Net für direkte Anon-Key-Zugriffe. Kein Handlungsbedarf bei der Policy selbst.

#### 3.3.4 `api/fund.js` auf SERVICE ROLE KEY umstellen

**Datei:** `api/fund.js`

**Vorher:**
```js
const { SUPABASE_URL, SUPABASE_ANON_KEY } = process.env;
// ...
headers: {
  apikey: SUPABASE_ANON_KEY,
  Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
}
```

**Nachher:**
```js
const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  return res.status(500).json({ error: 'Server misconfigured' });
}
// ...
headers: {
  apikey: SUPABASE_SERVICE_ROLE_KEY,
  Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
}
```

Select bleibt explizit auf `id,name,slug`. `attio_api_key` wird nie selektiert.

#### 3.3.5 Fehlerbehandlung im Submit-Formular für HTTP 429

**Datei:** `submit/index.html` — in der `handleSubmit()`-Funktion, nach dem `fetch`-Aufruf.

```js
if (res.status === 429) {
  const err = await res.json();
  document.getElementById('submitBtn').disabled = false;
  document.getElementById('loadingOverlay').style.display = 'none';
  showError(err.error || 'Zu viele Einreichungen. Bitte in 24 Stunden erneut versuchen.');
  return;
}
```

---

### 3.4 Null `fund_id` Lücke in `js/api.js` schließen

**Problem:** `apiLoadSubmissions()` und `apiLoadAcceptedSubmissions()` haben einen weichen `if (fund_id)` Check. Wenn `fund_id` null ist, wird kein Filter gesetzt und alle Submissions aller Fonds werden zurückgegeben.

**Datei:** `js/api.js`

**Vorher `apiLoadSubmissions()` (Zeile 27):**
```js
async function apiLoadSubmissions(fund_id) {
  let query = supabaseClient.from('submissions').select('*').eq('status', 'pending').order('submitted_at', { ascending: false });
  if (fund_id) query = query.eq('fund_id', fund_id);
  const { data, error } = await query;
  if (error) throw error;
  return data || [];
}
```

**Nachher:**
```js
async function apiLoadSubmissions(fund_id) {
  if (!fund_id) throw new Error('[apiLoadSubmissions] fund_id ist required — kein Query ohne Fund-Filter');
  const { data, error } = await supabaseClient
    .from('submissions')
    .select('*')
    .eq('status', 'pending')
    .eq('fund_id', fund_id)
    .order('submitted_at', { ascending: false });
  if (error) throw error;
  return data || [];
}
```

**Identische Änderung gilt für `apiLoadAcceptedSubmissions()` (Zeile 35):**
```js
async function apiLoadAcceptedSubmissions(fund_id) {
  if (!fund_id) throw new Error('[apiLoadAcceptedSubmissions] fund_id ist required — kein Query ohne Fund-Filter');
  const { data, error } = await supabaseClient
    .from('submissions')
    .select('*')
    .eq('status', 'accepted')
    .eq('fund_id', fund_id)
    .order('submitted_at', { ascending: false });
  if (error) throw error;
  return data || [];
}
```

---

### 3.5 Fehlende DB-Indexes anlegen

**Begründung:** Jede RLS-Policy-Prüfung auf `submissions`, `notes`, `pipeline` führt eine Subquery auf `fund_users` aus: `WHERE user_id = auth.uid()`. Ohne Index auf `fund_users.user_id` ist das ein Full Table Scan bei jeder Anfrage. Mit 45 Rows kein Problem — mit 5.000 Submissions pro Fonds und mehreren gleichzeitigen Usern spürbar.

**Migration — in Supabase SQL Editor ausführen (alle 6 auf einmal):**

```sql
-- fund_users: user_id — wird von JEDER RLS-Policy auf JEDER Tabelle als Subquery verwendet
-- Dieser Index ist der wichtigste
CREATE INDEX IF NOT EXISTS idx_fund_users_user_id
  ON public.fund_users (user_id);

-- submissions: fund_id — für RLS-Checks und Fund-Isolation-Queries
CREATE INDEX IF NOT EXISTS idx_submissions_fund_id
  ON public.submissions (fund_id);

-- submissions: contact_email — für Rate Limiting in api/submit.js (Woche 2)
CREATE INDEX IF NOT EXISTS idx_submissions_contact_email
  ON public.submissions (contact_email);

-- notes: fund_id — für RLS-Checks
CREATE INDEX IF NOT EXISTS idx_notes_fund_id
  ON public.notes (fund_id);

-- notes: submission_id — für apiLoadNotes()-Lookups
CREATE INDEX IF NOT EXISTS idx_notes_submission_id
  ON public.notes (submission_id);

-- pipeline: fund_id — für RLS-Checks
CREATE INDEX IF NOT EXISTS idx_pipeline_fund_id
  ON public.pipeline (fund_id);
```

`IF NOT EXISTS` macht die Migration idempotent — kann bei Bedarf mehrfach ausgeführt werden ohne Fehler.

---

### 3.6 Neue Fund-User manuell hinzufügen (bis Admin-UI gebaut wird)

Für den Piloten ohne Admin-Oberfläche: neue Fund-Mitarbeiter werden direkt in Supabase eingetragen.

**Voraussetzung:** Der User muss sich einmal über `login.html` angemeldet haben, damit sein Account in `auth.users` existiert.

**Schritt 1 — User-ID herausfinden:**
```sql
SELECT id, email FROM auth.users WHERE email = 'neue-person@fonds.vc';
```

**Schritt 2 — Fund-ID herausfinden (falls nicht bekannt):**
```sql
SELECT id, name FROM public.funds;
```

**Schritt 3 — User dem Fonds zuordnen:**
```sql
INSERT INTO public.fund_users (fund_id, user_id)
VALUES ('<fund-id-aus-schritt-2>', '<user-id-aus-schritt-1>');
```

**Wenn der User noch keinen Account hat:** Er muss zuerst auf `login.html` einen Magic Link anfordern und auf den Link klicken. Erst dann existiert sein Account in `auth.users`.

---

### 3.7 Woche-1-Checkliste (vor Start von Woche 2)

- [ ] `.gitignore` enthält `.env`, `.env.local`, `js/config.js`
- [ ] `js/config.example.js` existiert und ist in Git committed
- [ ] `js/config.js` existiert lokal und ist **nicht** in `git status` sichtbar
- [ ] `js/config.js` enthält aktuell noch den alten Key (Rotation kommt nach Deployment)
- [ ] `index.html`: `js/config.js` wird **vor** `js/supabase-client.js` geladen
- [ ] `login.html`: `js/config.js` wird **vor** `js/supabase-client.js` geladen
- [ ] `js/supabase-client.js` verwendet `SUPABASE_URL` und `SUPABASE_ANON_KEY` Variablen
- [ ] `.env.example` existiert und ist in Git committed
- [ ] `funds.attio_api_key` Column existiert nicht mehr (SQL Migration ausgeführt)
- [ ] `getCurrentFund()` selektiert kein `attio_api_key` mehr
- [ ] `apiLoadFund()` selektiert kein `attio_api_key` mehr
- [ ] `api/submit.js` verwendet `SUPABASE_SERVICE_ROLE_KEY`, kein `SUPABASE_ANON_KEY` mehr
- [ ] `api/submit.js` leitet `fund_id` aus `req.query.fund` ab
- [ ] `api/submit.js` generiert `anon_id` serverseitig mit Kollisionsschutz
- [ ] `api/submit.js` hardcodet `status: 'pending'`
- [ ] `api/submit.js` Rate Limiting läuft als erste Operation
- [ ] `api/fund.js` verwendet `SUPABASE_SERVICE_ROLE_KEY`
- [ ] `submit/index.html` sendet `fund_id`, `anon_id`, `status` nicht mehr im Body
- [ ] `submit/index.html` sendet `?fund=<slug>` als Query-Parameter
- [ ] `apiLoadSubmissions()` wirft Fehler wenn `fund_id` null
- [ ] `apiLoadAcceptedSubmissions()` wirft Fehler wenn `fund_id` null
- [ ] Alle 6 DB-Indexes angelegt
- [ ] `SUPABASE_SERVICE_ROLE_KEY` in Vercel Environment Variables gesetzt (Production + Preview + Development)
- [ ] **Deployment-Test 1:** Submit-Formular End-to-End — Submission landet in korrektem Fund mit serverseitig generierter `anon_id`
- [ ] **Deployment-Test 2:** Gleiche E-Mail 4x submiten → 4. gibt HTTP 429 mit deutschem Fehlertext
- [ ] **Deployment-Test 3:** Login → App lädt korrekt, Fund-Name erscheint
- [ ] **Anon Key rotieren** (nach erfolgreichem Test 3)
- [ ] `js/config.js` lokal mit neuem Key aktualisieren
- [ ] `SUPABASE_ANON_KEY` in Vercel auf neuen Wert aktualisieren

---

## 4. Woche 2 — Datenpersistenz vervollständigen

### 4.1 `activity_log` → Supabase

#### 4.1.1 Tabelle und RLS anlegen

**Migration — in Supabase SQL Editor ausführen:**

```sql
CREATE TABLE IF NOT EXISTS public.activity_log (
  id       uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  fund_id  uuid        NOT NULL REFERENCES public.funds(id) ON DELETE CASCADE,
  user_id  uuid        REFERENCES auth.users(id),
  event    text        NOT NULL,
  anon_id  text,
  meta     jsonb       NOT NULL DEFAULT '{}'::jsonb,
  ts       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_activity_log_fund_id
  ON public.activity_log (fund_id);

CREATE INDEX IF NOT EXISTS idx_activity_log_ts
  ON public.activity_log (ts DESC);

ALTER TABLE public.activity_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Fund members can read activity"
  ON public.activity_log FOR SELECT
  USING (fund_id IN (
    SELECT fund_id FROM public.fund_users WHERE user_id = auth.uid()
  ));

CREATE POLICY "Fund members can insert activity"
  ON public.activity_log FOR INSERT
  WITH CHECK (fund_id IN (
    SELECT fund_id FROM public.fund_users WHERE user_id = auth.uid()
  ));
```

**Kein UPDATE/DELETE auf activity_log** — Aktivitäten sind unveränderliche Ereignisse. Einmal geschrieben, bleiben sie.

#### 4.1.2 `apiLogActivity()` in `js/api.js` hinzufügen

```js
async function apiLogActivity(fund_id, event, anon_id = null, meta = null) {
  if (!fund_id) return;
  try {
    const { data: userData } = await supabaseClient.auth.getUser();
    await supabaseClient.from('activity_log').insert({
      fund_id,
      user_id: userData?.user?.id || null,
      event:   String(event || ''),
      anon_id: anon_id ? String(anon_id) : null,
      meta:    meta || {},
      ts:      new Date().toISOString(),
    });
  } catch (e) {
    console.warn('[activity] Supabase-Log fehlgeschlagen (nicht kritisch):', e.message);
  }
}
```

**Wichtig:** Diese Funktion ist bewusst silent — ein Fehler beim Loggen darf niemals eine User-Aktion blockieren oder einen Fehler im UI auslösen.

#### 4.1.3 `activityLogAppend()` in `js/state.js` erweitern

**Datei:** `js/state.js:341-347`

**Vorher:**
```js
function activityLogAppend(event, anon_id=null, meta=null){
  const a = getActivity();
  a.unshift({ id: uid(), ts: Date.now(), event: String(event||""), anon_id: anon_id?String(anon_id):null, meta: meta||null });
  if(a.length > 500) a.length = 500;
  setActivity(a);
  if(currentView==="activity") renderActivity();
}
```

**Nachher:**
```js
function activityLogAppend(event, anon_id=null, meta=null){
  // Lokaler Cache für sofortiges UI-Update (bleibt erhalten)
  const a = getActivity();
  a.unshift({ id: uid(), ts: Date.now(), event: String(event||""), anon_id: anon_id?String(anon_id):null, meta: meta||null });
  if(a.length > 500) a.length = 500;
  setActivity(a);
  if(currentView==="activity") renderActivity();

  // Supabase fire-and-forget — niemals await, niemals UI-blockierend
  if (typeof apiLogActivity === 'function' && typeof getCurrentFundId === 'function') {
    getCurrentFundId()
      .then(fund_id => { if (fund_id) apiLogActivity(fund_id, event, anon_id, meta); })
      .catch(() => {});
  }
}
```

#### 4.1.4 `apiLoadActivity()` in `js/api.js` hinzufügen

```js
async function apiLoadActivity(fund_id, limit = 200) {
  if (!fund_id) return [];
  const { data, error } = await supabaseClient
    .from('activity_log')
    .select('id, event, anon_id, meta, ts, user_id')
    .eq('fund_id', fund_id)
    .order('ts', { ascending: false })
    .limit(limit);
  if (error) { console.warn('[apiLoadActivity]', error.message); return []; }
  return (data || []).map(row => ({
    id:      row.id,
    ts:      new Date(row.ts).getTime(),
    event:   row.event,
    anon_id: row.anon_id,
    meta:    row.meta || {},
  }));
}
```

#### 4.1.5 Activity beim App-Start aus Supabase laden

**Datei:** `js/main.js` — im `DOMContentLoaded`-Block, nach `ensurePipelineLoaded()`.

```js
// Activity aus Supabase laden — überschreibt lokalen Cache mit Team-Daten
try {
  const fund_id = await getCurrentFundId();
  const remoteActivity = await apiLoadActivity(fund_id);
  if (remoteActivity.length > 0) {
    safeSetJSON(LS_KEYS.activity, remoteActivity);
  }
} catch (e) {
  console.warn('[CORE] Activity-Load fehlgeschlagen (non-fatal):', e.message);
}
```

**Verhalten:** Supabase ist canonical. Der localStorage-Cache wird bei jedem App-Start durch die Supabase-Daten ersetzt. Neue Aktivitäten werden sofort in localStorage geschrieben (für UI-Responsiveness) und asynchron nach Supabase gepusht.

---

### 4.2 `scoring_rules` → Supabase

#### 4.2.1 Tabelle und RLS anlegen

```sql
CREATE TABLE IF NOT EXISTS public.scoring_rules (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  fund_id     uuid        NOT NULL UNIQUE REFERENCES public.funds(id) ON DELETE CASCADE,
  rules       jsonb       NOT NULL,
  updated_at  timestamptz NOT NULL DEFAULT now(),
  updated_by  uuid        REFERENCES auth.users(id)
);

CREATE INDEX IF NOT EXISTS idx_scoring_rules_fund_id
  ON public.scoring_rules (fund_id);

ALTER TABLE public.scoring_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Fund members can read scoring rules"
  ON public.scoring_rules FOR SELECT
  USING (fund_id IN (
    SELECT fund_id FROM public.fund_users WHERE user_id = auth.uid()
  ));

CREATE POLICY "Fund members can insert scoring rules"
  ON public.scoring_rules FOR INSERT
  WITH CHECK (fund_id IN (
    SELECT fund_id FROM public.fund_users WHERE user_id = auth.uid()
  ));

CREATE POLICY "Fund members can update scoring rules"
  ON public.scoring_rules FOR UPDATE
  USING (fund_id IN (
    SELECT fund_id FROM public.fund_users WHERE user_id = auth.uid()
  ));
```

**Hinweis:** `UNIQUE` auf `fund_id` → ein Fonds hat genau ein Scoring-Regelset. Upsert via `onConflict: 'fund_id'`.

#### 4.2.2 `apiLoadScoringRules()` und `apiSaveScoringRules()` in `js/api.js`

```js
async function apiLoadScoringRules(fund_id) {
  if (!fund_id) return null;
  const { data, error } = await supabaseClient
    .from('scoring_rules')
    .select('rules')
    .eq('fund_id', fund_id)
    .single();
  // PGRST116 = "Row not found" → kein Error, einfach null zurückgeben
  if (error && error.code !== 'PGRST116') {
    console.warn('[apiLoadScoringRules]', error.message);
    return null;
  }
  return data?.rules || null;
}

async function apiSaveScoringRules(fund_id, rules) {
  if (!fund_id || !rules) return false;
  const { data: userData } = await supabaseClient.auth.getUser();
  const { error } = await supabaseClient
    .from('scoring_rules')
    .upsert(
      {
        fund_id,
        rules,
        updated_at: new Date().toISOString(),
        updated_by: userData?.user?.id || null,
      },
      { onConflict: 'fund_id' }
    );
  if (error) { console.error('[apiSaveScoringRules]', error.message); return false; }
  return true;
}
```

#### 4.2.3 `custom-index.js` — Regeln aus Supabase laden

**Problem:** `custom-index.js` liest Regeln synchron aus localStorage. Supabase-Reads sind async. Lösung: Regeln werden beim App-Start async geladen und in localStorage gecacht. Die synchrone `getCustomRulesV6()`-Funktion bleibt unverändert (liest aus localStorage). Nur die Initialisierung wird async.

**Wichtiger Hinweis zur Storage-Struktur in `custom-index.js`:** Das IIFE verwaltet zwei localStorage-Keys:
- `LS_CUSTOM_RULESETS_V6` (`"core_custom_rulesets_v6"`) — **Primärer Key**, enthält das volle Container-Objekt `{ active_id, rulesets: [{ id, rules }] }`
- `LS_CUSTOM_RULES_V6` (`"core_custom_rules_v6"`) — Legacy-Key, wird bei jedem Save in `setCustomRulesV6()` mitgeschrieben, aber NIE als primäre Quelle gelesen

`scoring_rules.rules` in Supabase speichert das **volle Container-Objekt** (`getRulesetsV6()` Rückgabe). `__refreshCustomRules` muss deshalb `setRulesetsV6()` aufrufen, nicht `safeSetJSON(LS_CUSTOM_RULES_V6, ...)`.

**Datei:** `custom-index.js` — am Ende der IIFE, direkt vor dem schließenden `})();`:

```js
// Wird von main.js aufgerufen nachdem Supabase-Rules geladen wurden
// newContainer muss { active_id, rulesets: [...] } sein — das Format von getRulesetsV6()
window.__refreshCustomRules = function(newContainer) {
  if (!newContainer || typeof newContainer !== 'object') return;
  try {
    setRulesetsV6(newContainer);  // schreibt LS_CUSTOM_RULESETS_V6 + LS_CUSTOM_ACTIVE_RULESET_ID
    _cache = {};                  // Score-Cache invalidieren
    try { renderCustomIndexUI(); } catch(_) {}
    try { patchVisibleCustomIndex(); } catch(_) {}
  } catch (e) {
    console.warn('[custom-index] __refreshCustomRules failed:', e);
  }
};
```

**`setRulesetsV6` und `_cache` sind in der IIFE definiert** — `__refreshCustomRules` ist innerhalb der IIFE definiert und hat direkten Zugriff auf beide.

**Datei:** `js/main.js` — im App-Init nach `ensurePipelineLoaded()`:

```js
// Scoring Rules aus Supabase laden (Team-Sync)
try {
  const fund_id = await getCurrentFundId();
  const remoteContainer = await apiLoadScoringRules(fund_id);
  if (remoteContainer && typeof window.__refreshCustomRules === 'function') {
    window.__refreshCustomRules(remoteContainer);
  }
} catch (e) {
  console.warn('[CORE] Scoring Rules load fehlgeschlagen (non-fatal):', e.message);
}
```

**Datei:** `custom-index.js` — in der Funktion `setCustomRulesV6(rules)` (Zeile 421), nach dem `setRulesetsV6(c)`-Aufruf (Zeile 434):

```js
// Nach setRulesetsV6(c): async nach Supabase syncen
// getRulesetsV6() gibt den aktualisierten Container zurück, der gerade gespeichert wurde
if (typeof apiSaveScoringRules === 'function' && typeof getCurrentFundId === 'function') {
  const updatedContainer = getRulesetsV6();
  getCurrentFundId()
    .then(fund_id => { if (fund_id) apiSaveScoringRules(fund_id, updatedContainer); })
    .catch(() => {});
}
```

**Fallback-Verhalten:** Wenn Supabase-Load fehlschlägt (Network-Fehler, etc.), bleibt der localStorage-Cache aktiv. Der User sieht seine lokalen Regeln. Beim nächsten erfolgreichen App-Start werden die Supabase-Regeln wieder geladen.

---

### 4.3 `outreach` → Supabase

#### 4.3.1 Tabelle und RLS anlegen

```sql
CREATE TABLE IF NOT EXISTS public.outreach (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  fund_id           uuid        NOT NULL REFERENCES public.funds(id) ON DELETE CASCADE,
  anon_id           text        NOT NULL,
  contact_name      text,
  contact_email     text,
  display_label     text,
  status            text        NOT NULL DEFAULT 'anfrage_gesendet',
  msg               text,
  sent_at           timestamptz NOT NULL DEFAULT now(),
  last_activity_at  timestamptz NOT NULL DEFAULT now(),
  followup_sent     boolean     NOT NULL DEFAULT false,
  UNIQUE (fund_id, anon_id)
);

CREATE INDEX IF NOT EXISTS idx_outreach_fund_id
  ON public.outreach (fund_id);

ALTER TABLE public.outreach ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Fund members can read outreach"
  ON public.outreach FOR SELECT
  USING (fund_id IN (SELECT fund_id FROM public.fund_users WHERE user_id = auth.uid()));

CREATE POLICY "Fund members can insert outreach"
  ON public.outreach FOR INSERT
  WITH CHECK (fund_id IN (SELECT fund_id FROM public.fund_users WHERE user_id = auth.uid()));

CREATE POLICY "Fund members can update outreach"
  ON public.outreach FOR UPDATE
  USING (fund_id IN (SELECT fund_id FROM public.fund_users WHERE user_id = auth.uid()));

CREATE POLICY "Fund members can delete outreach"
  ON public.outreach FOR DELETE
  USING (fund_id IN (SELECT fund_id FROM public.fund_users WHERE user_id = auth.uid()));
```

**Hinweis `UNIQUE(fund_id, anon_id)`:** Ein Deal kann pro Fonds nur einmal in der Outreach-Tabelle sein. Upsert-Operationen verwenden `onConflict: 'fund_id,anon_id'`.

#### 4.3.2 API-Funktionen in `js/api.js`

```js
async function apiLoadOutreach(fund_id) {
  if (!fund_id) return [];
  const { data, error } = await supabaseClient
    .from('outreach')
    .select('*')
    .eq('fund_id', fund_id)
    .order('sent_at', { ascending: false });
  if (error) { console.warn('[apiLoadOutreach]', error.message); return []; }
  return data || [];
}

async function apiUpsertOutreach(fund_id, item) {
  if (!fund_id || !item?.anon_id) return false;
  const { error } = await supabaseClient
    .from('outreach')
    .upsert(
      { ...item, fund_id },
      { onConflict: 'fund_id,anon_id' }
    );
  if (error) { console.error('[apiUpsertOutreach]', error.message); return false; }
  return true;
}

async function apiDeleteOutreach(fund_id, anon_id) {
  if (!fund_id || !anon_id) return false;
  const { error } = await supabaseClient
    .from('outreach')
    .delete()
    .eq('fund_id', fund_id)
    .eq('anon_id', anon_id);
  if (error) { console.error('[apiDeleteOutreach]', error.message); return false; }
  return true;
}
```

#### 4.3.3 Einmalige Migration aus localStorage

**Trigger:** Beim ersten App-Load nach Deployment wird ein Flag `core_outreach_migrated_v1` in localStorage gesetzt. Wenn das Flag nicht existiert, werden vorhandene Outreach-Daten aus localStorage nach Supabase übertragen.

**Datei:** `js/main.js` — im App-Init, nach dem Outreach-API-Load:

```js
const outreachMigrated = safeGetJSON('core_outreach_migrated_v1', false);
if (!outreachMigrated) {
  try {
    const localOutreach = safeGetJSON(LS_KEYS.outreach, []);
    if (localOutreach.length > 0) {
      const fund_id = await getCurrentFundId();
      if (fund_id) {
        for (const item of localOutreach) {
          await apiUpsertOutreach(fund_id, item).catch(() => {});
        }
      }
    }
    safeSetJSON('core_outreach_migrated_v1', true);
  } catch (e) {
    console.warn('[CORE] Outreach-Migration fehlgeschlagen (wird beim nächsten Start erneut versucht):', e.message);
    // Flag NICHT setzen bei Fehler — nächster Start versucht erneut
  }
}
```

#### 4.3.4 `state.js` Outreach-Funktionen erweitern

**Strategie:** Gleich wie Activity — localStorage bleibt als Session-Cache, Supabase ist canonical.

**Datei:** `js/state.js`

`getOutreach()` bleibt unverändert (liest aus localStorage-Cache).

`setOutreach()` wird erweitert:
```js
function setOutreach(arr){
  const normalized = Array.isArray(arr) ? arr : [];
  safeSetJSON(LS_KEYS.outreach, normalized);
  // Supabase fire-and-forget Sync — wird pro Item aufgerufen
}
```

`updateOutreachItem()` wird erweitert — nach dem localStorage-Update Supabase updaten:
```js
function updateOutreachItem(id, patch){
  const arr = getOutreach();
  const idx = arr.findIndex(x=>x.id===id);
  if(idx<0) return;
  arr[idx] = { ...arr[idx], ...patch, last_activity_at: Date.now() };
  setOutreach(arr);

  // Supabase fire-and-forget sync — window._authSession wird nicht geprüft,
  // da getCurrentFundId() intern auth.getUser() aufruft und bei nicht-eingeloggtem User null liefert
  if (typeof apiUpsertOutreach === 'function' && typeof getCurrentFundId === 'function') {
    const item = arr[idx];
    getCurrentFundId()
      .then(fund_id => { if (fund_id) apiUpsertOutreach(fund_id, item); })
      .catch(() => {});
  }
}
```

#### 4.3.5 Outreach beim App-Start aus Supabase laden

**Datei:** `js/main.js` — im App-Init, nach der Activity-Load:

```js
try {
  const fund_id = await getCurrentFundId();
  const remoteOutreach = await apiLoadOutreach(fund_id);
  if (remoteOutreach.length > 0) {
    safeSetJSON(LS_KEYS.outreach, remoteOutreach);
  }
} catch (e) {
  console.warn('[CORE] Outreach-Load fehlgeschlagen (non-fatal):', e.message);
}
```

---

### 4.4 Rate Limiting auf Submit

Rate Limiting ist bereits vollständig in Abschnitt 3.3.3 (Änderung 2) spezifiziert. Dieser Abschnitt wiederholt nur die Voraussetzungen:

**Voraussetzung:** `idx_submissions_contact_email` Index muss aktiv sein (Abschnitt 3.5).  
**Limit:** 3 Submissions pro `contact_email` pro 24 Stunden.  
**HTTP Response:** 429 mit deutschem Fehlertext.

---

### 4.5 Woche-2-Checkliste (vor Start von Woche 3)

- [ ] `activity_log` Tabelle mit korrektem Schema in Supabase angelegt
- [ ] `activity_log` RLS Policies aktiv: SELECT + INSERT für Fund-Mitglieder
- [ ] `apiLogActivity()` in `js/api.js` vorhanden und getestet
- [ ] `apiLoadActivity()` in `js/api.js` vorhanden und getestet
- [ ] `activityLogAppend()` in `js/state.js` schreibt async nach Supabase
- [ ] App-Init lädt Activity aus Supabase beim Start
- [ ] **Test:** User A führt Aktion aus → User B (gleicher Fonds) sieht sie in Activity-View nach Reload
- [ ] `scoring_rules` Tabelle mit korrektem Schema in Supabase angelegt
- [ ] `scoring_rules` RLS Policies aktiv: SELECT + INSERT + UPDATE
- [ ] `apiLoadScoringRules()` und `apiSaveScoringRules()` in `js/api.js`
- [ ] `window.__refreshCustomRules` in `custom-index.js` definiert
- [ ] App-Init lädt Scoring Rules aus Supabase
- [ ] `custom-index.js` speichert Regeln bei Änderung async nach Supabase
- [ ] **Test:** User A konfiguriert Scoring-Regel → User B sieht sie nach Reload
- [ ] `outreach` Tabelle mit korrektem Schema in Supabase angelegt
- [ ] `outreach` RLS Policies aktiv: SELECT + INSERT + UPDATE + DELETE
- [ ] `apiLoadOutreach()`, `apiUpsertOutreach()`, `apiDeleteOutreach()` in `js/api.js`
- [ ] Einmalige Migration aus localStorage funktioniert
- [ ] `updateOutreachItem()` in `js/state.js` synct nach Supabase
- [ ] App-Init lädt Outreach aus Supabase
- [ ] **Test:** Outreach-Eintrag von User A → User B sieht ihn nach Reload
- [ ] Rate Limiting aktiv und getestet (3 Submits → 4. gibt 429)

---

## 5. Woche 3 — Deploy & Hardening

### 5.1 `vercel.json` anlegen

**Datei:** `vercel.json` (neu, im Root-Verzeichnis)

```json
{
  "regions": ["fra1"],
  "functions": {
    "api/submit.js": {
      "maxDuration": 15
    },
    "api/fund.js": {
      "maxDuration": 10
    }
  },
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [
        { "key": "X-Content-Type-Options", "value": "nosniff" },
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "Referrer-Policy", "value": "strict-origin-when-cross-origin" }
      ]
    }
  ]
}
```

**Begründung der Werte:**
- `fra1` = Frankfurt → nächste Vercel-Region zu Supabase `eu-central-1` → minimale Netzwerklatenz zwischen Function und DB
- `maxDuration: 15` für `api/submit.js` → Fund-Lookup + Kollisionsprüfung + Rate-Limit-Check + Plausibility + Insert = bis zu 5 DB-Calls. Default von 10s könnte bei langsamer Verbindung reichen nicht.
- Security Headers: Standard für alle API-Endpoints

### 5.2 Plausibility-Logik — Dokumentierter Zustand (kein Code-Change)

**Befund:** Die Plausibility-Logik existiert in zwei Dateien mit unterschiedlichem Kontext:
- `api/submit.js`: liest `s.growth_pct` — direkte Supabase-Spalte aus dem Request Body
- `js/utils.js`: liest `s.growth.value_pct` — Startup-Objekt-Format nach `buildStartupFromSubmission()`

**Warum beide korrekt sind:** Die beiden Funktionen operieren auf unterschiedlichen Daten-Shapes. `api/submit.js` verarbeitet rohe Formulardaten, `utils.js` verarbeitet aufbereitete Startup-Objekte. Eine Konsolidierung wäre ein Refactoring-Sprint (Auslagern in eine gemeinsame Utility), kein Bug-Fix.

**Aktion:** Beide Dateien bekommen einen Kommentar der den Unterschied dokumentiert.

**Datei:** `js/utils.js:233`  
```js
// Liest s.growth.value_pct — Startup-Objekt-Format (nach buildStartupFromSubmission)
// api/submit.js liest s.growth_pct — direkte Supabase-Spalte. Beide sind korrekt für ihren Kontext.
```

**Datei:** `api/submit.js:36`  
```js
// Liest s.growth_pct — direkte Supabase-Spalte aus dem Request Body
// js/utils.js liest s.growth.value_pct für das Startup-Objekt-Format.
```

### 5.3 Pre-Pilot Smoke Tests

Diese Tests werden manuell durchgeführt bevor der erste Pilot-Fonds ongeboardet wird. Alle Tests müssen bestehen — kein Test kann übersprungen werden.

#### Auth Flow
- [ ] `login.html` öffnen → Magic Link für autorisierte E-Mail anfordern → Link klicken → Redirect zu `index.html` → Fund-Name in Header sichtbar
- [ ] `login.html` öffnen → Magic Link für **nicht** autorisierte E-Mail (nicht in `fund_users`) → Link klicken → Redirect zu `login.html?error=unauthorized` → Fehlermeldung sichtbar
- [ ] Direkter Aufruf von `index.html` ohne aktive Session → sofortiger Redirect zu `login.html`

#### Submit Flow
- [ ] `/submit/?fund=<korrekter-slug>` öffnen → Fund-Name-Badge korrekt angezeigt
- [ ] Formular vollständig ausfüllen und absenden → Erfolgsmeldung im Browser
- [ ] In Supabase SQL Editor: `SELECT fund_id, anon_id, status, contact_email FROM submissions ORDER BY submitted_at DESC LIMIT 1;` → `fund_id` stimmt mit dem Fund überein, `status = 'pending'`, `anon_id` ist serverseitig generiert (nicht vom Client)
- [ ] `/submit/?fund=nicht-existierender-slug` → Fehlermeldung "Fonds nicht gefunden" im Formular
- [ ] Gleiche E-Mail 4x absenden → 4. Versuch gibt HTTP 429 mit deutschem Fehlertext

#### Fund-Isolation (kritischster Test)
- [ ] Eingeloggt als Fund-A-User: In Browser-Konsole ausführen: `supabaseClient.from('submissions').select('fund_id').neq('fund_id', '<fund-a-id>')` → Ergebnis ist leeres Array (RLS verhindert Lesen fremder Submissions)
- [ ] In Browser-Konsole ausführen: `supabaseClient.from('funds').select('*')` → Ergebnis enthält **keine** `attio_api_key`-Spalte (Column wurde gedroppt)

#### Pipeline + Notes
- [ ] Startup aus Submissions-Tab annehmen → erscheint in Übersicht
- [ ] Startup zur Pipeline hinzufügen → in Supabase `pipeline`-Tabelle sichtbar
- [ ] Pipeline-Status ändern → `last_updated` in Supabase aktualisiert
- [ ] Notiz zum Startup hinzufügen → in Supabase `notes`-Tabelle sichtbar
- [ ] **Browser-Tab schließen und neu öffnen** → Pipeline-Daten und Notizen noch vorhanden (kein Datenverlust)

#### Team-Sync (nach Woche-2-Deployment)
- [ ] User A führt Pipeline-Aktion aus → User B (gleicher Fonds, separater Browser) sieht sie in Activity-View nach Page Reload
- [ ] User A konfiguriert eine Scoring-Regel → User B sieht exakt dieselbe Regel nach Page Reload
- [ ] User A startet Outreach für einen Deal → User B sieht den Outreach-Eintrag nach Page Reload

### 5.4 Pro-Upgrade Checkliste (Ende Woche 3)

Beide Upgrades erst nach erfolgreichem vollständigem Smoke Test.

**Supabase Pro:**
- Dashboard → Billing → Upgrade to Pro
- Aktiviert Point-in-Time Recovery → Datensicherheit für echte Deal-Daten
- Aktiviert höhere Connection Limits → relevant bei mehreren gleichzeitigen Fund-Mitarbeitern

**Vercel Pro:**
- Dashboard → Settings → Billing → Upgrade
- Aktiviert Edge Middleware für zukünftiges IP-basiertes Rate Limiting
- Aktiviert höhere Function Concurrency

---

## 6. Was explizit NICHT in diesem Spec ist

| Thema | Begründung |
|---|---|
| Attio CRM Integration | Explizit nach Pilot verschoben. `attio_pushes`-Tabelle existiert bereits in Supabase — kein Änderungsbedarf. |
| `leads`-Persistenz (Anfragen-Inbox-Tab) | Leads sind Read-only für den Fund (empfangene Kontaktanfragen). Kein Team-Sync-Bedarf für Pilot. localStorage akzeptabel. |
| `savedFilters`-Persistenz | Per-User-Präferenz, kein Team-Impact, kein Pilot-Risiko. |
| `compare`-Persistenz | Ephemer by Design — compare-Auswahl soll nicht persistieren. |
| Real-time Sync (Supabase Subscriptions) | Unnötige Komplexität für Pilot-Scale. Page Reload ist ausreichend. |
| Admin-UI für Fund-User-Management | Manueller Supabase-Dashboard-Eintrag per SQL reicht für Pilot (Anleitung in Abschnitt 3.6). |
| Plausibility-Logik Konsolidierung | Refactoring-Sprint ohne Security-Impact. Kein Scope in diesem Spec. |
| Änderungen an Scoring-Engine-Logik | Separater Sprint (Plan existiert bereits). |

---

## 7. Vollständiger Datei- und Migrations-Index

### Geänderte / neue Dateien

| Datei | Art | Woche | Beschreibung |
|---|---|---|---|
| `.gitignore` | Geändert | 1 | `.env`-Schutz + `js/config.js` hinzugefügt |
| `.env.example` | Neu (committed) | 1 | Env-Var-Dokumentation für Vercel |
| `js/config.js` | Neu (gitignored) | 1 | Supabase URL + Anon Key — niemals committed |
| `js/config.example.js` | Neu (committed) | 1 | Vorlage für `js/config.js` ohne echte Keys |
| `js/supabase-client.js` | Geändert | 1 | Hardcoded Keys → Config-Variablen; `attio_api_key` aus Select entfernt |
| `js/api.js` | Geändert + erweitert | 1+2 | `apiLoadFund` select fix; null fund_id guard; neue Api-Funktionen |
| `js/state.js` | Geändert | 2 | `activityLogAppend` + `updateOutreachItem` mit Supabase-Sync |
| `js/main.js` | Geändert | 2 | App-Init lädt Activity, Scoring Rules, Outreach aus Supabase; Outreach-Migration |
| `js/custom-index.js` | Geändert | 2 | `window.__refreshCustomRules` exportiert; Save synct nach Supabase |
| `js/utils.js` | Kommentar | 3 | Plausibility-Kontext dokumentiert |
| `api/submit.js` | Geändert | 1+2 | SERVICE_ROLE_KEY; fund_id aus Slug; anon_id serverseitig; status hardcoded; Rate Limiting |
| `api/fund.js` | Geändert | 1 | SERVICE_ROLE_KEY statt ANON_KEY |
| `submit/index.html` | Geändert | 1 | fund_id/anon_id/status aus Body entfernt; ?fund= Query-Param; HTTP 429 Handler |
| `index.html` | Geändert | 1 | `js/config.js` vor `js/supabase-client.js` verschoben |
| `login.html` | Geändert | 1 | `js/config.js` zwischen CDN und `js/supabase-client.js` eingefügt |
| `vercel.json` | Neu | 3 | Region, Timeouts, Security Headers |

### Supabase-Migrationen (SQL)

| Migration | Woche | Idempotent? |
|---|---|---|
| `funds.attio_api_key` Column droppen | 1 | Ja (`DROP COLUMN IF EXISTS`) |
| 6x DB-Indexes anlegen | 1 | Ja (`CREATE INDEX IF NOT EXISTS`) |
| `activity_log` Tabelle + RLS | 2 | Ja (`CREATE TABLE IF NOT EXISTS`) |
| `scoring_rules` Tabelle + RLS | 2 | Ja |
| `outreach` Tabelle + RLS | 2 | Ja |

**Ausführungsreihenfolge:** Woche-1-Migrationen vollständig abschließen bevor Woche-2-Migrationen beginnen. Keine Abhängigkeiten zwischen den Woche-2-Migrationen — können in beliebiger Reihenfolge ausgeführt werden.
