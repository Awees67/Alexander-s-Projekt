# Email-Versand (Anfragen) — Implementationsplan

**Goal:** Wenn ein Fund-Mitglied im Anfragen-Modal auf "E-Mail senden" klickt, wird die Mail tatsächlich über Resend an das Startup versendet.

**Architecture:** Frontend ruft eine neue Vercel Serverless Function `/api/send-email.js` auf. Die Function verifiziert den Supabase Auth-Token, dann sendet sie die Mail via Resend API. Der bestehende localStorage-Outreach-Eintrag bleibt unverändert.

**Tech Stack:** Resend (Email API), Vercel Serverless Function, Supabase Auth (Token-Verifizierung)

---

## Voraussetzungen (manuell — vor dem Coding)

### Schritt 0a: Resend Account erstellen
- [ ] Gehe auf resend.com → "Sign Up"
- [ ] Account mit awees6703@gmail.com erstellen
- [ ] Im Dashboard: **API Keys** → "Create API Key" → Name: `core-app-production` → Permissions: "Sending access"
- [ ] API Key kopieren (wird nur einmal angezeigt): `re_xxxxxxxxxxxx`

### Schritt 0b: Gmail als Absender verifizieren
- [ ] Resend Dashboard → **Domains** → "Add Domain"
- [ ] Wähle "Email Address" statt Domain (für Gmail)
- [ ] Gib `awees6703@gmail.com` ein → Resend sendet Verifikations-Email
- [ ] Email öffnen → Verify klicken
- [ ] Status muss "Verified" zeigen

### Schritt 0c: RESEND_API_KEY in Vercel setzen
- [ ] Vercel Dashboard → core-app Projekt → **Settings** → **Environment Variables**
- [ ] Variable hinzufügen:
  - Name: `RESEND_API_KEY`
  - Value: `re_xxxxxxxxxxxx` (aus Schritt 0a)
  - Environment: Production + Preview
- [ ] "Save" klicken

---

## Task 1: Vercel Function `/api/send-email.js`

**Files:**
- Create: `api/send-email.js`

**Was diese Function macht:**
1. Prüft ob Request POST ist
2. Verifiziert Supabase JWT-Token aus Authorization-Header
3. Validiert Pflichtfelder (to, subject, body)
4. Sendet Mail via Resend API
5. Gibt `{ success: true }` oder Fehler zurück

- [ ] **Schritt 1: Datei erstellen**

```javascript
// api/send-email.js
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Auth verifizieren
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const { SUPABASE_URL, SUPABASE_ANON_KEY, RESEND_API_KEY } = process.env;
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !RESEND_API_KEY) {
    return res.status(500).json({ error: 'Server misconfigured' });
  }

  // Token gegen Supabase verifizieren
  const authCheck = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${token}`,
    },
  });
  if (!authCheck.ok) return res.status(401).json({ error: 'Invalid session' });

  const { to, subject, body, from_name } = req.body;
  if (!to || !subject || !body) {
    return res.status(400).json({ error: 'to, subject und body sind Pflichtfelder' });
  }

  // Email via Resend senden
  const resendRes = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: `${from_name || 'APEX Ventures'} <awees6703@gmail.com>`,
      to: [to],
      subject,
      text: body,
    }),
  });

  if (!resendRes.ok) {
    const err = await resendRes.text();
    console.error('[send-email] Resend error:', err);
    return res.status(500).json({ error: 'Email konnte nicht gesendet werden' });
  }

  return res.status(200).json({ success: true });
}
```

- [ ] **Schritt 2: Commit**

```bash
git add api/send-email.js
git commit -m "feat: /api/send-email Vercel Function via Resend"
```

---

## Task 2: Frontend — confirmBtn verdrahten

**Files:**
- Modify: `js/renderers-inbox.js` (Funktion `_otOpenSendModal`, ab Zeile ~481)

**Was sich ändert:**
`confirmBtn.onclick` soll nach der bestehenden localStorage-Logik zusätzlich `/api/send-email` aufrufen. Bei Fehler: Toast mit Fehlermeldung, kein Outreach-Eintrag. Bei Erfolg: bestehender Toast + Outreach-Eintrag wie bisher.

- [ ] **Schritt 1: confirmBtn.onclick ersetzen**

Bestehende Stelle in `renderers-inbox.js` (ca. Zeile 481):
```javascript
if (confirmBtn) confirmBtn.onclick = () => {
```

Ersetzen durch:
```javascript
if (confirmBtn) confirmBtn.onclick = async () => {
```

Und den Block ab `const now = Date.now()` bis `renderInbox()` so umbauen:

```javascript
  if (confirmBtn) confirmBtn.onclick = async () => {
    const body    = bodyEl    ? bodyEl.value.trim()    : '';
    const subject = subjectEl ? subjectEl.value.trim() : '';
    if (!body)    { toast('Pflichtfeld', 'Nachricht darf nicht leer sein'); return; }
    if (!subject) { toast('Pflichtfeld', 'Betreff darf nicht leer sein'); return; }

    const fake = currentStartup || { anon_id: null, display_label: 'Unbekannt', contact_name: '—', contact_email: '—', sector: '—', stage: '—' };

    if (fake.anon_id && getOutreach().some(x => x.anon_id === fake.anon_id)) {
      toast('Bereits angefragt', fake.display_label + ' hat bereits eine Anfrage.');
      _close();
      return;
    }

    if (!fake.contact_email || fake.contact_email === '—') {
      toast('Keine Email', 'Für dieses Startup ist keine Email-Adresse hinterlegt.');
      return;
    }

    // Button sperren während Versand
    confirmBtn.disabled = true;
    confirmBtn.textContent = 'Wird gesendet…';

    try {
      const { data: { session } } = await supabaseClient.auth.getSession();
      const token = session?.access_token || '';
      const bearbeiter = (document.getElementById('otSendBearbeiter')?.value.trim()) || window.fundName || 'APEX Ventures';

      const res = await fetch('/api/send-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          to: fake.contact_email,
          subject,
          body,
          from_name: bearbeiter,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Unbekannter Fehler');
      }
    } catch (e) {
      toast('Fehler beim Versand', e.message || 'Email konnte nicht gesendet werden');
      confirmBtn.disabled = false;
      confirmBtn.textContent = 'E-Mail senden';
      return;
    }

    // Erfolg: Outreach-Eintrag speichern (bestehende Logik)
    const now = Date.now();
    const newEntry = {
      id: uid(),
      anon_id: fake.anon_id,
      display_label: fake.display_label,
      contact_name: fake.contact_name,
      contact_email: fake.contact_email,
      sector: fake.sector || '—',
      stage: fake.stage || '—',
      status: 'anfrage_gesendet',
      sent_at: now,
      last_activity_at: now,
      last_message_preview: body.slice(0, 70),
      last_message_from: 'outbound',
      thread_id: 'thrd_' + Math.random().toString(16).slice(2, 10),
      conversation_id: 'conv_' + Math.random().toString(16).slice(2, 10),
      messages: [{ id: uid(), direction: 'outbound', sender: _otGetBearbeiterLabel(), text: body, ts: now }]
    };

    const arr = getOutreach();
    arr.unshift(newEntry);
    setOutreach(arr);
    activityLogAppend('OUTREACH_SENT', newEntry.anon_id, { display_label: newEntry.display_label, template: currentTpl });
    _close();
    toast('E-Mail gesendet ✓', newEntry.display_label + ' wurde kontaktiert');
    _otTab = 'alle';
    _otSelected = newEntry.id;
    renderInbox();
  };
```

- [ ] **Schritt 2: Commit**

```bash
git add js/renderers-inbox.js
git commit -m "feat: E-Mail senden Button sendet tatsächlich via /api/send-email"
```

---

## Task 3: Vercel Deploy & Test

- [ ] **Schritt 1: Push**
```bash
git push
```

- [ ] **Schritt 2: Vercel deployment abwarten** (~1-2 Min)

- [ ] **Schritt 3: Test**
  1. Login → Startup öffnen → "Anfrage senden"
  2. Template ausfüllen, Bearbeiter-Name eingeben
  3. "E-Mail senden" klicken
  4. Button zeigt "Wird gesendet…"
  5. Toast "E-Mail gesendet ✓" erscheint
  6. awees6703@gmail.com → Posteingang prüfen → Email soll angekommen sein

- [ ] **Schritt 4: Fehlerfall testen**
  - Startup ohne Email-Adresse → Toast "Keine Email"
  - Falscher API Key in Vercel → Toast "Email konnte nicht gesendet werden"

---

## Bekannte Einschränkungen

- **Resend Free Plan:** 100 Emails/Tag, 3.000/Monat — ausreichend für aktuellen Bedarf
- **Gmail als Absender:** Resend muss die Adresse verifiziert haben, sonst schlägt der Versand fehl
- **contact_email:** Muss im Submission-Formular ausgefüllt worden sein — wenn leer, zeigt die App einen Hinweis
- **Outreach bleibt localStorage:** Kein Supabase-Sync der Anfragen in diesem Plan — separates Feature
