# Backend Security & Architecture Audit — CORE App

**Datum:** 2026-05-12  
**Bewerter:** Claude (Senior Backend Architect / Security Auditor)  
**Branch:** `claude/security-audit-backend-7XIYv`  
**Gesamtreife:** 42 %

---

## 1. Executive Summary

Das System ist eine Supabase-backed Frontend-App mit zwei serverseitigen Vercel Serverless Functions (`api/submit.js`, `api/fund.js`). Der Woche-1-Hardening-Sprint hat echte Fortschritte erzielt — Service Role Key ist aus dem Client-Code entfernt, RLS ist implementiert, fund_id wird serverseitig gesetzt.

**Trotzdem gibt es mehrere kritische und high-severity Lücken, die vor einem Demo-Pilot-Start geschlossen werden müssen.** Die größte ist strukturell: `js/env.js` mit dem echten Supabase Anon-Key ist committed und in git-History permanent gespeichert.

---

## 2. Architektur-Analyse

### Was existiert

- **API-Schicht:** 2 Serverless Functions (Vercel). Kein Framework, reiner `fetch()` gegen Supabase REST API
- **Auth:** Supabase Magic Link → JWT-Session im Browser → `getSession()` als Auth Guard in `main.js`
- **Datenbankzugriff (Client-side):** Supabase JS Client mit Anon Key + RLS
- **Datenbankzugriff (Server-side):** Service Role Key via Vercel ENV → direkte REST-Calls
- **State:** Mischung aus Supabase (pipeline, notes) und localStorage (activity, UI-state)
- **Kein Queue-System, kein Caching, kein Background Job Runner**

### Architektur-Schwächen

**CRITICAL: Kein zentrales API-Gateway**  
Beide Server-Funktionen implementieren ihre eigene Fehlerbehandlung, Rate-Limiting-Logik und Auth-Validation vollständig isoliert. Keine gemeinsame Middleware. Jede neue Function muss alle Security-Checks neu implementieren.

**HIGH: `apiDeleteNote` ohne fund_id-Check (`api.js:157`)**
```js
async function apiDeleteNote(note_id) {
  const { error } = await supabaseClient
    .from('notes')
    .delete()
    .eq('id', note_id);  // ← kein fund_id filter, kein user_id filter
```
Die einzige Schutzschicht ist RLS in Supabase. Wenn RLS korrekt konfiguriert ist, ist das tolerierbar — aber es fehlt Defense in Depth im Client-Code.

**HIGH: `apiLoadPipeline` ohne fund_id-Guard (`api.js:55`)**
```js
if (fund_id) query = query.eq('fund_id', fund_id);
```
Das `if` macht fund_id optional. Bei `null` oder `undefined` wird die Query **ohne Fund-Filter ausgeführt** — ein RLS-Bypass-Risiko wenn RLS für pipeline nicht vollständig greift.

**MEDIUM: Keine Versionierung der API**  
Kein `/v1/`-Präfix, kein Changelog-Mechanismus. Breaking Changes in `api/submit.js` brechen sofort alle Submit-Formulare in Produktion.

**MEDIUM: Kein Retry-Mechanismus**  
Alle `fetch()`-Calls gegen Supabase REST (in `api.js`, `api/submit.js`, `api/fund.js`) haben weder Retry noch Timeout. Ein 500ms-Hänger von Supabase → Request hängt unbegrenzt oder bricht mit nichtssagendem Netzwerkfehler ab.

**LOW: Monkey-Patching in main.js / custom-index.js**  
Die `._v41`- und `._ciV6`-Wrapping-Pattern machen Debugging unter Last unmöglich. Kein Stack-Trace zeigt korrekten Call-Ursprung.

---

## 3. Sicherheitsanalyse

### CRITICAL

**C1: `js/env.js` mit echtem Anon-Key ist in git-History committed**
```
Commit: fb03ed3 "fix: deploy js/env.js to production (public anon key, required in browser)"
Datei:  js/env.js
SUPABASE_ANON_KEY = 'sb_publishable_27NELp2B1onC07knBjxKVQ_n5A_k9ox'
SUPABASE_URL      = 'https://ggfjgzjevyemwbclvfpp.supabase.co'
```
Der Anon-Key ist per Design public (Browser-seitig), aber die Supabase-Projekt-URL ist bekannt und der Key ist dauerhaft in git-History. Das kritische Problem: Key-Rotation muss ohne Blocker möglich sein.

**C2: Anon-Key-Rotation blockiert ohne Build-Prozess**  
Weil `js/env.js` direkt committed ist: Key-Rotation = Commit + Push + Deploy. Bei einem kompromittierten Key keine Option für schnelle Rotation ohne Repository-Zugriff und Deployment-Pipeline.

**C3: Kein CORS-Schutz auf `api/submit.js` und `api/fund.js`**  
Beide API-Endpoints akzeptieren POST/GET von **jeder Origin**. Das bedeutet: jede Website weltweit kann `POST /api/submit?fund=<slug>` aufrufen und Dummy-Submissions einschleusen. Rate-Limiting per E-Mail ist bypassbar durch variable E-Mail-Adressen. Die `?fund=<slug>` URL ist öffentlich bekannt (Submit-Formular-URL).

```js
// api/submit.js — keine einzige Zeile CORS-Konfiguration
export default async function handler(req, res) {
  if (req.method !== 'POST') { return res.status(405)... }
  // direkt weiter ohne Origin-Check
```

### HIGH

**H1: Rate-Limiting bypassbar**  
Jeder Angreifer kann unbegrenzt Submissions mit variablen E-Mails (`a1@x.com`, `a2@x.com`, ...) einschleusen. Kein IP-basiertes Rate-Limiting, kein Token, kein CAPTCHA.

**H2: E-Mail-Validierung zu schwach**  
`contactEmail.includes('@')` — `@` ist das einzige Kriterium. `a@`, `@b`, `@@@@` alle passieren.

**H3: Kein Input-Size-Limit**  
`body` in `api/submit.js` wird ungefiltert als `insertData = { ...body, ... }` in die DB geschrieben. Kein `req.body` size limit, kein String-Length-Check auf einzelne Felder. Ein 50MB-JSON-Body würde verarbeitet und versucht in Supabase zu schreiben.

**H4: `pitch_deck_url` und `linkedin_url` ohne URL-Schema-Validierung — XSS-Pfad**  
```js
// renderers-modals.js:151
`<a href="${escapeHTML(f.linkedin_url)}" ...>LinkedIn</a>`
```
`escapeHTML()` encoded HTML-Entities, aber **nicht URL-Schemas**. Ein Startup könnte `javascript:alert(1)` als LinkedIn-URL oder Pitch-Deck-URL einreichen → XSS beim Öffnen des Detail-Modals. Das ist ein echter Angriffspfad für externe Startup-Founder gegen VC-Analysten.

**H5: Keine CSP (Content Security Policy)**  
Kein `Content-Security-Policy`-Header auf keiner der HTML-Seiten. Kein `X-Frame-Options`, kein `X-Content-Type-Options`, kein `Referrer-Policy`. Supabase CDN-Script von `cdn.jsdelivr.net` ohne Subresource Integrity (SRI):
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
```
Supply-Chain-Angriff auf jsdelivr → Code-Execution im App-Context.

**H6: Session-Token im `window._authSession`**  
```js
window._authSession = session; // main.js:125
```
Der komplette JWT (access_token, refresh_token) liegt auf `window` — zugänglich für jeden im gleichen Tab ausgeführten JavaScript-Code (Browser-Extensions, injiziertes XSS, Drittanbieter-Scripts).

**H7: `apiLoadPipeline` ohne fund_id-Guard**  
`if (fund_id) query = query.eq(...)` — fund_id ist optional. Ohne RLS-Garantie: alle pipeline-Rows aller Fonds sichtbar.

### MEDIUM

**M1: Magic Link ohne Rate-Limiting (Login-Page)**  
`supabaseClient.auth.signInWithOtp()` hat kein client-seitiges Rate-Limit. Supabase hat ein internes Limit (default: 3/Stunde per E-Mail), aber kein CAPTCHA für öffentliche Login-Page.

**M2: `?error=unauthorized` in URL**  
`textContent` wird korrekt verwendet (kein XSS), aber kein Parameter-Whitelist auf redirect-Parameter.

**M3: `window.prompt()` für Filterset-Namen (`state.js:413`)**  
Blockt UI-Thread.

**M4: Geplante E-Mail-Funktionalität ungeprüft**  
Der Plan `docs/plans/2026-04-22-email-versand.md` deutet auf geplante E-Mail-Funktionalität hin — muss vor Einführung auf E-Mail-Injection und DKIM/SPF-Konfiguration geprüft werden.

**M5: `console.error()` als einziges Error-Reporting**  
Alle silent failures in `api.js` (accept, decline, pipeline operations) werden nur per `console.error()` geloggt. In Produktion sind Browser-Konsolen nicht gemonitort.

### LOW

**L1: Activity Log in localStorage** — keine cross-device-Sync, keine Integrität, kein Audit-Trail.  
**L2: Hardcoded SVG-Farben** — kein Security-Risiko, bekannter Tech Debt.  
**L3: Toast-Duration-Inkonsistenz** — CLAUDE.md vs. tatsächlicher Code.

---

## 4. Infrastruktur-Analyse

| Szenario | Status |
|---|---|
| 10 Tester (Demo-Pilot) | Technisch möglich, riskant wegen CORS + fehlenden Error-Recovery |
| 100 Tester | Nicht empfohlen ohne IP-Rate-Limiting, Input-Size-Limits, CSP, Monitoring |
| Parallele Nutzung | Race Condition in `generateUniqueAnonId()` — TOCTOU-Problem |
| Öffentlich zugängliche Demo-Accounts | Submit-API ohne CORS aktiv angreifbar |
| Mobile Clients | Responsive Design vorhanden, kein separater Mobile-Client nötig |
| Langsame Netzwerke | Kein Timeout auf `fetch()`-Calls, kein User-Feedback bei Hänger |
| Traffic-Spikes | Vercel skaliert, aber Supabase Connection-Limits relevant |

**Race Condition Detail — `generateUniqueAnonId()` (`api/submit.js:206`):**
```js
for (let attempt = 0; attempt < 5; attempt++) {
  const candidate = generateAnonId();
  const checkRes = await fetch(...); // kein Lock, keine Transaktion
  // ↑ Zwischen Check und Insert kann parallele Request gleiche anon_id eintragen
```
Schutz: `UNIQUE CONSTRAINT (fund_id, anon_id)` in der DB — unklar ob vorhanden.

---

## 5. Produktionsreife

| Bereich | Status |
|---|---|
| Monitoring | Keins |
| Alerting | Keins |
| Observability | Nur `console.error()` |
| Crash Recovery | Manuell |
| CI/CD | Vercel Auto-Deploy (kein Test-Gate) |
| Deployment-Rollbacks | Vercel bietet Rollbacks, keine Konfiguration |
| Environment-Trennung | Keine Staging-Umgebung erkennbar |
| Staging vs. Production | Ein einziges Supabase-Projekt |
| Feature Flags | Nicht vorhanden |
| Audit Logs | localStorage only, nicht persistent |
| Analytics | Nicht vorhanden |
| GDPR/DSGVO | Teilweise — kritische Lücken (siehe unten) |

### DSGVO-Risiken

- `contact_email`, `contact_name`, echte Founder-Namen und LinkedIn-URLs werden in Supabase gespeichert — **kein Datenlöschkonzept** erkennbar
- **Kein Datenschutzhinweis im Submit-Formular** (`submit/index.html`) — Pflicht unter DSGVO Art. 13 vor Datenerhebung
- Activity Log in localStorage enthält `anon_id`-Referenzen — nicht löschbar
- Keine Datenschutzerklärung verlinkt

---

## 6. Technische Schulden

| # | Problem | Datei | Typ |
|---|---|---|---|
| 1 | `apiLoadPipeline` fund_id optional | `api.js:55` | Security Debt |
| 2 | `apiDeleteNote` ohne Ownership-Check | `api.js:157` | Security Debt |
| 3 | Kein Input-Size-Limit auf Submit-API | `api/submit.js` | Security Debt |
| 4 | Kein CORS-Header | `api/*.js` | Security Debt |
| 5 | Kein URL-Schema-Check für `pitch_deck_url`/`linkedin_url` | `renderers-modals.js:151,188,221` | Security Debt |
| 6 | `window._authSession` mit vollem JWT | `main.js:125` | Security Debt |
| 7 | Keine SRI für CDN-Script | `index.html`, `login.html` | Security Debt |
| 8 | Kein Timeout auf `fetch()` | `api.js`, `api/submit.js` | Reliability Debt |
| 9 | Race Condition in `generateUniqueAnonId()` | `api/submit.js:206` | Correctness Debt |
| 10 | Keine Staging-Umgebung | Infra | Ops Debt |
| 11 | Kein Monitoring/Alerting | Infra | Ops Debt |
| 12 | E-Mail-Validierung: nur `includes('@')` | `api/submit.js:169` | Correctness Debt |
| 13 | Activity Log nicht persistent | `activity.js` | Feature Debt |
| 14 | `window.prompt()` für Filtersets | `state.js:413` | UX Debt |
| 15 | Monkey-Patching in main.js/custom-index | `main.js:265` | Arch Debt |
| 16 | Kein DSGVO-Notice im Submit-Formular | `submit/index.html` | Legal Debt |
| 17 | Kein `UNIQUE`-Constraint `(fund_id, anon_id)` | DB | Correctness Debt |
| 18 | `author`-Feld in `apiAddNote` hardcoded als `'Analyst'` | `api.js:65` | Data Debt |
| 19 | SQL-Migrationen als Kommentar in `api/submit.js` (Zeile 301–324) | `api/submit.js` | Arch Debt |
| 20 | Keine CI-Testgate vor Deployment | Infra | Ops Debt |

---

## 7. Risiko-Matrix

| ID | Befund | Severity | Eintrittswahrscheinlichkeit | Impact |
|---|---|---|---|---|
| C1 | Anon-Key in git-History | CRITICAL | Hoch | Mittel |
| C2 | Key-Rotation blockiert | CRITICAL | Mittel | Hoch |
| C3 | Kein CORS → Spam-Submissions | CRITICAL | Hoch | Hoch |
| H1 | Rate-Limiting per E-Mail-Variation bypassbar | HIGH | Mittel | Hoch |
| H2 | Schwache E-Mail-Validierung | HIGH | Mittel | Mittel |
| H3 | Kein Input-Size-Limit | HIGH | Niedrig | Hoch |
| H4 | XSS via `pitch_deck_url`/`linkedin_url` | HIGH | Mittel | Hoch |
| H5 | Keine CSP / kein SRI für CDN | HIGH | Niedrig | Kritisch |
| H6 | JWT in `window._authSession` | HIGH | Niedrig | Hoch |
| H7 | `apiLoadPipeline` ohne fund_id-Guard | HIGH | Niedrig | Hoch |
| M1 | Magic-Link ohne Rate-Limit | MEDIUM | Niedrig | Mittel |
| M4 | Zukünftige E-Mail-Funktion ungeprüft | MEDIUM | N/A | Hoch |
| M5 | Silent Failures in API | MEDIUM | Hoch | Mittel |

---

## 8. Go/No-Go Entscheidung

### NO-GO für öffentlichen Demo-Pilot in aktuellem Zustand

Nicht wegen eines einzelnen Critical-Befunds, sondern wegen der Kombination:

1. Submit-API ist CORS-ungeschützt → aktiv angreifbar mit Spam-Submissions
2. XSS-Pfad via URL-Feldern → Angriff gegen Analysten möglich
3. Kein Error-Monitoring → Ausfälle unsichtbar

### Tolerierbare Risiken für kleinen Demo-Pilot (< 10 vertrauenswürdige Tester)

- Anon-Key in git-History (da by-design public)
- Fehlendes Monitoring (manuell kompensierbar bei kleiner Tester-Gruppe)
- localStorage Activity Log
- Monkey-Patching-Pattern
- Race Condition in `generateUniqueAnonId` (sehr unwahrscheinlich bei < 10 Testern)

### NIEMALS tolerierbare Risiken — auch nicht bei kleinem Pilot

- **XSS via `pitch_deck_url`/`linkedin_url`** — betrifft echte Analysten-Accounts
- **Kein CORS-Schutz auf Submit-API** — öffentlich angreifbar
- **Kein Datenschutzhinweis im Submit-Formular** — DSGVO Art. 13, keine Ausnahme

---

## 9. Priorisierte Next Steps

### P0 — Blocker vor Demo-Pilot (ca. 1 Tag Arbeit)

**P0.1 — XSS via URL-Felder schließen** (`renderers-modals.js:151, 188, 221`)
```js
function safeUrl(url) {
  if (!url) return '#';
  const u = String(url);
  if (!/^https?:\/\//i.test(u)) return '#'; // nur http/https erlaubt
  return escapeHTML(u);
}
```

**P0.2 — CORS auf Submit-API einschränken** (`api/submit.js`, `api/fund.js`)
```js
const ALLOWED_ORIGINS = ['https://deinedomain.vercel.app'];
res.setHeader('Access-Control-Allow-Origin',
  ALLOWED_ORIGINS.includes(req.headers.origin) ? req.headers.origin : '');
res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
```

**P0.3 — Input-Size-Limit auf Submit-API**  
Vercel default 4.5MB — explizit auf 50KB für JSON limitieren via frühem Body-Size-Check.

**P0.4 — Datenschutzhinweis im Submit-Formular** (`submit/index.html`)  
Checkbox "Ich stimme der Verarbeitung meiner Daten gemäß Datenschutzerklärung zu" vor Submit-Button — DSGVO Art. 13 Pflicht.

**P0.5 — `apiLoadPipeline` fund_id-Guard hardmachen** (`api.js:55`)
```js
if (!fund_id) throw new Error('[apiLoadPipeline] fund_id required');
```

### P1 — Vor echtem Produktionsbetrieb (innerhalb 2 Wochen)

**P1.1 — CSP-Header + SRI für CDN-Scripts**  
Alle HTML-Seiten brauchen `Content-Security-Policy`, alle externen Scripts brauchen `integrity="sha384-..."`.

**P1.2 — Error-Monitoring einrichten**  
Sentry Free Tier (< 5.000 errors/month gratis), integrierbar in < 30 Minuten. Minimal: `window.onerror` + Sentry-DSN.

**P1.3 — Staging-Umgebung (zweites Supabase-Projekt)**  
Staging-Branch in Vercel + separates Supabase-Projekt. Kosten: $0 bei Supabase Free Tier.

**P1.4 — `UNIQUE CONSTRAINT (fund_id, anon_id)` in DB**  
Verhindert die Race-Condition-Kollision permanent auf DB-Ebene.

**P1.5 — IP-basiertes Rate-Limiting**  
Vercel Edge Middleware oder Upstash Redis (kostenlos bis 10k requests/Tag) für IP-basiertes Limiting auf Submit-Endpoint.
