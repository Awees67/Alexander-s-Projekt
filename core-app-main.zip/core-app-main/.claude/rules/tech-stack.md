# Tech Stack

- Frontend: HTML, CSS, JavaScript (single-file prototype → being refactored)
- Backend/DB: Supabase
- Hosting: TBD
