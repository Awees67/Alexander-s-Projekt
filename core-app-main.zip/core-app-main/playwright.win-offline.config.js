// TEMP (Verifikation Compare-View v2): Offline-Tests auf Windows mit System-Edge
// statt @sparticuz/chromium (Linux-Binary) — der Playwright-Chromium-Download
// hängt auf diesem Rechner. Aufruf:
//   PW_OFFLINE=1 APP_URL=http://127.0.0.1:8765 npx playwright test -c playwright.win-offline.config.js
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  timeout: 45_000,
  workers: 1,
  retries: 1,
  reporter: [['list']],
  use: {
    baseURL: process.env.APP_URL || 'http://127.0.0.1:8765',
    ...devices['Desktop Chrome'],
    // Standard: Playwright-Chromium (manuell installiert, siehe Memory
    // windows-test-umgebung); Fallback auf System-Edge via PW_CHANNEL=msedge.
    channel: process.env.PW_CHANNEL || undefined,
  },
  projects: [
    { name: 'offline-smoke', testMatch: '**/offline-smoke.spec.js' },
    { name: 'pipeline-view', testMatch: '**/pipeline-view.spec.js' },
  ],
});
