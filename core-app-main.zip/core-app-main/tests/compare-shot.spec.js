// TEMP (Pixelvergleich Compare-View v2): rendert die Compare-View mit 5
// Fixture-Deals (Supabase-Stub wie offline-smoke.spec.js) und legt
// Screenshots unter test-results/ ab. Schlägt fehl bei JS-Fehlern.
import { test, expect } from '@playwright/test';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dir = dirname(fileURLToPath(import.meta.url));

function pgrstFulfill(route, rows, fallbackSingle) {
  const accept = route.request().headers()['accept'] || '';
  const single = accept.includes('vnd.pgrst.object') || fallbackSingle;
  const body = single ? (Array.isArray(rows) ? rows[0] : rows) : (Array.isArray(rows) ? rows : [rows]);
  return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body ?? (single ? {} : [])) });
}

async function setupOffline(page) {
  const fx = JSON.parse(readFileSync(join(__dir, 'fixtures', 'workspace-fixtures.json'), 'utf8'));
  const supabaseJs = readFileSync(join(__dir, '..', 'node_modules', '@supabase', 'supabase-js', 'dist', 'umd', 'supabase.js'), 'utf8');
  const user = { id: fx.user_id, email: 'test@core-app.dev', aud: 'authenticated', role: 'authenticated' };

  await page.route('**/cdn.jsdelivr.net/npm/@supabase/supabase-js**', r =>
    r.fulfill({ status: 200, contentType: 'application/javascript', body: supabaseJs }));
  await page.route('**/auth/v1/user**', r =>
    r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(user) }));
  await page.route('**/auth/v1/token**', r =>
    r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({
      access_token: 'offline', refresh_token: 'offline', token_type: 'bearer', expires_in: 3600, user }) }));
  await page.route('**/auth/v1/logout**', r => r.fulfill({ status: 204, body: '' }));
  await page.route('**/rest/v1/**', r => pgrstFulfill(r, []));
  await page.route('**/rest/v1/fund_users**', r => pgrstFulfill(r, fx.fund_users));
  await page.route('**/rest/v1/funds?**', r => pgrstFulfill(r, [fx.fund]));
  await page.route('**/rest/v1/fund_members**', r => pgrstFulfill(r, fx.fund_members));
  await page.route('**/rest/v1/submissions**', r => {
    if (r.request().method() !== 'GET') return pgrstFulfill(r, []);
    return pgrstFulfill(r, fx.submissions);
  });
  await page.route('**/rest/v1/pipeline**', r => pgrstFulfill(r, fx.pipeline));
  await page.route('**/rest/v1/activity_log**', r => pgrstFulfill(r, []));

  await page.addInitScript(({ userId, compareIds }) => {
    localStorage.setItem('sb-ggfjgzjevyemwbclvfpp-auth-token', JSON.stringify({
      access_token: 'offline', refresh_token: 'offline', token_type: 'bearer',
      expires_in: 3600, expires_at: Math.floor(Date.now() / 1000) + 3600,
      user: { id: userId, email: 'test@core-app.dev', aud: 'authenticated', role: 'authenticated' },
    }));
    localStorage.setItem('core_compare_v1', JSON.stringify(compareIds));
  }, { userId: fx.user_id, compareIds: ['N-3918', 'G-9549', 'X-7373', 'N-1247', 'R-5649'] });

  return fx;
}

test('Compare-View v2 Screenshot', async ({ page }) => {
  const errors = [];
  page.on('pageerror', e => errors.push(`pageerror: ${e.message}`));
  page.on('console', m => {
    if (m.type() !== 'error') return;
    const t = m.text();
    if (/Failed to load resource|favicon/i.test(t)) return;
    errors.push(`console: ${t}`);
  });

  await setupOffline(page);
  await page.goto('/');
  await page.waitForFunction(() => Array.isArray(window.startups) && window.fundName, null, { timeout: 15_000 });

  const view = page.locator('#viewCompare');
  for (let i = 0; i < 5; i++) {
    await page.click('#topTabCompare');
    try { await view.waitFor({ state: 'visible', timeout: 2_000 }); break; } catch (_) {}
  }
  await expect(view).toBeVisible({ timeout: 5_000 });
  await expect(page.locator('#compareBody tr')).toHaveCount(5);
  await page.waitForTimeout(500);
  await page.screenshot({ path: 'test-results/compare-v2.png', fullPage: false });

  // Leerzustand
  await page.click('#compareClearBtn');
  await page.waitForTimeout(300);
  await page.screenshot({ path: 'test-results/compare-v2-empty.png', fullPage: false });

  expect(errors, errors.join('\n')).toHaveLength(0);
});
