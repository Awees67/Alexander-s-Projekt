// TEMP (UI-Skalierung): Screenshot jeder View für den Vorher/Nachher-Vergleich.
// Läuft NUR mit PW_OFFLINE=1 (Supabase-Stub wie offline-smoke.spec.js).
// Aufruf: PW_OFFLINE=1 APP_URL=http://127.0.0.1:8765 npx playwright test -c playwright.shot.config.js views-shot

import { test } from '@playwright/test';
import { readFileSync, mkdirSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const OFFLINE = process.env.PW_OFFLINE === '1';
const __dir = dirname(fileURLToPath(import.meta.url));
const OUT = join(__dir, '..', 'test-results', 'view-shots');

function pgrstFulfill(route, rows, fallbackSingle) {
  const accept = route.request().headers()['accept'] || '';
  const single = accept.includes('vnd.pgrst.object') || fallbackSingle;
  const body = single ? (Array.isArray(rows) ? rows[0] : rows) : (Array.isArray(rows) ? rows : [rows]);
  return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body ?? (single ? {} : [])) });
}

async function setupOffline(page) {
  const fx = JSON.parse(readFileSync(join(__dir, 'fixtures', 'workspace-fixtures.json'), 'utf8'));
  const supabaseJs = readFileSync(join(__dir, '..', 'node_modules', '@supabase', 'supabase-js', 'dist', 'umd', 'supabase.js'), 'utf8');
  const user = { id: fx.user_id, email: 'test@core-app.dev', aud: 'authenticated', role: 'authenticated' };

  await page.route('**/cdn.jsdelivr.net/npm/@supabase/supabase-js**', r =>
    r.fulfill({ status: 200, contentType: 'application/javascript', body: supabaseJs }));
  await page.route('**/auth/v1/user**', r =>
    r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(user) }));
  await page.route('**/auth/v1/token**', r =>
    r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({
      access_token: 'offline', refresh_token: 'offline', token_type: 'bearer', expires_in: 3600, user }) }));
  await page.route('**/rest/v1/**', r => pgrstFulfill(r, []));
  await page.route('**/rest/v1/fund_users**', r => pgrstFulfill(r, fx.fund_users));
  await page.route('**/rest/v1/funds?**', r => pgrstFulfill(r, [fx.fund]));
  await page.route('**/rest/v1/fund_members**', r => pgrstFulfill(r, fx.fund_members));
  await page.route('**/rest/v1/submissions**', r => pgrstFulfill(r, fx.submissions));
  await page.route('**/rest/v1/pipeline**', r => pgrstFulfill(r, fx.pipeline));
  await page.route('**/rest/v1/activity_log**', r => pgrstFulfill(r, []));

  await page.addInitScript(({ userId }) => {
    localStorage.setItem('sb-ggfjgzjevyemwbclvfpp-auth-token', JSON.stringify({
      access_token: 'offline', refresh_token: 'offline', token_type: 'bearer',
      expires_in: 3600, expires_at: Math.floor(Date.now() / 1000) + 3600,
      user: { id: userId, email: 'test@core-app.dev', aud: 'authenticated', role: 'authenticated' },
    }));
  }, { userId: fx.user_id });
  return fx;
}

const VIEW_OF_TAB = {
  topTabDashboard: '#viewDashboard',
  topTabHome: '#cardGrid',
  topTabSubmissions: '#viewSubmissions',
  topTabPipeline: '#viewPipeline',
  topTabCompare: '#viewCompare',
  topTabActivity: '#viewActivity',
  topTabInbox: '#viewInbox',
};

async function clickTab(page, tabId) {
  const view = page.locator(VIEW_OF_TAB[tabId]);
  for (let i = 0; i < 5; i++) {
    await page.click(`#${tabId}`);
    try { await view.waitFor({ state: 'visible', timeout: 2_000 }); return; } catch (_) {}
  }
  await view.waitFor({ state: 'visible', timeout: 5_000 });
}

test.describe('View-Screenshots', () => {
  test.skip(!OFFLINE, 'Nur mit PW_OFFLINE=1 sinnvoll');

  test('Alle 7 Views + Detail-Modal screenshotten', async ({ page }) => {
    mkdirSync(OUT, { recursive: true });
    await setupOffline(page);
    await page.goto('/');
    await page.waitForFunction(() => Array.isArray(window.startups) && window.fundName, null, { timeout: 15_000 });

    const metrics = [];
    for (const [tabId, sel] of Object.entries(VIEW_OF_TAB)) {
      await clickTab(page, tabId);
      await page.waitForTimeout(400);
      const name = tabId.replace('topTab', '').toLowerCase();
      await page.screenshot({ path: join(OUT, `${name}.png`) });
      metrics.push(await page.evaluate((s) => {
        const el = document.querySelector(s);
        const r = el ? el.getBoundingClientRect() : null;
        return {
          view: s,
          viewWidth: r ? Math.round(r.width) : null,
          docScrollH: document.documentElement.scrollHeight,
          rootFontSize: getComputedStyle(document.documentElement).fontSize,
          bodyFontSize: getComputedStyle(document.body).fontSize,
        };
      }, sel));
    }

    // Detail-Modal
    await page.evaluate(() => openModalByAnonId(window.startups[0].anon_id, window.startups));
    await page.waitForTimeout(600);
    await page.screenshot({ path: join(OUT, 'detail-modal.png') });

    console.log(JSON.stringify(metrics, null, 2));
  });
});
