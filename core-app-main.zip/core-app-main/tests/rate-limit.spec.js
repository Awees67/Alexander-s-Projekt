// Test: Rate Limiting — gleiche E-Mail 4x submittieren, 4. muss HTTP 429 zurückgeben
// Cleanup: DELETE FROM submissions WHERE contact_email = 'ratelimit-test@playwright.local';

import { test, expect } from '@playwright/test';

const FUND_SLUG = process.env.FUND_SLUG || 'apex';
const TEST_EMAIL = 'ratelimit-test@playwright.local';

// Minimale Formulardaten — nur Pflichtfelder
async function fillMinimalForm(page) {
  await page.goto(`/submit/?fund=${FUND_SLUG}`);
  await expect(page.locator('#fundName')).not.toHaveText('Laden...', { timeout: 10_000 });
  await page.waitForFunction(() => typeof currentFund !== 'undefined' && currentFund?.id != null, { timeout: 10_000 }).catch(() => {});

  await page.fill('#company_name', 'RateLimit Test GmbH');
  await page.fill('#contact_name', 'Test User');
  await page.fill('#contact_email', TEST_EMAIL);
  await page.fill('#description', 'Rate limit test submission — kann gelöscht werden. Dieser Text ist lang genug um die 80-Zeichen-Validierung zu bestehen.');
  await page.selectOption('#origin_country', 'DE');
  await page.selectOption('#stage', 'Seed');
  await page.selectOption('#sector', 'B2B SaaS');
  await page.fill('#team_size', '3');
  await page.locator('#market_served_group input[value="DACH"]').check();
  await page.fill('#mrr_eur', '15000');
  await page.fill('#burn_eur_per_month', '20000');
  await page.fill('#runway_months', '18');
  await page.fill('#ticket_eur', '500000');

  // Founder-Pflichtfelder
  const card = page.locator('.founder-card').first();
  await card.locator('.f-name').fill('Test Founder');
  await card.locator('.f-role').selectOption('CEO');
  await card.locator('.f-prev-companies').fill('Testcorp');
}

test('3 Submissions funktionieren, 4. gibt 429', { timeout: 120_000 }, async ({ page }) => {
  // 3 erfolgreiche Submissions
  for (let i = 1; i <= 3; i++) {
    await fillMinimalForm(page);
    await page.click('#submitBtn');
    await expect(page.locator('#successScreen')).toBeVisible({ timeout: 15_000 });
  }

  // 4. Submission — muss Rate-Limit Fehler zeigen
  await fillMinimalForm(page);
  await page.click('#submitBtn');

  await expect(page.locator('#errorMsg')).toBeVisible({ timeout: 10_000 });
  await expect(page.locator('#errorMsg')).toContainText('24 Stunden');
});
