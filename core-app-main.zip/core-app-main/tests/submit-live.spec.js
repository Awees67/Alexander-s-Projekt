// TEMP (Live-Durchlauf-Test): füllt das echte Submit-Formular auf Vercel 15× mit
// realistischen, in sich konsistenten Startup-Daten aus und schickt ab — wie 15
// echte Bewerbungen im realen Workflow. Jeder Datensatz hat eine eigene
// Kontakt-E-Mail (E-Mail-Rate-Limit: 3/24h). Verteilung wie echter Dealflow:
// 11× plausibility passed, 3× flagged (Soft-Findings), 1× failed (Pre-Revenue).
// Aufruf: npx playwright test -c playwright.live-submit.config.js
import { test, expect } from '@playwright/test';

const SUBMISSIONS = [
  {
    company_name: 'Taxomatic GmbH', contact_name: 'Lukas Brandt', contact_email: 'lukas.brandt@taxomatic-app.de',
    pitch_deck_url: 'https://docsend.com/view/taxomatic-seed', origin_country: 'DE',
    market_served: ['DACH'], stage: 'Seed', sector: 'B2B SaaS', sub_sector: 'Vertical SaaS',
    description: 'Taxomatic automatisiert die Mandanten-Buchhaltung für kleine Steuerkanzleien: Belege werden per KI vorkontiert, Rückfragen an Mandanten laufen über ein Portal statt per E-Mail-Pingpong.',
    problem_solution: 'Steuerkanzleien verlieren 30% ihrer Zeit mit Belegbeschaffung und manueller Vorkontierung. Wir reduzieren das auf ein Fünftel.',
    traction_note: '95 zahlende Kanzleien, davon 70% über Empfehlungen des DATEV-Partnernetzwerks.',
    team_note: 'Gründerteam aus Ex-DATEV-Produktmanager und Ex-Personio-Engineer.',
    nums: { team_size: 12, founded_year: 2023, mrr_eur: 38000, burn_eur_per_month: 95000, runway_months: 14, growth_pct: 12, paying_customers: 95, net_new_mrr_eur: 4200, nrr_pct: 112, gross_margin_pct: 82, cac_eur: 3800, logo_churn_pct: 1.4, revenue_churn_pct: 1.1, tam_eur: 4500000000, sam_eur: 800000000, ticket_eur: 2500000, valuation_eur: 12000000, total_raised_eur: 750000, investor_count: 4, founder_pct: 78, investor_pct: 12, employees_pct: 10 },
    founders: [
      { name: 'Lukas Brandt', role: 'CEO', prev_companies: ['DATEV'], prev_roles: ['Senior Product Manager'], years: 9, education: 'WHU, BWL', strengths: ['Domain Expert', 'GTM / Sales'], linkedin: 'https://linkedin.com/in/lukasbrandt' },
      { name: 'Jana Keller', role: 'CTO', prev_companies: ['Personio'], prev_roles: ['Staff Engineer'], years: 11, education: 'TU München, Informatik', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/janakeller' },
    ],
  },
  {
    company_name: 'PayLane Technologies', contact_name: 'Sophie Maier', contact_email: 'sophie@paylane.io',
    pitch_deck_url: 'https://pitch.com/paylane-series-a', origin_country: 'AT',
    market_served: ['DACH', 'EU'], stage: 'Series A', sector: 'FinTech', sub_sector: 'Payments',
    description: 'PayLane ist die Payment-Orchestrierungs-Plattform für den europäischen Mittelstand: ein API-Vertrag, dahinter 40+ Zahlarten und automatisches Routing nach Kosten und Conversion.',
    problem_solution: 'Händler verlieren 2-4% Umsatz durch fehlgeschlagene Zahlungen und suboptimales Routing. PayLane hebt die Authorization Rate um durchschnittlich 3,1 Punkte.',
    traction_note: '340 Händler live, 1,2 Mrd. € jährliches Zahlungsvolumen, NRR 118%.',
    team_note: 'CEO hat zuvor Zahlungsdienstleister an Nets verkauft.',
    nums: { team_size: 46, founded_year: 2021, mrr_eur: 210000, burn_eur_per_month: 480000, runway_months: 18, growth_pct: 9, paying_customers: 340, net_new_mrr_eur: 22000, nrr_pct: 118, gross_margin_pct: 71, cac_eur: 9500, logo_churn_pct: 1.0, revenue_churn_pct: 0.8, tam_eur: 12000000000, sam_eur: 2400000000, ticket_eur: 8000000, valuation_eur: 48000000, total_raised_eur: 6200000, investor_count: 9, founder_pct: 52, investor_pct: 38, employees_pct: 10 },
    founders: [
      { name: 'Sophie Maier', role: 'CEO', prev_companies: ['Payolution', 'Klarna'], prev_roles: ['Gründerin', 'Director Payments'], years: 14, education: 'WU Wien', strengths: ['Repeat Founder', 'Domain Expert'], had_exit: true, exit_detail: 'Payolution an Nets verkauft (2019)', linkedin: 'https://linkedin.com/in/sophiemaier' },
      { name: 'Daniel Hofer', role: 'CTO', prev_companies: ['Adyen'], prev_roles: ['Engineering Lead'], years: 12, education: 'TU Wien, Software Engineering', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/danielhofer' },
      { name: 'Clara Steiner', role: 'COO', prev_companies: ['N26'], prev_roles: ['VP Operations'], years: 10, education: 'HSG St. Gallen', strengths: ['Operator'], linkedin: 'https://linkedin.com/in/clarasteiner' },
    ],
  },
  {
    company_name: 'MediNotes AI', contact_name: 'Dr. Felix Wagner', contact_email: 'felix.wagner@medinotes.health',
    pitch_deck_url: 'https://docsend.com/view/medinotes', origin_country: 'DE',
    market_served: ['Germany', 'DACH'], stage: 'Seed', sector: 'HealthTech', sub_sector: 'Clinical Workflow',
    description: 'MediNotes nimmt Ärztinnen und Ärzten die Dokumentation ab: Ambient-KI hört im Behandlungszimmer mit und erstellt strukturierte, abrechnungsfertige Befunde direkt im KIS.',
    problem_solution: 'Klinikärzte verbringen 3 Stunden pro Tag mit Dokumentation. MediNotes reduziert das auf unter 40 Minuten — DSGVO-konform, On-Premise-fähig.',
    traction_note: '31 Kliniken zahlend, davon 6 Uniklinika. Pilot-zu-Vertrag-Konversion 78%.',
    team_note: 'Arzt + ML-Engineer als Gründerduo, klinischer Beirat mit 4 Chefärzten.',
    nums: { team_size: 9, founded_year: 2024, mrr_eur: 22000, burn_eur_per_month: 70000, runway_months: 16, growth_pct: 18, paying_customers: 31, net_new_mrr_eur: 3100, nrr_pct: 124, gross_margin_pct: 76, cac_eur: 5200, logo_churn_pct: 0.9, revenue_churn_pct: 0.7, tam_eur: 6000000000, sam_eur: 900000000, ticket_eur: 3000000, valuation_eur: 15000000, total_raised_eur: 900000, investor_count: 3, founder_pct: 81, investor_pct: 11, employees_pct: 8 },
    founders: [
      { name: 'Dr. Felix Wagner', role: 'CEO', prev_companies: ['Charité Berlin'], prev_roles: ['Assistenzarzt Innere Medizin'], years: 8, education: 'Charité, Humanmedizin', strengths: ['Domain Expert'], linkedin: 'https://linkedin.com/in/drfelixwagner' },
      { name: 'Mira Schulz', role: 'CTO', prev_companies: ['DeepL'], prev_roles: ['Senior ML Engineer'], years: 7, education: 'RWTH Aachen, Informatik', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/miraschulz' },
    ],
  },
  {
    company_name: 'GridFlex Energy', contact_name: 'Matthias Keller', contact_email: 'm.keller@gridflex.ch',
    pitch_deck_url: 'https://pitch.com/gridflex-series-a', origin_country: 'CH',
    market_served: ['Switzerland', 'DACH', 'EU'], stage: 'Series A', sector: 'ClimateTech', sub_sector: 'Energy Storage',
    description: 'GridFlex vernetzt Industriebatterien zu virtuellen Kraftwerken und vermarktet die Flexibilität automatisiert am Regelenergiemarkt — Betreiber verdienen mit, ohne selbst zu handeln.',
    problem_solution: 'Industrielle Batteriespeicher stehen 70% der Zeit ungenutzt. GridFlex monetarisiert sie über Regelenergie- und Spotmarkt-Optimierung.',
    traction_note: '28 Industriekunden, 240 MWh unter Management, Erlöse je Kunde +35% YoY.',
    team_note: 'Team aus ETH-Spin-off, CTO hat Promotion in Leistungselektronik.',
    nums: { team_size: 58, founded_year: 2020, mrr_eur: 145000, burn_eur_per_month: 600000, runway_months: 15, growth_pct: 7, paying_customers: 28, net_new_mrr_eur: 9800, nrr_pct: 109, gross_margin_pct: 54, cac_eur: 18000, logo_churn_pct: 0.5, revenue_churn_pct: 0.4, tam_eur: 20000000000, sam_eur: 3000000000, ticket_eur: 12000000, valuation_eur: 60000000, total_raised_eur: 9500000, investor_count: 7, founder_pct: 44, investor_pct: 46, employees_pct: 10 },
    founders: [
      { name: 'Matthias Keller', role: 'CEO', prev_companies: ['ABB'], prev_roles: ['Business Development Energy'], years: 13, education: 'ETH Zürich, Elektrotechnik', strengths: ['Domain Expert', 'GTM / Sales'], linkedin: 'https://linkedin.com/in/matthiaskeller' },
      { name: 'Dr. Anna Frei', role: 'CTO', prev_companies: ['ETH Zürich'], prev_roles: ['Postdoc Leistungselektronik'], years: 9, education: 'ETH Zürich, Dr. sc.', strengths: ['Technical', 'Domain Expert'], linkedin: 'https://linkedin.com/in/annafrei' },
    ],
  },
  {
    company_name: 'Klarsicht Analytics', contact_name: 'Tobias Renner', contact_email: 'tobias@klarsicht-analytics.de',
    pitch_deck_url: null, origin_country: 'DE',
    market_served: ['DACH'], stage: 'Pre-Seed', sector: 'AI', sub_sector: 'Applied AI / Vertical AI',
    description: 'Klarsicht baut KI-gestützte Schadenprüfung für Sachversicherer: Fotos und Gutachten werden automatisch ausgewertet, Plausibilität geprüft und Regulierungsvorschläge erstellt.',
    problem_solution: 'Schadenregulierung dauert im Schnitt 12 Tage. Klarsicht bringt Standardfälle auf unter 24 Stunden.',
    traction_note: '14 zahlende Kunden (Makler und zwei Versicherer im Pilotbetrieb), MRR wächst 32% MoM.',
    team_note: null,
    nums: { team_size: 5, founded_year: 2025, mrr_eur: 6500, burn_eur_per_month: 28000, runway_months: 11, growth_pct: 32, paying_customers: 14, net_new_mrr_eur: 1500, nrr_pct: 105, gross_margin_pct: 85, cac_eur: 1900, logo_churn_pct: 2.2, revenue_churn_pct: 1.8, tam_eur: 3000000000, sam_eur: 400000000, ticket_eur: 900000, valuation_eur: 5000000, total_raised_eur: 150000, investor_count: 2, founder_pct: 92, investor_pct: 4, employees_pct: 4 },
    founders: [
      { name: 'Tobias Renner', role: 'CEO', prev_companies: ['Allianz'], prev_roles: ['Schadenmanagement Lead'], years: 10, education: 'LMU München', strengths: ['Domain Expert'], linkedin: 'https://linkedin.com/in/tobiasrenner' },
      { name: 'Yusuf Demir', role: 'CTO', prev_companies: ['Celonis'], prev_roles: ['ML Engineer'], years: 6, education: 'TUM, Data Engineering', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/yusufdemir' },
    ],
  },
  {
    company_name: 'SecureMesh', contact_name: 'Nina Albrecht', contact_email: 'nina.albrecht@securemesh.io',
    pitch_deck_url: 'https://docsend.com/view/securemesh-a', origin_country: 'DE',
    market_served: ['EU', 'UK'], stage: 'Series A', sector: 'Cybersecurity', sub_sector: 'Cloud Security',
    description: 'SecureMesh gibt Sicherheitsteams eine Echtzeit-Inventur aller Cloud-Workloads samt Angriffspfad-Analyse: Wer kann von wo auf was zugreifen — und welcher Pfad ist kritisch.',
    problem_solution: 'Cloud-Security-Tools alarmieren zu viel und priorisieren nicht. SecureMesh reduziert Alerts um 90%, weil nur ausnutzbare Angriffspfade gemeldet werden.',
    traction_note: '72 Kunden, davon 11 aus dem DAX/MDAX-Umfeld. 121% NRR, Logo-Churn unter 1%.',
    team_note: 'Gründer waren Red-Team-Lead bei Siemens und Engineering Manager bei Crowdstrike.',
    nums: { team_size: 41, founded_year: 2021, mrr_eur: 165000, burn_eur_per_month: 420000, runway_months: 20, growth_pct: 8, paying_customers: 72, net_new_mrr_eur: 13000, nrr_pct: 121, gross_margin_pct: 84, cac_eur: 14500, logo_churn_pct: 0.8, revenue_churn_pct: 0.6, tam_eur: 15000000000, sam_eur: 2200000000, ticket_eur: 10000000, valuation_eur: 55000000, total_raised_eur: 7800000, investor_count: 6, founder_pct: 49, investor_pct: 41, employees_pct: 10 },
    founders: [
      { name: 'Nina Albrecht', role: 'CEO', prev_companies: ['Siemens'], prev_roles: ['Red Team Lead'], years: 12, education: 'KIT, IT-Security', strengths: ['Domain Expert', 'Technical'], linkedin: 'https://linkedin.com/in/ninaalbrecht' },
      { name: 'Paul Sturm', role: 'CTO', prev_companies: ['Crowdstrike'], prev_roles: ['Engineering Manager'], years: 11, education: 'TU Darmstadt', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/paulsturm' },
    ],
  },
  {
    company_name: 'BauPilot', contact_name: 'Markus Leitner', contact_email: 'markus@baupilot.at',
    pitch_deck_url: 'https://docsend.com/view/baupilot-seed', origin_country: 'AT',
    market_served: ['Austria', 'DACH'], stage: 'Seed', sector: 'PropTech', sub_sector: 'Construction Tech',
    description: 'BauPilot digitalisiert die Baustellenabnahme für Generalunternehmer: Mängel werden per App erfasst, automatisch den Gewerken zugeordnet und bis zur Behebung nachverfolgt.',
    problem_solution: 'Mängelmanagement läuft heute über Excel und E-Mail — pro Projekt gehen so im Schnitt 6 Wochen verloren. BauPilot halbiert die Abnahmedauer.',
    traction_note: '47 zahlende GU-Kunden in AT und Süddeutschland, 15% MoM Wachstum seit Jahresbeginn.',
    team_note: 'CEO kommt von STRABAG, CTO hat zuvor zwei SaaS-Produkte gebaut.',
    nums: { team_size: 11, founded_year: 2023, mrr_eur: 18500, burn_eur_per_month: 62000, runway_months: 13, growth_pct: 15, paying_customers: 47, net_new_mrr_eur: 2400, nrr_pct: 108, gross_margin_pct: 68, cac_eur: 2700, logo_churn_pct: 1.9, revenue_churn_pct: 1.5, tam_eur: 2500000000, sam_eur: 350000000, ticket_eur: 2000000, valuation_eur: 9000000, total_raised_eur: 550000, investor_count: 3, founder_pct: 84, investor_pct: 9, employees_pct: 7 },
    founders: [
      { name: 'Markus Leitner', role: 'CEO', prev_companies: ['STRABAG'], prev_roles: ['Projektleiter Hochbau'], years: 11, education: 'TU Graz, Bauingenieurwesen', strengths: ['Domain Expert', 'GTM / Sales'], linkedin: 'https://linkedin.com/in/markusleitner' },
      { name: 'Stefan Auer', role: 'CTO', prev_companies: ['Runtastic', 'Tractive'], prev_roles: ['Mobile Lead', 'Head of Engineering'], years: 13, education: 'JKU Linz, Informatik', strengths: ['Technical', 'Repeat Founder'], linkedin: 'https://linkedin.com/in/stefanauer' },
    ],
  },
  {
    company_name: 'Fermentic Bio', contact_name: 'Dr. Laura Brunner', contact_email: 'laura.brunner@fermentic.bio',
    pitch_deck_url: 'https://docsend.com/view/fermentic', origin_country: 'CH',
    market_served: ['EU'], stage: 'Pre-Series A', sector: 'DeepTech', sub_sector: 'Synthetic Biology',
    description: 'Fermentic entwickelt Präzisionsfermentation für Spezialproteine in der Lebensmittelindustrie und lizenziert Stämme samt Prozess an Hersteller statt selbst zu produzieren.',
    problem_solution: 'Eigene Produktionsanlagen machen FoodTech kapitalintensiv. Unser Asset-Light-Lizenzmodell skaliert über Partner mit bestehender Fermentationskapazität.',
    traction_note: '9 Lizenzkunden, davon 2 Top-10-Molkereikonzerne. Pipeline von 14 weiteren Stämmen.',
    team_note: 'Spin-off der ETH, 11 Patente, Team mit 5 PhDs.',
    nums: { team_size: 24, founded_year: 2021, mrr_eur: 32000, burn_eur_per_month: 240000, runway_months: 12, growth_pct: 6, paying_customers: 9, net_new_mrr_eur: 1900, nrr_pct: 102, gross_margin_pct: 48, cac_eur: 26000, logo_churn_pct: 0.4, revenue_churn_pct: 0.3, tam_eur: 9000000000, sam_eur: 1100000000, ticket_eur: 6000000, valuation_eur: 28000000, total_raised_eur: 4100000, investor_count: 5, founder_pct: 56, investor_pct: 36, employees_pct: 8 },
    founders: [
      { name: 'Dr. Laura Brunner', role: 'CEO', prev_companies: ['ETH Zürich', 'Givaudan'], prev_roles: ['Postdoc', 'R&D Scientist'], years: 9, education: 'ETH Zürich, Dr. sc. Biotechnologie', strengths: ['Domain Expert', 'Technical'], linkedin: 'https://linkedin.com/in/laurabrunner' },
      { name: 'Jonas Wyss', role: 'COO', prev_companies: ['Bühler Group'], prev_roles: ['Head of Business Development'], years: 12, education: 'HSG St. Gallen', strengths: ['Operator', 'GTM / Sales'], linkedin: 'https://linkedin.com/in/jonaswyss' },
    ],
  },
  {
    company_name: 'Lieferkette24', contact_name: 'Robert Krause', contact_email: 'robert.krause@lieferkette24.de',
    pitch_deck_url: null, origin_country: 'DE',
    market_served: ['Germany', 'EU'], stage: 'Seed', sector: 'Marketplace', sub_sector: 'B2B Marketplace',
    description: 'Lieferkette24 ist der B2B-Marktplatz für kurzfristige Industrie-Ersatzteile: Einkäufer finden geprüfte Lieferanten mit Echtzeit-Verfügbarkeit statt tagelanger Telefonakquise.',
    problem_solution: 'Bei Maschinenstillstand kostet jede Stunde fünfstellig — die Ersatzteilsuche läuft aber noch per Telefon und Fax. Wir liefern verbindliche Angebote in unter 2 Stunden.',
    traction_note: '410 aktive Einkäufer-Accounts, GMV 920k €/Monat, Take Rate 3%, 22% MoM Wachstum.',
    team_note: null,
    nums: { team_size: 18, founded_year: 2023, mrr_eur: 27000, burn_eur_per_month: 88000, runway_months: 10, growth_pct: 22, paying_customers: 410, net_new_mrr_eur: 4600, nrr_pct: 96, gross_margin_pct: 62, cac_eur: 480, logo_churn_pct: 3.1, revenue_churn_pct: 2.4, tam_eur: 7000000000, sam_eur: 1500000000, ticket_eur: 3500000, valuation_eur: 14000000, total_raised_eur: 1100000, investor_count: 4, founder_pct: 74, investor_pct: 17, employees_pct: 9 },
    founders: [
      { name: 'Robert Krause', role: 'CEO', prev_companies: ['Würth', 'Mercateo'], prev_roles: ['Key Account Manager', 'Head of Sales'], years: 14, education: 'Uni Mannheim, BWL', strengths: ['GTM / Sales', 'Domain Expert'], linkedin: 'https://linkedin.com/in/robertkrause' },
      { name: 'Elif Kaya', role: 'CTO', prev_companies: ['Zalando'], prev_roles: ['Senior Backend Engineer'], years: 8, education: 'TU Berlin, Informatik', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/elifkaya' },
    ],
  },
  {
    company_name: 'DevHarbor', contact_name: 'Jan Petersen', contact_email: 'jan@devharbor.dev',
    pitch_deck_url: 'https://devharbor.dev/deck', origin_country: 'DE',
    market_served: ['EU', 'UK'], stage: 'Pre-Seed', sector: 'DevTools', sub_sector: 'CI/CD / Deployment',
    description: 'DevHarbor macht Preview-Umgebungen zum Standard: Jeder Pull Request bekommt automatisch eine vollständige, isolierte Staging-Umgebung inklusive Datenbank-Seeding — in unter 90 Sekunden.',
    problem_solution: 'Teams teilen sich heute eine Staging-Umgebung und blockieren sich gegenseitig. DevHarbor eliminiert die Warteschlange komplett.',
    traction_note: '230 zahlende Self-Serve-Teams, 28% MoM Wachstum, komplett inbound über GitHub-Marketplace.',
    team_note: 'Bootstrapped bis 120k € Angel-Runde, beide Gründer Ex-Open-Source-Maintainer.',
    nums: { team_size: 4, founded_year: 2025, mrr_eur: 4200, burn_eur_per_month: 19000, runway_months: 9, growth_pct: 28, paying_customers: 230, net_new_mrr_eur: 800, nrr_pct: 101, gross_margin_pct: 88, cac_eur: 220, logo_churn_pct: 4.5, revenue_churn_pct: 3.2, tam_eur: 5000000000, sam_eur: 600000000, ticket_eur: 700000, valuation_eur: 4000000, total_raised_eur: 120000, investor_count: 2, founder_pct: 94, investor_pct: 3, employees_pct: 3 },
    founders: [
      { name: 'Jan Petersen', role: 'CEO', prev_companies: ['GitLab'], prev_roles: ['Senior Engineer CI/CD'], years: 9, education: 'Uni Hamburg, Informatik', strengths: ['Technical', 'Domain Expert'], linkedin: 'https://linkedin.com/in/janpetersen' },
      { name: 'Ole Martens', role: 'CTO', prev_companies: ['Hetzner'], prev_roles: ['Infrastructure Engineer'], years: 7, education: 'CAU Kiel, Informatik', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/olemartens' },
    ],
  },
  {
    // Flagged erwartet: 240% MoM-Wachstum liegt über der Plausibilitäts-Spanne (Launch-Spike)
    company_name: 'WealthBee', contact_name: 'Katharina Egger', contact_email: 'katharina@wealthbee.app',
    pitch_deck_url: 'https://pitch.com/wealthbee', origin_country: 'AT',
    market_served: ['Austria', 'Germany'], stage: 'Seed', sector: 'FinTech', sub_sector: 'WealthTech',
    description: 'WealthBee ist die Vorsorge-App für Selbstständige: automatisiertes ETF-Sparen mit steueroptimierter Hülle, Einnahmen-basierte dynamische Sparraten und integrierter Säule-für-Säule-Beratung.',
    problem_solution: 'Selbstständige haben keine betriebliche Altersvorsorge und schieben das Thema auf. WealthBee macht den Einstieg in 7 Minuten möglich.',
    traction_note: 'Launch vor 4 Monaten: 1.800 zahlende Abos, +240% MoM im ersten Quartal nach App-Store-Feature.',
    team_note: null,
    nums: { team_size: 8, founded_year: 2024, mrr_eur: 9000, burn_eur_per_month: 45000, runway_months: 12, growth_pct: 240, paying_customers: 1800, net_new_mrr_eur: 5200, nrr_pct: 99, gross_margin_pct: 78, cac_eur: 35, logo_churn_pct: 6, revenue_churn_pct: 4, tam_eur: 4000000000, sam_eur: 500000000, ticket_eur: 1800000, valuation_eur: 8000000, total_raised_eur: 650000, investor_count: 3, founder_pct: 79, investor_pct: 13, employees_pct: 8 },
    founders: [
      { name: 'Katharina Egger', role: 'CEO', prev_companies: ['Bitpanda'], prev_roles: ['Product Lead'], years: 8, education: 'WU Wien', strengths: ['Domain Expert', 'GTM / Sales'], linkedin: 'https://linkedin.com/in/katharinaegger' },
      { name: 'Lukas Pichler', role: 'CTO', prev_companies: ['George Labs'], prev_roles: ['Mobile Engineering Lead'], years: 9, education: 'TU Wien', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/lukaspichler' },
    ],
  },
  {
    company_name: 'Voltaris Robotics', contact_name: 'Dr. Henrik Vogel', contact_email: 'henrik.vogel@voltaris-robotics.de',
    pitch_deck_url: 'https://docsend.com/view/voltaris-b', origin_country: 'DE',
    market_served: ['EU', 'UK'], stage: 'Series B', sector: 'DeepTech', sub_sector: 'Robotics / Automation',
    description: 'Voltaris baut autonome Kommissionier-Roboter für bestehende Lagerhallen: keine Umbauten, keine Schienen — die Flotte navigiert frei und amortisiert sich in unter 18 Monaten.',
    problem_solution: 'Lagerlogistik findet kein Personal mehr, klassische Automatisierung erfordert Millionen-Umbauten. Voltaris automatisiert Brownfield-Lager ohne Infrastrukturänderung.',
    traction_note: '36 Kunden, 580 Roboter im Feld, Auftragsbestand 14 Mio. €. NRR 114% über Flottenerweiterungen.',
    team_note: 'CEO promovierter Robotiker (KIT), 140 Mitarbeitende, Produktion in Dresden.',
    nums: { team_size: 140, founded_year: 2019, mrr_eur: 480000, burn_eur_per_month: 1300000, runway_months: 22, growth_pct: 5, paying_customers: 36, net_new_mrr_eur: 30000, nrr_pct: 114, gross_margin_pct: 51, cac_eur: 42000, logo_churn_pct: 0.3, revenue_churn_pct: 0.2, tam_eur: 30000000000, sam_eur: 5000000000, ticket_eur: 25000000, valuation_eur: 180000000, total_raised_eur: 32000000, investor_count: 11, founder_pct: 31, investor_pct: 58, employees_pct: 11 },
    founders: [
      { name: 'Dr. Henrik Vogel', role: 'CEO', prev_companies: ['KUKA', 'KIT'], prev_roles: ['Lead Robotics Engineer', 'Doktorand'], years: 15, education: 'KIT, Dr.-Ing. Robotik', strengths: ['Technical', 'Domain Expert'], linkedin: 'https://linkedin.com/in/henrikvogel' },
      { name: 'Sandra Lindner', role: 'CFO', prev_companies: ['Siemens Financial Services'], prev_roles: ['Finance Director'], years: 16, education: 'Uni Köln, BWL', strengths: ['Operator'], linkedin: 'https://linkedin.com/in/sandralindner' },
      { name: 'Timo Berg', role: 'CTO', prev_companies: ['Magazino'], prev_roles: ['Head of Perception'], years: 11, education: 'TUM, Robotics', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/timoberg' },
    ],
  },
  {
    // Flagged erwartet: CAC/Churn noch nicht getrackt → Unit-Economics-Check schlägt an
    company_name: 'CarbonLedger', contact_name: 'Lea Hoffmann', contact_email: 'lea@carbonledger.eco',
    pitch_deck_url: 'https://docsend.com/view/carbonledger', origin_country: 'DE',
    market_served: ['EU'], stage: 'Seed', sector: 'ClimateTech', sub_sector: 'Carbon Capture / Removal',
    description: 'CarbonLedger ist das Buchungssystem für CO2-Entnahme: Projekte, Zertifikate und Verifizierungen werden revisionssicher erfasst, Doppelzählungen technisch ausgeschlossen.',
    problem_solution: 'Der CDR-Markt leidet unter Doppelzählungen und intransparenten Registern. CarbonLedger schafft eine prüfbare Single Source of Truth für Käufer und Auditoren.',
    traction_note: '22 zahlende Projektentwickler, Partnerschaft mit zwei Big-4-Auditoren in Verhandlung.',
    team_note: 'CAC und Churn tracken wir noch nicht sauber — Fokus lag auf Produkt und Registry-Integrationen.',
    nums: { team_size: 10, founded_year: 2023, mrr_eur: 12000, burn_eur_per_month: 95000, runway_months: 8, growth_pct: 14, paying_customers: 22, net_new_mrr_eur: 1600, nrr_pct: 104, gross_margin_pct: 70, tam_eur: 8000000000, sam_eur: 700000000, ticket_eur: 2800000, valuation_eur: 11000000, total_raised_eur: 1300000, investor_count: 5, founder_pct: 72, investor_pct: 19, employees_pct: 9 },
    founders: [
      { name: 'Lea Hoffmann', role: 'CEO', prev_companies: ['South Pole'], prev_roles: ['Senior Carbon Consultant'], years: 9, education: 'Uni Freiburg, Umweltwissenschaften', strengths: ['Domain Expert'], linkedin: 'https://linkedin.com/in/leahoffmann' },
      { name: 'David Roth', role: 'CTO', prev_companies: ['SAP'], prev_roles: ['Development Architect'], years: 12, education: 'Uni Heidelberg, Informatik', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/davidroth' },
    ],
  },
  {
    // Flagged erwartet: Burn liegt bei 11x MRR (über der 10x-Plausibilitäts-Schwelle)
    company_name: 'Nordlicht Health', contact_name: 'Finja Carstens', contact_email: 'finja@nordlicht-health.de',
    pitch_deck_url: null, origin_country: 'DE',
    market_served: ['Germany'], stage: 'Pre-Seed', sector: 'HealthTech', sub_sector: 'Mental Health',
    description: 'Nordlicht ist die digitale Begleitung für pflegende Angehörige: strukturierte Selbsthilfe-Programme, Peer-Gruppen und Krisen-Hotline — als Selbstzahler-Abo und über Pflegekassen.',
    problem_solution: '4,9 Millionen pflegende Angehörige in Deutschland sind psychisch hochbelastet, aber therapeutisch unterversorgt. Nordlicht schließt die Lücke zwischen Wartezimmer und Nichtstun.',
    traction_note: '310 zahlende Abos zwei Monate nach Launch, erste Pflegekasse im Erstattungs-Pilot.',
    team_note: 'Gründerin kommt aus der Pflegewissenschaft, technischer Mitgründer von Ada Health.',
    nums: { team_size: 6, founded_year: 2025, mrr_eur: 2500, burn_eur_per_month: 27500, runway_months: 7, growth_pct: 19, paying_customers: 310, net_new_mrr_eur: 600, nrr_pct: 97, gross_margin_pct: 81, cac_eur: 28, logo_churn_pct: 5.5, revenue_churn_pct: 4.1, tam_eur: 2000000000, sam_eur: 300000000, ticket_eur: 600000, valuation_eur: 3500000, total_raised_eur: 100000, investor_count: 1, founder_pct: 95, investor_pct: 3, employees_pct: 2 },
    founders: [
      { name: 'Finja Carstens', role: 'CEO', prev_companies: ['Diakonie Hamburg'], prev_roles: ['Leitung Angehörigenberatung'], years: 8, education: 'Uni Bremen, Pflegewissenschaft', strengths: ['Domain Expert'], linkedin: 'https://linkedin.com/in/finjacarstens' },
      { name: 'Aron Becker', role: 'CTO', prev_companies: ['Ada Health'], prev_roles: ['Senior Software Engineer'], years: 9, education: 'HU Berlin, Informatik', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/aronbecker' },
    ],
  },
  {
    // Failed erwartet: Pre-Revenue (MRR 0) — kommt im echten Dealflow regelmäßig vor
    company_name: 'QubitWorks', contact_name: 'Dr. Stefan Mayrhofer', contact_email: 'stefan.mayrhofer@qubitworks.at',
    pitch_deck_url: 'https://docsend.com/view/qubitworks', origin_country: 'AT',
    market_served: ['EU'], stage: 'Pre-Seed', sector: 'DeepTech', sub_sector: 'Quantum Computing',
    description: 'QubitWorks entwickelt Fehlerkorrektur-Software für supraleitende Quantencomputer: unser Decoder läuft auf FPGA in Echtzeit und reduziert die logische Fehlerrate um eine Größenordnung.',
    problem_solution: 'Ohne Echtzeit-Fehlerkorrektur bleibt Quantum Computing im Labor. Wir liefern den Decoder als lizenzierbare IP für Hardware-Hersteller — noch pre-revenue, zwei LOIs unterschrieben.',
    traction_note: 'Zwei LOIs mit europäischen QC-Hardware-Herstellern, FFG-Förderung über 480k € bewilligt.',
    team_note: 'Spin-off der Uni Innsbruck, Gründerteam aus zwei Quantenphysikern.',
    nums: { team_size: 7, founded_year: 2025, mrr_eur: 0, burn_eur_per_month: 35000, runway_months: 18, tam_eur: 30000000000, sam_eur: 2000000000, ticket_eur: 1500000, valuation_eur: 6000000, total_raised_eur: 480000, investor_count: 1, founder_pct: 90, investor_pct: 5, employees_pct: 5 },
    founders: [
      { name: 'Dr. Stefan Mayrhofer', role: 'CEO', prev_companies: ['Uni Innsbruck'], prev_roles: ['Postdoc Quantenphysik'], years: 7, education: 'Uni Innsbruck, Dr. Physik', strengths: ['Technical', 'Domain Expert'], linkedin: 'https://linkedin.com/in/stefanmayrhofer' },
      { name: 'Dr. Petra Egger', role: 'CTO', prev_companies: ['IQM Quantum Computers'], prev_roles: ['Quantum Engineer'], years: 6, education: 'ETH Zürich, Dr. Physik', strengths: ['Technical'], linkedin: 'https://linkedin.com/in/petraegger' },
    ],
  },
];

async function fillAndSubmit(page, s) {
  await page.goto('/submit/?fund=apex');

  // Warten, bis der Fonds geladen ist — vorher lehnt handleSubmit() ab
  await expect(page.locator('#fundName')).not.toHaveText(/Lädt|Ungültig|nicht gefunden|^$/, { timeout: 15000 });
  await expect(page.locator('#submitBtn')).toBeEnabled();

  // Basisdaten
  await page.fill('#company_name', s.company_name);
  await page.fill('#contact_name', s.contact_name);
  await page.fill('#contact_email', s.contact_email);
  if (s.pitch_deck_url) await page.fill('#pitch_deck_url', s.pitch_deck_url);
  await page.fill('#description', s.description);
  if (s.problem_solution) await page.fill('#problem_solution', s.problem_solution);
  if (s.traction_note) await page.fill('#traction_note', s.traction_note);
  if (s.team_note) await page.fill('#team_note', s.team_note);

  await page.selectOption('#origin_country', s.origin_country);
  await page.selectOption('#stage', s.stage);
  await page.selectOption('#sector', s.sector);
  if (s.sub_sector) await page.selectOption('#sub_sector', s.sub_sector);

  for (const m of s.market_served) {
    await page.check(`#market_served_group input[value="${m}"]`);
  }

  // Zahlenfelder — Feld-IDs entsprechen den Keys
  for (const [id, v] of Object.entries(s.nums)) {
    await page.fill(`#${id}`, String(v));
  }

  // Founder-Cards (eine existiert nach dem Laden bereits)
  for (let i = 0; i < s.founders.length; i++) {
    if (i > 0) await page.click('#addFounderBtn');
    const f = s.founders[i];
    const card = page.locator('.founder-card').nth(i);
    await card.locator('.f-name').fill(f.name);
    await card.locator('.f-role').selectOption(f.role);
    await card.locator('.f-prev-companies').fill(f.prev_companies.join(', '));
    if (f.prev_roles?.length) await card.locator('.f-prev-roles').fill(f.prev_roles.join(', '));
    if (f.years != null) await card.locator('.f-years').fill(String(f.years));
    if (f.education) await card.locator('.f-education').fill(f.education);
    if (f.linkedin) await card.locator('.f-linkedin').fill(f.linkedin);
    for (const st of f.strengths || []) {
      await card.locator(`.f-strength[value="${st}"]`).check();
    }
    if (f.had_exit) {
      await card.locator('.f-had-exit').check();
      if (f.exit_detail) await card.locator('.f-exit-detail').fill(f.exit_detail);
    }
  }

  await page.check('#privacyConsent');

  const [resp] = await Promise.all([
    page.waitForResponse((r) => r.url().includes('/api/submit'), { timeout: 60000 }),
    page.click('#submitBtn'),
  ]);
  const body = await resp.text().catch(() => '<kein Body>');
  expect(resp.status(), `API-Antwort für ${s.company_name}: HTTP ${resp.status()} — ${body}`).toBe(200);
  await expect(page.locator('#successScreen')).toBeVisible({ timeout: 10000 });
}

for (let i = 0; i < SUBMISSIONS.length; i++) {
  const s = SUBMISSIONS[i];
  test(`Submission ${String(i + 1).padStart(2, '0')}/15 — ${s.company_name} (${s.stage}, ${s.sector})`, async ({ page }) => {
    await fillAndSubmit(page, s);
  });
}
