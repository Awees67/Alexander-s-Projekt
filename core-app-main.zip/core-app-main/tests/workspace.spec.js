// Workspace-Tests: prüft alle 7 Views als eingeloggter User auf Bugs.
// Läuft mit gespeichertem Login-State aus tests/auth.setup.js.

import { test, expect } from '@playwright/test';

const VIEWS = [
  { tab: '#topTabDashboard',   container: '#viewDashboard',   name: 'Dashboard'   },
  { tab: '#topTabHome',        container: '#cardGrid',        name: 'Übersicht'   },
  { tab: '#topTabSubmissions', container: '#viewSubmissions', name: 'Submissions' },
  { tab: '#topTabPipeline',    container: '#viewPipeline',    name: 'Pipeline'    },
  { tab: '#topTabCompare',     container: '#viewCompare',     name: 'Compare'     },
  { tab: '#topTabActivity',    container: '#viewActivity',    name: 'Activity'    },
  { tab: '#topTabInbox',       container: '#viewInbox',       name: 'Anfragen'    },
];

test.describe('Workspace', () => {
  test.use({ storageState: 'playwright/.auth/user.json' });

  test('Login funktioniert — App lädt, kein Redirect zu login.html', async ({ page }) => {
    const errors = [];
    page.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()); });

    await page.goto('/');
    await page.waitForTimeout(3000); // Warten bis Supabase-Session geprüft + Daten geladen

    // Soll auf / bleiben, nicht zu login.html weitergeleitet werden
    expect(page.url()).not.toContain('login.html');

    // Navigation muss sichtbar sein
    await expect(page.locator('#topTabDashboard')).toBeVisible();
    await expect(page.locator('#topTabSubmissions')).toBeVisible();
  });

  for (const view of VIEWS) {
    test(`View "${view.name}" lädt ohne Fehler`, async ({ page }) => {
      const jsErrors = [];
      page.on('pageerror', err => jsErrors.push(err.message));

      await page.goto('/');
      await page.waitForTimeout(2000);

      // Tab klicken
      await page.click(view.tab);
      await page.waitForTimeout(1500);

      // Container muss sichtbar sein und Inhalt haben
      const container = page.locator(view.container);
      await expect(container).toBeVisible({ timeout: 8000 });

      const content = await container.innerHTML();
      expect(content.trim().length).toBeGreaterThan(50); // kein leerer Container

      // Keine JavaScript-Crashes
      expect(jsErrors).toHaveLength(0);
    });
  }

  test('Submissions-Liste zeigt Einträge an', async ({ page }) => {
    await page.goto('/');
    await page.waitForTimeout(2000);
    await page.click('#topTabSubmissions');

    // Warten bis Mount gerendert ist (max 10s)
    await page.waitForSelector('#submissionsMount', { timeout: 10000 });

    // Entweder Zeilen ODER leerer-Zustand muss sichtbar sein
    const hasRows = await page.locator('#submissionsMount tr').count() > 0;
    const hasEmpty = await page.locator('#submissionsMount .empty').count() > 0;
    expect(hasRows || hasEmpty).toBe(true);
  });

  test('Suche filtert und "Filter löschen" setzt zurück', async ({ page }) => {
    await page.goto('/');
    await page.waitForTimeout(2000);

    await page.click('#topTabHome');
    await page.waitForTimeout(1000);

    // Basis-Anzahl merken
    const countBefore = await page.locator('#resultCount').textContent();

    // Suche tippen
    await page.locator('#searchInput').pressSequentially('TEST-', { delay: 50 });
    await page.waitForTimeout(500);
    await expect(page.locator('#searchInput')).toHaveValue('TEST-');

    // Filter löschen
    await page.click('#clearAllFiltersBtn');
    await page.waitForTimeout(500);

    // Suchfeld muss geleert sein
    await expect(page.locator('#searchInput')).toHaveValue('');

    // Ergebnis-Anzahl muss wieder dem Ausgangswert entsprechen
    const countAfter = await page.locator('#resultCount').textContent();
    expect(countAfter).toBe(countBefore);
  });
});
