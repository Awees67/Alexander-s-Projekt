# Test-Dokumentation — CORE App

Alle 40 automatisierten Playwright-Tests. Jeder Test öffnet Chrome selbstständig,
navigiert durch die App und prüft ob alles korrekt funktioniert.

Ausführen: `npm test`
Mit UI (live beobachten): `npm run test:ui`

---

## Übersicht

| Datei | Tests | Was wird getestet |
|---|---|---|
| `auth.setup.js` | 1 | Login einmalig, Session speichern |
| `submit-form.spec.js` | 10 | Submit-Formular für alle 10 Startups |
| `workspace.spec.js` | 10 | Alle 7 Views laden, Suche, Filter |
| `workspace-deep.spec.js` | 9 | Daten korrekt, Interaktionen funktionieren |
| `outreach.spec.js` | 10 | Anfragen-Flow komplett |
| `pipeline-view.spec.js` | 4 | Pipeline-View v2: Tabs, Zugewiesen, Zuletzt aktiv, Bulk-Bar |
| **Gesamt** | **44** | |

Hinweis: `pipeline-view.spec.js` loggt sich selbst ein (kein Setup-Projekt nötig).
Mit `PW_OFFLINE=1` werden alle Supabase-Calls aus `tests/fixtures/workspace-fixtures.json`
beantwortet — so läuft der Test auch ohne Netzzugriff auf Supabase.

---

## auth.setup.js — Login-Setup

Läuft einmal vor allen anderen Tests. Speichert die Session damit jeder
Workspace-Test automatisch eingeloggt startet.

### Test 1: Einloggen und Session speichern
**Was passiert:**
1. Ruft die Supabase Auth API direkt auf mit Email + Passwort
2. Öffnet die App im Browser
3. Injiziert den Session-Token in den localStorage
4. Speichert den Auth-State als Datei (`playwright/.auth/user.json`)

**Was wird geprüft:** Login-API gibt keinen Fehler zurück

**Warum wichtig:** Alle Workspace-Tests würden ohne diesen Setup-Schritt auf
die Login-Seite weitergeleitet werden und scheitern.

---

## submit-form.spec.js — Submit-Formular (10 Tests)

Testet ob das öffentliche Bewerbungsformular (`/submit/?fund=apex`) korrekt
funktioniert. Füllt alle Felder aus wie ein echter Founder und sendet ab.

Die 10 Startups kommen aus `scripts/fixtures.mjs` — dieselben die auch
der Seed-Script (`node scripts/seed-submissions.mjs`) verwendet.

### Test 1: Flowmatic GmbH (passed)
**Was passiert:** Füllt alle Felder für ein B2B SaaS Startup aus:
Beschreibung, Problem/Lösung, Traktion, Firmenname, Kontakt, Land (DE),
Stage (Seed), Sektor (B2B SaaS / Horizontal SaaS), Teamgröße (14),
Märkte (Germany, DACH), MRR (€85.000), Burn (€125.000), Runway (18 Monate),
Wachstum (18% MoM), NRR (118%), CAC/LTV, Churn, Ticket-Größe (€2,5M),
Cap-Table, 2 Founder-Profile mit LinkedIn, Vorjobs, Ausbildung und Stärken.
Dann: Klick auf "Absenden".

**Was wird geprüft:**
- Erfolgsseite (`#successScreen`) erscheint
- Fehlermeldung (`#errorMsg2`) bleibt verborgen

**Erwarteter Plausibility-Status:** passed (alle 11 Regeln grün)

### Test 2: Medvault AG (passed)
**Was passiert:** Wie Test 1, aber HealthTech / Clinical Workflow aus der Schweiz.
MRR €58.000, Burn €140.000, Runway 20 Monate. CEO ist Ärztin (Charité), CTO
kommt von Siemens Healthineers.

**Erwarteter Plausibility-Status:** passed

### Test 3: Carbonloop (flagged)
**Was passiert:** ClimateTech / Carbon Capture aus Österreich. MRR €8.000,
aber Burn €92.000 — das ist 11,5x MRR und verletzt die Burn/MRR-Regel (max 10x).

**Was wird geprüft:** Erfolgsseite erscheint (Submit funktioniert trotzdem)

**Erwarteter Plausibility-Status:** flagged (1 Soft-Fail: Burn > 10x MRR)

### Test 4: Legalyze GmbH (passed)
**Was passiert:** LegalTech / Vertical SaaS aus Deutschland. KI-Vertragsmanagement
für Kanzleien. MRR €42.000, NRR 116%, solide Metriken.

**Erwarteter Plausibility-Status:** passed

### Test 5: Tractify (flagged)
**Was passiert:** AgriTech / Precision Farming, Series A. CAC €45.000 aber
LTV nur €32.000 — LTV ist kleiner als CAC, verletzt die ltv_cac-Regel.

**Erwarteter Plausibility-Status:** flagged (1 Soft-Fail: LTV < CAC)

### Test 6: SwiftPay (failed)
**Was passiert:** FinTech / Embedded Finance aus Österreich. Runway nur 1 Monat —
verletzt die Runway-Regel (min. 2 Monate). Das ist ein Hard-Fail.

**Erwarteter Plausibility-Status:** failed (Hard-Fail: Runway < 2 Monate)

### Test 7: Skillbridge (passed)
**Was passiert:** Enterprise EdTech / B2B SaaS. 18 Enterprise-Kunden inkl.
3 DAX-Konzerne. NRR 114%, kein Logo-Churn in 18 Monaten. Alle Regeln grün.

**Erwarteter Plausibility-Status:** passed

### Test 8: Nexobot AG (flagged)
**Was passiert:** DeepTech / Robotics, Series A aus der Schweiz. ETH-Spin-off.
CAC €85.000 (langer Enterprise-Sales-Zyklus), LTV nur €60.000 — LTV < CAC.

**Erwarteter Plausibility-Status:** flagged (1 Soft-Fail: LTV < CAC)

### Test 9: Growthly (flagged)
**Was passiert:** AI / Applied AI aus Deutschland. Burn €155.000 bei MRR €10.000
— das ist 15,5x MRR (wegen GPU-Cluster für KI-Training).

**Erwarteter Plausibility-Status:** flagged (1 Soft-Fail: Burn > 10x MRR)

### Test 10: Buildwise (passed)
**Was passiert:** PropTech / Construction Tech aus Österreich. 28 Kunden,
NRR 110%, Österreich-Marktführer in der Nische. Alle Regeln grün.

**Erwarteter Plausibility-Status:** passed

---

## workspace.spec.js — Workspace Views (10 Tests)

Testet ob alle Bereiche der App für einen eingeloggten User korrekt laden.
Nutzt den gespeicherten Login aus `auth.setup.js`.

### Test 1: Login funktioniert — kein Redirect zu login.html
**Was passiert:** Öffnet die App, wartet 3 Sekunden.

**Was wird geprüft:**
- URL enthält nicht "login.html" (kein ungewollter Redirect)
- Navigation-Tabs (`#topTabDashboard`, `#topTabSubmissions`) sind sichtbar

**Warum wichtig:** Grundlegendster Test — wenn dieser fehlschlägt, funktioniert
der Login nicht und alle anderen Tests sind sinnlos.

### Tests 2–8: View "Dashboard / Übersicht / Submissions / Pipeline / Compare / Activity / Anfragen" lädt ohne Fehler
**Was passiert (für jeden View gleich):**
1. Öffnet die App
2. Klickt auf den entsprechenden Tab
3. Wartet 1,5 Sekunden

**Was wird geprüft:**
- Der Container des Views ist sichtbar (z.B. `#viewDashboard`, `#cardGrid`)
- Der Container hat Inhalt (mehr als 50 Zeichen HTML)
- Keine JavaScript-Fehler im Browser (keine `pageerror`-Events)

**Warum wichtig:** Deckt auf wenn ein View abstürzt, leer bleibt oder einen
JS-Fehler wirft — auch wenn er äußerlich normal aussieht.

### Test 9: Submissions-Liste zeigt Einträge an
**Was passiert:** Klickt auf Submissions-Tab, wartet bis `#submissionsMount` geladen ist.

**Was wird geprüft:** Entweder Tabellenzeilen (`tr`) ODER ein Leer-Zustand
(`.empty`) ist sichtbar — der View hängt nie in einem leeren Zustand fest.

### Test 10: Suche filtert und "Filter löschen" setzt zurück
**Was passiert:**
1. Öffnet Übersicht, merkt sich die angezeigte Anzahl Startups
2. Tippt "TEST-" in das Suchfeld
3. Klickt "Filter löschen"

**Was wird geprüft:**
- Suchfeld hat nach dem Tippen den Wert "TEST-"
- Nach "Filter löschen": Suchfeld ist leer
- Anzahl Startups ist wieder identisch zur Ausgangszahl

**Welchen Bug das gefunden hat:** Vor dem Fix zeigte die App nach "Filter löschen"
0 Ergebnisse weil das Suchfeld nicht geleert wurde, aber der Filter noch aktiv war.

---

## workspace-deep.spec.js — Daten & Interaktionen (9 Tests)

Geht tiefer als workspace.spec.js: prüft nicht nur ob Views laden, sondern
ob die angezeigten Daten korrekt sind und Interaktionen wie erwartet funktionieren.

### STUFE 1 — Daten stimmen (5 Tests)

#### Test 1: Dashboard — alle KPI-Kacheln zeigen Zahlen
**Was passiert:** Öffnet Dashboard, liest alle `.dbv2-kpi-val` Elemente aus.

**Was wird geprüft:**
- Mindestens 4 KPI-Kacheln sind sichtbar
- Jede Kachel enthält einen nicht-leeren Text (keine leeren Platzhalter)

**Warum wichtig:** Deckt auf wenn die Supabase-Daten nicht ankommen und
die KPIs leer bleiben.

#### Test 2: Übersicht — Karten haben Score, MRR und Tags
**Was passiert:** Öffnet die Übersicht, liest die erste Startup-Karte aus.

**Was wird geprüft:**
- Mindestens eine Startup-Karte ist sichtbar
- Score-Ring zeigt eine Zahl (Regex: nur Ziffern)
- Mindestens ein KPI-Wert (MRR, Runway etc.) ist sichtbar
- Mindestens 2 Tags (Land, Stage, Sektor) sind sichtbar

#### Test 3: Übersicht — Sortierung ändert die Reihenfolge
**Was passiert:** Wechselt Sortierung auf "Runway hoch → niedrig",
dann auf "MRR hoch → niedrig".

**Was wird geprüft:** Nach der Sortierung sind die Karten noch sichtbar
(kein Absturz durch die Sortier-Logik).

#### Test 4: Submissions — Tabellenzeilen haben Name, Stage und Plausibility-Badge
**Was passiert:** Öffnet Submissions, liest die erste Tabellenzeile aus.

**Was wird geprüft:**
- Startup-Name (`.subs2-name`) ist sichtbar und nicht leer
- Stage (`.subs2-stage`) ist sichtbar und nicht leer
- Plausibility-Badge (`.subs2-plaus-label`) zeigt "PASSED", "FLAGGED" oder "FAILED"
- Score (`.subs2-score-val`) ist eine Zahl

#### Test 5: Submissions — Filter (passed/flagged/failed) funktioniert
**Was passiert:** Wählt im Filter "Passed" aus.

**Was wird geprüft:**
- Alle sichtbaren Plausibility-Badges zeigen "PASSED" (kein anderer Status
  durchsickert)
- Nach Zurücksetzen auf "Alle" ist der Container wieder sichtbar

### STUFE 2 — Interaktionen (4 Tests)

#### Test 6: Startup-Karte anklicken öffnet Detail-Modal mit Inhalt
**Was passiert:** Klickt auf die Beschreibung (`.desc`) der ersten Startup-Karte.

**Was wird geprüft:**
- Backdrop (`#modalBackdrop`) wird sichtbar
- Modal-Inhalt (`.modal`) ist nicht leer — wartet bis async-Daten geladen sind
  (das Modal lädt Notes via Supabase bevor es befüllt wird)
- Modal-HTML hat mehr als 100 Zeichen Inhalt

**Technischer Hintergrund:** Das Modal ist async — es zeigt den Backdrop sofort,
lädt dann Notes via `await getNotesForDeal()` und befüllt erst danach den Inhalt.
Der Test wartet explizit darauf mit `not.toBeEmpty({ timeout: 8000 })`.

#### Test 7: Detail-Modal schließen via Escape
**Was passiert:** Öffnet Modal, drückt die Escape-Taste.

**Was wird geprüft:** Backdrop ist danach ausgeblendet.

#### Test 8: Detail-Modal schließen via X-Button
**Was passiert:** Öffnet Modal, klickt den X-Button (`#modalClose`).

**Was wird geprüft:** Backdrop ist danach ausgeblendet.

**Welchen Bug das gefunden hat:** Der X-Button war im HTML vorhanden (nach Fix),
aber der Event-Handler wurde beim App-Start registriert bevor der Button im DOM
existierte. Fix: Handler wird jetzt direkt nach `modal.innerHTML` gesetzt.

#### Test 9: Modal zeigt Navigation-Buttons
**Was passiert:** Öffnet Modal, prüft die Topbar-Buttons.

**Was wird geprüft:**
- "← Zurück" Button (`#dvPrevBtn`) ist sichtbar
- "Weiter →" Button (`#dvNextBtn`) ist sichtbar
- "Pipeline" Button (`#dvPipeBtn`) ist sichtbar

---

## outreach.spec.js — Anfragen-Flow (10 Tests)

Testet den kompletten Weg von Submissions → Detail-Modal → Send-Modal →
Anfragen-View. Wichtig vor der Einführung echter E-Mail-Funktionalität um
sicherzustellen dass die bestehende Logik stabil ist.

### Hilfs-Funktion: openFirstSubmissionModal
Wird von fast allen Tests wiederverwendet:
1. Öffnet App → Submissions-Tab
2. Klickt auf die erste Tabellenzeile (`.subs2-name`)
3. Wartet bis Detail-Modal geladen ist
4. Gibt den Firmennamen zurück

### Test 1: Send-Modal öffnet sich mit Startup-Name und E-Mail
**Was passiert:**
1. Öffnet Detail-Modal eines Startups
2. Prüft "Anfrage senden" Button
3. Klickt "Anfrage senden"

**Was wird geprüft:**
- "Anfrage senden" Button ist sichtbar und aktiv (nicht disabled)
- Nach dem Klick: Detail-Modal schließt sich
- Send-Modal (`#otSendBackdrop`) öffnet sich
- Chip-Name (`#otSendChipName`) zeigt exakt den Firmennamen
- Empfänger-Adresse (`#otSendToAddr`) ist befüllt und enthält "@"
- Betreff (`#otSendSubject`) ist vorausgefüllt (mehr als 5 Zeichen)
- Nachricht (`#otSendBody`) ist vorausgefüllt (mehr als 20 Zeichen)

### Test 2: Template-Wechsel ändert Betreff und Nachricht
**Was passiert:** Wechselt zwischen den 3 Templates:
"Interesse bestätigen" → "Screening-Anfrage" → "Blank" → zurück zu "Interesse bestätigen"

**Was wird geprüft:**
- Jeder Template-Wechsel ändert den Body-Text (kein Template ist identisch)
- Zurück zu "Interesse bestätigen" gibt exakt denselben Text wie zu Beginn

### Test 3: Senden ohne Nachricht — Toast, Modal bleibt offen
**Was passiert:** Leert das Nachrichtenfeld (`#otSendBody`), klickt "E-Mail senden".

**Was wird geprüft:**
- Send-Modal bleibt geöffnet (kein ungewolltes Schließen)
- Toast-Meldung erscheint (Pflichtfeld-Hinweis)

### Test 4: Senden ohne Betreff — Toast, Modal bleibt offen
**Was passiert:** Leert den Betreff (`#otSendSubject`), klickt "E-Mail senden".

**Was wird geprüft:**
- Send-Modal bleibt geöffnet
- Toast-Meldung erscheint

### Test 5: Bearbeiter-Name wird in Nachricht eingesetzt
**Was passiert:** Tippt "Max Mustermann" in das Bearbeiter-Feld (`#otSendBearbeiter`).

**Was wird geprüft:** Der Name "Max Mustermann" erscheint automatisch im
Nachrichtentext (dynamische Template-Interpolation funktioniert).

### Test 6: Anfrage senden → Toast + Eintrag in Anfragen-View
**Was passiert:**
1. Öffnet Send-Modal, setzt Bearbeiter auf "Test Analyst"
2. Klickt "E-Mail senden"

**Was wird geprüft:**
- Send-Modal schließt sich
- Toast "Anfrage gesendet" erscheint
- In der Anfragen-View (`#topTabInbox`) ist der Firmenname sichtbar

**Was das abdeckt:** Kompletter End-to-End-Flow — von Submission bis Eintrag
in der Anfragen-Liste.

### Test 7: Nach Senden ist Button deaktiviert
**Was passiert:** Sendet eine Anfrage, öffnet dann dasselbe Startup nochmal.

**Was wird geprüft:**
- "Anfrage senden" Button zeigt "✓ Angefragt"
- Button ist deaktiviert (kein Doppel-Senden möglich)

**Was das abdeckt:** Duplikat-Schutz — ein Startup kann nicht zweimal angefragt werden.

### Test 8: X-Button schließt Send-Modal
**Was passiert:** Klickt den X-Button (`#otSendCloseBtn`).

**Was wird geprüft:** Send-Modal ist danach ausgeblendet.

### Test 9: Abbrechen-Button schließt Send-Modal
**Was passiert:** Klickt "Abbrechen" (`#otSendCancelBtn`).

**Was wird geprüft:** Send-Modal ist danach ausgeblendet.

### Test 10: Klick auf Backdrop schließt Send-Modal
**Was passiert:** Klickt auf den äußeren Rand des Backdrops (Position 5,5).

**Was wird geprüft:** Send-Modal ist danach ausgeblendet.

---

## Gefundene und behobene Bugs

Durch die Tests wurden folgende echte App-Bugs entdeckt:

| Bug | Gefunden durch | Fix |
|---|---|---|
| `ltv_cac_ratio` wurde nicht an Plausibility Check übergeben → jede Submission war mindestens "flagged" | seed-submissions.mjs (TEST-Alpha war flagged statt passed) | `api/submit.js`: `ltv_cac_ratio` zur `computePlausibility()` übergeben |
| "Filter löschen" leerte nicht das Suchfeld → 0 Ergebnisse nach Reset | workspace.spec.js (Suche-Test) | `filters.js`: `searchInput.value = ""` in `resetFiltersAll()` ergänzt |
| X-Button (`#modalClose`) im Modal fehlte im DOM | workspace-deep.spec.js (Modal-Tests) | `renderers-modals.js`: Button zur Topbar hinzugefügt |
| X-Button hatte keinen Event-Handler (registriert beim App-Start, bevor Button existiert) | outreach.spec.js (X-Button Test) | `renderers-modals.js`: `closeBtn.onclick = closeModal` direkt nach `modal.innerHTML` |

---

## Wie man einen neuen Test schreibt

```js
import { test, expect } from '@playwright/test';

test.describe('Meine Tests', () => {
  test.use({ storageState: 'playwright/.auth/user.json' }); // eingeloggt

  test('Mein Test', async ({ page }) => {
    await page.goto('/');
    await page.click('#topTabPipeline');
    await expect(page.locator('#viewPipeline')).toBeVisible();
  });
});
```

Neue Test-Datei in `tests/` ablegen und in `playwright.config.js` registrieren.
