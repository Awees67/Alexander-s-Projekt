// Pipeline-View v2 (Design-Mockup Juni 2026)
// Prüft: Kopf, Stage-Tabs mit Zählern, Tabellenspalten inkl. ZUGEWIESEN
// (Fund-Mitarbeiter + Position) und ZULETZT AKTIV (Zeit + "Person · Aktion"),
// Bulk-Bar, Push-to-CRM nur bei Hot Deals, Synced-Sperre.
//
// Zwei Modi:
//  - Standard: echter Login gegen Supabase (wie auth.setup.js)
//  - PW_OFFLINE=1: alle Supabase-Calls werden mit tests/fixtures/
//    workspace-fixtures.json beantwortet (für Umgebungen ohne Netz)

import { test, expect } from '@playwright/test';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const SUPABASE_URL = 'https://ggfjgzjevyemwbclvfpp.supabase.co';
const SUPABASE_KEY = 'sb_publishable_27NELp2B1onC07knBjxKVQ_n5A_k9ox';
const TEST_EMAIL = 'test@core-app.dev';
const TEST_PASSWORD = 'TestPasswort123!';
const OFFLINE = process.env.PW_OFFLINE === '1';
const __dir = dirname(fileURLToPath(import.meta.url));

function pgrstFulfill(route, rows, fallbackSingle) {
  const accept = route.request().headers()['accept'] || '';
  const single = accept.includes('vnd.pgrst.object') || fallbackSingle;
  const body = single ? (Array.isArray(rows) ? rows[0] : rows) : (Array.isArray(rows) ? rows : [rows]);
  return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body ?? (single ? {} : [])) });
}

async function setupOffline(page) {
  const fx = JSON.parse(readFileSync(join(__dir, 'fixtures', 'workspace-fixtures.json'), 'utf8'));
  const supabaseJs = readFileSync(join(__dir, '..', 'node_modules', '@supabase', 'supabase-js', 'dist', 'umd', 'supabase.js'), 'utf8');
  const user = { id: fx.user_id, email: TEST_EMAIL, aud: 'authenticated', role: 'authenticated' };
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/supabase-js**', r =>
    r.fulfill({ status: 200, contentType: 'application/javascript', body: supabaseJs }));
  await page.route('**/auth/v1/user**', r =>
    r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(user) }));
  await page.route('**/auth/v1/token**', r =>
    r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({
      access_token: 'offline', refresh_token: 'offline', token_type: 'bearer', expires_in: 3600, user }) }));
  // Achtung: Playwright matcht zuletzt registrierte Routen zuerst —
  // Catch-all daher VOR den spezifischen Routen registrieren.
  await page.route('**/rest/v1/**', r => pgrstFulfill(r, []));
  await page.route('**/rest/v1/fund_users**', r => pgrstFulfill(r, fx.fund_users));
  await page.route('**/rest/v1/funds?**', r => pgrstFulfill(r, [fx.fund]));
  await page.route('**/rest/v1/fund_members**', r => pgrstFulfill(r, fx.fund_members));
  await page.route('**/rest/v1/submissions**', r => pgrstFulfill(r, fx.submissions));
  await page.route('**/rest/v1/pipeline**', r => pgrstFulfill(r, fx.pipeline));
  await page.addInitScript(({ userId }) => {
    localStorage.setItem('sb-ggfjgzjevyemwbclvfpp-auth-token', JSON.stringify({
      access_token: 'offline', refresh_token: 'offline', token_type: 'bearer',
      expires_in: 3600, expires_at: Math.floor(Date.now() / 1000) + 3600,
      user: { id: userId, email: 'test@core-app.dev', aud: 'authenticated', role: 'authenticated' },
    }));
  }, { userId: fx.user_id });
}

async function setupOnline(page) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_KEY },
    body: JSON.stringify({ email: TEST_EMAIL, password: TEST_PASSWORD }),
  });
  if (!res.ok) throw new Error(`Login fehlgeschlagen: ${await res.text()}`);
  const session = await res.json();
  await page.addInitScript(({ s }) => {
    localStorage.setItem('sb-ggfjgzjevyemwbclvfpp-auth-token', JSON.stringify({
      access_token: s.access_token, refresh_token: s.refresh_token, token_type: 'bearer',
      expires_in: s.expires_in, expires_at: Math.floor(Date.now() / 1000) + s.expires_in,
      user: s.user,
    }));
  }, { s: session });
}

test.describe('Pipeline-View v2', () => {
  test.beforeEach(async ({ page }) => {
    if (OFFLINE) await setupOffline(page); else await setupOnline(page);
    await page.goto('/');
    // Warten bis App-Init durch ist (Fund geladen + Startansicht gerendert).
    await page.waitForFunction(() => Array.isArray(window.startups) && window.fundName, null, { timeout: 15_000 });
    // Klick wiederholen, falls die Nav-Listener beim ersten Versuch noch nicht gebunden sind.
    const rendered = page.locator('#viewPipeline .pipe3-wrap, #viewPipeline .empty').first();
    for (let i = 0; i < 5; i++) {
      await page.click('#topTabPipeline');
      try { await rendered.waitFor({ state: 'visible', timeout: 3_000 }); break; } catch (_) {}
    }
    await expect(rendered).toBeVisible({ timeout: 10_000 });
  });

  test('Kopf, Tabs und v2-Dark sind aktiv', async ({ page }) => {
    await expect(page.locator('body')).toHaveClass(/v2-dark/);
    await expect(page.locator('#viewPipeline .panelhead h2')).toHaveText('Pipeline');
    await expect(page.locator('#viewPipeline .panelhead .note')).toContainText(/\d+ Startups?/);
    const tabs = page.locator('#viewPipeline .pipe3-tab');
    await expect(tabs).toHaveCount(7); // Alle + 6 Stages
    await expect(tabs.nth(0)).toContainText('Alle');
    await expect(tabs.nth(2)).toContainText('Contacted');
  });

  test('Spalten ZUGEWIESEN und ZULETZT AKTIV zeigen Mitarbeiter mit Position und Aktion', async ({ page }) => {
    const headers = page.locator('#viewPipeline thead th');
    await expect(headers.nth(6)).toHaveText('ZUGEWIESEN');
    await expect(headers.nth(7)).toHaveText('ZULETZT AKTIV');
    const firstAssignee = page.locator('#viewPipeline .pipe3-assignee').first();
    await expect(firstAssignee).not.toHaveText('—');
    await expect(page.locator('#viewPipeline .pipe3-assignee-role').first()).toHaveText(/Partner|Analyst/);
    await expect(page.locator('#viewPipeline .pipe3-act-time').first()).toHaveText(/Heute|Gestern|\d{2}\.\d{2}\.\d{4}/);
    await expect(page.locator('#viewPipeline .pipe3-act-detail').first()).toContainText('·');
  });

  test('Stage-Tab filtert, Push-to-CRM in jeder aktiven Zeile, Synced gesperrt', async ({ page }) => {
    await page.click('#viewPipeline .pipe3-tab:has-text("In Review")');
    const rows = page.locator('#viewPipeline tbody tr');
    const n = await rows.count();
    expect(n).toBeGreaterThan(0);
    await expect(page.locator('#viewPipeline .pipe3-crm')).toHaveCount(n);
    // Stage-Dropdown bietet "Synced" nicht an (CRM nur über den Button)
    expect(await page.locator('#viewPipeline .pipe3-stagesel option[value="Synced"]').count()).toBe(0);
    await page.click('#viewPipeline .pipe3-tab:has-text("Synced")');
    if (await page.locator('#viewPipeline tbody tr').count() > 0) {
      await expect(page.locator('#viewPipeline .pipe3-incrm').first()).toHaveText('✓ Im CRM');
      await expect(page.locator('#viewPipeline tbody input.bulk-check')).toHaveCount(0);
      await expect(page.locator('#viewPipeline .pipe3-crm')).toHaveCount(0);
    }
  });

  test('Auswahl öffnet Bulk-Bar mit Stage ändern / Entfernen / Auswahl aufheben', async ({ page }) => {
    await page.locator('#viewPipeline tbody input.bulk-check').first().check();
    await expect(page.locator('#viewPipeline .pipe3-bulk-count')).toContainText('1 ausgewählt');
    await expect(page.locator('#pipeBulkStatusSel')).toBeVisible();
    await expect(page.locator('#pipeBulkRemove')).toHaveText('Entfernen');
    await page.click('#pipeBulkDeselect');
    await expect(page.locator('#viewPipeline .pipe3-bulkbar')).toHaveCount(0);
  });
});
