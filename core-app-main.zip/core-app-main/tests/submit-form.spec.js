// Playwright UI-Test: öffnet /submit?fund=apex, füllt alle Pflichtfelder,
// klickt Submit und prüft dass die Success-Screen erscheint.
// Nutzt dieselben Fixtures wie scripts/seed-submissions.mjs.

import { test, expect } from '@playwright/test';
import { fixtures } from '../scripts/fixtures.mjs';

const FUND_SLUG = process.env.FUND_SLUG || 'apex';

for (const fx of fixtures) {
  test(`submit ${fx.label}`, async ({ page }) => {
    const d = fx.data;

    await page.goto(`/submit/?fund=${FUND_SLUG}`);
    await expect(page.locator('#fundName')).not.toHaveText('', { timeout: 10_000 });
    // Sicherstellen dass fund_id geladen ist (nicht nur der Name)
    await page.waitForFunction(() => typeof currentFund !== 'undefined' && currentFund?.id != null, { timeout: 10_000 }).catch(() => {});

    // Pitch Deck URL
    if (d.pitch_deck_url) await page.fill('#pitch_deck_url', d.pitch_deck_url);

    // Basis
    await page.fill('#description', d.description);
    if (d.problem_solution) await page.fill('#problem_solution', d.problem_solution);
    if (d.traction_note) await page.fill('#traction_note', d.traction_note);
    await page.fill('#company_name', d.company_name);
    await page.fill('#contact_name', d.contact_name);
    await page.fill('#contact_email', d.contact_email);
    await page.selectOption('#origin_country', d.origin_country);
    await page.selectOption('#stage', d.stage);
    await page.selectOption('#sector', d.sector);
    if (d.sub_sector) await page.selectOption('#sub_sector', d.sub_sector);
    await page.fill('#team_size', String(d.team_size));
    if (d.founded_year != null) await page.fill('#founded_year', String(d.founded_year));

    for (const m of d.market_served) {
      await page.locator(`#market_served_group input[value="${m}"]`).check();
    }

    // Revenue & Unit Economics
    await page.fill('#mrr_eur', String(d.mrr_eur));
    await page.fill('#burn_eur_per_month', String(d.burn_eur_per_month));
    await page.fill('#runway_months', String(d.runway_months));
    if (d.growth_pct != null) await page.fill('#growth_pct', String(d.growth_pct));
    if (d.net_new_mrr_eur != null) await page.fill('#net_new_mrr_eur', String(d.net_new_mrr_eur));
    if (d.nrr_pct != null) await page.fill('#nrr_pct', String(d.nrr_pct));
    if (d.gross_margin_pct != null) await page.fill('#gross_margin_pct', String(d.gross_margin_pct));
    if (d.paying_customers != null) await page.fill('#paying_customers', String(d.paying_customers));
    if (d.cac_eur != null) await page.fill('#cac_eur', String(d.cac_eur));
    if (d.logo_churn_pct != null) await page.fill('#logo_churn_pct', String(d.logo_churn_pct));
    if (d.revenue_churn_pct != null) await page.fill('#revenue_churn_pct', String(d.revenue_churn_pct));

    // Marktgröße & Bewertung
    if (d.tam_eur != null) await page.fill('#tam_eur', String(d.tam_eur));
    if (d.sam_eur != null) await page.fill('#sam_eur', String(d.sam_eur));
    if (d.valuation_eur != null) await page.fill('#valuation_eur', String(d.valuation_eur));
    if (d.total_raised_eur != null) await page.fill('#total_raised_eur', String(d.total_raised_eur));
    if (d.investor_count != null) await page.fill('#investor_count', String(d.investor_count));

    // Runde
    await page.fill('#ticket_eur', String(d.ticket_eur));
    if (d.founder_pct != null) await page.fill('#founder_pct', String(d.founder_pct));
    if (d.investor_pct != null) await page.fill('#investor_pct', String(d.investor_pct));
    if (d.employees_pct != null) await page.fill('#employees_pct', String(d.employees_pct));
    if (d.team_note) await page.fill('#team_note', d.team_note);

    // Founders — Form startet mit 1 leerer Karte; bei mehr → addFounder() klicken
    for (let i = 1; i < d.founders.length; i++) {
      await page.click('#addFounderBtn');
    }
    const cards = page.locator('.founder-card');
    for (let i = 0; i < d.founders.length; i++) {
      const f = d.founders[i];
      const card = cards.nth(i);
      await card.locator('.f-name').fill(f.name);
      await card.locator('.f-role').selectOption(f.role);
      if (f.linkedin_url) await card.locator('.f-linkedin').fill(f.linkedin_url);
      await card.locator('.f-prev-companies').fill(f.prev_companies.join(', '));
      if (f.prev_roles?.length) await card.locator('.f-prev-roles').fill(f.prev_roles.join(', '));
      if (f.years_experience != null) await card.locator('.f-years').fill(String(f.years_experience));
      if (f.education) await card.locator('.f-education').fill(f.education);
      for (const s of f.strengths || []) {
        await card.locator(`.f-strength[value="${s}"]`).check();
      }
      if (f.had_exit) {
        await card.locator('.f-had-exit').check();
        if (f.exit_detail) await card.locator('.f-exit-detail').fill(f.exit_detail);
      }
    }

    await page.click('#submitBtn');

    // Success-Screen erscheint (kein Error)
    await expect(page.locator('#successScreen')).toBeVisible({ timeout: 15_000 });
    await expect(page.locator('#errorMsg2')).toBeHidden();
  });
}
