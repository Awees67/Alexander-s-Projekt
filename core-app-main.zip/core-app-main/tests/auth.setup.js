// Einmaliges Login-Setup für Playwright.
// Holt sich einen echten Supabase-Session-Token via Email+Passwort (REST API),
// injiziert ihn in den Browser und speichert den Auth-State in playwright/.auth/user.json.
// Alle anderen Tests laden diesen State und sind damit automatisch eingeloggt.

import { test as setup } from '@playwright/test';

const SUPABASE_URL = 'https://ggfjgzjevyemwbclvfpp.supabase.co';
const SUPABASE_KEY = 'sb_publishable_27NELp2B1onC07knBjxKVQ_n5A_k9ox';
const TEST_EMAIL   = 'test@core-app.dev';
const TEST_PASSWORD = 'TestPasswort123!';
const AUTH_FILE    = 'playwright/.auth/user.json';

setup('Einloggen und Session speichern', async ({ page }) => {
  // Session via Supabase REST API holen (kein Formular, direkt API)
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_KEY,
    },
    body: JSON.stringify({ email: TEST_EMAIL, password: TEST_PASSWORD }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Login fehlgeschlagen: ${err}`);
  }

  const session = await res.json();

  // App öffnen und Session in localStorage injizieren
  await page.goto('/');

  const storageKey = `sb-ggfjgzjevyemwbclvfpp-auth-token`;
  await page.evaluate(({ key, value }) => {
    localStorage.setItem(key, JSON.stringify(value));
    // Scoring ist ab Werk deaktiviert (custom-index.js, Datenschutzerklärung §6.1)
    // — die Tests simulieren einen Fonds, der das Regelwerk aktiviert hat.
    // Der Migrations-Marker verhindert, dass die einmalige Opt-in-Migration
    // den Schalter beim App-Start wieder zurücksetzt.
    localStorage.setItem('core_custom_rules_v6_optin_migrated', 'true');
    localStorage.setItem('core_custom_rules_v6_enabled', 'true');
  }, {
    key: storageKey,
    value: {
      access_token:  session.access_token,
      refresh_token: session.refresh_token,
      expires_at:    Math.floor(Date.now() / 1000) + session.expires_in,
      expires_in:    session.expires_in,
      token_type:    'bearer',
      user:          session.user,
    }
  });

  // Session-State speichern
  await page.context().storageState({ path: AUTH_FILE });
});
