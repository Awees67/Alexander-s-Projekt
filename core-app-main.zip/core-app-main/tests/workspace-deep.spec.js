// Tiefe Workspace-Tests: Stufe 1 (Daten stimmen) + Stufe 2 (Interaktionen).
// Läuft mit gespeichertem Login-State aus tests/auth.setup.js.

import { test, expect } from '@playwright/test';

// Navigiert zur Übersicht und stellt sicher, dass mindestens eine Startup-Karte sichtbar ist.
// Falls keine Karten da sind (noch keine accepted-Submissions), wird die erste pending
// Submission akzeptiert — danach ist die Karte in der Übersicht verfügbar.
async function navigateToCardsView(page) {
  await page.goto('/');
  await page.waitForTimeout(2000);
  await page.click('#topTabHome');
  await page.waitForTimeout(1500);

  const cardCount = await page.locator('.startup-card').count();
  if (cardCount === 0) {
    await page.click('#topTabSubmissions');
    await page.waitForSelector('#submissionsMount', { timeout: 10000 });
    await page.waitForTimeout(1000);
    const acceptBtn = page.locator('.subs2-btn-accept').first();
    if (await acceptBtn.count() > 0) {
      await acceptBtn.click();
      await page.waitForTimeout(2000);
    }
    await page.click('#topTabHome');
    await page.waitForTimeout(1500);
  }
}

test.describe('Stufe 1 — Daten stimmen', () => {
  test.use({ storageState: 'playwright/.auth/user.json' });

  // ─── DASHBOARD ────────────────────────────────────────────────────────────

  test('Dashboard: alle 5 KPI-Kacheln zeigen Zahlen', async ({ page }) => {
    await page.goto('/');
    await page.waitForTimeout(2000);
    await page.click('#topTabDashboard');
    await page.waitForTimeout(1500);

    const kpiVals = page.locator('.dbv2-kpi-val');
    await expect(kpiVals.first()).toBeVisible({ timeout: 8000 });

    const count = await kpiVals.count();
    expect(count).toBeGreaterThanOrEqual(4); // Gesamt, Submissions, Pipeline, Score

    // Jede Kachel muss eine Zahl enthalten (nicht leer)
    for (let i = 0; i < count; i++) {
      const text = await kpiVals.nth(i).textContent();
      expect(text.trim()).not.toBe('');
    }
  });

  // ─── CARDS (ÜBERSICHT) ────────────────────────────────────────────────────

  test('Übersicht: Karten haben Score, MRR und Tags', async ({ page }) => {
    await navigateToCardsView(page);

    // Mindestens eine Startup-Karte muss da sein
    const cards = page.locator('.startup-card');
    await expect(cards.first()).toBeVisible({ timeout: 8000 });

    const firstCard = cards.first();

    // Score-Ring mit Zahl
    await expect(firstCard.locator('.score-num')).toBeVisible();
    const score = await firstCard.locator('.score-num').textContent();
    expect(score.trim()).toMatch(/^\d+$/); // muss eine Zahl sein

    // KPI-Werte (MRR, Runway etc.)
    await expect(firstCard.locator('.kpi-val').first()).toBeVisible();

    // Tags (Land, Stage, Sektor)
    await expect(firstCard.locator('.tag').first()).toBeVisible();
    const tagCount = await firstCard.locator('.tag').count();
    expect(tagCount).toBeGreaterThanOrEqual(2);
  });

  test('Übersicht: Sortierung ändert die Reihenfolge', async ({ page }) => {
    await navigateToCardsView(page);

    // Ersten Score vor Sortierung merken
    const firstScoreBefore = await page.locator('.startup-card .score-num').first().textContent();

    // Auf "Runway hoch → niedrig" umstellen
    await page.selectOption('#sortSelect', 'runway_desc');
    await page.waitForTimeout(500);

    // Auf "MRR hoch → niedrig" zurückstellen
    await page.selectOption('#sortSelect', 'mrr_desc');
    await page.waitForTimeout(500);

    // Karten müssen noch da sein
    await expect(page.locator('.startup-card').first()).toBeVisible();
  });

  // ─── SUBMISSIONS ──────────────────────────────────────────────────────────

  test('Submissions: Tabellenzeilen haben Name, Stage und Plausibility-Badge', async ({ page }) => {
    await page.goto('/');
    await page.waitForTimeout(2000);
    await page.click('#topTabSubmissions');
    await page.waitForSelector('#submissionsMount', { timeout: 10000 });

    // Wenn keine Submissions da: leerer Zustand ist ok
    const isEmpty = await page.locator('#submissionsMount .empty').count() > 0;
    if (isEmpty) {
      test.skip(true, 'Keine Submissions in der DB — leerer Zustand ok');
      return;
    }

    const firstRow = page.locator('#submissionsMount tbody tr').first();
    await expect(firstRow).toBeVisible({ timeout: 8000 });

    // Company-Name Button
    await expect(firstRow.locator('.subs2-name')).toBeVisible();
    const name = await firstRow.locator('.subs2-name').textContent();
    expect(name.trim().length).toBeGreaterThan(0);

    // Stage
    await expect(firstRow.locator('.subs2-stage')).toBeVisible();
    const stage = await firstRow.locator('.subs2-stage').textContent();
    expect(stage.trim().length).toBeGreaterThan(0);

    // Plausibility Badge (passed / flagged / failed)
    await expect(firstRow.locator('.subs2-plaus-label')).toBeVisible();
    const badge = await firstRow.locator('.subs2-plaus-label').textContent();
    expect(['PASSED', 'FLAGGED', 'FAILED']).toContain(badge.trim().replace(/[^A-Z]/g, '').trim());

    // Score
    await expect(firstRow.locator('.subs2-score-val')).toBeVisible();
    const scoreText = await firstRow.locator('.subs2-score-val').textContent();
    expect(scoreText.trim()).toMatch(/^\d+$/);
  });

  test('Submissions: Filter (passed/flagged/failed) funktioniert', async ({ page }) => {
    await page.goto('/');
    await page.waitForTimeout(2000);
    await page.click('#topTabSubmissions');
    await page.waitForSelector('#submissionsMount', { timeout: 10000 });

    const isEmpty = await page.locator('#submissionsMount .empty').count() > 0;
    if (isEmpty) {
      test.skip(true, 'Keine Submissions in der DB');
      return;
    }

    // Auf "Passed" filtern
    await page.selectOption('#submissionsFilter', 'passed');
    await page.waitForTimeout(500);

    // Alle sichtbaren Badges müssen "PASSED" sein
    const badges = page.locator('#submissionsMount .subs2-plaus-label');
    const badgeCount = await badges.count();
    for (let i = 0; i < badgeCount; i++) {
      const text = await badges.nth(i).textContent();
      expect(text).toContain('PASSED');
    }

    // Zurück auf "Alle"
    await page.selectOption('#submissionsFilter', 'Alle');
    await page.waitForTimeout(500);
    await expect(page.locator('#submissionsMount')).toBeVisible();
  });
});

test.describe('Stufe 2 — Interaktionen', () => {
  test.use({ storageState: 'playwright/.auth/user.json' });

  // ─── MODAL ────────────────────────────────────────────────────────────────

  test('Startup-Karte anklicken öffnet Detail-Modal mit Inhalt', async ({ page }) => {
    await navigateToCardsView(page);

    const cards = page.locator('.startup-card');
    await expect(cards.first()).toBeVisible({ timeout: 8000 });

    // Auf Karten-Beschreibung klicken (nicht auf Button)
    const firstCard = cards.first();
    const desc = firstCard.locator('.desc');
    const hasDesc = await desc.count() > 0;
    if (hasDesc) {
      await desc.click();
    } else {
      await firstCard.locator('.card-name').click();
    }

    // Backdrop muss sichtbar sein
    await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });

    // Modal-Inhalt erscheint async (nach await getNotesForDeal) — warten bis befüllt
    await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });
    const modalContent = await page.locator('#modalBackdrop .modal').innerHTML();
    expect(modalContent.trim().length).toBeGreaterThan(100);
  });

  test('Detail-Modal schließen via Escape', async ({ page }) => {
    await navigateToCardsView(page);

    await page.locator('.startup-card').first().locator('.desc').click();
    await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });
    await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });

    // Schließen via Escape
    await page.keyboard.press('Escape');
    await expect(page.locator('#modalBackdrop')).toBeHidden({ timeout: 3000 });
  });

  test('Detail-Modal schließen via X-Button', async ({ page }) => {
    await navigateToCardsView(page);

    await page.locator('.startup-card').first().locator('.desc').click();
    await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });
    await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });

    // X-Button muss sichtbar sein und Modal schließen
    await expect(page.locator('#modalClose')).toBeVisible();
    await page.click('#modalClose');
    await expect(page.locator('#modalBackdrop')).toBeHidden({ timeout: 3000 });
  });

  test('Modal zeigt Startup-Details (Name, Score, Stage)', async ({ page }) => {
    await navigateToCardsView(page);

    const firstCard = page.locator('.startup-card').first();
    const cardName = await firstCard.locator('.card-name').textContent();

    await firstCard.locator('.desc').click();
    await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });
    await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });

    // Modal muss Stage, Sektor und Navigation-Buttons haben
    await expect(page.locator('#dvPrevBtn')).toBeVisible();
    await expect(page.locator('#dvNextBtn')).toBeVisible();
    await expect(page.locator('#dvPipeBtn')).toBeVisible();

    // Schließen
    await page.keyboard.press('Escape');
    await expect(page.locator('#modalBackdrop')).toBeHidden({ timeout: 3000 });
  });

  test('Score Breakdown: Stage-Badge sichtbar und max_score = 85', async ({ page }) => {
    // Submissions-View nutzen — dort sind immer scoreinfo-Buttons verfügbar
    await page.goto('/');
    await page.waitForTimeout(2000);
    await page.click('#topTabSubmissions');
    await page.waitForSelector('#submissionsMount', { timeout: 10000 });
    await page.waitForTimeout(1500);

    // localStorage leeren damit Migration sauber läuft
    await page.evaluate(() => {
      localStorage.removeItem('core_custom_rules_v6');
      localStorage.removeItem('core_custom_rulesets_v6');
    });
    await page.reload();
    await page.waitForTimeout(2000);
    await page.click('#topTabSubmissions');
    await page.waitForSelector('#submissionsMount', { timeout: 10000 });
    await page.waitForTimeout(1500);

    // ⓘ-Button in der Submissions-Liste
    const scoreBtn = page.locator('.subs2-infoicon[data-action="scoreinfo"]').first();
    await expect(scoreBtn).toBeVisible({ timeout: 8000 });
    await scoreBtn.click();
    await page.waitForTimeout(600);

    // Popover muss sichtbar sein
    const popover = page.locator('#signalIndexPopover');
    await expect(popover).toBeVisible({ timeout: 5000 });
    await expect(popover.locator('text=Score Breakdown')).toBeVisible();

    const popText = await popover.textContent();

    // max_score muss 85 sein (nicht mehr 100)
    expect(popText).toContain('/ 85');
    expect(popText).not.toContain('/ 100');

    // Stage-Badge: eine der bekannten Stages muss im Popover stehen
    const knownStages = ['Pre-Seed', 'Seed', 'Pre-Series A', 'Series A', 'Series B'];
    const hasStage = knownStages.some(s => popText.includes(s));
    expect(hasStage).toBe(true);

    await page.screenshot({ path: 'test-results/score-breakdown-badge.png' });
  });
});
