// Smoke-Test: Score Breakdown Popover zeigt Stage-Badge + max_score 85
import { test, expect } from '@playwright/test';

test.use({ storageState: 'playwright/.auth/user.json' });

test('Score Breakdown: stage badge sichtbar und max_score = 85', async ({ page }) => {
  await page.goto('/');
  await page.waitForTimeout(2000);

  // Zur Übersicht navigieren
  await page.click('#topTabHome');
  await page.waitForTimeout(1500);

  // Ersten ⓘ-Button (scoreinfo) klicken
  const scoreBtn = page.locator('button[data-action="scoreinfo"]').first();
  await expect(scoreBtn).toBeVisible({ timeout: 8000 });
  await scoreBtn.click();
  await page.waitForTimeout(600);

  // Popover muss sichtbar sein
  const popover = page.locator('#signalIndexPopover');
  await expect(popover).toBeVisible({ timeout: 5000 });

  // Score Breakdown Titel
  await expect(popover.locator('text=Score Breakdown')).toBeVisible();

  // max_score = 85 (nicht mehr 100)
  const popText = await popover.textContent();
  expect(popText).toContain('/ 85');
  expect(popText).not.toContain('/ 100');

  // Stage-Badge: eine der bekannten Stages muss im Popover stehen
  const knownStages = ['Pre-Seed', 'Seed', 'Pre-Series A', 'Series A', 'Series B'];
  const hasStage = knownStages.some(s => popText.includes(s));
  expect(hasStage).toBe(true);

  // Screenshot zur Verifikation
  await page.screenshot({ path: 'test-results/score-breakdown-badge.png', clip: {
    x: 0, y: 0, width: 600, height: 500
  }});
});
