// Offline-Smoke-Test: alle 7 Views ohne JS-Fehler + Supabase-backed Activity-Log.
// Läuft NUR mit PW_OFFLINE=1 — alle Supabase-Calls werden mit
// tests/fixtures/workspace-fixtures.json beantwortet (keine echte DB nötig).
// Aufruf siehe playwright.offline.config.js.

import { test, expect } from '@playwright/test';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const OFFLINE = process.env.PW_OFFLINE === '1';
const __dir = dirname(fileURLToPath(import.meta.url));

function pgrstFulfill(route, rows, fallbackSingle) {
  const accept = route.request().headers()['accept'] || '';
  const single = accept.includes('vnd.pgrst.object') || fallbackSingle;
  const body = single ? (Array.isArray(rows) ? rows[0] : rows) : (Array.isArray(rows) ? rows : [rows]);
  return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body ?? (single ? {} : [])) });
}

// Wie setupOffline in pipeline-view.spec.js, plus activity_log-Routen.
// Gibt das Array der abgefangenen activity_log-POST-Bodies zurück.
async function setupOffline(page, { activity = [] } = {}) {
  const fx = JSON.parse(readFileSync(join(__dir, 'fixtures', 'workspace-fixtures.json'), 'utf8'));
  const supabaseJs = readFileSync(join(__dir, '..', 'node_modules', '@supabase', 'supabase-js', 'dist', 'umd', 'supabase.js'), 'utf8');
  const user = { id: fx.user_id, email: 'test@core-app.dev', aud: 'authenticated', role: 'authenticated' };
  const activityPosts = [];

  await page.route('**/cdn.jsdelivr.net/npm/@supabase/supabase-js**', r =>
    r.fulfill({ status: 200, contentType: 'application/javascript', body: supabaseJs }));
  await page.route('**/auth/v1/user**', r =>
    r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(user) }));
  await page.route('**/auth/v1/token**', r =>
    r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({
      access_token: 'offline', refresh_token: 'offline', token_type: 'bearer', expires_in: 3600, user }) }));
  await page.route('**/auth/v1/logout**', r => r.fulfill({ status: 204, body: '' }));
  // Catch-all VOR den spezifischen Routen registrieren (zuletzt registrierte matchen zuerst).
  await page.route('**/rest/v1/**', r => pgrstFulfill(r, []));
  await page.route('**/rest/v1/fund_users**', r => pgrstFulfill(r, fx.fund_users));
  await page.route('**/rest/v1/funds?**', r => pgrstFulfill(r, [fx.fund]));
  await page.route('**/rest/v1/fund_members**', r => pgrstFulfill(r, fx.fund_members));
  // Fixtures enthalten nur akzeptierte Submissions — für den Accept-Flow
  // wird eine pending-Submission dazu synthetisiert.
  const pendingSub = { ...fx.submissions[0], id: '00000000-0000-4000-8000-000000000001',
    anon_id: 'N-PEND', company_name: 'Pending GmbH', status: 'pending' };
  await page.route('**/rest/v1/submissions**', r => {
    if (r.request().method() !== 'GET') return pgrstFulfill(r, []);
    if (r.request().url().includes('status=eq.pending')) return pgrstFulfill(r, [pendingSub]);
    return pgrstFulfill(r, fx.submissions);
  });
  await page.route('**/rest/v1/pipeline**', r => pgrstFulfill(r, fx.pipeline));
  await page.route('**/rest/v1/activity_log**', r => {
    if (r.request().method() === 'POST') {
      const body = JSON.parse(r.request().postData() || '{}');
      activityPosts.push(body);
      return r.fulfill({ status: 201, contentType: 'application/json',
        body: JSON.stringify({ id: `evt-${activityPosts.length}`, created_at: new Date().toISOString(), ...body }) });
    }
    return pgrstFulfill(r, activity);
  });

  await page.addInitScript(({ userId }) => {
    // Session nur EINMAL seeden — sonst wäre man nach Logout sofort wieder
    // "eingeloggt" und login.html würde zurück in die App redirecten.
    if (localStorage.getItem('pw-auth-seeded')) return;
    localStorage.setItem('pw-auth-seeded', '1');
    localStorage.setItem('sb-ggfjgzjevyemwbclvfpp-auth-token', JSON.stringify({
      access_token: 'offline', refresh_token: 'offline', token_type: 'bearer',
      expires_in: 3600, expires_at: Math.floor(Date.now() / 1000) + 3600,
      user: { id: userId, email: 'test@core-app.dev', aud: 'authenticated', role: 'authenticated' },
    }));
  }, { userId: fx.user_id });

  return { fx, activityPosts };
}

async function bootApp(page) {
  await page.goto('/');
  await page.waitForFunction(() => Array.isArray(window.startups) && window.fundName, null, { timeout: 15_000 });
}

const VIEW_OF_TAB = {
  topTabDashboard: '#viewDashboard',
  topTabHome: '#cardGrid',
  topTabSubmissions: '#viewSubmissions',
  topTabPipeline: '#viewPipeline',
  topTabCompare: '#viewCompare',
  topTabActivity: '#viewActivity',
  topTabInbox: '#viewInbox',
};

// Klick wiederholen, bis die Ziel-View sichtbar ist (Nav-Listener binden
// beim App-Start asynchron — gleiches Muster wie pipeline-view.spec.js).
async function clickTab(page, tabId) {
  const view = page.locator(VIEW_OF_TAB[tabId]);
  for (let i = 0; i < 5; i++) {
    await page.click(`#${tabId}`);
    try { await view.waitFor({ state: 'visible', timeout: 2_000 }); return; } catch (_) {}
  }
  await expect(view).toBeVisible({ timeout: 5_000 });
}

test.describe('Offline-Smoke', () => {
  test.skip(!OFFLINE, 'Nur mit PW_OFFLINE=1 sinnvoll');

  test('Alle 7 Views rendern ohne JS-Fehler', async ({ page }) => {
    const errors = [];
    page.on('pageerror', e => errors.push(`pageerror: ${e.message}`));
    page.on('console', m => {
      if (m.type() !== 'error') return;
      const t = m.text();
      if (/Failed to load resource|favicon/i.test(t)) return; // 404s der Stub-Umgebung
      errors.push(`console: ${t}`);
    });
    await setupOffline(page);
    await bootApp(page);

    for (const id of Object.keys(VIEW_OF_TAB)) {
      await clickTab(page, id);
      await page.waitForTimeout(250);
    }
    expect(errors, errors.join('\n')).toHaveLength(0);
  });

  test('Header zeigt eingeloggten User, Abmelden führt zur Login-Seite', async ({ page }) => {
    await setupOffline(page);
    await bootApp(page);
    // User-Badge: Initialen-Avatar + Name (Member-Profil oder E-Mail-Fallback)
    const badge = page.locator('#userBadge');
    await expect(badge).toBeVisible();
    await expect(page.locator('#userBadgeIni')).toHaveText(/^[A-ZÄÖÜ?]{1,2}$/);
    expect((await page.locator('#userBadgeName').textContent()).trim().length).toBeGreaterThan(0);
    expect(await badge.getAttribute('title')).toContain('Angemeldet als');
    // Abmelden → Login-Seite mit Passwort-Feld und Magic-Link-Button
    await page.click('#logoutBtn');
    await page.waitForURL('**/login.html', { timeout: 10_000 });
    await expect(page.locator('#emailInput')).toBeVisible();
    await expect(page.locator('#passwordInput')).toBeVisible();
    await expect(page.locator('#loginBtn')).toHaveText('Anmelden');
    await expect(page.locator('#magicBtn')).toHaveText('Magic Link senden');
  });

  test('Activity-View: Supabase-Events sichtbar, kein Clear-Button', async ({ page }) => {
    const now = new Date().toISOString();
    await setupOffline(page, { activity: [
      { id: 'evt-a', event: 'SUBMISSION_ACCEPTED', anon_id: 'N-3918', submission_id: null, meta: {}, created_at: now },
      { id: 'evt-b', event: 'PIPELINE_ADDED', anon_id: 'N-3918', submission_id: null, meta: { status: 'In Review' }, created_at: now },
    ] });
    await bootApp(page);
    await clickTab(page, 'topTabActivity');
    await expect(page.locator('#viewActivity .panelhead h2')).toHaveText('Verlauf');
    // Beide Fixture-Events gerendert, Labels aus ACTIVITY_LABELS
    await expect(page.locator('#actList .startup-card')).toHaveCount(2);
    await expect(page.locator('#actList')).toContainText('Submission angenommen');
    await expect(page.locator('#actMetaTotal')).toHaveText('2 Events');
    // Audit-Trail: Export ja, Clear nein
    await expect(page.locator('#actExportBtn')).toBeVisible();
    await expect(page.locator('#actClearBtn')).toHaveCount(0);
  });

  test('Detail-Modal: Plausibility-Badge + ACV auch für akzeptierte Deals', async ({ page }) => {
    // Der pending-Cache enthält die akzeptierte Submission NICHT (wie in Produktion) —
    // Badge und ACV müssen aus den ins Startup gemappten Werten kommen.
    await setupOffline(page);
    await bootApp(page);
    await page.evaluate(() => openModalByAnonId(window.startups[0].anon_id, window.startups));
    await expect(page.locator('#dvPlausBadge')).toBeVisible({ timeout: 5_000 });
    await expect(page.locator('#dvPlausBadge')).toHaveText(/Plausibility Passed|Flagged|Failed/);
    const hasAcv = await page.evaluate(() => window.startups[0].acv_eur != null);
    expect(hasAcv).toBe(true);
  });

  test('Stage-Wechsel erzeugt STATUS_CHANGED im Activity-Log', async ({ page }) => {
    await setupOffline(page);
    await bootApp(page);
    await clickTab(page, 'topTabPipeline');
    await page.click('#viewPipeline .pipe3-tab:has-text("In Review")');
    const sel = page.locator('#viewPipeline tbody select.pipe3-stagesel').first();
    await sel.waitFor({ state: 'visible', timeout: 10_000 });
    const [req] = await Promise.all([
      page.waitForRequest(r => r.url().includes('/rest/v1/activity_log') && r.method() === 'POST', { timeout: 10_000 }),
      sel.selectOption('Contacted'),
    ]);
    const body = req.postDataJSON();
    expect(body.event).toBe('STATUS_CHANGED');
    expect(body.meta).toMatchObject({ from: 'In Review', to: 'Contacted' });
    expect(body.user_id).toBeTruthy();
  });

  test('Submission annehmen erzeugt activity_log-Insert mit korrektem Event', async ({ page }) => {
    await setupOffline(page);
    await bootApp(page);
    await clickTab(page, 'topTabSubmissions');
    const accept = page.locator('.subs2-btn-accept').first();
    await accept.waitFor({ state: 'visible', timeout: 10_000 });
    const [req] = await Promise.all([
      page.waitForRequest(r => r.url().includes('/rest/v1/activity_log') && r.method() === 'POST', { timeout: 10_000 }),
      accept.click(),
    ]);
    const body = req.postDataJSON();
    expect(body.event).toBe('SUBMISSION_ACCEPTED');
    expect(body.fund_id).toBeTruthy();
    expect(body.user_id).toBeTruthy();
  });
});
