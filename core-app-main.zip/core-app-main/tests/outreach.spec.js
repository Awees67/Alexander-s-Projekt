// Anfragen-Flow: komplette User-Journey von Submissions → Detail-Modal → Send-Modal → Anfragen-View.
// Testet jeden Schritt wie ein echter User — findet Bugs bevor echte E-Mail-Integration kommt.

import { test, expect } from '@playwright/test';

// ── Hilfs-Funktion: Submissions öffnen + erste Zeile anklicken + Modal warten ──
async function openFirstSubmissionModal(page) {
  await page.goto('/');
  await page.waitForTimeout(2000);
  await page.click('#topTabSubmissions');
  await page.waitForSelector('#submissionsMount', { timeout: 10000 });

  const firstRow = page.locator('#submissionsMount tbody tr').first();
  await expect(firstRow).toBeVisible({ timeout: 8000 });

  // Startup-Namen merken
  const companyName = await firstRow.locator('.subs2-name').textContent();

  // Detail-Modal öffnen
  await firstRow.locator('.subs2-name').click();
  await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });
  await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });

  return companyName.trim();
}

test.describe('Anfragen-Flow', () => {
  test.use({ storageState: 'playwright/.auth/user.json' });

  // ── 1. Send-Modal öffnet sich mit korrekten Startup-Daten ────────────────────
  test('Send-Modal öffnet sich mit Startup-Name und E-Mail', async ({ page }) => {
    const companyName = await openFirstSubmissionModal(page);

    // "Anfrage senden" Button muss aktiv sein
    const anfrageBtn = page.locator('#dvAnfrageBtn');
    await expect(anfrageBtn).toBeVisible();
    await expect(anfrageBtn).not.toBeDisabled();
    await expect(anfrageBtn).toHaveText('Anfrage senden');

    // Klicken → Detail-Modal schließt sich, Send-Modal öffnet
    await anfrageBtn.click();
    await expect(page.locator('#modalBackdrop')).toBeHidden({ timeout: 3000 });
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

    // Startup-Name muss im Modal stehen
    const chipName = await page.locator('#otSendChipName').textContent();
    expect(chipName.trim()).toBe(companyName);

    // E-Mail-Adresse muss befüllt sein (nicht "—")
    const toAddr = await page.locator('#otSendToAddr').textContent();
    expect(toAddr.trim()).not.toBe('—');
    expect(toAddr.trim()).toContain('@');

    // Betreff und Nachricht müssen vorausgefüllt sein
    const subject = await page.locator('#otSendSubject').inputValue();
    expect(subject.trim().length).toBeGreaterThan(5);

    const body = await page.locator('#otSendBody').inputValue();
    expect(body.trim().length).toBeGreaterThan(20);
  });

  // ── 2. Template-Wechsel ändert Body-Text ────────────────────────────────────
  test('Template-Wechsel ändert Betreff und Nachricht', async ({ page }) => {
    await openFirstSubmissionModal(page);
    await page.locator('#dvAnfrageBtn').click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

    // Ausgangstext merken (Template: "Interesse bestätigen")
    const bodyInteresse = await page.locator('#otSendBody').inputValue();

    // Auf "Screening-Anfrage" wechseln
    await page.click('[data-tpl="screening"]');
    await page.waitForTimeout(200);
    const bodyScreening = await page.locator('#otSendBody').inputValue();
    expect(bodyScreening.trim()).not.toBe(bodyInteresse.trim()); // Text muss sich ändern

    // Auf "Blank" wechseln
    await page.click('[data-tpl="blank"]');
    await page.waitForTimeout(200);
    const bodyBlank = await page.locator('#otSendBody').inputValue();
    expect(bodyBlank.trim()).not.toBe(bodyScreening.trim());

    // Zurück auf "Interesse bestätigen"
    await page.click('[data-tpl="interesse"]');
    await page.waitForTimeout(200);
    const bodyBack = await page.locator('#otSendBody').inputValue();
    expect(bodyBack.trim()).toBe(bodyInteresse.trim()); // muss identisch zum Start sein
  });

  // ── 3. Senden ohne Nachricht zeigt Pflichtfeld-Fehler ───────────────────────
  test('Senden ohne Nachricht: Toast "Pflichtfeld", Modal bleibt offen', async ({ page }) => {
    await openFirstSubmissionModal(page);
    await page.locator('#dvAnfrageBtn').click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

    // Nachricht leeren
    await page.locator('#otSendBody').fill('');

    // Absenden
    await page.click('#otSendConfirmBtn');
    await page.waitForTimeout(500);

    // Modal muss noch offen sein
    await expect(page.locator('#otSendBackdrop')).toBeVisible();

    // Toast muss erscheinen
    await expect(page.locator('.toast, [class*="toast"]').first()).toBeVisible({ timeout: 3000 });
  });

  // ── 4. Senden ohne Betreff zeigt Pflichtfeld-Fehler ─────────────────────────
  test('Senden ohne Betreff: Toast "Pflichtfeld", Modal bleibt offen', async ({ page }) => {
    await openFirstSubmissionModal(page);
    await page.locator('#dvAnfrageBtn').click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

    // Betreff leeren
    await page.locator('#otSendSubject').fill('');

    // Absenden
    await page.click('#otSendConfirmBtn');
    await page.waitForTimeout(500);

    // Modal muss noch offen sein
    await expect(page.locator('#otSendBackdrop')).toBeVisible();

    // Toast muss erscheinen
    await expect(page.locator('.toast, [class*="toast"]').first()).toBeVisible({ timeout: 3000 });
  });

  // ── 5. Bearbeiter-Name wird in Nachricht eingesetzt ──────────────────────────
  test('Bearbeiter-Name wird dynamisch in den Nachrichtentext eingesetzt', async ({ page }) => {
    await openFirstSubmissionModal(page);
    await page.locator('#dvAnfrageBtn').click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

    // Bearbeiter-Name eingeben
    await page.locator('#otSendBearbeiter').fill('Max Mustermann');
    await page.waitForTimeout(300);

    // Name muss im Body stehen
    const body = await page.locator('#otSendBody').inputValue();
    expect(body).toContain('Max Mustermann');
  });

  // ── 6. Erfolgreiche Anfrage → erscheint in Anfragen-View ────────────────────
  test('Anfrage senden → Toast erscheint → Eintrag in Anfragen-View', async ({ page }) => {
    const companyName = await openFirstSubmissionModal(page);
    await page.locator('#dvAnfrageBtn').click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

    // Bearbeiter setzen, dann absenden
    await page.locator('#otSendBearbeiter').fill('Test Analyst');
    await page.click('#otSendConfirmBtn');
    await page.waitForTimeout(500);

    // Send-Modal muss geschlossen sein
    await expect(page.locator('#otSendBackdrop')).toBeHidden({ timeout: 3000 });

    // Toast "Anfrage gesendet" muss erscheinen
    await expect(page.locator('.toast, [class*="toast"]').first()).toBeVisible({ timeout: 3000 });

    // Anfragen-View muss Eintrag zeigen
    await page.click('#topTabInbox');
    await page.waitForTimeout(1000);
    await expect(page.locator('#viewInbox')).toBeVisible();
    const inboxContent = await page.locator('#viewInbox').innerHTML();
    expect(inboxContent).toContain(companyName);
  });

  // ── 7. Nach Senden ist "Anfrage senden" Button deaktiviert ──────────────────
  test('Nach Senden: Button zeigt "✓ Angefragt" und ist deaktiviert', async ({ page }) => {
    // Anfrage senden
    await openFirstSubmissionModal(page);
    await page.locator('#dvAnfrageBtn').click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });
    await page.click('#otSendConfirmBtn');
    await expect(page.locator('#otSendBackdrop')).toBeHidden({ timeout: 3000 });

    // Dasselbe Startup nochmal öffnen
    await page.click('#topTabSubmissions');
    await page.waitForSelector('#submissionsMount', { timeout: 10000 });
    await page.locator('#submissionsMount tbody tr').first().locator('.subs2-name').click();
    await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });
    await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });

    // Button muss deaktiviert sein
    const anfrageBtn = page.locator('#dvAnfrageBtn');
    await expect(anfrageBtn).toBeDisabled();
    await expect(anfrageBtn).toHaveText('✓ Angefragt');
  });

  // ── 8. X-Button schließt Send-Modal ─────────────────────────────────────────
  test('X-Button schließt Send-Modal', async ({ page }) => {
    await openFirstSubmissionModal(page);
    await page.locator('#dvAnfrageBtn').click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

    await page.click('#otSendCloseBtn');
    await expect(page.locator('#otSendBackdrop')).toBeHidden({ timeout: 3000 });
  });

  // ── 9. Abbrechen-Button schließt Send-Modal ──────────────────────────────────
  test('Abbrechen-Button schließt Send-Modal', async ({ page }) => {
    await openFirstSubmissionModal(page);
    await page.locator('#dvAnfrageBtn').click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

    await page.click('#otSendCancelBtn');
    await expect(page.locator('#otSendBackdrop')).toBeHidden({ timeout: 3000 });
  });

  // ── 10. Klick auf Backdrop schließt Send-Modal ───────────────────────────────
  test('Klick auf Backdrop schließt Send-Modal', async ({ page }) => {
    await openFirstSubmissionModal(page);
    await page.locator('#dvAnfrageBtn').click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

    // Klick auf den äußeren Rand des Backdrops
    await page.locator('#otSendBackdrop').click({ position: { x: 5, y: 5 } });
    await expect(page.locator('#otSendBackdrop')).toBeHidden({ timeout: 3000 });
  });
});
