/**
 * Vollständiger App-Test: alle 7 Views, alle Buttons, Detail-Modal-Viewport-Check.
 * Läuft gegen eine eingeloggte Session (storageState: playwright/.auth/user.json).
 *
 * Testkategorien:
 *   A – Initialisierung & Navigation (alle 7 Views erreichbar)
 *   B – Dashboard
 *   C – Übersicht (Karten, Sortierung, Filter)
 *   D – Detail-Modal (VOLLBILD-PRÜFUNG + alle Buttons)
 *   E – Submissions (Filter, Accept-All)
 *   F – Pipeline
 *   G – Compare
 *   H – Activity
 *   I – Inbox / Anfragen-Flow
 */

import { test, expect } from '@playwright/test';

// ── Globals ───────────────────────────────────────────────────────────────────

const VIEWPORT = { width: 1280, height: 720 };

// ── Helpers ───────────────────────────────────────────────────────────────────

async function appReady(page) {
  await page.goto('/');
  // Warte bis mindestens einer der Haupt-Tabs sichtbar ist (App vollständig initialisiert)
  await page.waitForSelector('#topTabHome', { timeout: 15000 });
  // Zusätzlich warten, bis keine Netzwerkrequests mehr laufen
  await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
  await page.waitForTimeout(500);
}

async function goToTab(page, tabId, waitSelector) {
  await page.click(`#${tabId}`);
  await page.waitForTimeout(300);
  if (waitSelector) {
    await page.waitForSelector(waitSelector, { timeout: 8000 });
  }
}

async function screenshot(page, name) {
  await page.screenshot({
    path: `test-results/screenshots/${name}.png`,
    fullPage: false
  });
}

async function ensureCardsVisible(page) {
  await goToTab(page, 'topTabHome', null);
  const count = await page.locator('.startup-card').count();
  if (count === 0) {
    // Submissions annehmen, falls noch welche da sind
    await goToTab(page, 'topTabSubmissions', '#viewSubmissions');
    const acceptBtn = page.locator('.subs2-btn-accept').first();
    if (await acceptBtn.count() > 0) {
      await acceptBtn.click();
      await page.waitForTimeout(1500);
    }
    await goToTab(page, 'topTabHome', null);
    await page.waitForTimeout(1000);
  }
}

// ── A: Navigation ─────────────────────────────────────────────────────────────

test.describe('A – Navigation', () => {
  test('A01 alle 7 Views per Tab erreichbar', async ({ page }) => {
    await appReady(page);

    const tabs = [
      { tab: 'topTabDashboard',   wait: '.dbv2-kpi-row, #viewDashboard' },
      { tab: 'topTabHome',        wait: '#cardGrid, .startup-card, .empty-state' },
      { tab: 'topTabSubmissions', wait: '#viewSubmissions' },
      { tab: 'topTabPipeline',    wait: '#viewPipeline, #pipelineMount' },
      { tab: 'topTabCompare',     wait: '#viewCompare, #compareBody' },
      { tab: 'topTabActivity',    wait: '#viewActivity, #activityMount' },
      { tab: 'topTabInbox',       wait: '#viewInbox' },
    ];

    for (const { tab, wait } of tabs) {
      const tabEl = page.locator(`#${tab}`);
      if (await tabEl.count() === 0) continue;
      await tabEl.click();
      await page.waitForTimeout(400);
      const el = page.locator(wait);
      await expect(el.first()).toBeVisible({ timeout: 8000 });
    }
  });

  test('A02 aktiver Tab hat CSS-Klasse active', async ({ page }) => {
    await appReady(page);

    const tabIds = ['topTabDashboard', 'topTabHome', 'topTabSubmissions', 'topTabPipeline'];
    for (const tabId of tabIds) {
      const tab = page.locator(`#${tabId}`);
      if (await tab.count() === 0) continue;
      await tab.click();
      await page.waitForTimeout(300);
      await expect(tab).toHaveClass(/active/, { timeout: 3000 });
    }
  });
});

// ── B: Dashboard ──────────────────────────────────────────────────────────────

test.describe('B – Dashboard', () => {
  test('B01 KPI-Kacheln zeigen Zahlen', async ({ page }) => {
    await appReady(page);
    await goToTab(page, 'topTabDashboard', '.dbv2-kpi-row, #viewDashboard');

    const kpiVals = page.locator('.dbv2-kpi-val');
    await expect(kpiVals.first()).toBeVisible({ timeout: 8000 });
    const count = await kpiVals.count();
    expect(count).toBeGreaterThanOrEqual(4);

    for (let i = 0; i < count; i++) {
      const text = await kpiVals.nth(i).textContent();
      expect(text.trim()).not.toBe('');
    }
    await screenshot(page, 'B01-dashboard');
  });

  test('B02 Dashboard-Charts und Sektions gerendert', async ({ page }) => {
    await appReady(page);
    await goToTab(page, 'topTabDashboard', '.dbv2-kpi-row, #viewDashboard');

    const dashView = page.locator('#viewDashboard, .dbv2-kpi-row').first();
    await expect(dashView).toBeVisible({ timeout: 8000 });
    const html = await dashView.innerHTML();
    expect(html.trim().length).toBeGreaterThan(200);
  });
});

// ── C: Übersicht ──────────────────────────────────────────────────────────────

test.describe('C – Übersicht', () => {
  test('C01 Karten: Score-Ring, KPIs und Tags vorhanden', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    const cards = page.locator('.startup-card');
    await expect(cards.first()).toBeVisible({ timeout: 10000 });

    const first = cards.first();
    await expect(first.locator('.score-num')).toBeVisible();
    const score = await first.locator('.score-num').textContent();
    expect(score.trim()).toMatch(/^\d+$/);

    const kpiCount = await first.locator('.kpi-val').count();
    expect(kpiCount).toBeGreaterThanOrEqual(4);

    const tagCount = await first.locator('.tag').count();
    expect(tagCount).toBeGreaterThanOrEqual(1);

    await screenshot(page, 'C01-uebersicht-karten');
  });

  test('C02 Sortierung ändert Reihenfolge', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    for (const val of ['runway_desc', 'mrr_desc', 'nrr_desc']) {
      await page.selectOption('#sortSelect', val);
      await page.waitForTimeout(400);
      await expect(page.locator('.startup-card').first()).toBeVisible();
    }
  });

  test('C03 Suchfeld filtert Karten', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    const totalBefore = await page.locator('.startup-card').count();
    await page.fill('#searchInput', 'xxxxnotexistsquery9999');
    await page.waitForTimeout(400);
    const totalAfter = await page.locator('.startup-card').count();
    expect(totalAfter).toBeLessThanOrEqual(totalBefore);

    // Suche zurücksetzen
    await page.fill('#searchInput', '');
    await page.waitForTimeout(400);
  });

  test('C04 Score-Info-Button (ⓘ) öffnet Popover und schließt es', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    const scoreBtn = page.locator('.startup-card button[data-action="scoreinfo"]').first();
    await expect(scoreBtn).toBeVisible({ timeout: 8000 });
    await scoreBtn.click();
    await page.waitForTimeout(500);

    const pop = page.locator('#signalIndexPopover');
    await expect(pop).toBeVisible({ timeout: 5000 });
    const popText = await pop.textContent();
    expect(popText).toContain('Score Breakdown');
    expect(popText).toContain('/ 85');

    await screenshot(page, 'C04-score-popover');

    // Schließen per Außenklick
    await page.locator('#cardGrid').click({ position: { x: 5, y: 5 } }).catch(() => {});
    await expect(pop).toBeHidden({ timeout: 3000 });
  });

  test('C05 Pipeline-Button auf Karte funktioniert', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    const pipeBtn = page.locator('.startup-card button[data-action="addpipeline"]').first();
    await expect(pipeBtn).toBeVisible({ timeout: 8000 });
    if (!await pipeBtn.isDisabled()) {
      await pipeBtn.click();
      await page.waitForTimeout(500);
      // Toast oder Button-Text ändert sich
      const toastOrBtnChanged =
        (await page.locator('.toast, [class*="toast"]').count() > 0) ||
        (await pipeBtn.textContent()).includes('Pipeline');
      expect(toastOrBtnChanged).toBe(true);
    }
  });

  test('C06 Compare-Button fügt Startup hinzu und Tab zeigt Daten', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    const cards = page.locator('.startup-card');
    const count = await cards.count();
    if (count < 2) { test.skip(); return; }

    for (let i = 0; i < 2; i++) {
      const btn = cards.nth(i).locator('button[data-action="compare"]');
      if (await btn.count() > 0) {
        await btn.click();
        await page.waitForTimeout(200);
      }
    }

    // Kein Tray mehr — direkt Compare-Tab öffnen und Inhalt prüfen
    await page.click('#topTabCompare');
    await page.waitForTimeout(600);
    const compareEl = page.locator('#compareBody, #viewCompare').first();
    await expect(compareEl).toBeVisible({ timeout: 8000 });
    const html = await compareEl.innerHTML();
    expect(html.trim().length).toBeGreaterThan(100);
  });
});

// ── D: Detail-Modal ───────────────────────────────────────────────────────────

test.describe('D – Detail-Modal', () => {

  async function openFirstModal(page) {
    await ensureCardsVisible(page);
    const firstCard = page.locator('.startup-card').first();
    const desc = firstCard.locator('.desc');
    if (await desc.count() > 0) await desc.click();
    else await firstCard.locator('.card-name').click();
    await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 8000 });
    await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });
  }

  test('D01 Modal öffnet und ist VOLLBILD (füllt gesamten Viewport)', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    const vp = page.viewportSize();
    const modalBox = await page.locator('#modalBackdrop .modal').boundingBox();
    await screenshot(page, 'D01-modal-vollbild');

    expect(modalBox).not.toBeNull();

    // Modal soll den vollen Viewport abdecken (Toleranz ±2px)
    expect(modalBox.x).toBeLessThanOrEqual(2);
    expect(modalBox.y).toBeLessThanOrEqual(2);
    expect(modalBox.width).toBeGreaterThanOrEqual(vp.width - 4);
    expect(modalBox.height).toBeGreaterThanOrEqual(vp.height - 4);

    await page.keyboard.press('Escape');
  });

  test('D02 Modal-Backdrop deckt GESAMTEN Bildschirm ab', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    const vp = page.viewportSize();
    const backdropBox = await page.locator('#modalBackdrop').boundingBox();
    await screenshot(page, 'D02-modal-backdrop');

    expect(backdropBox).not.toBeNull();
    expect(backdropBox.x).toBeLessThanOrEqual(0);
    expect(backdropBox.y).toBeLessThanOrEqual(0);
    expect(backdropBox.width).toBeGreaterThanOrEqual(vp.width);
    expect(backdropBox.height).toBeGreaterThanOrEqual(vp.height);

    await page.keyboard.press('Escape');
  });

  test('D03 Topbar: alle Buttons vorhanden (Prev, Next, Pipeline, Anfrage, Close)', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    await expect(page.locator('#dvPrevBtn')).toBeVisible();
    await expect(page.locator('#dvNextBtn')).toBeVisible();
    await expect(page.locator('#dvPipeBtn')).toBeVisible();
    await expect(page.locator('#dvAnfrageBtn')).toBeVisible();
    await expect(page.locator('#modalClose')).toBeVisible();

    await screenshot(page, 'D03-modal-topbar');
    await page.keyboard.press('Escape');
  });

  test('D04 Navigation Prev/Next wechselt Startup', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    const nameBefore = await page.locator('.dv-topbar-id').textContent().catch(() => '');

    await page.click('#dvNextBtn');
    await page.waitForTimeout(400);
    await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 5000 });

    const nameAfter = await page.locator('.dv-topbar-id').textContent().catch(() => '');
    // Namen können gleich sein wenn nur 1 Karte — trotzdem kein Fehler
    await screenshot(page, 'D04-modal-next');

    await page.click('#dvPrevBtn');
    await page.waitForTimeout(400);
    await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 5000 });

    await page.keyboard.press('Escape');
  });

  test('D05 Schließen per X-Button', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    await page.click('#modalClose');
    await expect(page.locator('#modalBackdrop')).toBeHidden({ timeout: 5000 });
  });

  test('D06 Schließen per Escape-Taste', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    await page.keyboard.press('Escape');
    await expect(page.locator('#modalBackdrop')).toBeHidden({ timeout: 5000 });
  });

  test('D07 Score Breakdown (i)-Button im Modal öffnet Popover', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    const scoreInfoBtn = page.locator('#dvScoreInfo');
    await expect(scoreInfoBtn).toBeVisible({ timeout: 5000 });
    await scoreInfoBtn.click();
    await page.waitForTimeout(500);

    const pop = page.locator('#signalIndexPopover');
    await expect(pop).toBeVisible({ timeout: 5000 });
    const popText = await pop.textContent();
    expect(popText).toContain('Score Breakdown');
    expect(popText).toContain('/ 85');

    await screenshot(page, 'D07-modal-score-popover');

    await page.keyboard.press('Escape');
    await page.keyboard.press('Escape');
  });

  test('D08 Pitch-Deck-Link sichtbar (falls vorhanden)', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    const deckLink = page.locator('#modalBackdrop a[href*="deck"], .dv-topbar a[href]');
    // Nicht zwingend vorhanden — nur prüfen wenn da
    const hasDeck = await deckLink.count() > 0;
    if (hasDeck) {
      await expect(deckLink.first()).toBeVisible();
    }

    await page.keyboard.press('Escape');
  });

  test('D09 Pipeline-Button im Modal: In-Pipeline-Status korrekt', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    const pipeBtn = page.locator('#dvPipeBtn');
    await expect(pipeBtn).toBeVisible();
    const btnText = await pipeBtn.textContent();
    expect(btnText.trim().length).toBeGreaterThan(0);

    await screenshot(page, 'D09-modal-pipeline-btn');
    await page.keyboard.press('Escape');
  });

  test('D10 Anfrage senden: kompletter Outreach-Flow', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    // Ersten Startup finden, der noch nicht angefragt wurde
    const cards = page.locator('.startup-card');
    const count = await cards.count();
    let opened = false;

    for (let i = 0; i < Math.min(count, 5); i++) {
      const card = cards.nth(i);
      const desc = card.locator('.desc');
      if (await desc.count() > 0) await desc.click();
      else await card.locator('.card-name').click();

      await page.waitForTimeout(400);
      const anfrageBtn = page.locator('#dvAnfrageBtn');
      const btnText = await anfrageBtn.textContent().catch(() => 'Angefragt');
      if (!btnText.includes('Angefragt')) {
        opened = true;
        break;
      }
      await page.keyboard.press('Escape');
      await page.waitForTimeout(300);
    }

    if (!opened) {
      test.skip(true, 'Alle Startups bereits angefragt');
      return;
    }

    const anfrageBtn = page.locator('#dvAnfrageBtn');
    await anfrageBtn.click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

    await screenshot(page, 'D10-anfrage-modal');

    // Vorausgefüllte Felder prüfen
    const subject = await page.locator('#otSendSubject').inputValue();
    expect(subject.trim().length).toBeGreaterThan(5);
    const body = await page.locator('#otSendBody').inputValue();
    expect(body.trim().length).toBeGreaterThan(20);

    await page.locator('#otSendBearbeiter').fill('Test Analyst');
    await page.click('#otSendConfirmBtn');
    await page.waitForTimeout(800);

    await expect(page.locator('#otSendBackdrop')).toBeHidden({ timeout: 5000 });
    await expect(page.locator('.toast, [class*="toast"]').first()).toBeVisible({ timeout: 5000 });
  });

  test('D11 Modal linke Seite scrollbar (langer Inhalt)', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    const dvLeft = page.locator('.dv-left');
    await expect(dvLeft).toBeVisible({ timeout: 5000 });

    // Scroll nach unten im linken Panel
    await dvLeft.evaluate(el => { el.scrollTop = 9999; });
    await page.waitForTimeout(300);
    const scrolled = await dvLeft.evaluate(el => el.scrollTop);
    // Wenn scrollbar funktioniert, ist scrollTop > 0 (oder 0 wenn Inhalt passt)
    await screenshot(page, 'D11-modal-scroll-bottom');

    // Scroll zurück
    await dvLeft.evaluate(el => { el.scrollTop = 0; });
    await page.keyboard.press('Escape');
  });

  test('D12 Modal rechte Seite: Notes-Bereich sichtbar', async ({ page }) => {
    await appReady(page);
    await openFirstModal(page);

    const dvRight = page.locator('.dv-right');
    await expect(dvRight).toBeVisible({ timeout: 5000 });

    await screenshot(page, 'D12-modal-right-panel');
    await page.keyboard.press('Escape');
  });
});

// ── E: Submissions ────────────────────────────────────────────────────────────

test.describe('E – Submissions', () => {
  test('E01 Submissions-View rendert (auch bei leer)', async ({ page }) => {
    await appReady(page);
    await page.click('#topTabSubmissions');
    // Warte auf viewSubmissions sichtbar — nicht auf submissionsMount
    await expect(page.locator('#viewSubmissions')).toBeVisible({ timeout: 10000 });
    await page.waitForTimeout(500);
    await screenshot(page, 'E01-submissions-view');
  });

  test('E02 Filter-Tabs (passed/flagged/failed) funktionieren', async ({ page }) => {
    await appReady(page);
    await page.click('#topTabSubmissions');
    await expect(page.locator('#viewSubmissions')).toBeVisible({ timeout: 10000 });
    await page.waitForTimeout(500);

    const hasRows = await page.locator('#submissionsMount tbody tr').count() > 0;
    if (!hasRows) { test.skip(true, 'Keine pending Submissions'); return; }

    for (const val of ['passed', 'flagged', 'Alle']) {
      const filterSel = page.locator('#submissionsFilter');
      if (await filterSel.count() > 0) {
        await filterSel.selectOption(val);
        await page.waitForTimeout(400);
      }
    }
  });

  test('E03 Alle annehmen Button vorhanden', async ({ page }) => {
    await appReady(page);
    await page.click('#topTabSubmissions');
    await expect(page.locator('#viewSubmissions')).toBeVisible({ timeout: 10000 });

    const acceptAll = page.locator('#acceptAllBtn');
    await expect(acceptAll).toBeVisible({ timeout: 5000 });
  });
});

// ── F: Pipeline ───────────────────────────────────────────────────────────────

test.describe('F – Pipeline', () => {
  test('F01 Pipeline-View lädt ohne Fehler', async ({ page }) => {
    await appReady(page);
    await goToTab(page, 'topTabPipeline', '#viewPipeline, #pipelineMount, .pipeline-board');

    const view = page.locator('#viewPipeline, #pipelineMount').first();
    await expect(view).toBeVisible({ timeout: 8000 });
    const html = await view.innerHTML();
    expect(html.trim().length).toBeGreaterThan(20);
    await screenshot(page, 'F01-pipeline');
  });

  test('F02 Startup zur Pipeline hinzufügen (via Karten-Button)', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    const pipeBtn = page.locator('.startup-card button[data-action="addpipeline"]').first();
    await expect(pipeBtn).toBeVisible({ timeout: 8000 });
    if (!await pipeBtn.isDisabled()) {
      await pipeBtn.click();
      await page.waitForTimeout(500);
    }

    await goToTab(page, 'topTabPipeline', '#viewPipeline, #pipelineMount');
    const view = page.locator('#viewPipeline, #pipelineMount').first();
    await expect(view).toBeVisible({ timeout: 8000 });
  });
});

// ── G: Compare ────────────────────────────────────────────────────────────────

test.describe('G – Compare', () => {
  test('G01 Compare: 2 Startups vergleichen', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    const cards = page.locator('.startup-card');
    const count = await cards.count();
    if (count < 2) { test.skip(true, 'Weniger als 2 Karten'); return; }

    for (let i = 0; i < 2; i++) {
      const btn = cards.nth(i).locator('button[data-action="compare"]');
      if (await btn.count() > 0) {
        await btn.click();
        await page.waitForTimeout(200);
      }
    }

    await goToTab(page, 'topTabCompare', '#viewCompare, #compareBody');
    const compareEl = page.locator('#compareBody, #viewCompare').first();
    await expect(compareEl).toBeVisible({ timeout: 8000 });
    const html = await compareEl.innerHTML();
    expect(html.trim().length).toBeGreaterThan(100);
    await screenshot(page, 'G01-compare');
  });

  test('G02 Compare Export-Button vorhanden', async ({ page }) => {
    await appReady(page);
    await goToTab(page, 'topTabCompare', '#viewCompare, #compareBody');
    const exportBtn = page.locator('#compareExportBtn');
    if (await exportBtn.count() > 0) {
      await expect(exportBtn).toBeVisible();
    }
  });
});

// ── H: Activity ───────────────────────────────────────────────────────────────

test.describe('H – Activity', () => {
  test('H01 Activity-View rendert ohne Fehler', async ({ page }) => {
    await appReady(page);
    await goToTab(page, 'topTabActivity', '#viewActivity, #activityMount, .activity-list');

    const view = page.locator('#viewActivity, #activityMount').first();
    await expect(view).toBeVisible({ timeout: 8000 });
    await screenshot(page, 'H01-activity');
  });

  test('H02 Activity enthält Einträge nach Pipeline-Aktion', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    // Pipeline-Aktion erzeugen
    const pipeBtn = page.locator('.startup-card button[data-action="addpipeline"]').first();
    if (await pipeBtn.count() > 0 && !await pipeBtn.isDisabled()) {
      await pipeBtn.click();
      await page.waitForTimeout(500);
    }

    await goToTab(page, 'topTabActivity', '#viewActivity, #activityMount');
    const view = page.locator('#viewActivity, #activityMount').first();
    await expect(view).toBeVisible({ timeout: 8000 });
    const html = await view.innerHTML();
    expect(html.trim().length).toBeGreaterThan(50);
  });
});

// ── I: Inbox / Anfragen ───────────────────────────────────────────────────────

test.describe('I – Inbox', () => {
  test('I01 Inbox-View rendert ohne Fehler', async ({ page }) => {
    await appReady(page);
    await goToTab(page, 'topTabInbox', '#viewInbox');

    const view = page.locator('#viewInbox');
    await expect(view).toBeVisible({ timeout: 8000 });
    await screenshot(page, 'I01-inbox');
  });

  test('I02 Inbox zeigt Einträge nach Anfrage-Send', async ({ page }) => {
    await appReady(page);
    await ensureCardsVisible(page);

    // Anfrage senden
    const firstCard = page.locator('.startup-card').first();
    const desc = firstCard.locator('.desc');
    if (await desc.count() > 0) await desc.click();
    else await firstCard.locator('.card-name').click();

    await page.waitForTimeout(400);
    const anfrageBtn = page.locator('#dvAnfrageBtn');
    const btnText = await anfrageBtn.textContent().catch(() => 'Angefragt');

    if (!btnText.includes('Angefragt')) {
      await anfrageBtn.click();
      await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });
      await page.locator('#otSendBearbeiter').fill('Analyst');
      await page.click('#otSendConfirmBtn');
      await expect(page.locator('#otSendBackdrop')).toBeHidden({ timeout: 5000 });
    } else {
      await page.keyboard.press('Escape');
    }

    await goToTab(page, 'topTabInbox', '#viewInbox');
    const view = page.locator('#viewInbox');
    await expect(view).toBeVisible({ timeout: 8000 });
    const html = await view.innerHTML();
    expect(html.trim().length).toBeGreaterThan(50);
  });
});
