// Kompletter User-Journey-Test: setzt voraus, dass submit-form.spec.js vorher lief
// und 10 Submissions in der DB hat.
//
// Reihenfolge bewusst:
//   01–02  Submissions prüfen (solange noch pending)
//   03     Alle Submissions akzeptieren
//   04–05  Dashboard + Übersicht
//   06–07  Detail-Modal
//   08     Score Breakdown
//   09–10  Anfrage senden + Anfragen-View
//   11–12  Pipeline
//   13     Compare
//   14     Activity
//   15     Alle Views navigierbar

import { test, expect } from '@playwright/test';

// ── Hilfsfunktionen ───────────────────────────────────────────────────────────

async function goHome(page) {
  await page.goto('/');
  // Warte bis App vollständig initialisiert (Supabase-Calls abgeschlossen)
  await page.waitForSelector('#topTabHome', { timeout: 15000 });
  await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
  await page.waitForTimeout(500);
}

async function ensureCardsVisible(page) {
  await page.click('#topTabHome');
  await page.waitForTimeout(1500);
  const count = await page.locator('.startup-card').count();
  if (count === 0) {
    await page.click('#topTabSubmissions');
    await page.waitForSelector('#submissionsMount', { timeout: 10000 });
    await page.waitForTimeout(1000);
    const btn = page.locator('.subs2-btn-accept').first();
    if (await btn.count() > 0) {
      await btn.click();
      await page.waitForTimeout(2000);
    }
    await page.click('#topTabHome');
    await page.waitForTimeout(1500);
  }
}

// ── 01. Submissions vorhanden ─────────────────────────────────────────────────

test('01 Submissions: 10 Einträge, Badges und Scores korrekt', async ({ page }) => {
  await goHome(page);
  await page.click('#topTabSubmissions');
  // Warte auf viewSubmissions (rendert immer), dann auf submissionsMount innen
  await page.waitForSelector('#viewSubmissions', { timeout: 10000 });
  await page.waitForTimeout(800);

  const isEmpty = await page.locator('#submissionsMount .empty').count() > 0;
  if (isEmpty) {
    test.skip(true, 'Keine Submissions — submit-form Tests zuerst ausführen');
    return;
  }

  const rows = page.locator('#submissionsMount tbody tr');
  await expect(rows.first()).toBeVisible({ timeout: 8000 });
  const rowCount = await rows.count();
  expect(rowCount).toBeGreaterThanOrEqual(5);

  // Jede Zeile: Name, Stage, Plausibility-Badge, Score-Wert
  for (let i = 0; i < Math.min(rowCount, 10); i++) {
    const row = rows.nth(i);
    const name = await row.locator('.subs2-name').textContent();
    expect(name.trim().length).toBeGreaterThan(0);
    const stage = await row.locator('.subs2-stage').textContent();
    expect(stage.trim().length).toBeGreaterThan(0);
    const badge = await row.locator('.subs2-plaus-label').textContent();
    const badgeUpper = badge.toUpperCase();
    expect(badgeUpper.includes('PASSED') || badgeUpper.includes('FLAGGED') || badgeUpper.includes('FAILED')).toBe(true);
    const scoreText = await row.locator('.subs2-score-val').textContent();
    expect(scoreText.trim()).toMatch(/^\d+$/);
  }
});

test('01b Submissions: Filter-Tabs (passed / flagged) funktionieren', async ({ page }) => {
  await goHome(page);
  await page.click('#topTabSubmissions');
  await page.waitForSelector('#viewSubmissions', { timeout: 10000 });
  await page.waitForTimeout(800);

  const isEmpty = await page.locator('#submissionsMount .empty').count() > 0;
  if (isEmpty) {
    test.skip(true, 'Keine Submissions');
    return;
  }

  // "passed" filtern
  await page.selectOption('#submissionsFilter', 'passed');
  await page.waitForTimeout(500);
  const passedBadges = page.locator('#submissionsMount .subs2-plaus-label');
  const passedCount = await passedBadges.count();
  for (let i = 0; i < passedCount; i++) {
    const t = (await passedBadges.nth(i).textContent()).toUpperCase();
    expect(t.includes('PASSED')).toBe(true);
  }

  // "flagged" filtern
  await page.selectOption('#submissionsFilter', 'flagged');
  await page.waitForTimeout(500);
  const flaggedBadges = page.locator('#submissionsMount .subs2-plaus-label');
  const flaggedCount = await flaggedBadges.count();
  for (let i = 0; i < flaggedCount; i++) {
    const t = (await flaggedBadges.nth(i).textContent()).toUpperCase();
    expect(t.includes('FLAGGED')).toBe(true);
  }

  // Zurück auf "Alle"
  await page.selectOption('#submissionsFilter', 'Alle');
  await page.waitForTimeout(500);
  await expect(page.locator('#submissionsMount')).toBeVisible();
});

test('01c Submissions: Score Breakdown Popover — max_score = 85 und Stage-Badge', async ({ page }) => {
  await goHome(page);
  await page.click('#topTabSubmissions');
  await page.waitForSelector('#viewSubmissions', { timeout: 10000 });
  await page.waitForTimeout(800);

  const isEmpty = await page.locator('#submissionsMount .empty').count() > 0;
  if (isEmpty) {
    test.skip(true, 'Keine Submissions');
    return;
  }

  const scoreBtn = page.locator('.subs2-infoicon[data-action="scoreinfo"]').first();
  await expect(scoreBtn).toBeVisible({ timeout: 8000 });
  await scoreBtn.click();
  await page.waitForTimeout(600);

  const pop = page.locator('#signalIndexPopover');
  await expect(pop).toBeVisible({ timeout: 5000 });
  await expect(pop.locator('text=Score Breakdown')).toBeVisible();

  const popText = await pop.textContent();
  expect(popText).toContain('/ 85');
  expect(popText).not.toContain('/ 100');

  const knownStages = ['Pre-Seed', 'Seed', 'Pre-Series A', 'Series A', 'Series B'];
  const hasStage = knownStages.some(s => popText.includes(s));
  expect(hasStage).toBe(true);

  await page.screenshot({ path: 'test-results/score-breakdown-full-flow.png' });

  // Schließen
  await page.locator('#submissionsMount').click({ position: { x: 5, y: 5 } }).catch(() => {});
  await page.keyboard.press('Escape').catch(() => {});
});

// ── 02. Alle Submissions akzeptieren ─────────────────────────────────────────

test('02 Submissions: alle pending Einträge akzeptieren', async ({ page }) => {
  await goHome(page);
  await page.click('#topTabSubmissions');
  await page.waitForSelector('#viewSubmissions', { timeout: 10000 });
  await page.waitForTimeout(800);

  const isEmpty = await page.locator('#submissionsMount .empty').count() > 0;
  if (isEmpty) {
    test.skip(true, 'Keine Submissions — submit-form Tests zuerst ausführen');
    return;
  }

  for (let round = 0; round < 15; round++) {
    const btns = await page.locator('.subs2-btn-accept').count();
    if (btns === 0) break;
    await page.locator('.subs2-btn-accept').first().click();
    await page.waitForTimeout(800);
  }

  // Übersicht zeigt jetzt Karten
  await page.click('#topTabHome');
  await page.waitForTimeout(1500);
  const cards = page.locator('.startup-card');
  await expect(cards.first()).toBeVisible({ timeout: 10000 });
  const cardCount = await cards.count();
  expect(cardCount).toBeGreaterThanOrEqual(1);
});

// ── 03. Dashboard ─────────────────────────────────────────────────────────────

test('03 Dashboard: alle KPI-Kacheln zeigen Zahlen', async ({ page }) => {
  await goHome(page);
  await page.click('#topTabDashboard');
  await page.waitForTimeout(1500);

  const kpiVals = page.locator('.dbv2-kpi-val');
  await expect(kpiVals.first()).toBeVisible({ timeout: 8000 });
  const count = await kpiVals.count();
  expect(count).toBeGreaterThanOrEqual(4);

  for (let i = 0; i < count; i++) {
    const text = await kpiVals.nth(i).textContent();
    expect(text.trim()).not.toBe('');
  }
});

// ── 04. Übersicht — Karten ────────────────────────────────────────────────────

test('04 Übersicht: Karten zeigen Score-Ring, KPIs und Tags', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  const cards = page.locator('.startup-card');
  await expect(cards.first()).toBeVisible({ timeout: 8000 });

  const first = cards.first();

  await expect(first.locator('.score-num')).toBeVisible();
  const score = await first.locator('.score-num').textContent();
  expect(score.trim()).toMatch(/^\d+$/);

  await expect(first.locator('.kpi-val').first()).toBeVisible();
  const kpiCount = await first.locator('.kpi-val').count();
  expect(kpiCount).toBeGreaterThanOrEqual(4);

  const tagCount = await first.locator('.tag').count();
  expect(tagCount).toBeGreaterThanOrEqual(2);
});

test('04b Übersicht: Sortierung ändert die Reihenfolge', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  await page.selectOption('#sortSelect', 'runway_desc');
  await page.waitForTimeout(500);
  await expect(page.locator('.startup-card').first()).toBeVisible();

  await page.selectOption('#sortSelect', 'mrr_desc');
  await page.waitForTimeout(500);
  await expect(page.locator('.startup-card').first()).toBeVisible();

  await page.selectOption('#sortSelect', 'nrr_desc');
  await page.waitForTimeout(500);
  await expect(page.locator('.startup-card').first()).toBeVisible();
});

// ── 05. Detail-Modal ──────────────────────────────────────────────────────────

test('05 Detail-Modal: Score, Stage, Pitch-Deck-Link, Navigation', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  const firstCard = page.locator('.startup-card').first();
  const desc = firstCard.locator('.desc');
  if (await desc.count() > 0) await desc.click();
  else await firstCard.locator('.card-name').click();

  await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });
  await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });

  await expect(page.locator('#dvPrevBtn')).toBeVisible();
  await expect(page.locator('#dvNextBtn')).toBeVisible();
  await expect(page.locator('#dvPipeBtn')).toBeVisible();
  await expect(page.locator('#dvAnfrageBtn')).toBeVisible();

  // Pitch-Deck-Link (alle fixtures haben pitch_deck_url)
  const deckLink = page.locator('#modalBackdrop a[href*="deck"]');
  await expect(deckLink.first()).toBeVisible({ timeout: 3000 });

  // Navigation Prev/Next
  await page.click('#dvNextBtn');
  await page.waitForTimeout(500);
  await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 5000 });

  await page.click('#dvPrevBtn');
  await page.waitForTimeout(500);
  await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 5000 });

  await page.keyboard.press('Escape');
  await expect(page.locator('#modalBackdrop')).toBeHidden({ timeout: 3000 });
});

test('05b Detail-Modal: X-Button schließt', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  const firstCard = page.locator('.startup-card').first();
  const desc = firstCard.locator('.desc');
  if (await desc.count() > 0) await desc.click();
  else await firstCard.locator('.card-name').click();

  await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });
  await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });
  await page.click('#modalClose');
  await expect(page.locator('#modalBackdrop')).toBeHidden({ timeout: 3000 });
});

// ── 06. Score Breakdown via Karten-ⓘ ─────────────────────────────────────────

test('06 Score Breakdown: max_score = 85 und Stage-Badge (via Karten-ⓘ)', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  // ⓘ-Button auf der ersten Karte klicken
  const scoreBtn = page.locator('.startup-card button[data-action="scoreinfo"]').first();
  await expect(scoreBtn).toBeVisible({ timeout: 8000 });
  await scoreBtn.click();
  await page.waitForTimeout(600);

  const pop = page.locator('#signalIndexPopover');
  await expect(pop).toBeVisible({ timeout: 5000 });
  await expect(pop.locator('text=Score Breakdown')).toBeVisible();

  const popText = await pop.textContent();
  expect(popText).toContain('/ 85');
  expect(popText).not.toContain('/ 100');

  const knownStages = ['Pre-Seed', 'Seed', 'Pre-Series A', 'Series A', 'Series B'];
  const hasStage = knownStages.some(s => popText.includes(s));
  expect(hasStage).toBe(true);

  await page.screenshot({ path: 'test-results/score-breakdown-full-flow.png' });

  // Schließen via Außenklick
  await page.locator('#cardGrid').click({ position: { x: 5, y: 5 } }).catch(() => {});
  await expect(pop).toBeHidden({ timeout: 3000 });
});

// ── 07. Anfrage senden ────────────────────────────────────────────────────────

test('07 Anfrage senden: kompletter Outreach-Flow via Karten-Modal', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  // Erste Karte öffnen
  const firstCard = page.locator('.startup-card').first();
  const cardName = await firstCard.locator('.card-name').textContent();
  const desc = firstCard.locator('.desc');
  if (await desc.count() > 0) await desc.click();
  else await firstCard.locator('.card-name').click();

  await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });
  await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });

  const anfrageBtn = page.locator('#dvAnfrageBtn');
  await expect(anfrageBtn).toBeVisible();

  const btnText = await anfrageBtn.textContent();
  if (btnText.includes('Angefragt')) {
    // Bereits angefragt — nächste Karte versuchen
    await page.click('#dvNextBtn');
    await page.waitForTimeout(500);
    const nextBtnText = await anfrageBtn.textContent();
    if (nextBtnText.includes('Angefragt')) {
      await page.keyboard.press('Escape');
      test.skip(true, 'Alle Startups bereits angefragt');
      return;
    }
  }

  await anfrageBtn.click();
  await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });

  // Betreff und Nachricht müssen vorausgefüllt sein
  const subject = await page.locator('#otSendSubject').inputValue();
  expect(subject.trim().length).toBeGreaterThan(5);
  const body = await page.locator('#otSendBody').inputValue();
  expect(body.trim().length).toBeGreaterThan(20);

  // Bearbeiter setzen und absenden
  await page.locator('#otSendBearbeiter').fill('APEX Analyst');
  await page.waitForTimeout(200);
  await page.click('#otSendConfirmBtn');
  await page.waitForTimeout(800);

  await expect(page.locator('#otSendBackdrop')).toBeHidden({ timeout: 3000 });
  await expect(page.locator('.toast, [class*="toast"]').first()).toBeVisible({ timeout: 3000 });
});

// ── 08. Anfragen-View ─────────────────────────────────────────────────────────

test('08 Anfragen-View: Inbox zeigt Einträge nach Anfrage', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  // Anfrage erzeugen (frische Session)
  const firstCard = page.locator('.startup-card').first();
  const desc = firstCard.locator('.desc');
  if (await desc.count() > 0) await desc.click();
  else await firstCard.locator('.card-name').click();

  await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });
  await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });

  const anfrageBtn = page.locator('#dvAnfrageBtn');
  const btnText = await anfrageBtn.textContent();
  if (!btnText.includes('Angefragt')) {
    await anfrageBtn.click();
    await expect(page.locator('#otSendBackdrop')).toBeVisible({ timeout: 5000 });
    await page.locator('#otSendBearbeiter').fill('APEX Analyst');
    await page.click('#otSendConfirmBtn');
    await expect(page.locator('#otSendBackdrop')).toBeHidden({ timeout: 3000 });
  } else {
    await page.keyboard.press('Escape');
  }

  await page.click('#topTabInbox');
  await page.waitForTimeout(1000);
  await expect(page.locator('#viewInbox')).toBeVisible();

  const inboxHtml = await page.locator('#viewInbox').innerHTML();
  expect(inboxHtml.trim().length).toBeGreaterThan(50);
});

// ── 09. Pipeline ──────────────────────────────────────────────────────────────

test('09 Pipeline: Startup hinzufügen und View aufrufen', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  const firstCard = page.locator('.startup-card').first();
  const pipeBtn = firstCard.locator('button[data-action="addpipeline"]');
  await expect(pipeBtn).toBeVisible({ timeout: 5000 });
  if (!await pipeBtn.isDisabled()) {
    await pipeBtn.click();
    await page.waitForTimeout(500);
  }

  await page.click('#topTabPipeline');
  await page.waitForTimeout(1500);

  const pipelineView = page.locator('#viewPipeline, #pipelineMount, .pipeline-board, .pipeline-column');
  await expect(pipelineView.first()).toBeVisible({ timeout: 8000 });

  const pipelineContent = await page.locator('#viewPipeline, #pipelineMount').first().innerHTML();
  expect(pipelineContent.trim().length).toBeGreaterThan(50);
});

test('09b Pipeline: Pipeline-Button im Detail-Modal sichtbar', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  const firstCard = page.locator('.startup-card').first();
  const desc = firstCard.locator('.desc');
  if (await desc.count() > 0) await desc.click();
  else await firstCard.locator('.card-name').click();

  await expect(page.locator('#modalBackdrop')).toBeVisible({ timeout: 5000 });
  await expect(page.locator('#modalBackdrop .modal')).not.toBeEmpty({ timeout: 8000 });

  const pipeBtnModal = page.locator('#dvPipeBtn');
  await expect(pipeBtnModal).toBeVisible();
  const pipeBtnText = await pipeBtnModal.textContent();
  expect(pipeBtnText.trim().length).toBeGreaterThan(0);

  await page.keyboard.press('Escape');
  await expect(page.locator('#modalBackdrop')).toBeHidden({ timeout: 3000 });
});

// ── 10. Compare ───────────────────────────────────────────────────────────────

test('10 Compare: 2 Startups vergleichen', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  const cards = page.locator('.startup-card');
  await expect(cards.first()).toBeVisible({ timeout: 8000 });
  const cardCount = await cards.count();
  if (cardCount < 2) {
    test.skip(true, 'Weniger als 2 Karten — Compare braucht mindestens 2');
    return;
  }

  // 2 Karten zum Compare hinzufügen
  for (let i = 0; i < Math.min(2, cardCount); i++) {
    const compareBtn = cards.nth(i).locator('button[data-action="compare"]');
    if (await compareBtn.count() > 0) {
      await compareBtn.click();
      await page.waitForTimeout(300);
    }
  }

  await page.click('#topTabCompare');
  await page.waitForTimeout(1500);

  const compareBody = page.locator('#compareBody, #viewCompare');
  await expect(compareBody.first()).toBeVisible({ timeout: 8000 });

  const compareContent = await compareBody.first().innerHTML();
  expect(compareContent.trim().length).toBeGreaterThan(100);

  // Export-Button vorhanden
  const exportBtn = page.locator('#compareExportBtn');
  if (await exportBtn.count() > 0) {
    await expect(exportBtn).toBeVisible();
  }
});

// ── 11. Activity ──────────────────────────────────────────────────────────────

test('11 Activity: Log hat Einträge nach Pipeline/Outreach-Aktionen', async ({ page }) => {
  await goHome(page);
  await ensureCardsVisible(page);

  // Pipeline-Aktion erzeugen
  const firstCard = page.locator('.startup-card').first();
  const pipeBtn = firstCard.locator('button[data-action="addpipeline"]');
  if (await pipeBtn.count() > 0 && !await pipeBtn.isDisabled()) {
    await pipeBtn.click();
    await page.waitForTimeout(500);
  }

  await page.click('#topTabActivity');
  await page.waitForTimeout(1500);

  const activityView = page.locator('#viewActivity, #activityMount, .activity-list');
  await expect(activityView.first()).toBeVisible({ timeout: 8000 });

  const activityHtml = await activityView.first().innerHTML();
  expect(activityHtml.trim().length).toBeGreaterThan(50);
});

// ── 12. Alle Views erreichbar ─────────────────────────────────────────────────

test('12 Alle Views per Navigation erreichbar', async ({ page }) => {
  await goHome(page);

  const tabs = [
    { selector: '#topTabDashboard', view: '#viewDashboard, .dbv2-kpi-row, .dashboard' },
    { selector: '#topTabHome',       view: '.startup-card, .empty-state, #cardGrid' },
    { selector: '#topTabSubmissions',view: '#submissionsMount' },
    { selector: '#topTabPipeline',   view: '#viewPipeline, #pipelineMount, .pipeline-board' },
    { selector: '#topTabCompare',    view: '#viewCompare, #compareBody' },
    { selector: '#topTabActivity',   view: '#viewActivity, #activityMount' },
    { selector: '#topTabInbox',      view: '#viewInbox' },
  ];

  for (const { selector, view } of tabs) {
    const tabEl = page.locator(selector);
    if (await tabEl.count() === 0) continue;
    await tabEl.click();
    await page.waitForTimeout(1000);
    const viewEl = page.locator(view);
    await expect(viewEl.first()).toBeVisible({ timeout: 8000 });
  }
});
