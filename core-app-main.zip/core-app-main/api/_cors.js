// CORS-Allowlist für alle /api/*-Endpoints (Audit C3/P0.2).
// ALLOWED_ORIGINS = kommaseparierte Liste erlaubter Origins, z.B.
//   ALLOWED_ORIGINS=https://core-app.vercel.app,https://core.example.com
// Solange die ENV-Variable NICHT gesetzt ist, bleibt das bisherige offene
// Verhalten erhalten (Launch-Checkliste: vor Go-Live in Vercel setzen!).
//
// Rückgabe false = Response wurde bereits beendet (Preflight oder 403),
// der Handler muss sofort returnen.
export function applyCors(req, res) {
  const allowed = (process.env.ALLOWED_ORIGINS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const origin = req.headers.origin;

  res.setHeader('Vary', 'Origin');

  if (origin) {
    if (allowed.length === 0 || allowed.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
    } else {
      res.status(403).json({ error: 'Origin not allowed' });
      return false;
    }
  }
  // Requests ohne Origin-Header (curl, Server-zu-Server) unterliegen nicht
  // CORS — dagegen schützt das IP-Rate-Limiting in submit.js.

  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return false;
  }
  return true;
}
