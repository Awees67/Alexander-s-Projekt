import { createHmac } from 'node:crypto';
import { applyCors } from './_cors.js';

function computePlausibility(s) {
  const rules = [
    {
      id: 'mrr_arr_consistency',
      label: 'MRR/ARR Konsistenz',
      kategorie: 'Konsistenz',
      schwere: 'hard',
      check: (s) => Math.abs((s.arr_eur || 0) - ((s.mrr_eur || 0) * 12)) < 1000,
      fail_text: 'ARR weicht von MRR × 12 ab',
      pass_text: 'ARR konsistent mit MRR'
    },
    {
      id: 'burn_vs_mrr',
      label: 'Burn/MRR Verhältnis',
      kategorie: 'Konsistenz',
      schwere: 'soft',
      check: (s) => s.burn_eur_per_month > 0 && s.burn_eur_per_month < (s.mrr_eur * 10),
      fail_text: 'Burn unrealistisch hoch im Verhältnis zum MRR (>10x)',
      pass_text: 'Burn/MRR Verhältnis plausibel'
    },
    {
      id: 'runway_consistency',
      label: 'Runway Plausibilität',
      kategorie: 'Konsistenz',
      schwere: 'hard',
      check: (s) => s.runway_months >= 2 && s.runway_months <= 48,
      fail_text: 'Runway außerhalb plausibler Spanne (2–48 Monate)',
      pass_text: 'Runway im plausiblen Bereich'
    },
    {
      id: 'growth_plausibility',
      label: 'Wachstum realistisch',
      kategorie: 'Konsistenz',
      schwere: 'soft',
      check: (s) => s.growth_pct >= -50 && s.growth_pct <= 200,
      fail_text: 'Wachstumsrate außerhalb plausibler Spanne (-50% bis 200%)',
      pass_text: 'Wachstumsrate im plausiblen Bereich'
    },
    {
      id: 'mrr_positive',
      label: 'MRR vorhanden',
      kategorie: 'Vollständigkeit',
      schwere: 'hard',
      check: (s) => s.mrr_eur > 0,
      fail_text: 'Kein MRR angegeben oder 0€',
      pass_text: 'MRR vorhanden'
    },
    {
      id: 'ownership_total',
      label: 'Ownership-Summe',
      kategorie: 'Konsistenz',
      schwere: 'hard',
      check: (s) => ((s.founder_pct || 0) + (s.investor_pct || 0) + (s.employees_pct || 0)) <= 100.5,
      fail_text: 'Ownership-Anteile summieren sich auf über 100%',
      pass_text: 'Ownership-Summe plausibel'
    },
    {
      id: 'founded_year_range',
      label: 'Gründungsjahr',
      kategorie: 'Konsistenz',
      schwere: 'soft',
      check: (s) => s.founded_year == null || (s.founded_year >= 1990 && s.founded_year <= new Date().getFullYear()),
      fail_text: 'Gründungsjahr außerhalb plausibler Spanne',
      pass_text: 'Gründungsjahr plausibel'
    },
    {
      id: 'ltv_cac_positive',
      label: 'LTV/CAC vorhanden',
      kategorie: 'Vollständigkeit',
      schwere: 'soft',
      check: (s) => s.ltv_cac_ratio > 0 && s.cac_eur > 0,
      fail_text: 'LTV oder CAC fehlt',
      pass_text: 'Unit Economics angegeben'
    },
    {
      id: 'gross_margin_range',
      label: 'Gross Margin Spanne',
      kategorie: 'Konsistenz',
      schwere: 'soft',
      check: (s) => s.gross_margin_pct >= 0 && s.gross_margin_pct <= 99,
      fail_text: 'Gross Margin außerhalb plausibler Spanne (0–99%)',
      pass_text: 'Gross Margin plausibel'
    },
    {
      id: 'ticket_range',
      label: 'Rundengröße plausibel',
      kategorie: 'Konsistenz',
      schwere: 'soft',
      check: (s) => {
        const ranges = {
          'Pre-Seed':    [50000, 2000000],
          'Seed':        [200000, 5000000],
          'Pre-Series A':[500000, 8000000],
          'Series A':    [1000000, 15000000],
          'Series B':    [3000000, 50000000]
        };
        const r = ranges[s.stage];
        if (!r) return true;
        return s.ticket_eur >= r[0] && s.ticket_eur <= r[1];
      },
      fail_text: 'Rundengröße ungewöhnlich für die angegebene Stage',
      pass_text: 'Rundengröße passt zur Stage'
    },
    {
      id: 'team_size_range',
      label: 'Teamgröße plausibel',
      kategorie: 'Vollständigkeit',
      schwere: 'soft',
      check: (s) => s.team_size >= 1 && s.team_size <= 500,
      fail_text: 'Teamgröße außerhalb plausibler Spanne',
      pass_text: 'Teamgröße plausibel'
    },
    {
      id: 'founders_present',
      label: 'Founder angegeben',
      kategorie: 'Vollständigkeit',
      schwere: 'hard',
      check: (s) => Array.isArray(s.founders) && s.founders.length >= 1,
      fail_text: 'Keine Founder-Informationen angegeben',
      pass_text: 'Founder-Team dokumentiert'
    }
  ];

  const checks = rules.map(rule => {
    let passed;
    try { passed = !!rule.check(s); } catch(e) { passed = false; }
    return {
      id: rule.id,
      label: rule.label,
      kategorie: rule.kategorie,
      schwere: rule.schwere,
      result: passed ? 'pass' : 'fail',
      message: passed ? rule.pass_text : rule.fail_text
    };
  });

  const failed_hard = checks.filter(c => c.result === 'fail' && c.schwere === 'hard').length;
  const failed_soft = checks.filter(c => c.result === 'fail' && c.schwere === 'soft').length;
  const passed_count = checks.filter(c => c.result === 'pass').length;

  let status;
  if (failed_hard > 0) status = 'failed';
  else if (failed_soft > 0) status = 'flagged';
  else status = 'passed';

  return {
    status,
    checks,
    summary: {
      total: checks.length,
      passed: passed_count,
      failed_hard,
      failed_soft
    }
  };
}

// ---- Server-seitige Input-Validierung (Audit P0.3) ----
// Whitelist in BODY_FIELDS verhindert fremde Spalten; hier zusätzlich:
// Größen-, Längen-, Typ- und Bereichs-Checks, damit weder Riesen-Payloads
// noch falsche Typen die DB erreichen (falsche Typen lösten vorher einen
// PostgREST-Fehler für die ganze Submission aus).
const STR_LIMITS = {
  company_name: 120, contact_name: 120, contact_email: 320, origin_country: 60,
  stage: 40, sector: 80, sub_sector: 80, growth_type: 10,
  description: 4000, problem_solution: 4000, traction_note: 2000, team_note: 2000,
  pitch_deck_url: 2048,
};
const NUM_LIMITS = {
  team_size: [1, 100000], founded_year: [1900, 2100], mrr_eur: [0, 1e12],
  burn_eur_per_month: [0, 1e12], runway_months: [0, 600], growth_pct: [-100, 100000],
  paying_customers: [0, 1e8], net_new_mrr_eur: [-1e12, 1e12], net_new_arr_eur: [-1e13, 1e13],
  nrr_pct: [0, 1000], gross_margin_pct: [-100, 100], cac_eur: [0, 1e9],
  logo_churn_pct: [0, 100], revenue_churn_pct: [0, 100], tam_eur: [0, 1e15],
  sam_eur: [0, 1e15], ticket_eur: [0, 1e12], valuation_eur: [0, 1e15],
  total_raised_eur: [0, 1e13], investor_count: [0, 100000],
  founder_pct: [0, 100], investor_pct: [0, 100], employees_pct: [0, 100], esop_pct: [0, 100],
};
const FOUNDER_STR_LIMITS = { name: 120, role: 60, linkedin_url: 300, education: 200, exit_detail: 300 };

function validateBody(body) {
  const fail = (field, msg) => `${msg} (Feld: ${field})`;
  if (!body || typeof body !== 'object' || Array.isArray(body)) return 'Ungültiger Request-Body.';
  if (JSON.stringify(body).length > 60000) return 'Anfrage zu groß.';

  for (const [k, max] of Object.entries(STR_LIMITS)) {
    const v = body[k];
    if (v == null) continue;
    if (typeof v !== 'string') return fail(k, 'Muss Text sein');
    if (v.length > max) return fail(k, `Text zu lang (max. ${max} Zeichen)`);
  }
  // Wird in der App als klickbarer Link gerendert — javascript:-URLs blocken
  if (body.pitch_deck_url != null && !/^https?:\/\//i.test(body.pitch_deck_url)) {
    return fail('pitch_deck_url', 'Link muss mit http:// oder https:// beginnen');
  }

  for (const [k, range] of Object.entries(NUM_LIMITS)) {
    const v = body[k];
    if (v == null) continue;
    if (typeof v !== 'number' || !Number.isFinite(v)) return fail(k, 'Muss eine Zahl sein');
    if (v < range[0] || v > range[1]) return fail(k, `Wert außerhalb des erlaubten Bereichs (${range[0]} bis ${range[1]})`);
  }

  if (body.market_served != null) {
    if (!Array.isArray(body.market_served) || body.market_served.length > 20
      || body.market_served.some((m) => typeof m !== 'string' || m.length > 60)) {
      return fail('market_served', 'Ungültige Zielmarkt-Liste');
    }
  }

  if (body.privacy_accepted != null && typeof body.privacy_accepted !== 'boolean') {
    return fail('privacy_accepted', 'Ungültiger Wert');
  }

  if (body.founders != null) {
    if (!Array.isArray(body.founders) || body.founders.length > 10) {
      return fail('founders', 'Maximal 10 Founder erlaubt');
    }
    const strArr = (a, maxItems, maxLen) => Array.isArray(a) && a.length <= maxItems
      && a.every((x) => typeof x === 'string' && x.length <= maxLen);
    for (const f of body.founders) {
      if (!f || typeof f !== 'object' || Array.isArray(f)) return fail('founders', 'Ungültiger Founder-Eintrag');
      for (const [k, max] of Object.entries(FOUNDER_STR_LIMITS)) {
        if (f[k] != null && (typeof f[k] !== 'string' || f[k].length > max)) {
          return fail(`founders.${k}`, 'Ungültig oder zu lang');
        }
      }
      if (f.prev_companies != null && !strArr(f.prev_companies, 20, 120)) return fail('founders.prev_companies', 'Ungültige Liste');
      if (f.prev_roles != null && !strArr(f.prev_roles, 20, 120)) return fail('founders.prev_roles', 'Ungültige Liste');
      if (f.strengths != null && !strArr(f.strengths, 20, 60)) return fail('founders.strengths', 'Ungültige Liste');
      if (f.years_experience != null && (typeof f.years_experience !== 'number'
        || !Number.isFinite(f.years_experience) || f.years_experience < 0 || f.years_experience > 80)) {
        return fail('founders.years_experience', 'Ungültige Zahl');
      }
      if (f.had_exit != null && typeof f.had_exit !== 'boolean') return fail('founders.had_exit', 'Ungültiger Wert');
    }
  }
  return null;
}

export default async function handler(req, res) {
  if (!applyCors(req, res)) return;

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return res.status(500).json({ error: 'Server misconfigured' });
  }

  const headers = {
    apikey: SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
    'Content-Type': 'application/json',
  };

  const body = req.body;

  // Validierung VOR dem Rate-Limiting: Müll-Requests werden abgewiesen,
  // ohne dass dafür DB-Queries anfallen.
  const validationError = validateBody(body);
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  // Pflichtfelder — contact_email ist required für Rate Limiting und DB
  const contactEmail = body?.contact_email;
  if (!contactEmail || typeof contactEmail !== 'string' || !contactEmail.includes('@')) {
    return res.status(400).json({ error: 'E-Mail-Adresse fehlt oder ist ungültig.' });
  }

  // Kenntnisnahme der Datenschutzerklärung ist Pflicht (Formular-Checkbox).
  // Der Zeitpunkt wird unten serverseitig gesetzt — Nachweis nach Art. 5 Abs. 2 DSGVO.
  if (body?.privacy_accepted !== true) {
    return res.status(400).json({ error: 'Bitte stimme der Verarbeitung deiner Daten gemäß Datenschutzerklärung zu.' });
  }

  // 1. Rate Limiting — max 3 Submissions pro E-Mail in 24h
  const since = new Date(Date.now() - 86400000).toISOString();
  const rlRes = await fetch(
    `${SUPABASE_URL}/rest/v1/submissions?contact_email=eq.${encodeURIComponent(contactEmail)}&submitted_at=gte.${since}&select=id`,
    { headers }
  );
  const rlData = await rlRes.json();
  if (Array.isArray(rlData) && rlData.length >= 3) {
    return res.status(429).json({ error: 'Zu viele Einreichungen von dieser E-Mail-Adresse. Bitte warte 24 Stunden.' });
  }

  // 1b. IP-Rate-Limiting — das E-Mail-Limit allein ist mit Wegwerf-Adressen
  // bypassbar (Audit H1). Die IP wird nie roh gespeichert, nur als
  // HMAC-SHA256 mit IP_HASH_SALT (DSGVO-Pseudonymisierung). Ohne gesetzten
  // Salt wird der Check übersprungen statt Roh-IPs zu persistieren.
  // Limit bewusst höher als das E-Mail-Limit: Co-Working/NAT teilt sich IPs.
  const { IP_HASH_SALT } = process.env;
  let ip_hash = null;
  if (IP_HASH_SALT) {
    const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()
      || req.socket?.remoteAddress || '';
    if (ip) {
      ip_hash = createHmac('sha256', IP_HASH_SALT).update(ip).digest('hex');
      const ipRes = await fetch(
        `${SUPABASE_URL}/rest/v1/submissions?ip_hash=eq.${ip_hash}&submitted_at=gte.${since}&select=id`,
        { headers }
      );
      const ipData = await ipRes.json();
      if (Array.isArray(ipData) && ipData.length >= 10) {
        return res.status(429).json({ error: 'Zu viele Einreichungen von dieser IP-Adresse. Bitte warte 24 Stunden.' });
      }
    }
  }

  // 2. fund_id serverseitig aus URL-Parameter ableiten
  const fundSlug = req.query.fund;
  if (!fundSlug) {
    return res.status(400).json({ error: 'Fund-Parameter fehlt. URL muss ?fund=<slug> enthalten.' });
  }
  const fundRes = await fetch(
    `${SUPABASE_URL}/rest/v1/funds?slug=eq.${encodeURIComponent(fundSlug)}&select=id`,
    { headers }
  );
  const fundData = await fundRes.json();
  if (!fundRes.ok || !Array.isArray(fundData) || fundData.length === 0) {
    return res.status(404).json({ error: 'Fonds nicht gefunden. Bitte prüfe den Link.' });
  }
  const fund_id = fundData[0].id;

  // 3. anon_id serverseitig generieren. Eindeutigkeit erzwingt der
  // Unique-Index (fund_id, anon_id) beim Insert (Retry unten, Audit P1.4) —
  // ein Vorab-SELECT wäre ein Check-then-Insert-Race bei parallelen Requests.
  function generateAnonId() {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const letter = letters[Math.floor(Math.random() * letters.length)];
    const num = Math.floor(1000 + Math.random() * 9000);
    return letter + '-' + num;
  }

  // Server-side derived fields — always overrides any client-supplied values
  const mrr   = body.mrr_eur           || null;
  const cac   = body.cac_eur           || null;
  const burn  = body.burn_eur_per_month || null;
  // Net New MRR (monatlich, Doku §13). Fallback: alte Clients senden noch net_new_arr_eur (jaehrlich).
  const netNewMrr = body.net_new_mrr_eur || (body.net_new_arr_eur ? body.net_new_arr_eur / 12 : null);

  const arr_eur          = mrr ? mrr * 12 : null;
  const paying_customers = body.paying_customers || null;
  const arpa_eur         = (mrr && paying_customers && paying_customers > 0) ? parseFloat((mrr / paying_customers).toFixed(2)) : null;
  const acv_eur          = arpa_eur ? parseFloat((arpa_eur * 12).toFixed(2)) : null;
  const gross_margin_pct = body.gross_margin_pct || null;
  const revenue_churn_pct = body.revenue_churn_pct || null;
  const ltv_eur          = (arpa_eur && gross_margin_pct && revenue_churn_pct && revenue_churn_pct > 0)
    ? parseFloat((arpa_eur * (gross_margin_pct / 100) / (revenue_churn_pct / 100)).toFixed(2))
    : null;
  const cac_payback_months = (cac && arpa_eur && arpa_eur > 0)
    ? parseFloat((cac / arpa_eur).toFixed(1))
    : null;
  const ltv_cac_ratio    = (cac && ltv_eur && cac > 0) ? parseFloat((ltv_eur / cac).toFixed(2)) : null;
  const burn_multiple = (burn && netNewMrr && netNewMrr > 0)
    ? parseFloat((burn / netNewMrr).toFixed(2))
    : null;
  const notes = [body.description, body.problem_solution, body.traction_note]
    .filter(Boolean).join(' ') || null;

  // Founder-Ableitungen — Strings werden case-insensitive verglichen
  const foundersArr = Array.isArray(body.founders) ? body.founders : [];
  const hasStrength = (tag) => foundersArr.some(f =>
    Array.isArray(f.strengths) && f.strengths.some(s => String(s).toLowerCase() === tag.toLowerCase())
  );
  const founder_count = foundersArr.length;
  const has_repeat_founder = hasStrength('Repeat Founder');
  const has_prior_exit = foundersArr.some(f => f.had_exit === true);
  const has_technical_founder = hasStrength('Technical');
  const has_domain_expert = hasStrength('Domain Expert');

  // Re-compute plausibility server-side — overrides any client-supplied values
  const plaus = computePlausibility({ ...body, arr_eur, ltv_cac_ratio });

  // Whitelist statt Body-Spread: Clients dürfen weder serverseitige Spalten
  // setzen (id, submitted_at, status, ip_hash, ...) noch mit unbekannten Keys
  // einen PostgREST-400 für die ganze Submission auslösen.
  const BODY_FIELDS = [
    'company_name', 'contact_name', 'contact_email', 'pitch_deck_url', 'description',
    'problem_solution', 'traction_note', 'origin_country', 'market_served', 'stage',
    'sector', 'sub_sector', 'team_size', 'founded_year', 'mrr_eur', 'burn_eur_per_month',
    'runway_months', 'growth_pct', 'growth_type', 'paying_customers', 'net_new_mrr_eur',
    'nrr_pct', 'gross_margin_pct', 'cac_eur', 'logo_churn_pct', 'revenue_churn_pct',
    'tam_eur', 'sam_eur', 'ticket_eur', 'valuation_eur', 'total_raised_eur',
    'investor_count', 'founder_pct', 'investor_pct', 'employees_pct', 'founders', 'team_note',
    // Altclients — Fallback-Verarbeitung oben (net_new_arr_eur → /12)
    'net_new_arr_eur', 'esop_pct',
  ];
  const picked = {};
  for (const k of BODY_FIELDS) if (body[k] !== undefined) picked[k] = body[k];

  const insertData = {
    ...picked,
    fund_id,           // serverseitig aus slug abgeleitet
    ip_hash,           // serverseitig gehasht (null wenn IP_HASH_SALT fehlt)
    status: 'pending', // immer hardcoded — client darf status nicht setzen
    privacy_accepted_at: new Date().toISOString(), // serverseitig — Pflicht-Check oben

    arr_eur,
    net_new_mrr_eur: netNewMrr,
    paying_customers,
    arpa_eur,
    acv_eur,
    ltv_eur,
    cac_payback_months,
    ltv_cac_ratio,
    burn_multiple,
    notes,
    founder_count,
    has_repeat_founder,
    has_prior_exit,
    has_technical_founder,
    has_domain_expert,
    plausibility_status: plaus.status,
    plausibility_checks: plaus.checks,
    plausibility_summary: plaus.summary,
  };

  // Insert mit Kollisions-Retry (Audit P1.4): Bei exakt gleichzeitig
  // gewürfelter anon_id schlägt der Unique-Index zu (409) — dann wird mit
  // frischer ID erneut eingefügt statt dem Bewerber einen Fehler zu zeigen.
  for (let attempt = 0; attempt < 5; attempt++) {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/submissions`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_SERVICE_ROLE_KEY,
        Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        'Content-Type': 'application/json',
        Prefer: 'return=minimal',
      },
      body: JSON.stringify({ ...insertData, anon_id: generateAnonId() }),
    });

    if (response.ok) {
      return res.status(200).json({ success: true });
    }

    // Rohe PostgREST-Fehler verraten Tabellen-/Constraint-Namen — nur ins
    // Vercel-Log, nie an den Client (Audit P0.2).
    const err = await response.text();
    if (response.status === 409 && err.includes('submissions_fund_anon_unique')) {
      continue; // anon_id-Kollision — neu würfeln
    }
    console.error('[submit] Supabase-Insert fehlgeschlagen:', response.status, err);
    return res.status(500).json({ error: 'Einreichung fehlgeschlagen. Bitte versuche es in ein paar Minuten erneut.' });
  }

  console.error('[submit] anon_id: 5 Kollisionen in Folge — ID-Raum (26×9000 pro Fund) prüfen');
  return res.status(500).json({ error: 'Einreichung fehlgeschlagen. Bitte versuche es in ein paar Minuten erneut.' });
}

/*
  SQL — run once in Supabase SQL editor if columns are missing:

  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS description text;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS notes text;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS problem_solution text;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS traction_note text;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS sub_sector text;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS market_served jsonb;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS net_new_arr_eur numeric;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS net_new_mrr_eur numeric;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS founded_year int;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS revenue_churn_pct numeric;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS employees_pct numeric;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS investor_pct numeric;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS burn_multiple numeric;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS ltv_cac_ratio numeric;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS arr_eur numeric;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS founders jsonb;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS founder_count int;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS has_repeat_founder boolean;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS has_prior_exit boolean;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS has_technical_founder boolean;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS has_domain_expert boolean;
  ALTER TABLE submissions ADD COLUMN IF NOT EXISTS team_note text;
*/
