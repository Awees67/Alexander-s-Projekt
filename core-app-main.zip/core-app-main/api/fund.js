import { applyCors } from './_cors.js';

export default async function handler(req, res) {
  if (!applyCors(req, res)) return;

  const { slug } = req.query;
  if (!slug) {
    return res.status(400).json({ error: 'Missing fund slug' });
  }

  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return res.status(500).json({ error: 'Server misconfigured' });
  }

  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/funds?slug=eq.${encodeURIComponent(slug)}&select=id,name,slug`,
    {
      headers: {
        apikey: SUPABASE_SERVICE_ROLE_KEY,
        Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      },
    }
  );

  const data = await response.json();

  if (!response.ok) {
    // Rohe PostgREST-Fehler nur ins Vercel-Log, nie an den Client (Audit P0.2).
    console.error('[fund] Supabase-Lookup fehlgeschlagen:', response.status, JSON.stringify(data));
    return res.status(500).json({ error: 'Fund lookup failed' });
  }

  if (!data || data.length === 0) {
    return res.status(404).json({ error: 'Fund not found' });
  }

  return res.status(200).json(data[0]);
}
